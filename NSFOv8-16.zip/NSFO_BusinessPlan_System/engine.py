"""Streaming XLSX-to-SQLite NSFO business-plan forecast engine.

Runtime dependencies: Python 3.11+, openpyxl (already installed on the bank terminal).
No Flask, Streamlit, pandas or external database service is required.
"""
from __future__ import annotations
import os, json, sqlite3, re, datetime as dt, time, math, shutil
from pathlib import Path
from collections import defaultdict
from contextlib import contextmanager
from openpyxl import load_workbook
from risk import Criteria, MethodologyError, classify, currency, flag, rate_percent, gr_value, micro_flag, is_black_zone, side_for_operation, match_key, compute_factors, FACTOR_NAMES, FACTOR_GROUPS, is_new_contract, canonical_security

ROOT=Path(__file__).resolve().parent
DATA=ROOT/'storage'; DATA.mkdir(exist_ok=True)
DB=DATA/'nsfo.sqlite3'
PERIOD_REGEX=re.compile(r'(?:Факт на|Прогноз на|Задолженность_)\s*(\d{2}\.\d{2}\.\d{4})',re.I)

@contextmanager
def connect():
    con=sqlite3.connect(str(DB),timeout=90)
    con.row_factory=sqlite3.Row
    con.execute('PRAGMA foreign_keys=ON')
    con.execute('PRAGMA busy_timeout=90000')
    try:yield con;con.commit()
    except:con.rollback();raise
    finally:con.close()


def initialize():
    with connect() as db:
        db.executescript('''
        PRAGMA journal_mode=WAL;
        PRAGMA synchronous=NORMAL;
        CREATE TABLE IF NOT EXISTS projects(id INTEGER PRIMARY KEY, name TEXT NOT NULL, created TEXT NOT NULL,
            fact_date TEXT, periods TEXT DEFAULT '[]', status TEXT DEFAULT 'draft', version INTEGER DEFAULT 0, note TEXT DEFAULT '');
        CREATE TABLE IF NOT EXISTS uploads(project_id INTEGER,kind TEXT,original_name TEXT,path TEXT,uploaded TEXT,
            PRIMARY KEY(project_id,kind));
        CREATE TABLE IF NOT EXISTS fx(project_id INTEGER,period TEXT,currency TEXT,rate REAL,
            PRIMARY KEY(project_id,period,currency));
        CREATE TABLE IF NOT EXISTS fact_contracts(project_id INTEGER,match_key TEXT,unp TEXT,contract TEXT,ccy TEXT,side TEXT,
            operation TEXT,client TEXT,crm TEXT,rd TEXT,upper_contract TEXT,security TEXT,restra TEXT,
            ni INTEGER,pfn INTEGER,nvv INTEGER,zone TEXT,micro TEXT,gr TEXT,rate REAL,
            debt REAL,reserve REAL,fx REAL,row_count INTEGER DEFAULT 1,issues TEXT DEFAULT '[]',
            PRIMARY KEY(project_id,match_key));
        CREATE TABLE IF NOT EXISTS fact_clients(project_id INTEGER,unp TEXT,ni INTEGER,pfn INTEGER,nvv INTEGER,
            zone TEXT,client TEXT,crm TEXT,PRIMARY KEY(project_id,unp));
        CREATE TABLE IF NOT EXISTS positions(id INTEGER PRIMARY KEY,project_id INTEGER NOT NULL,match_key TEXT,src TEXT,
            unp TEXT,contract TEXT,parent_contract TEXT,ccy TEXT,side TEXT,operation TEXT,client TEXT,crm TEXT,rd TEXT,
            product TEXT,micro INTEGER,poc INTEGER,zone TEXT,security TEXT,restra TEXT,
            ni INTEGER,pfn INTEGER,nvv INTEGER,poc_rate REAL,segment26 TEXT,segment27 TEXT,
            start_date TEXT,end_date TEXT,limit_date TEXT,spok TEXT,sector TEXT,km TEXT,
            comment TEXT DEFAULT '', comment_manual INTEGER DEFAULT 0, source_row INTEGER DEFAULT 0,
            classification_error TEXT DEFAULT '', added_at TEXT DEFAULT '');
        CREATE INDEX IF NOT EXISTS positions_project_key ON positions(project_id,match_key);
        CREATE INDEX IF NOT EXISTS positions_unp ON positions(project_id,unp);
        CREATE INDEX IF NOT EXISTS positions_client ON positions(project_id,client);
        CREATE TABLE IF NOT EXISTS input_risk(
            position_id INTEGER PRIMARY KEY REFERENCES positions(id) ON DELETE CASCADE,
            original_gr TEXT,original_rate TEXT,gr TEXT,rate REAL,
            token TEXT NOT NULL DEFAULT (hex(randomblob(16))));
        CREATE TABLE IF NOT EXISTS position_periods(project_id INTEGER,position_id INTEGER,period TEXT,
            debt REAL,fx REAL,od REAL,ni INTEGER,pfn INTEGER,nvv INTEGER,restra TEXT,security TEXT,
            base_ni INTEGER,base_pfn INTEGER,base_nvv INTEGER,
            gr TEXT,method_gr TEXT,rate REAL,reserve REAL,expenses REAL DEFAULT 0,movement REAL DEFAULT 0,
            revaluation REAL DEFAULT 0,quality REAL DEFAULT 0,financial_state REAL DEFAULT 0,security_effect REAL DEFAULT 0,rounding REAL DEFAULT 0,
            factors TEXT DEFAULT '{}',events TEXT DEFAULT '[]',override_reason TEXT DEFAULT '',
            PRIMARY KEY(project_id,position_id,period));
        CREATE INDEX IF NOT EXISTS pp_project_period ON position_periods(project_id,period);
        CREATE TABLE IF NOT EXISTS missing(id INTEGER PRIMARY KEY,project_id INTEGER,match_key TEXT,
            unp TEXT,contract TEXT,client TEXT,ccy TEXT,side TEXT,operation TEXT,zone TEXT,
            amount_byn REAL,fx REAL,status TEXT,position_id INTEGER,created TEXT,added TEXT,
            UNIQUE(project_id,match_key));
        CREATE INDEX IF NOT EXISTS missing_status ON missing(project_id,status);
        CREATE TABLE IF NOT EXISTS warnings(id INTEGER PRIMARY KEY,project_id INTEGER,kind TEXT,severity TEXT,
            match_key TEXT,client TEXT,contract TEXT,message TEXT,details TEXT DEFAULT '{}');
        CREATE INDEX IF NOT EXISTS warnings_project ON warnings(project_id,kind);
        CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY,project_id INTEGER,at TEXT,action TEXT,
            position_id INTEGER,period TEXT,field TEXT,old TEXT,new TEXT,reason TEXT DEFAULT '');
        CREATE TABLE IF NOT EXISTS versions(id INTEGER PRIMARY KEY,project_id INTEGER,version INTEGER,
            created TEXT,title TEXT,backup_path TEXT);
        CREATE TABLE IF NOT EXISTS current_portfolios(
            project_id INTEGER PRIMARY KEY REFERENCES projects(id) ON DELETE CASCADE,
            token TEXT NOT NULL, asof TEXT NOT NULL, filename TEXT NOT NULL, applied TEXT);
        CREATE TABLE IF NOT EXISTS current_contracts(
            project_id INTEGER REFERENCES current_portfolios(project_id) ON DELETE CASCADE,
            match_key TEXT NOT NULL, unp TEXT, client TEXT, contract TEXT, ccy TEXT, side TEXT,
            ni INTEGER, pfn INTEGER, nvv INTEGER, restra TEXT, security TEXT, mapped_id INTEGER,
            PRIMARY KEY(project_id, match_key));
        CREATE TABLE IF NOT EXISTS comparison_plans(
            project_id INTEGER PRIMARY KEY REFERENCES projects(id) ON DELETE CASCADE,
            filename TEXT NOT NULL, uploaded TEXT NOT NULL, username TEXT NOT NULL, periods TEXT NOT NULL,
            positions INTEGER NOT NULL DEFAULT 0, legacy_fx INTEGER NOT NULL DEFAULT 0);
        CREATE TABLE IF NOT EXISTS comparison_positions(
            id INTEGER PRIMARY KEY, project_id INTEGER NOT NULL REFERENCES comparison_plans(project_id) ON DELETE CASCADE,
            row_key TEXT NOT NULL, unp TEXT NOT NULL, client TEXT NOT NULL, contract TEXT NOT NULL,
            side TEXT NOT NULL, zone TEXT NOT NULL, UNIQUE(project_id,row_key));
        CREATE TABLE IF NOT EXISTS comparison_periods(
            project_id INTEGER NOT NULL, position_id INTEGER NOT NULL REFERENCES comparison_positions(id) ON DELETE CASCADE,
            period TEXT NOT NULL, od REAL NOT NULL, reserve REAL NOT NULL, expenses REAL NOT NULL,
            movement REAL NOT NULL, financial_state REAL NOT NULL, security_effect REAL NOT NULL,
            quality REAL NOT NULL, revaluation REAL NOT NULL, rounding REAL NOT NULL, factors TEXT NOT NULL,
            events TEXT NOT NULL, PRIMARY KEY(position_id,period));
        CREATE INDEX IF NOT EXISTS comparison_period ON comparison_periods(project_id,period);
        CREATE TABLE IF NOT EXISTS plan_event_batches(
            id INTEGER PRIMARY KEY, project_id INTEGER NOT NULL, version INTEGER NOT NULL,
            original_name TEXT NOT NULL, uploaded_at TEXT NOT NULL, status TEXT NOT NULL,
            event_count INTEGER DEFAULT 0, summary TEXT DEFAULT '{}',
            UNIQUE(project_id,version));
        CREATE INDEX IF NOT EXISTS plan_batches_project ON plan_event_batches(project_id,status,version);
        CREATE TABLE IF NOT EXISTS plan_events(
            id INTEGER PRIMARY KEY, project_id INTEGER NOT NULL, batch_id INTEGER NOT NULL,
            unp TEXT NOT NULL, feature TEXT NOT NULL, action TEXT NOT NULL,
            target_value INTEGER NOT NULL, source_date TEXT NOT NULL,
            requested_date TEXT NOT NULL, applied_period TEXT,
            status TEXT NOT NULL, conflict_message TEXT DEFAULT '',
            resolution TEXT DEFAULT '', created_at TEXT NOT NULL,
            FOREIGN KEY(batch_id) REFERENCES plan_event_batches(id));
        CREATE INDEX IF NOT EXISTS plan_events_batch ON plan_events(project_id,batch_id,applied_period);
        CREATE INDEX IF NOT EXISTS plan_events_unp ON plan_events(project_id,unp,feature);
        ''')
        # Migration for projects created before the risk-group filter was added.
        # Unknown method_gr (NULL) in legacy records is not treated as an error.
        columns={row['name'] for row in db.execute('PRAGMA table_info(position_periods)')}
        if 'input_rate_text' not in {r['name'] for r in db.execute('PRAGMA table_info(fact_contracts)')}:
            db.execute('ALTER TABLE fact_contracts ADD COLUMN input_rate_text TEXT')
        if 'method_gr' not in columns:
            db.execute('ALTER TABLE position_periods ADD COLUMN method_gr TEXT')
        if 'financial_state' not in columns:
            db.execute('ALTER TABLE position_periods ADD COLUMN financial_state REAL DEFAULT 0')
            # Existing `quality` is retained as a compatibility aggregate.
            db.execute('UPDATE position_periods SET financial_state=COALESCE(quality,0)')
        if 'security_effect' not in columns:
            db.execute('ALTER TABLE position_periods ADD COLUMN security_effect REAL DEFAULT 0')
        for column in ('base_ni','base_pfn','base_nvv'):
            if column not in columns:
                db.execute(f'ALTER TABLE position_periods ADD COLUMN {column} INTEGER')
                # Legacy projects predate plan-event overlays. Their current
                # values become the recoverable source state for future imports.
                db.execute(f'UPDATE position_periods SET {column}={column[5:]} WHERE {column} IS NULL')
        db.execute('CREATE INDEX IF NOT EXISTS pp_period_gr ON position_periods(project_id,period,gr)')
        db.execute('CREATE INDEX IF NOT EXISTS warnings_project_key_kind ON warnings(project_id,match_key,kind)')


def now():return dt.datetime.now().isoformat(timespec='seconds')
def js(obj):return json.dumps(obj,ensure_ascii=False,default=str,separators=(',',':'))
def val(x):
    if x is None or (isinstance(x,str) and not x.strip()):return 0.0
    if isinstance(x,(int,float)):return float(x)
    try:return float(str(x).replace(' ','').replace('\xa0','').replace(',','.'))
    except:raise MethodologyError(f'Ожидалось число, получено {x!r}')
def normalize_header(s):return ' '.join(str(s or '').strip().casefold().replace('ё','е').split())
def iso_date(x):
    if isinstance(x,(dt.date,dt.datetime)):return x.strftime('%Y-%m-%d')
    s=str(x or '').strip()
    if not s:return ''
    for fmt in ('%d.%m.%Y','%Y-%m-%d'):
        try:return dt.datetime.strptime(s,fmt).strftime('%Y-%m-%d')
        except ValueError:pass
    return s

def dd(iso):
    try:return dt.datetime.strptime(iso,'%Y-%m-%d').strftime('%d.%m.%Y')
    except:return iso


def find_sheet_header(wb, required):
    for sheet in wb.worksheets:
        for rowi,row in enumerate(sheet.iter_rows(min_row=1,max_row=12,values_only=True),start=1):
            heads={normalize_header(c):j for j,c in enumerate(row) if c is not None}
            if all(normalize_header(h) in heads for h in required):return sheet,rowi,list(row)
    raise MethodologyError('Не найдена шапка с полями: '+', '.join(required))

def get(row,heads,head,default=None):
    k=heads.get(normalize_header(head))
    return row[k] if k is not None and k<len(row) else default

def get_col(row,col):return row[col-1] if len(row)>=col else None

def warn(db,pid,kind,message,severity='warning',key='',client='',contract='',details=None):
    db.execute('INSERT INTO warnings(project_id,kind,severity,match_key,client,contract,message,details) VALUES(?,?,?,?,?,?,?,?)',
        (pid,kind,severity,key,client,contract,message,js(details or {})))



def confirm_fact_date(pid,date):
    date=iso_date(date)
    try: parsed=dt.date.fromisoformat(date)
    except ValueError:raise MethodologyError('Укажите корректную дату в формате YYYY-MM-DD')
    if parsed.day!=1:raise MethodologyError('Выверенный факт должен быть только на 1-е число месяца')
    with connect() as db:
        db.execute('UPDATE projects SET note=? WHERE id=?',(date,pid))
    return date

def create_project(name):
    with connect() as db:
        row=db.execute('INSERT INTO projects(name,created) VALUES(?,?)',(str(name).strip() or 'Бизнес-план НСФО',now()))
        pid=row.lastrowid
        (DATA/str(pid)).mkdir(exist_ok=True)
        return pid


def upload_path(pid,kind,path,original_name):
    if kind not in ('bp','fact','rates'):raise ValueError('Неизвестный тип файла')
    path=Path(path)
    with connect() as db:
        exists=db.execute('SELECT id FROM projects WHERE id=?',(pid,)).fetchone()
        if not exists:raise ValueError('Бизнес-план не найден')
        target=DATA/str(pid)/(kind+'.xlsx'); target.parent.mkdir(exist_ok=True)
        os.replace(path,target)
        # Store project-relative paths so the whole application folder can be
        # moved to another bank workstation without breaking uploaded sources.
        stored_path=str(target.relative_to(ROOT))
        db.execute('INSERT OR REPLACE INTO uploads VALUES(?,?,?,?,?)',(pid,kind,str(original_name),stored_path,now()))
    return {'kind':kind,'file':original_name,'size':target.stat().st_size}


def load_rates(db,pid,path):
    book=load_workbook(path,read_only=True,data_only=True)
    try:
        ws,headrow,head=find_sheet_header(book,['Дата','Валюта'])
        h={normalize_header(v):j for j,v in enumerate(head) if v is not None}
        idx_rate=next((j for j,v in enumerate(head) if v is not None and ('курс' in normalize_header(v))),None)
        if idx_rate is None:raise MethodologyError('В файле курсов нет столбца с курсом')
        count=0
        for row in ws.iter_rows(min_row=headrow+1,values_only=True):
            date=iso_date(get(row,h,'Дата'));ccy=currency(get(row,h,'Валюта'))
            if not date or not ccy:continue
            raw=row[idx_rate]
            if raw is None or raw=='':continue
            r=val(raw)
            if r<=0:raise MethodologyError(f'Курс {ccy} на {date} должен быть положительным')
            db.execute('INSERT OR REPLACE INTO fx VALUES(?,?,?,?)',(pid,date,ccy,r));count+=1
        return count
    finally:book.close()


def load_fact(db,pid,path):
    book=load_workbook(path,read_only=True,data_only=True)
    ws,headrow,head=find_sheet_header(book,['УНП','Номер договора','Тип операции','Код валюты'])
    h={normalize_header(v):j for j,v in enumerate(head) if v is not None}
    count=0;issues=0
    try:
        # aggregate key via SQL to keep memory bounded
        for rowno,cells in enumerate(ws.iter_rows(min_row=headrow+1),headrow+1):
            row=tuple(cell.value for cell in cells)
            unp=normalize_unp(get(row,h,'УНП'));contract=str(get(row,h,'Номер договора') or '').strip()
            if not unp or not contract:continue
            operation=str(get(row,h,'Тип операции') or '').strip()
            ccy=currency(get(row,h,'Код валюты'))
            side=side_for_operation(operation)
            k=match_key(unp,contract,ccy,side)
            client=str(get(row,h,'Клиент') or '').strip()
            ni=flag(get(row,h,'НИ'));pfn=flag(get(row,h,'ПФН'));nvv=flag(get(row,h,'НВВ'))
            raw_security=get(row,h,'Обеспеченность')
            micro=micro_flag(get(row,h,'Вид кредита'))
            try:sec=canonical_security(raw_security,micro)
            except MethodologyError as exc:raise MethodologyError(f'Факт, строка {rowno}: {exc}') from exc
            restra=str(get(row,h,'Рестра') or '').strip()
            zone=str(get(row,h,'Зона проблемности') or '').strip()
            crm=str(get(row,h,'ID CRM') or '').strip()
            debt=val(get(row,h,'Задолженность, тыс BYN'))*1000
            reserve=val(get(row,h,'Резерв факт'))*1000
            fx=val(get(row,h,'Курс'))
            if fx<=0:raise MethodologyError(f'Факт, строка {rowno}: отсутствует положительный курс {ccy}')
            gr=str(get(row,h,'ГР') or '')
            rawrate=get(row,h,'% рез')
            try: rate=rate_percent(rawrate)
            except MethodologyError:rate=None
            # Check client flags for conflicting values, rather than silently selecting one.
            previous=db.execute('SELECT ni,pfn,nvv FROM fact_clients WHERE project_id=? AND unp=?',(pid,unp)).fetchone()
            if previous and (previous['ni'],previous['pfn'],previous['nvv'])!=(ni,pfn,nvv):
                issues+=1
                warn(db,pid,'data',f'Противоречивые НИ/ПФН/НВВ по УНП {unp}, строка {rowno}', 'error', k,client,contract)
            db.execute('''INSERT INTO fact_clients VALUES(?,?,?,?,?,?,?,?)
                ON CONFLICT(project_id,unp) DO UPDATE SET zone=CASE WHEN excluded.zone LIKE '%черн%' THEN excluded.zone ELSE fact_clients.zone END''',
                (pid,unp,ni,pfn,nvv,zone,client,crm))
            prev=db.execute('SELECT security,restra,rate FROM fact_contracts WHERE project_id=? AND match_key=?',(pid,k)).fetchone()
            if prev and (str(prev['security'])!=sec or str(prev['restra'])!=restra):
                issues+=1
                warn(db,pid,'data',f'В нескольких строках одного договора различаются реструктуризация/обеспеченность: {contract}', 'error',k,client,contract)
            db.execute('''INSERT INTO fact_contracts(project_id,match_key,unp,contract,ccy,side,operation,client,crm,rd,upper_contract,security,restra,ni,pfn,nvv,zone,micro,gr,rate,debt,reserve,fx)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                ON CONFLICT(project_id,match_key) DO UPDATE SET debt=debt+excluded.debt,reserve=reserve+excluded.reserve,row_count=row_count+1''',
                (pid,k,unp,contract,ccy,side,operation,client,crm,str(get(row,h,'РД') or ''),str(get(row,h,'Номер договора верхнего уровня') or contract),sec,restra,ni,pfn,nvv,zone,'микро' if 'микро' in str(get(row,h,'Вид кредита') or '').lower() else '',gr,rate,debt,reserve,fx))
            if not prev:
                original=input_rate_cell(cells,h.get(normalize_header('% рез')))
                db.execute('UPDATE fact_contracts SET input_rate_text=? WHERE project_id=? AND match_key=?',
                           (str(original) if original is not None else '',pid,k))
            count+=1
            if count%3000==0:db.commit()
        return {'rows':count,'issues':issues}
    finally:book.close()


def actual_rate_from_bp(row,rate_cols,baseline):
    """Recover a missing/zero baseline rate from the nearest later BP date.

    Rates in the source may be fractions (0.005) or percentage points (0.5).
    Zero is not a valid reserving rate and is treated as absent here.
    """
    ordered=[(baseline,rate_cols.get(baseline))]
    ordered.extend((d,idx) for d,idx in sorted(rate_cols.items()) if d>baseline)
    for date,idx in ordered:
        if idx is None or idx>=len(row):continue
        raw=row[idx]
        if raw is None or str(raw).strip()=='':continue
        try:
            if float(str(raw).strip().replace(',','.'))==0:continue
            rate=rate_percent(raw)
        except (ValueError,TypeError,MethodologyError):
            continue
        if rate is not None:return rate,date
    return None,None


RESTORE_REASON='Восстановлены исходные ГР и ставка на дату начального факта'

def input_rate_cell(cells,index):
    if index is None or index>=len(cells):
        return None
    cell=cells[index]
    if isinstance(cell.value,(float,int)) and '%' in (cell.number_format or ''):
        return f'{cell.value*100:.12g}%'
    return cell.value


def remember_input_risk(db,position_id,raw_gr,raw_rate):
    label=str(raw_gr).strip() if raw_gr is not None else ''
    match=re.fullmatch(r'(?:ГР\s*)?([1-6])(?:[.,]0+)?(?:\s*ГР)?',label,re.I)
    group='ПОК' if label.upper()=='ПОК' else match.group(1) if match else None
    try:
        if isinstance(raw_rate,str) and raw_rate.strip().endswith('%'):
            rate=float(raw_rate.strip()[:-1].strip().replace(',','.'))
            if not .5<=rate<=100:
                rate=None
        else:
            rate=rate_percent(raw_rate)
    except ValueError:
        rate=None
    db.execute('INSERT INTO input_risk(position_id,original_gr,original_rate,gr,rate) VALUES(?,?,?,?,?)',
               (position_id,label,str(raw_rate) if raw_rate is not None else '',group,rate))


def read_bp_positions(db,pid,path):
    book=load_workbook(path,read_only=True,data_only=True)
    ws,headrow,head=find_sheet_header(book,['УНП','Номер договора','Валюта','Наименование клиента'])
    h={normalize_header(v):j for j,v in enumerate(head) if v is not None}
    dates={}
    for j,title in enumerate(head):
        t=str(title or '')
        match=re.search(r'^(?:Факт|Прогноз)\s+на\s+(\d{2}\.\d{2}\.\d{4})$',t,re.I)
        if match:
            date=iso_date(match.group(1))
            # only first fact on first of month, user supplies first-day report
            if dt.date.fromisoformat(date).day!=1:continue
            dates[date]=j
    if not dates:raise MethodologyError('Во входном БП не найдены столбцы «Факт на 01.MM.YYYY» и «Прогноз на 01.MM.YYYY»')
    periods=sorted(dates)
    baseline=periods[0]
    if 'факт' not in str(head[dates[baseline]]).casefold():raise MethodologyError('Первая дата должна быть фактической на 1 число')
    # use column AO or visible source rates only for validation and POK fallback
    rate_cols={}
    for j,title in enumerate(head):
        match=re.search(r'%\s*рез\s*на\s*(\d{2}\.\d{2}\.\d{4})',str(title or ''),re.I)
        if match:rate_cols[iso_date(match.group(1))]=j
    n=0
    try:
        # A UO row can precede its credit row, including in a different Excel block.
        pok_credit_keys = {r['match_key'] for r in db.execute(
            'SELECT match_key,operation,gr FROM fact_contracts WHERE project_id=? AND side=?',
            (pid,'баланс')) if r['operation'].strip().casefold()=='кредит' and gr_value(r['gr'])=='ПОК'}
        for row in ws.iter_rows(min_row=headrow+1,values_only=True):
            if str(get_col(row,1) or '').strip().casefold()=='кредит' and gr_value(get(row,h,'ГР'))=='ПОК':
                pok_credit_keys.add(match_key(normalize_unp(get(row,h,'УНП')),get(row,h,'Номер договора'),
                                              get(row,h,'Валюта'),'баланс'))
        for rowno,cells in enumerate(ws.iter_rows(min_row=headrow+1),headrow+1):
            row=tuple(cell.value for cell in cells)
            unp=normalize_unp(get(row,h,'УНП'));contract=str(get(row,h,'Номер договора') or '').strip()
            if not unp or not contract:continue
            operation=str(get_col(row,1) or '').strip()
            ccy=currency(get(row,h,'Валюта'))
            side=side_for_operation(operation)
            k=match_key(unp,contract,ccy,side)
            matched=db.execute('SELECT * FROM fact_contracts WHERE project_id=? AND match_key=?',(pid,k)).fetchone()
            clientdata=db.execute('SELECT * FROM fact_clients WHERE project_id=? AND unp=?',(pid,unp)).fetchone()
            client=str(matched['client'] if matched and matched['client'] else get(row,h,'Наименование клиента') or '')
            zone=str(clientdata['zone'] if clientdata and clientdata['zone'] else get(row,h,'Зона проблемности') or '')
            ni,pfn,nvv=(clientdata['ni'],clientdata['pfn'],clientdata['nvv']) if clientdata else (flag(get(row,h,'НИ')),flag(get(row,h,'ПФН')),flag(get(row,h,'НВВ')))
            restra=str(matched['restra'] if matched else get(row,h,'Реструктуризация') or '')
            security=str(matched['security'] if matched else get(row,h,'Обеспеченность') or '')
            if side=='внебаланс' and restra:
                warn(db,pid,'data','Реструктуризация УО проигнорирована: признак относится только к активу','warning',k,client,contract)
                restra=''
            micro=micro_flag(get(row,h,'Микрокредит'))
            try:security=canonical_security(security,micro)
            except MethodologyError as exc:raise MethodologyError(f'Бизнес-план, строка {rowno}: {exc}') from exc
            gr_input=gr_value(get(row,h,'ГР'))
            poc=(gr_input=='ПОК' or bool(matched and gr_value(matched['gr'])=='ПОК'))
            if operation.casefold()=='уо' and match_key(unp,contract,ccy,'баланс') in pok_credit_keys:
                poc=True
            source_rate,source_rate_date=actual_rate_from_bp(row,rate_cols,baseline)
            poc_rate=matched['rate'] if poc and matched and side=='баланс' else None
            # A zero in the fact is also absent; use the first valid BP rate.
            if poc and operation.casefold()=='кредит':
                poc_rate=source_rate if source_rate_date==baseline else None
            elif poc and side=='баланс' and (poc_rate is None or poc_rate==0):
                poc_rate=source_rate
            criteria=Criteria(ni,pfn,nvv,restra,security,operation,ccy,micro,poc,poc_rate)
            error='';gr=None;rate=None
            try:
                if poc and operation.casefold()=='кредит' and poc_rate is None:
                    raise MethodologyError(f'Кредит ПОК, строка {rowno}: заполните «% рез на {dd(baseline)}» во входном БП.')
                gr,rate,reason=classify(criteria)
            except MethodologyError as e:error=str(e);warn(db,pid,'classification',error,'error',k,client,contract)
            # Baseline source rate may be blank or zero: validate using the first
            # valid rate from a later reporting date without changing BP amounts.
            declared_rate=source_rate
            if declared_rate is not None and rate is not None and abs(declared_rate-rate)>.001:
                warn(db,pid,'classification',f'Ставка БП {declared_rate:g}% скорректирована по методике до {rate:g}%', 'info',k,client,contract)
            if gr is not None and gr_input is not None and str(gr_input)!=str(gr):
                warn(db,pid,'classification',f'ГР БП {gr_input} заменена методической ГР {gr}', 'info',k,client,contract)
            old_date=get(row,h,'Дата окончания договора');new_date=get(row,h,'Новая дата окончания')
            end_date=iso_date(new_date) if new_date not in (None,'') else iso_date(old_date)
            old_limit=get(row,h,'Предельная дата выборки');new_limit=get(row,h,'Новая дата выборки')
            limit_date=iso_date(new_limit) if new_limit not in (None,'') else iso_date(old_limit)
            rec=db.execute('''INSERT INTO positions(project_id,match_key,src,unp,contract,parent_contract,ccy,side,operation,client,crm,rd,product,micro,poc,zone,security,restra,ni,pfn,nvv,poc_rate,segment26,segment27,start_date,end_date,limit_date,spok,sector,km,source_row,classification_error)
              VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)''',
                (pid,k,'bp',unp,contract,str(get(row,h,'Номер договора верхнего уровня (ГС)') or contract),ccy,side,operation,client,str(matched['crm'] if matched and matched['crm'] else get(row,h,'CRM-ID') or ''),str(get(row,h,'РД') or ''),str(get(row,h,'Вид кредита') or ''),int(micro),int(poc),zone,security,restra,ni,pfn,nvv,poc_rate,str(get(row,h,'Сегмент 2026') or ''),str(get(row,h,'Сегмент 2027') or ''),iso_date(get(row,h,'Дата начала договора')),end_date,limit_date,str(get(row,h,'СПОК') or ''),str(get(row,h,'ОКЭДЫ') or ''),str(get(row,h,'КМ') or ''),rowno,error))
            posid=rec.lastrowid
            base_col=rate_cols.get(baseline)
            remember_input_risk(db,posid,get(row,h,'ГР'),input_rate_cell(cells,base_col))
            for period,j in dates.items():
                try: debt=val(row[j] if j<len(row) else None)
                except MethodologyError as e:
                    warn(db,pid,'data',f'Строка {rowno}, дата {period}: {e}','error',k,client,contract);debt=0.0
                db.execute('''INSERT INTO position_periods(
                    project_id,position_id,period,debt,fx,od,ni,pfn,nvv,
                    restra,security,base_ni,base_pfn,base_nvv,gr,rate,reserve
                    ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)''',
                    (pid,posid,period,debt,0,0,ni,pfn,nvv,restra,security,
                     ni,pfn,nvv,str(gr) if gr is not None else '',rate,0))
            n+=1
            if n%2000==0:db.commit()
        return baseline,periods,n
    finally:book.close()


def get_fx(db,pid,position,period,baseline):
    ccy=position['ccy'];k=position['match_key']
    if ccy=='BYN':return 1.
    if period==baseline:
        fc=db.execute('SELECT fx FROM fact_contracts WHERE project_id=? AND match_key=?',(pid,k)).fetchone()
        if fc and fc['fx'] and fc['fx']>0:return fc['fx']
    row=db.execute('SELECT rate FROM fx WHERE project_id=? AND period=? AND currency=?',(pid,period,ccy)).fetchone()
    if row and row['rate']>0:return row['rate']
    raise MethodologyError(f'Не найден курс {ccy} на {dd(period)}')


def add_missing_position(db,pid,key,reason='manual'):
    m=db.execute('SELECT * FROM missing WHERE project_id=? AND match_key=?',(pid,key)).fetchone()
    if not m:raise ValueError('Договор не найден в реестре')
    if m['status'] in ('auto','added'):return m['position_id']
    f=db.execute('SELECT * FROM fact_contracts WHERE project_id=? AND match_key=?',(pid,key)).fetchone()
    if not f:raise ValueError('Договор отсутствует в сохранённом факте')
    project=db.execute('SELECT periods FROM projects WHERE id=?',(pid,)).fetchone()
    periods=json.loads(project['periods'])
    # Automatic addition uses *actual currency debt* constant for every future date.
    debt=f['debt']/f['fx']
    poc=gr_value(f['gr'])=='ПОК'; micro=bool(f['micro'])
    if not poc and f['operation'].strip().casefold()=='уо':
        credit_key=match_key(f['unp'],f['contract'],f['ccy'],'баланс')
        credits=db.execute('SELECT operation FROM positions WHERE project_id=? AND match_key=? AND poc=1',
                           (pid,credit_key))
        poc=any(row['operation'].strip().casefold()=='кредит' for row in credits)
        if not poc:
            credit=db.execute('SELECT operation,gr FROM fact_contracts WHERE project_id=? AND match_key=?',
                              (pid,credit_key)).fetchone()
            poc=bool(credit and credit['operation'].strip().casefold()=='кредит' and gr_value(credit['gr'])=='ПОК')
    restra=f['restra'] if f['side']=='баланс' else ''
    criteria=Criteria(f['ni'],f['pfn'],f['nvv'],restra,f['security'],f['operation'],f['ccy'],micro,poc,f['rate'] if poc else None)
    error=''
    try:gr,rate,_=classify(criteria)
    except MethodologyError as exc:gr,rate=None,None;error=str(exc);warn(db,pid,'classification',error,'error',key,f['client'],f['contract'])
    rec=db.execute('''INSERT INTO positions(project_id,match_key,src,unp,contract,parent_contract,ccy,side,operation,client,crm,rd,product,micro,poc,zone,security,restra,ni,pfn,nvv,poc_rate,added_at,classification_error)
      VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)''',
      (pid,key,'fact_auto' if reason=='auto' else 'fact_manual',f['unp'],f['contract'],f['upper_contract'] or f['contract'],f['ccy'],f['side'],f['operation'],f['client'],f['crm'],f['rd'],'',int(micro),int(poc),f['zone'],f['security'],restra,f['ni'],f['pfn'],f['nvv'],f['rate'] if poc else None,now(),error))
    posid=rec.lastrowid
    remember_input_risk(db,posid,f['gr'],f['input_rate_text'] if f['input_rate_text'] is not None else f['rate'])
    for p in periods:
        db.execute('''INSERT INTO position_periods(
          project_id,position_id,period,debt,fx,od,ni,pfn,nvv,restra,security,
          base_ni,base_pfn,base_nvv,gr,rate,reserve
          ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)''',
          (pid,posid,p,debt,0,0,f['ni'],f['pfn'],f['nvv'],f['restra'],f['security'],
           f['ni'],f['pfn'],f['nvv'],str(gr) if gr is not None else '',rate,0))
    db.execute('UPDATE missing SET status=?,position_id=?,added=? WHERE id=?',('auto' if reason=='auto' else 'added',posid,now(),m['id']))
    db.execute('INSERT INTO audit(project_id,at,action,position_id,reason) VALUES(?,?,?,?,?)',(pid,now(),'add_missing',posid,reason))
    return posid


def reconcile(db,pid,baseline):
    n=0
    facts=db.execute('SELECT * FROM fact_contracts WHERE project_id=?',(pid,))
    for f in facts:
        rows=db.execute('''SELECT p.id,pp.debt FROM positions p JOIN position_periods pp ON pp.position_id=p.id AND pp.period=?
          WHERE p.project_id=? AND p.match_key=?''',(baseline,pid,f['match_key'])).fetchall()
        if rows:
            plan=sum(r['debt'] for r in rows)*f['fx']
            diff=round(plan-f['debt'],2)
            if abs(diff)>.01:
                warn(db,pid,'debt',f'Расхождение задолженности: {diff:+,.2f} BYN','warning',f['match_key'],f['client'],f['contract'],
                    {'bp_byn':round(plan,2),'fact_byn':round(f['debt'],2),'diff_byn':diff,'fx':f['fx'],'ccy':f['ccy']})
        else:
            black=is_black_zone(f['zone'])
            db.execute('''INSERT INTO missing(project_id,match_key,unp,contract,client,ccy,side,operation,zone,amount_byn,fx,status,created)
              VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)''',
              (pid,f['match_key'],f['unp'],f['contract'],f['client'],f['ccy'],f['side'],f['operation'],f['zone'],f['debt'],f['fx'],'waiting',now()))
            if black:add_missing_position(db,pid,f['match_key'],'auto')
            n+=1
    return n


def calc_one(db,pid,posid,baseline,periods,enable_warnings=True,from_period=None):
    pos=db.execute('SELECT * FROM positions WHERE id=? AND project_id=?',(posid,pid)).fetchone()
    if not pos:return
    new_contract_marker = is_new_contract(pos['contract'])
    prev=None
    for period in periods:
        r=db.execute('SELECT * FROM position_periods WHERE project_id=? AND position_id=? AND period=?',(pid,posid,period)).fetchone()
        if not r:continue
        criteria=Criteria(r['ni'],r['pfn'],r['nvv'],r['restra'],r['security'],pos['operation'],pos['ccy'],bool(pos['micro']),bool(pos['poc']),pos['poc_rate'])
        if from_period and period < from_period:
            prev = None if r['reserve'] is None else {
                **{key:r[key] for key in ('debt','fx','od','rate','reserve','gr')}, 'criteria':criteria.as_dict()}
            continue
        try:gr,methodrate,why=classify(criteria)
        except MethodologyError as exc:
            if enable_warnings:warn(db,pid,'classification',f'{dd(period)}: {exc}','error',pos['match_key'],pos['client'],pos['contract'])
            gr=None;methodrate=None
        override=r['override_reason']
        if override and r['gr'] and r['rate'] is not None:
            grout=r['gr'];rate=r['rate']
        else:
            grout=str(gr) if gr is not None else '';rate=methodrate
        try:fx=get_fx(db,pid,pos,period,baseline)
        except MethodologyError as exc:
            fx=None
            if enable_warnings:warn(db,pid,'fx',f'{dd(period)}: {exc}','error',pos['match_key'],pos['client'],pos['contract'])
        od=round(r['debt']*fx,2) if fx is not None else None
        reserve=round(od*rate/100,2) if (rate is not None and od is not None) else None
        current={'debt':r['debt'],'fx':fx,'od':od,'rate':rate,'reserve':reserve,
                 'criteria':criteria.as_dict(),'gr':grout}
        if prev is not None and rate is not None and fx is not None and prev['rate'] is not None:
            try:
                factors=compute_factors(prev,current,new_contract=new_contract_marker)
            except MethodologyError as exc:
                if enable_warnings:warn(db,pid,'factor',f'{dd(period)}: {exc}','error',pos['match_key'],pos['client'],pos['contract'])
                # Preserve exact reserve reconciliation but expose the unresolved
                # amount as a technical residual instead of inventing a factor.
                expenses=round(prev['reserve']-reserve,2)
                factors={'movement':0,'financial_state':0,'security_effect':0,'quality':0,
                         'fx':0,'expenses':expenses,'rounding':expenses,
                         'factors':{},'events':[]}
        else:
            factors={'movement':0,'financial_state':0,'security_effect':0,'quality':0,
                     'fx':0,'expenses':0,'rounding':0,'factors':{},'events':[]}
        db.execute('''UPDATE position_periods SET fx=?,od=?,gr=?,method_gr=?,rate=?,reserve=?,expenses=?,
          movement=?,financial_state=?,security_effect=?,revaluation=?,quality=?,rounding=?,factors=?,events=?
          WHERE project_id=? AND position_id=? AND period=?''',
          (fx,od,grout,str(gr) if gr is not None else '',rate,reserve,factors['expenses'],
           factors['movement'],factors['financial_state'],factors['security_effect'],factors['fx'],
           factors['quality'],factors['rounding'],js(factors['factors']),js(factors['events']),
           pid,posid,period))
        prev=current if rate is not None and fx is not None else None


def build(pid, progress=None):
    def stage(message):
        if progress:
            progress(message)

    stage('Проверка файлов и подготовка расчёта')
    initialize()
    with connect() as db:
        files={}
        for upload in db.execute('SELECT * FROM uploads WHERE project_id=?',(pid,)):
            source=Path(upload['path'])
            if not source.is_absolute():
                source=ROOT/source
            if not source.exists():
                fallback=DATA/str(pid)/(upload['kind']+'.xlsx')
                if fallback.exists():source=fallback
            if not source.exists():
                raise MethodologyError(f'Не найден сохранённый файл {upload["original_name"]}. Загрузите его повторно.')
            files[upload['kind']]=str(source)
        missing={'bp','fact','rates'}-files.keys()
        if missing:raise MethodologyError('Сначала загрузите: '+', '.join(sorted(missing)))
        db.execute('UPDATE projects SET status=? WHERE id=?',('building',pid))
        db.execute('DELETE FROM current_portfolios WHERE project_id=?',(pid,))
        # A rebuild replaces the underlying BP/fact rows. Keep the imported
        # event file in history, but require an explicit re-application to the
        # newly built forecast so conflicts are reviewed against the new base.
        db.execute("UPDATE plan_event_batches SET status='needs_reapply' WHERE project_id=? AND status IN ('active','pending')",(pid,))
        db.execute(
            'INSERT INTO audit(project_id,at,action,reason) VALUES(?,?,?,?)',
            (pid, now(), 'rebuild', 'Начато новое построение базовой версии; ручные правки предыдущей версии не переносятся автоматически')
        )
        for table in ('fact_contracts','fact_clients','positions','position_periods','missing','warnings','fx'):
            db.execute(f'DELETE FROM {table} WHERE project_id=?',(pid,))
        db.commit()
        stage('Загрузка курсов')
        nfx=load_rates(db,pid,files['rates']);db.commit()
        stage(f'Курсы загружены: {nfx}. Загрузка факта')
        fact=load_fact(db,pid,files['fact']);db.commit()
        stage(f'Факт загружен: {fact["rows"]} строк. Загрузка бизнес-плана')
        baseline,periods,nplan=read_bp_positions(db,pid,files['bp'])
        stage(f'Бизнес-план загружен: {nplan} строк. Сверка договоров')
        confirmed=db.execute('SELECT note FROM projects WHERE id=?',(pid,)).fetchone()['note']
        if confirmed and confirmed != baseline:
            raise MethodologyError(f'Дата выверенного факта {dd(confirmed)} не совпадает с исходной датой БП {dd(baseline)}')
        db.execute('UPDATE projects SET fact_date=?,periods=? WHERE id=?',(baseline,js(periods),pid));db.commit()
        missing_count=reconcile(db,pid,baseline);db.commit()
        total=db.execute('SELECT COUNT(*) FROM positions WHERE project_id=?',(pid,)).fetchone()[0]
        stage(f'Сверка завершена. Расчёт позиций: 0 из {total}')
        count=0
        for (posid,) in db.execute('SELECT id FROM positions WHERE project_id=? ORDER BY id',(pid,)):
            calc_one(db,pid,posid,baseline,periods)
            count+=1
            if count%1000==0:
                db.commit()
                stage(f'Расчёт позиций: {count} из {total}')
        stage(f'Расчёт позиций завершён: {count} из {total}. Проверка резервов')
        # Compare calculated reserve vs actual fact reserve only for matched positions.
        for f in db.execute('SELECT * FROM fact_contracts WHERE project_id=?',(pid,)):
            rr=db.execute('''SELECT SUM(pp.reserve) r FROM positions p JOIN position_periods pp ON pp.position_id=p.id
                WHERE p.project_id=? AND p.match_key=? AND pp.period=?''',(pid,f['match_key'],baseline)).fetchone()
            if rr['r'] is None:continue
            diff=round(rr['r']-f['reserve'],2)
            if abs(diff)>.01:
                warn(db,pid,'reserve',f'Расчётный резерв отличается от фактического: {diff:+,.2f} BYN','warning',f['match_key'],f['client'],f['contract'],
                  {'calc_byn':round(rr['r'],2),'fact_byn':f['reserve'],'diff_byn':diff})
        error_count=db.execute("SELECT count(*) n FROM warnings WHERE project_id=? AND severity='error'",(pid,)).fetchone()['n']
        db.execute('UPDATE projects SET status=?,version=version+1 WHERE id=?',('needs_review' if error_count else 'ready',pid))
        db.commit()
        stage('Расчёт завершён')
        return {'positions':count,'fact_rows':fact['rows'],'business_plan_rows':nplan,'dates':periods,'missing':missing_count,
                'fx_rows':nfx,'errors':error_count,'status':'needs_review' if error_count else 'ready'}


# ---------------------------------------------------------------------------
# Planned client-risk events (НИ / ПФН / НВВ)
# ---------------------------------------------------------------------------

PLAN_FEATURES = {'ni': 'НИ', 'pfn': 'ПФН', 'nvv': 'НВВ'}
PLAN_ACTIONS = {'recognition': 'Возникновение', 'removal': 'Снятие'}


def normalize_unp(value):
    """Normalize an Excel UNP without changing significant leading zeroes."""
    if value is None:
        return ''
    if isinstance(value, float) and value.is_integer():
        return str(int(value))
    text = str(value).strip()
    if re.fullmatch(r'\d+\.0+', text):
        return text.split('.', 1)[0]
    return text


def add_one_month(date_iso):
    """Move a first-of-month source event to the next calendar month."""
    d = dt.date.fromisoformat(date_iso)
    year = d.year + (1 if d.month == 12 else 0)
    month = 1 if d.month == 12 else d.month + 1
    return dt.date(year, month, 1).isoformat()


def _plan_header_map(headers):
    result = {}
    patterns = {
        'ni': re.compile(r'(?<![а-яa-z0-9])ни(?![а-яa-z0-9])', re.I),
        'pfn': re.compile(r'(?<![а-яa-z0-9])пфн(?![а-яa-z0-9])', re.I),
        'nvv': re.compile(r'(?<![а-яa-z0-9])нвв(?![а-яa-z0-9])', re.I),
    }
    for index, raw in enumerate(headers):
        header = normalize_header(raw)
        if not header:
            continue
        if 'дата возникновения' in header or 'дата признания' in header:
            action = 'recognition'
        elif 'дата снятия' in header or 'дата прекращения' in header:
            action = 'removal'
        else:
            continue
        for feature, pattern in patterns.items():
            if pattern.search(header):
                key = (feature, action)
                if key in result:
                    raise MethodologyError(
                        f'В файле несколько столбцов для {PLAN_ACTIONS[action].lower()} {PLAN_FEATURES[feature]}'
                    )
                result[key] = index
    return result


def _detect_client_summary_layout(ws):
    """Detect the user's wide 'Таблица 1' workbook layout.

    The workbook has a two-level header:
      B  = УНП
      V:X = recognition dates for НИ / ПФН / НВВ
      Y:AA = removal dates for НИ / ПФН / НВВ

    All other columns are deliberately ignored by the event importer.
    Returns (data_start_row, unp_column_index, event_columns) or None.
    """
    max_scan = min(ws.max_row or 20, 20)
    rows = list(ws.iter_rows(
        min_row=1, max_row=max_scan, min_col=1, max_col=27,
        values_only=True
    ))

    unp_header_row = None
    for row_no, row in enumerate(rows, start=1):
        value = normalize_header(row[1] if len(row) > 1 else None)
        if value in ('унп', 'учетный номер плательщика', 'учётный номер плательщика'):
            unp_header_row = row_no
            break

    expected = ['ни', 'пфн', 'нвв', 'ни', 'пфн', 'нвв']
    event_header_row = None
    for row_no, row in enumerate(rows, start=1):
        values = [normalize_header(row[i] if i < len(row) else None) for i in range(21, 27)]
        if values == expected:
            event_header_row = row_no
            break

    if unp_header_row is None or event_header_row is None:
        return None

    event_columns = {
        ('ni', 'recognition'): 21,   # V
        ('pfn', 'recognition'): 22,  # W
        ('nvv', 'recognition'): 23,  # X
        ('ni', 'removal'): 24,       # Y
        ('pfn', 'removal'): 25,      # Z
        ('nvv', 'removal'): 26,      # AA
    }
    return max(unp_header_row, event_header_row) + 1, 1, event_columns


def _parse_plan_event_date(raw, epoch):
    """Parse Excel date cells, including numeric Excel serials."""
    if isinstance(raw, (int, float)) and not isinstance(raw, bool):
        try:
            from openpyxl.utils.datetime import from_excel
            raw = from_excel(raw, epoch)
        except Exception:
            pass
    return iso_date(raw)


def parse_plan_change_file(path):
    """Read client-level events from either the full source table or legacy template.

    Full source table: only column B (УНП) and V:AA (six event dates) are read.
    Columns with current НИ/ПФН/НВВ, ГР, debt, zone and all other attributes are ignored.
    A single row per УНП is required because events are client-level.
    """
    book = load_workbook(path, read_only=True, data_only=True)
    try:
        selected = None

        # First prefer the exact wide layout shown by the analyst.
        for sheet in book.worksheets:
            layout = _detect_client_summary_layout(sheet)
            if layout:
                data_start, unp_index, header_map = layout
                selected = (sheet, data_start, unp_index, header_map, 'wide')
                break

        # Backward compatibility: accept the earlier compact 7-column template.
        if not selected:
            for sheet in book.worksheets:
                for row_index, row in enumerate(
                    sheet.iter_rows(min_row=1, max_row=12, values_only=True), start=1
                ):
                    headers = list(row)
                    header_map = _plan_header_map(headers)
                    normalized = {normalize_header(v): i for i, v in enumerate(headers) if v is not None}
                    unp_index = next((normalized[x] for x in ('унп', 'учетный номер плательщика') if x in normalized), None)
                    if unp_index is not None and header_map:
                        selected = (sheet, row_index + 1, unp_index, header_map, 'compact')
                        break
                if selected:
                    break

        if not selected:
            raise MethodologyError(
                'Не найдена структура файла плановых изменений. Для исходной таблицы ожидаются '
                'УНП в столбце B и даты событий НИ/ПФН/НВВ в V:AA; также поддерживается '
                'старый компактный шаблон с заголовками в одной строке.'
            )

        ws, data_start, unp_index, header_map, layout_kind = selected
        events = []
        seen = {}

        for row_number, row in enumerate(
            ws.iter_rows(min_row=data_start, values_only=True), start=data_start
        ):
            unp = normalize_unp(row[unp_index] if unp_index < len(row) else None)
            if not unp:
                continue

            if unp in seen:
                raise MethodologyError(
                    f'УНП {unp} встречается в файле более одного раза '
                    f'(строки {seen[unp]} и {row_number}). События задаются на уровне клиента: '
                    'оставьте одну строку на УНП.'
                )
            seen[unp] = row_number

            row_events = []
            for (feature, action), column in header_map.items():
                raw = row[column] if column < len(row) else None
                if raw is None or str(raw).strip() == '':
                    continue

                source_date = _parse_plan_event_date(raw, book.epoch)
                try:
                    parsed = dt.date.fromisoformat(source_date)
                except (TypeError, ValueError):
                    raise MethodologyError(
                        f'Строка {row_number}, УНП {unp}: некорректная дата {raw!r} '
                        f'в поле {PLAN_ACTIONS[action]} {PLAN_FEATURES[feature]}'
                    )
                if parsed.day != 1:
                    raise MethodologyError(
                        f'Строка {row_number}, УНП {unp}: дата {dd(source_date)} '
                        'должна быть первым числом месяца'
                    )

                row_events.append({
                    'unp': unp,
                    'feature': feature,
                    'action': action,
                    'target_value': 1 if action == 'recognition' else 0,
                    'source_date': source_date,
                    'requested_date': add_one_month(source_date),
                    'row_number': row_number,
                })

            for feature in PLAN_FEATURES:
                recognition = next((e for e in row_events if e['feature'] == feature and e['action'] == 'recognition'), None)
                removal = next((e for e in row_events if e['feature'] == feature and e['action'] == 'removal'), None)
                if recognition and removal and recognition['requested_date'] >= removal['requested_date']:
                    raise MethodologyError(
                        f'УНП {unp}: дата возникновения {PLAN_FEATURES[feature]} '
                        'должна быть раньше даты снятия'
                    )
            events.extend(row_events)

        if not seen:
            raise MethodologyError('В файле плановых изменений нет строк с УНП в столбце B')
        if not events:
            raise MethodologyError('В файле нет заполненных дат событий в V:AA')
        return events
    finally:
        book.close()


def _latest_manual_flag(db, pid, position_id, period, feature):
    row = db.execute(
        '''SELECT new FROM audit WHERE project_id=? AND action='edit'
           AND position_id=? AND period=? AND field=?
           AND id>(SELECT COALESCE(MAX(id),0) FROM audit WHERE project_id=? AND action='rebuild')
           ORDER BY id DESC LIMIT 1''',
        (pid, position_id, period, feature, pid)
    ).fetchone()
    return None if row is None else flag(row['new'])


def _event_conflict(db, pid, unp, feature, target_value, applied_period, periods, simulated_state=None):
    positions = db.execute('SELECT id FROM positions WHERE project_id=? AND unp=?', (pid, unp)).fetchall()
    position_ids = [r['id'] for r in positions]
    if not position_ids:
        return 'Клиент с таким УНП отсутствует в построенном бизнес-плане'
    previous_periods = [d for d in periods if d < applied_period]
    previous_period = previous_periods[-1] if previous_periods else periods[0]
    base_field = 'base_' + feature
    values = set()
    for position_id in position_ids:
        row = db.execute(
            f'SELECT {base_field} FROM position_periods WHERE project_id=? AND position_id=? AND period=?',
            (pid, position_id, previous_period)
        ).fetchone()
        if row is None:
            continue
        manual = _latest_manual_flag(db, pid, position_id, previous_period, feature)
        value = manual if manual is not None else flag(row[base_field])
        values.add(value)
    reasons = []
    state_before = simulated_state if simulated_state is not None else (next(iter(values)) if len(values) == 1 else None)
    if simulated_state is not None and simulated_state == target_value:
        reasons.append(
            f'После предыдущих событий этого файла признак {PLAN_FEATURES[feature]} уже имеет значение {target_value}'
        )
    elif simulated_state is None and target_value in values:
        reasons.append(
            f'На {dd(previous_period)} в бизнес-плане уже установлен признак {PLAN_FEATURES[feature]}={target_value}'
        )
    if len(values) > 1:
        reasons.append(f'У договоров клиента разные значения {PLAN_FEATURES[feature]} до применения события')

    placeholders = ','.join('?' for _ in position_ids)
    latest_manual = db.execute(
        f'''SELECT a.position_id,a.period,a.new FROM audit a
            JOIN (SELECT MAX(id) id FROM audit
                  WHERE project_id=? AND action='edit' AND field=? AND period>=?
                    AND position_id IN ({placeholders})
                    AND id>(SELECT COALESCE(MAX(id),0) FROM audit WHERE project_id=? AND action='rebuild')
                  GROUP BY position_id,period) latest ON latest.id=a.id''',
        [pid, feature, applied_period, *position_ids, pid]
    ).fetchall()
    conflicts = [r for r in latest_manual if flag(r['new']) != target_value]
    if conflicts:
        sample = conflicts[0]
        reasons.append(
            f'Есть ручная корректировка {PLAN_FEATURES[feature]} на {dd(sample["period"])} '
            f'со значением {flag(sample["new"])}'
        )
    return '; '.join(reasons), state_before


def stage_plan_changes(pid, path, original_name):
    """Parse a new plan-event file and stage it for review without changing forecast values."""
    parsed_events = parse_plan_change_file(path)
    with connect() as db:
        project = db.execute('SELECT periods,fact_date FROM projects WHERE id=?', (pid,)).fetchone()
        if not project or not project['periods']:
            raise MethodologyError('Сначала постройте бизнес-план и прогноз')
        periods = json.loads(project['periods'])
        forecast_periods = [d for d in periods if d > project['fact_date']]
        previous = db.execute(
            "SELECT * FROM plan_event_batches WHERE project_id=? AND status IN ('active','needs_reapply') ORDER BY version DESC LIMIT 1",
            (pid,)
        ).fetchone()
        db.execute("UPDATE plan_event_batches SET status='superseded' WHERE project_id=? AND status='pending'", (pid,))
        version = db.execute('SELECT COALESCE(MAX(version),0)+1 n FROM plan_event_batches WHERE project_id=?', (pid,)).fetchone()['n']
        cur = db.execute(
            "INSERT INTO plan_event_batches(project_id,version,original_name,uploaded_at,status,event_count,summary) VALUES(?,?,?,?,?,?,?)",
            (pid, version, str(original_name), now(), 'pending', len(parsed_events), '{}')
        )
        batch_id = cur.lastrowid
        new_keys = set()
        simulated_states = {}
        parsed_events.sort(key=lambda e: (e['requested_date'], e['unp'], e['feature'], e['action']))
        for event in parsed_events:
            requested = event['requested_date']
            applied = next((d for d in forecast_periods if d >= requested), None)
            client_exists = db.execute('SELECT 1 FROM positions WHERE project_id=? AND unp=? LIMIT 1', (pid, event['unp'])).fetchone()
            conflict = ''
            if not client_exists:
                status = 'client_not_found'
            elif applied is None:
                status = 'out_of_horizon'
            else:
                state_key = (event['unp'], event['feature'])
                simulated_state = simulated_states.get(state_key)
                conflict, state_before = _event_conflict(
                    db, pid, event['unp'], event['feature'], event['target_value'],
                    applied, periods, simulated_state=simulated_state
                )
                status = 'conflict' if conflict else 'ready'
                # Subsequent events for this client/feature are evaluated after
                # the preceding event from the same incoming file.
                simulated_states[state_key] = event['target_value']
            db.execute(
                '''INSERT INTO plan_events(project_id,batch_id,unp,feature,action,target_value,
                   source_date,requested_date,applied_period,status,conflict_message,created_at)
                   VALUES(?,?,?,?,?,?,?,?,?,?,?,?)''',
                (pid, batch_id, event['unp'], event['feature'], event['action'], event['target_value'],
                 event['source_date'], requested, applied, status, conflict, now())
            )
            new_keys.add((event['unp'], event['feature'], event['action'], event['source_date']))
        # Sparse forecast horizons can map two chronologically distinct events
        # to the same available period. Preserve both events, but make the
        # resulting same-period collapse visible to the analyst.
        collapsed = db.execute(
            '''SELECT unp,feature,applied_period,COUNT(*) n FROM plan_events
               WHERE batch_id=? AND applied_period IS NOT NULL
               GROUP BY unp,feature,applied_period HAVING COUNT(*)>1''',
            (batch_id,)
        ).fetchall()
        for group in collapsed:
            note = (
                f'Несколько событий {PLAN_FEATURES[group["feature"]]} попали на одну дату '
                f'{dd(group["applied_period"])}; итоговое значение задаст событие с более поздней датой в файле'
            )
            db.execute(
                '''UPDATE plan_events SET conflict_message=CASE
                    WHEN COALESCE(conflict_message,'')='' THEN ?
                    ELSE conflict_message || '; ' || ? END
                   WHERE batch_id=? AND unp=? AND feature=? AND applied_period=?''',
                (note, note, batch_id, group['unp'], group['feature'], group['applied_period'])
            )
        old_keys = set()
        if previous:
            old_keys = {
                (r['unp'], r['feature'], r['action'], r['source_date'])
                for r in db.execute('SELECT unp,feature,action,source_date FROM plan_events WHERE batch_id=?', (previous['id'],))
            }
        summary = {
            'added': len(new_keys - old_keys),
            'removed': len(old_keys - new_keys),
            'unchanged': len(new_keys & old_keys),
            'previous_batch': previous['id'] if previous else None,
        }
        db.execute('UPDATE plan_event_batches SET summary=? WHERE id=?', (js(summary), batch_id))
    return get_plan_changes(pid)


def get_plan_changes(pid):
    with connect() as db:
        batches = [dict(r) for r in db.execute(
            'SELECT * FROM plan_event_batches WHERE project_id=? ORDER BY version DESC LIMIT 20', (pid,)
        )]
        for batch in batches:
            batch['summary'] = json.loads(batch['summary'] or '{}')
            batch['events'] = [dict(r) for r in db.execute(
                '''SELECT e.*,
                    COALESCE((SELECT MAX(p.client) FROM positions p WHERE p.project_id=e.project_id AND p.unp=e.unp),'') client
                   FROM plan_events e WHERE e.batch_id=? ORDER BY e.applied_period,e.unp,e.feature,e.requested_date,e.id''',
                (batch['id'],)
            )]
        pending = next((b for b in batches if b['status'] == 'pending'), None)
        active = next((b for b in batches if b['status'] in ('active', 'needs_reapply')), None)
        return {'pending': pending, 'active': active, 'history': batches}


def apply_plan_changes(pid, batch_id, decisions=None):
    """Replace the active event set, replay manual flag edits, apply approved events and recalculate."""
    decisions = decisions or {}
    with connect() as db:
        project = db.execute('SELECT * FROM projects WHERE id=?', (pid,)).fetchone()
        if not project:
            raise MethodologyError('Бизнес-план не найден')
        periods = json.loads(project['periods'])
        batch = db.execute('SELECT * FROM plan_event_batches WHERE id=? AND project_id=? AND status=?',
                           (batch_id, pid, 'pending')).fetchone()
        if not batch:
            raise MethodologyError('Ожидающий файл плановых изменений не найден или уже обработан')
        events = db.execute('SELECT * FROM plan_events WHERE batch_id=? ORDER BY applied_period,unp,feature,requested_date,id',
                            (batch_id,)).fetchall()
        resolutions = {}
        for event in events:
            if event['status'] == 'conflict':
                choice = str(decisions.get(str(event['id']), decisions.get(event['id'], '')))
                if choice not in ('apply', 'keep'):
                    raise MethodologyError(f'Не выбрано решение по конфликту: УНП {event["unp"]}, {PLAN_FEATURES[event["feature"]]}')
                resolutions[event['id']] = choice
            elif event['status'] == 'ready':
                resolutions[event['id']] = 'apply'
            else:
                resolutions[event['id']] = 'skip'

        old_batches = db.execute(
            "SELECT id FROM plan_event_batches WHERE project_id=? AND status IN ('active','needs_reapply')",
            (pid,)
        ).fetchall()
        affected_unps = {r['unp'] for r in events}
        for old in old_batches:
            affected_unps.update(r['unp'] for r in db.execute('SELECT DISTINCT unp FROM plan_events WHERE batch_id=?', (old['id'],)))

        # Restore source BP/fact flags, then replay the analyst's manual flag
        # edits from audit. This makes replacing an event file deterministic.
        db.execute('''UPDATE position_periods SET
            ni=COALESCE(base_ni,ni), pfn=COALESCE(base_pfn,pfn), nvv=COALESCE(base_nvv,nvv)
            WHERE project_id=?''', (pid,))
        manual_rows = db.execute(
            '''SELECT a.position_id,a.period,a.field,a.new FROM audit a
               JOIN (SELECT MAX(id) id FROM audit WHERE project_id=? AND action='edit'
                     AND field IN ('ni','pfn','nvv')
                     AND id>(SELECT COALESCE(MAX(id),0) FROM audit WHERE project_id=? AND action='rebuild')
                     GROUP BY position_id,period,field) latest
                 ON latest.id=a.id''', (pid, pid)
        ).fetchall()
        for manual in manual_rows:
            if manual['period'] not in periods or manual['field'] not in PLAN_FEATURES:
                continue
            try:
                manual_value = flag(manual['new'])
            except MethodologyError:
                continue
            db.execute(
                f'UPDATE position_periods SET {manual["field"]}=? WHERE project_id=? AND position_id=? AND period=?',
                (manual_value, pid, manual['position_id'], manual['period'])
            )

        applied_count = 0
        kept_count = 0
        skipped_count = 0
        for event in events:
            choice = resolutions[event['id']]
            if choice == 'skip':
                skipped_count += 1
                continue
            if choice == 'keep':
                kept_count += 1
                db.execute("UPDATE plan_events SET status='kept_manual',resolution='keep' WHERE id=?", (event['id'],))
                db.execute(
                    'INSERT INTO audit(project_id,at,action,period,field,new,reason) VALUES(?,?,?,?,?,?,?)',
                    (pid, now(), 'plan_event_keep', event['applied_period'], event['feature'], str(event['target_value']),
                     f'УНП {event["unp"]}; событие {PLAN_ACTIONS[event["action"]]} {PLAN_FEATURES[event["feature"]]}')
                )
                continue
            if not event['applied_period']:
                skipped_count += 1
                continue
            position_ids = [r['id'] for r in db.execute('SELECT id FROM positions WHERE project_id=? AND unp=?', (pid, event['unp']))]
            if not position_ids:
                db.execute("UPDATE plan_events SET status='client_not_found' WHERE id=?", (event['id'],))
                skipped_count += 1
                continue
            placeholders = ','.join('?' for _ in position_ids)
            db.execute(
                f'''UPDATE position_periods SET {event['feature']}=?
                    WHERE project_id=? AND period>=? AND position_id IN ({placeholders})''',
                [event['target_value'], pid, event['applied_period'], *position_ids]
            )
            db.execute("UPDATE plan_events SET status='applied',resolution=? WHERE id=?", ('apply' if event['status']=='conflict' else 'automatic', event['id']))
            db.execute(
                'INSERT INTO audit(project_id,at,action,period,field,new,reason) VALUES(?,?,?,?,?,?,?)',
                (pid, now(), 'plan_event_apply', event['applied_period'], event['feature'], str(event['target_value']),
                 f'УНП {event["unp"]}; источник {batch["original_name"]}; дата в файле {dd(event["source_date"])}')
            )
            applied_count += 1

        # The new event set replaces the old one; old batches remain in history.
        db.execute("UPDATE plan_event_batches SET status='replaced' WHERE project_id=? AND status IN ('active','needs_reapply')", (pid,))
        db.execute("UPDATE plan_event_batches SET status='active' WHERE id=?", (batch_id,))
        for unp in affected_unps:
            for position in db.execute('SELECT id FROM positions WHERE project_id=? AND unp=?', (pid, unp)):
                calc_one(db, pid, position['id'], project['fact_date'], periods, enable_warnings=False)
        errors = db.execute("SELECT COUNT(*) n FROM warnings WHERE project_id=? AND severity='error'", (pid,)).fetchone()['n']
        db.execute('UPDATE projects SET status=? WHERE id=?', ('needs_review' if errors else 'ready', pid))
        db.commit()
    return {'applied': applied_count, 'kept_manual': kept_count, 'skipped': skipped_count,
            'batch_id': batch_id, 'state': get_plan_changes(pid)}


def cancel_plan_changes(pid, batch_id):
    with connect() as db:
        cur = db.execute("UPDATE plan_event_batches SET status='cancelled' WHERE id=? AND project_id=? AND status='pending'", (batch_id, pid))
        if not cur.rowcount:
            raise MethodologyError('Ожидающий файл не найден')
    return get_plan_changes(pid)


def build_plan_changes_template():
    """Create a template matching the analyst's 27-column source workbook."""
    from io import BytesIO
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
    from openpyxl.utils import get_column_letter

    wb = Workbook()
    ws = wb.active
    ws.title = 'Таблица 1'
    ws.merge_cells('A1:AA1')
    ws['A1'] = 'Таблица 1'
    ws['A1'].font = Font(bold=True, color='FFFFFF', size=12)
    ws['A1'].fill = PatternFill('solid', fgColor='203B61')
    ws['A1'].alignment = Alignment(horizontal='center', vertical='center')
    ws.row_dimensions[1].height = 24

    base_headers = {
        1: 'Итог по клиенту', 2: 'УНП', 3: 'Клиент', 4: 'Зона', 5: 'Рейтинг',
        6: 'Номер договора', 7: 'ГР', 8: 'Задолженность', 9: 'Актив', 10: 'УО',
        11: 'Валюта', 12: 'Сегмент', 13: 'НИ', 14: 'ПФН', 15: 'НВВ',
        16: 'Рестра', 17: 'Обеспеченность', 18: 'Ранее: Прогноз фев',
        19: 'Прогноз 2026', 20: 'Изменение в ребаф', 21: 'Фильтр',
    }
    for col, header in base_headers.items():
        ws.cell(row=2, column=col, value=header)

    ws.merge_cells('V2:X2')
    ws['V2'] = 'Дата возникновения признака которого раньше не было'
    ws.merge_cells('Y2:AA2')
    ws['Y2'] = 'Дата снятия признака'

    event_headers = ['НИ', 'ПФН', 'НВВ', 'НИ', 'ПФН', 'НВВ']
    for offset, header in enumerate(event_headers, start=22):
        ws.cell(row=3, column=offset, value=header)

    dark = PatternFill('solid', fgColor='203B61')
    mid = PatternFill('solid', fgColor='DCE6F1')
    thin = Side(style='thin', color='B8C5D3')
    for row in ws.iter_rows(min_row=2, max_row=3, min_col=1, max_col=27):
        for cell in row:
            cell.font = Font(bold=True, color='FFFFFF' if cell.row == 2 else '203B61')
            cell.fill = dark if cell.row == 2 else mid
            cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
            cell.border = Border(left=thin, right=thin, top=thin, bottom=thin)
    ws.row_dimensions[2].height = 42
    ws.row_dimensions[3].height = 22

    widths = {
        'A': 20, 'B': 16, 'C': 28, 'D': 17, 'E': 12, 'F': 22, 'G': 9,
        'H': 16, 'I': 14, 'J': 14, 'K': 11, 'L': 15, 'M': 8, 'N': 8,
        'O': 8, 'P': 13, 'Q': 24, 'R': 19, 'S': 16, 'T': 19, 'U': 14,
        'V': 15, 'W': 15, 'X': 15, 'Y': 15, 'Z': 15, 'AA': 15,
    }
    for col, width in widths.items():
        ws.column_dimensions[col].width = width

    ws.freeze_panes = 'C4'
    ws.auto_filter.ref = 'A3:AA3'

    info = wb.create_sheet('Инструкция')
    notes = [
        ['Правило', 'Описание'],
        ['Используемые поля', 'Только УНП из столбца B и шесть дат событий: V — возникновение НИ, W — возникновение ПФН, X — возникновение НВВ, Y — снятие НИ, Z — снятие ПФН, AA — снятие НВВ.'],
        ['Игнорируемые поля', 'Текущие НИ/ПФН/НВВ (M:O), ГР, зону, задолженность, валюту, сегмент, реструктуризацию, обеспеченность, комментарии и остальные столбцы не используем даже для сверки.'],
        ['Уровень событий', 'Все события задаются на уровне клиента. Один УНП — одна строка; дубли УНП считаются ошибкой. При применении признак меняется по всем договорам клиента.'],
        ['Дата события', 'Дата в файле — начало месяца. В прогнозе событие применяется с первого числа следующего календарного месяца.'],
        ['Нет точной даты в БП', 'Используется ближайшая следующая доступная прогнозная дата. Новые периоды не создаются; перенос показывается как предупреждение.'],
        ['Возникновение / снятие', 'С даты применения возникновение устанавливает признак в 1, снятие — в 0. Значение сохраняется на всех следующих прогнозных датах.'],
        ['Ограничение', 'Повторное возникновение / снятие одного признака в горизонте не предусматривается. Одновременные события разных признаков допускаются.'],
    ]
    for row in notes:
        info.append(row)
    info.column_dimensions['A'].width = 28
    info.column_dimensions['B'].width = 120
    for cell in info[1]:
        cell.font = Font(bold=True, color='FFFFFF')
        cell.fill = dark
    for row in info.iter_rows(min_row=2):
        row[1].alignment = Alignment(wrap_text=True, vertical='top')
    info.freeze_panes = 'A2'

    buffer = BytesIO()
    wb.save(buffer)
    buffer.seek(0)
    return buffer


def add_waiting(pid,keys):
    with connect() as db:
        project=db.execute('SELECT * FROM projects WHERE id=?',(pid,)).fetchone();periods=json.loads(project['periods'])
        count=0
        for key in keys:
            r=db.execute('SELECT status FROM missing WHERE project_id=? AND match_key=?',(pid,key)).fetchone()
            if r and r['status']=='waiting':
                posid=add_missing_position(db,pid,key)
                calc_one(db,pid,posid,project['fact_date'],periods)
                count+=1
        return count


def undo_waiting(pid,keys):
    with connect() as db:
        n=0
        for key in keys:
            row=db.execute('SELECT * FROM missing WHERE project_id=? AND match_key=?',(pid,key)).fetchone()
            if not row or row['status']!='added':continue
            posid=row['position_id'];db.execute('DELETE FROM position_periods WHERE project_id=? AND position_id=?',(pid,posid))
            db.execute('DELETE FROM positions WHERE project_id=? AND id=?',(pid,posid))
            db.execute('UPDATE missing SET status=?,position_id=NULL,added=NULL WHERE id=?',('waiting',row['id']))
            db.execute('INSERT INTO audit(project_id,at,action,position_id,reason) VALUES(?,?,?,?,?)',(pid,now(),'undo_missing',posid,key))
            n+=1
        return n

EDIT_FIELDS=('debt','ni','pfn','nvv','restra','security','gr','rate')

def edit(pid,position_id,period,field,value,reason=''):
    if field not in EDIT_FIELDS:raise MethodologyError('Редактирование поля не поддерживается')
    with connect() as db:
        proj=db.execute('SELECT * FROM projects WHERE id=?',(pid,)).fetchone()
        dates=json.loads(proj['periods']);
        if period not in dates:raise MethodologyError('Нет выбранной отчётной даты')
        pos=db.execute('SELECT * FROM positions WHERE id=? AND project_id=?',(position_id,pid)).fetchone()
        if not pos:raise MethodologyError('Договор не найден')
        if field in ('ni','pfn','nvv'): v=flag(value)
        elif field=='debt': v=val(value)
        elif field=='rate': v=rate_percent(value)
        elif field=='gr':
            v=gr_value(value)
            if v not in (1,2,3,4,5,6,'ПОК'):raise MethodologyError('Недопустимая ГР')
            v=str(v)
        else:v=str(value or '').strip()
        if field=='security':
            try:v=canonical_security(v,bool(pos['micro']))
            except MethodologyError:pass  # Keep the editable classification-error state visible.
        if field=='restra' and pos['side']=='внебаланс' and v:raise MethodologyError('Реструктуризация не может быть установлена на УО')
        if field in ('gr','rate') and not str(reason).strip():raise MethodologyError('Для ручного изменения группы риска или ставки обязательно укажите причину')
        dates_to_change=[period] if field=='debt' else dates[dates.index(period):]
        posids=[position_id]
        if field in ('ni','pfn','nvv'):
            posids=[row['id'] for row in db.execute('SELECT id FROM positions WHERE project_id=? AND unp=?',(pid,pos['unp']))]
        for id_ in posids:
            for d in dates_to_change:
                old=db.execute(f'SELECT {field} FROM position_periods WHERE project_id=? AND position_id=? AND period=?',(pid,id_,d)).fetchone()
                if old is None:continue
                if field in ('gr','rate'):
                    if field=='gr':
                        db.execute('UPDATE position_periods SET gr=?,override_reason=? WHERE project_id=? AND position_id=? AND period=?',(v,reason,pid,id_,d))
                    else:
                        db.execute('UPDATE position_periods SET rate=?,override_reason=? WHERE project_id=? AND position_id=? AND period=?',(v,reason,pid,id_,d))
                else:
                    if field in ('ni','pfn','nvv','restra','security'):
                        db.execute(f'UPDATE position_periods SET {field}=?,override_reason=CASE WHEN override_reason=? THEN override_reason ELSE \'\' END WHERE project_id=? AND position_id=? AND period=?',(v,RESTORE_REASON,pid,id_,d))
                    else:
                        db.execute(f'UPDATE position_periods SET {field}=? WHERE project_id=? AND position_id=? AND period=?',(v,pid,id_,d))
                db.execute('INSERT INTO audit(project_id,at,action,position_id,period,field,old,new,reason) VALUES(?,?,?,?,?,?,?,?,?)',
                    (pid,now(),'edit',id_,d,field,str(old[field]),str(v),reason))
        for id_ in posids:calc_one(db,pid,id_,proj['fact_date'],dates,enable_warnings=False)
        db.execute('UPDATE projects SET status=? WHERE id=?',('draft',pid))
        return {'positions_recalculated':len(posids),'dates_updated':len(dates_to_change)}


def set_comment(pid,unp,comment):
    with connect() as db:
        ids=[r['id'] for r in db.execute('SELECT id FROM positions WHERE project_id=? AND unp=?',(pid,unp))]
        for id_ in ids:db.execute('UPDATE positions SET comment=?,comment_manual=1 WHERE id=?',(str(comment),id_))
        db.execute('INSERT INTO audit(project_id,at,action,field,new) VALUES(?,?,?,?,?)',(pid,now(),'comment',unp,str(comment)))
        return len(ids)


def list_projects():
    with connect() as db:
        return [dict(r) for r in db.execute('SELECT id,name,created,fact_date,status,version FROM projects ORDER BY id DESC')]


def get_state(pid):
    with connect() as db:
        p=db.execute('SELECT * FROM projects WHERE id=?',(pid,)).fetchone()
        if not p:raise ValueError('Проект не найден')
        periods=json.loads(p['periods']);uploads=[dict(r) for r in db.execute('SELECT kind,original_name,uploaded FROM uploads WHERE project_id=?',(pid,))]
        totals=[]
        for r in db.execute('''SELECT period,COUNT(*) positions,COALESCE(SUM(od),0) od,COALESCE(SUM(reserve),0) reserve,
          COALESCE(SUM(expenses),0) expenses,COALESCE(SUM(movement),0) movement,
          COALESCE(SUM(financial_state),0) financial_state,COALESCE(SUM(security_effect),0) security_effect,
          COALESCE(SUM(quality),0) quality,COALESCE(SUM(revaluation),0) revaluation, COALESCE(SUM(rounding),0) rounding
          FROM position_periods WHERE project_id=? GROUP BY period ORDER BY period''',(pid,)):
            totals.append(dict(r))
        wrns={r['kind']:r['n'] for r in db.execute('SELECT kind,count(*) n FROM warnings WHERE project_id=? GROUP BY kind',(pid,))}
        wrns_error={r['kind']:r['n'] for r in db.execute('SELECT kind,count(*) n FROM warnings WHERE project_id=? AND severity="error" GROUP BY kind',(pid,))}
        miss={r['status']:r['n'] for r in db.execute('SELECT status,count(*) n FROM missing WHERE project_id=? GROUP BY status',(pid,))}
        return {'project':dict(p),'periods':periods,'uploads':uploads,'totals':totals,'warnings':wrns,'warnings_error':wrns_error,'missing':miss}


# Wrong-risk-group means no calculated group, or a manual group that differs
# from the methodology. A NULL method_gr in legacy reports means "not yet
# checked", not an error; it is populated on the next recalculation.
RISK_GROUP_ERROR_SQL = "(COALESCE(pp.gr,'')='' OR (pp.method_gr IS NOT NULL AND COALESCE(pp.gr,'')<>pp.method_gr))"
RISK_GROUP_CORRECTED_SQL = "EXISTS(SELECT 1 FROM warnings w WHERE w.project_id=p.project_id AND w.match_key=p.match_key AND w.kind='classification' AND w.message LIKE 'ГР БП % заменена методической ГР %')"


def list_positions(pid,period,search='',page=1,limit=50,side='',zone='',gr='',sort='client'):
    page=max(1,int(page));limit=max(1,min(200,int(limit)))
    if gr not in ('','1','2','3','4','5','6','ПОК','__issues__','__error__','__corrected__'):
        raise ValueError('Недопустимый фильтр группы риска')
    if sort not in ('client','risk_errors'):
        raise ValueError('Недопустимый порядок сортировки')
    conditions=['p.project_id=?','pp.period=?'];args=[pid,period]
    if search:
        conditions.append('(p.client LIKE ? OR p.unp LIKE ? OR p.contract LIKE ?)')
        args+=['%'+search+'%']*3
    if side:conditions.append('p.side=?');args.append(side)
    if zone:conditions.append('p.zone LIKE ?');args.append('%'+zone+'%')
    if gr=='__issues__':conditions.append('('+RISK_GROUP_ERROR_SQL+' OR '+RISK_GROUP_CORRECTED_SQL+')')
    elif gr=='__error__':conditions.append(RISK_GROUP_ERROR_SQL)
    elif gr=='__corrected__':conditions.append(RISK_GROUP_CORRECTED_SQL)
    elif gr:conditions.append('pp.gr=?');args.append(gr)
    where=' AND '.join(conditions)
    order=('CASE WHEN '+RISK_GROUP_ERROR_SQL+' THEN 0 WHEN '+RISK_GROUP_CORRECTED_SQL+' THEN 1 ELSE 2 END, ' if sort=='risk_errors' else '')+'p.client,p.contract,p.id'
    with connect() as db:
        count=db.execute('SELECT count(*) n FROM positions p JOIN position_periods pp ON pp.position_id=p.id AND pp.project_id=p.project_id WHERE '+where,args).fetchone()['n']
        rows=db.execute('''SELECT p.id,p.client,p.unp,p.contract,p.parent_contract,p.ccy,p.side,p.operation,p.zone,p.src,p.rd,p.micro,p.comment,
          pp.period,pp.debt,pp.fx,pp.od,pp.ni,pp.pfn,pp.nvv,pp.restra,pp.security,pp.gr,pp.method_gr,pp.rate,pp.reserve,pp.expenses,
          pp.movement,pp.financial_state,pp.security_effect,pp.quality,pp.revaluation,pp.factors,pp.override_reason,
          CASE WHEN '''+RISK_GROUP_ERROR_SQL+''' THEN 1 ELSE 0 END AS risk_error,
          CASE WHEN '''+RISK_GROUP_CORRECTED_SQL+''' THEN 1 ELSE 0 END AS source_gr_corrected
          FROM positions p JOIN position_periods pp ON pp.position_id=p.id AND pp.project_id=p.project_id
          WHERE '''+where+' ORDER BY '+order+' LIMIT ? OFFSET ?',args+[limit,(page-1)*limit]).fetchall()
        return {'total':count,'page':page,'limit':limit,'rows':[dict(r) for r in rows]}


def list_missing(pid,status='waiting',page=1,limit=100):
    page=max(1,int(page));limit=min(200,max(1,int(limit)))
    with connect() as db:
        where='project_id=?'+(' AND status=?' if status else '')
        args=[pid]+([status] if status else [])
        total=db.execute('SELECT count(*) n FROM missing WHERE '+where,args).fetchone()['n']
        rows=db.execute('SELECT * FROM missing WHERE '+where+' ORDER BY status,client,contract LIMIT ? OFFSET ?',args+[limit,(page-1)*limit]).fetchall()
        return {'total':total,'rows':[dict(r) for r in rows]}


def list_warnings(pid,kind='',page=1,limit=100):
    page=max(1,int(page));limit=min(200,max(1,int(limit)))
    with connect() as db:
        where='project_id=?'+(' AND kind=?' if kind else '')
        args=[pid]+([kind] if kind else [])
        total=db.execute('SELECT count(*) n FROM warnings WHERE '+where,args).fetchone()['n']
        rows=db.execute('SELECT * FROM warnings WHERE '+where+' ORDER BY CASE severity WHEN "error" THEN 0 WHEN "warning" THEN 1 ELSE 2 END,id LIMIT ? OFFSET ?',args+[limit,(page-1)*limit]).fetchall()
        return {'total':total,'rows':[dict(r) for r in rows]}


def recalculate_project(pid):
    """Recalculate every position using the current factor methodology."""
    with connect() as db:
        project=db.execute('SELECT * FROM projects WHERE id=?',(pid,)).fetchone()
        if not project:raise ValueError('Проект не найден')
        periods=json.loads(project['periods'])
        if len(periods)<2:raise ValueError('Сначала постройте прогноз')
        ids=[r['id'] for r in db.execute('SELECT id FROM positions WHERE project_id=?',(pid,))]
        for position_id in ids:
            calc_one(db,pid,position_id,project['fact_date'],periods,enable_warnings=False)
        db.execute('INSERT INTO audit(project_id,at,action,reason) VALUES(?,?,?,?)',
                   (pid,now(),'recalculate_factors','Пересчёт всех договоров по новой методике факторного анализа'))
        return {'positions_recalculated':len(ids),'periods':len(periods),'methodology':'4-factor-v2'}


def factor_summary(pid,period,search='',zone='',side=''):
    with connect() as db:
        return factor_summary_in(db,pid,period,search,zone,side)


def factor_summary_in(db,pid,period,search='',zone='',side='',*,reference=False,prior_period=None,unp=''):
    positions,period_rows=(('comparison_positions','comparison_periods') if reference
                           else ('positions','position_periods'))
    args=[pid,period];conditions=['p.project_id=?','pp.period=?']
    if search:conditions.append('(p.unp LIKE ? OR p.client LIKE ? OR p.contract LIKE ?)');args+=['%'+search+'%']*3
    if zone:conditions.append('p.zone LIKE ?');args.append('%'+zone+'%')
    if side:conditions.append('p.side=?');args.append(side)
    if unp:conditions.append('p.unp=?');args.append(unp)
    prior_join=''
    incomplete='0'
    if prior_period and not reference:
        prior_join='LEFT JOIN position_periods old ON old.position_id=p.id AND old.project_id=p.project_id AND old.period=?'
        args.insert(0,prior_period)
        incomplete='(old.reserve IS NULL OR pp.reserve IS NULL)'
    sql=f"""SELECT pp.*, p.unp, {incomplete} AS incomplete FROM {positions} p
            JOIN {period_rows} pp ON pp.position_id=p.id AND pp.project_id=p.project_id
            {prior_join} WHERE """+' AND '.join(conditions)
    sums={'od':0.,'reserve':0.,'expenses':0.,'movement':0.,'financial_state':0.,
          'security_effect':0.,'quality':0.,'revaluation':0.,'rounding':0.}
    clients=set();factors=defaultdict(float);events=defaultdict(int);count=invalid=0
    for r in db.execute(sql,args):
        count+=1
        invalid+=r['incomplete']
        clients.add(r['unp'])
        for k in sums:sums[k]+=r[k] or 0
        for k,v in json.loads(r['factors'] or '{}').items():factors[k]+=v
        for k in json.loads(r['events'] or '[]'):events[k]+=1
    return {'period':period,'totals':{k:round(v,2) for k,v in sums.items()},
            'subfactors':{k:round(v,2) for k,v in factors.items()},
            'events':dict(events),'clients':len(clients),'positions':count,'incomplete':invalid,'factor_names':FACTOR_NAMES,
            'factor_groups':FACTOR_GROUPS}


SEGMENTS = ('Крупнейший', 'Крупный', 'Средний')

def client_segments(db, pid, period):
    # Segment is a client attribute; fact-only positions inherit the BP client's segment.
    column = 'segment26' if int(period[:4]) <= 2026 else 'segment27'
    values = defaultdict(set)
    for r in db.execute(f'SELECT unp,{column} segment FROM positions WHERE project_id=?', (pid,)):
        raw = ' '.join(str(r['segment'] or '').split())
        if not raw:continue
        normalized = next((name for name in SEGMENTS if raw.casefold().startswith(name.casefold())), raw)
        values[r['unp']].add(normalized)
    return {unp:(next(iter(v)) if len(v)==1 else 'Конфликт сегментов') for unp,v in values.items()}


def factor_clients(pid, period, factor, search='', side='', page=1, limit=100, zone=''):
    if factor is not None and factor not in FACTOR_NAMES:raise ValueError('Неизвестный подфактор')
    with connect() as db:
        segments=client_segments(db,pid,period)
        args=[pid,period]; where=['p.project_id=?','pp.period=?']
        if search:
            where.append('(p.unp LIKE ? OR p.client LIKE ? OR p.contract LIKE ?)');args+=['%'+search+'%']*3
        if side:where.append('p.side=?');args.append(side)
        if zone:where.append('p.zone LIKE ?');args.append('%'+zone+'%')
        grouped={}
        for r in db.execute("SELECT p.unp,p.client,p.contract,pp.factors FROM positions p JOIN position_periods pp ON pp.position_id=p.id AND pp.project_id=p.project_id WHERE "+' AND '.join(where),args):
            amounts=json.loads(r['factors'] or '{}')
            for key,value in amounts.items():
                if (factor is not None and key!=factor) or not value:continue
                item=grouped.setdefault((key,r['unp']),dict(factor=key,unp=r['unp'],client=r['client'],segment=segments.get(r['unp'],'Не указан'),amount=0.,creation=0.,recovery=0.,contracts=set()))
                item['amount']+=value
                item['creation']+=min(value,0)
                item['recovery']+=max(value,0)
                item['contracts'].add(r['contract'])
        rows=sorted(grouped.values(),key=lambda x:(-abs(x['amount']),x['unp']))
        totals={k:round(sum(r[k] for r in rows),2) for k in ('amount','creation','recovery')}
        for r in rows:
            r['contracts']=sorted(r['contracts'])
            for k in totals:r[k]=round(r[k],2)
        page=max(1,int(page));limit=max(1,int(limit))
        return dict(factor=factor,name=FACTOR_NAMES.get(factor,'Все подфакторы'),period=period,rows=rows[(page-1)*limit:page*limit],count=len(rows),page=page,totals=totals)


def client_report(pid,period,search='',limit=200,page=1):
    from client_comments import collect
    comment_periods, comments = collect(pid)
    # Group by client for the selected date.
    with connect() as db:
        allrows=db.execute('''SELECT p.unp,MAX(p.client) client,MAX(p.zone) zone,MAX(p.comment) comment,
          SUM(pp.expenses) expenses,SUM(pp.reserve) reserve,SUM(pp.movement) movement,
          SUM(pp.financial_state) financial_state,SUM(pp.security_effect) security_effect,
          SUM(pp.quality) quality,SUM(pp.revaluation) revaluation,SUM(pp.od) od
          FROM positions p JOIN position_periods pp ON p.id=pp.position_id
          WHERE p.project_id=? AND pp.period=? GROUP BY p.unp ORDER BY ABS(SUM(pp.expenses)) DESC''',(pid,period))
        segments=client_segments(db,pid,period)
        important=[]
        standard={'client':'Стандартный портфель','unp':'','expenses':0.,'reserve':0.,'movement':0.,
                  'financial_state':0.,'security_effect':0.,'quality':0.,'revaluation':0.,
                  'od':0.,'zone':'','comment':''}
        standard_count=0
        standard_segments={name:{**standard,'segment':name,'clients':0} for name in SEGMENTS}
        for r in allrows:
            row=dict(r)
            row['segment']=segments.get(row['unp'],'Не указан')
            if abs(row['expenses'] or 0)>=100000:
                if not search or search.lower() in (row['client']+' '+row['unp']).lower():important.append(row)
            else:
                bucket=standard_segments.setdefault(row['segment'],{**{k:(0. if isinstance(v,(int,float)) else v) for k,v in standard.items()},'segment':row['segment'],'clients':0})
                for key in ('expenses','reserve','movement','financial_state','security_effect','quality','revaluation','od'):
                    standard[key]+=row[key] or 0.
                    bucket[key]+=row[key] or 0.
                bucket['clients']+=1
                standard_count+=1
        count=len(important)
        important=important[(max(1,page)-1)*limit:max(1,page)*limit]
        for row in important:
            row['period_comments'] = {period: comments.get((row['unp'],period),'') for period in comment_periods}
            debt_changes=[]
            for c in db.execute('''SELECT p.ccy, SUM(CASE WHEN a.period=? THEN a.debt ELSE 0 END) debt_prev,
                SUM(CASE WHEN a.period=? THEN a.debt ELSE 0 END) debt_cur
                FROM positions p JOIN position_periods a ON a.position_id=p.id
                WHERE p.project_id=? AND p.unp=? AND a.period IN (?,?) GROUP BY p.ccy''',
                (_prior_period(db,pid,period),period,pid,row['unp'],_prior_period(db,pid,period),period)):
                delta=(c['debt_cur'] or 0)-(c['debt_prev'] or 0)
                if abs(delta)>.000001:debt_changes.append(f'{delta/1e6:+.3f} млн {c["ccy"]}')
            label='; '.join(debt_changes)
            factors=[]
            for k,name in (('movement','Движение КП'),('financial_state','Финансовое состояние'),
                           ('security_effect','Изменение обеспечения'),('revaluation','Переоценка')):
                if abs(row[k] or 0)>.005:factors.append(f'{name} {row[k]/1e6:+.6f} млн BYN')
            transitions=db.execute('''SELECT DISTINCT old.gr AS prior_gr,a.gr,old.rate AS prior_rate,a.rate
                FROM position_periods a JOIN positions p ON p.id=a.position_id
                LEFT JOIN position_periods old ON old.position_id=a.position_id AND old.period=?
                WHERE p.project_id=? AND p.unp=? AND a.period=? ORDER BY a.gr,a.rate''',
                (_prior_period(db,pid,period),pid,row['unp'],period))
            risk=', '.join(f"{v['prior_gr'] or '—'} ({v['prior_rate']}%) → {v['gr']} ({v['rate']}%)" for v in transitions)
            row['auto_comment']=('. '.join([f'{dd(period)}. ГР и ставки по договорам: {risk}',('Изменение задолженности: '+label) if label else 'Задолженность без изменений',
                'Факторы: '+(', '.join(factors) if factors else 'без изменений')])+'.')
        for k in ('expenses','reserve','movement','financial_state','security_effect','quality','revaluation','od'):
            standard[k]=round(standard[k],2)
        standard['clients']=standard_count
        return {'period':period,'important':important,'standard':standard,'standard_segments':list(standard_segments.values()),'count':count,'threshold':100000,'comment_periods':comment_periods}


def _prior_period(db,pid,period):
    p=db.execute('SELECT periods FROM projects WHERE id=?',(pid,)).fetchone()
    periods=json.loads(p['periods']);i=periods.index(period)
    return periods[i-1] if i>0 else periods[0]


def period_debt_horizon(pid,metric='debt',search='',limit=50,page=1):
    if metric not in ('debt','od','reserve','expenses','gr','rate','ni','pfn','nvv','security'):raise ValueError('Недопустимый показатель')
    with connect() as db:
        periods=json.loads(db.execute('SELECT periods FROM projects WHERE id=?',(pid,)).fetchone()['periods'])
        c=' AND (p.client LIKE ? OR p.unp LIKE ? OR p.contract LIKE ?)' if search else ''
        args=[pid]+(['%'+search+'%']*3 if search else [])
        ids=[dict(r) for r in db.execute('SELECT id,client,contract,ccy,side,unp,src,zone FROM positions p WHERE p.project_id=?'+c+' ORDER BY p.client,p.contract LIMIT ? OFFSET ?',args+[limit,(max(1,page)-1)*limit])]
        values=defaultdict(dict)
        if ids:
            q=','.join('?' for _ in ids)
            for row in db.execute(f'SELECT position_id,period,{metric} v FROM position_periods WHERE project_id=? AND position_id IN ({q})',(pid,*[x['id'] for x in ids])):
                values[row['position_id']][row['period']]=row['v']
        for r in ids:r['values']=values[r['id']]
        return {'periods':periods,'metric':metric,'rows':ids}


def save_version(pid,title):
    """Immutable snapshot for current project; may be disk-intensive for very large portfolios."""
    with connect() as db:
        p=db.execute('SELECT version FROM projects WHERE id=?',(pid,)).fetchone()
        if not p:raise ValueError('Нет проекта')
        version=db.execute('SELECT coalesce(MAX(version),0)+1 n FROM versions WHERE project_id=?',(pid,)).fetchone()['n']
        version_dir=DATA/str(pid)/'versions';version_dir.mkdir(exist_ok=True,parents=True)
        target=version_dir/f'checkpoint_{version}.sqlite3'
        # SQLite's backup API provides a consistent snapshot even with WAL enabled.
        with sqlite3.connect(str(target)) as backup:db.backup(backup)
        sources=version_dir/f'sources_{version}'
        sources.mkdir(exist_ok=True)
        try:
            for source in db.execute('SELECT kind,path FROM uploads WHERE project_id=?',(pid,)):
                original=Path(source['path'])
                if not original.is_absolute():original=ROOT/original
                if not original.exists():original=DATA/str(pid)/(source['kind']+'.xlsx')
                if not original.exists():raise ValueError(f'Не найден входной файл {source["kind"]}')
                shutil.copy2(original,sources/(source['kind']+'.xlsx'))
        except Exception:
            shutil.rmtree(sources,ignore_errors=True)
            target.unlink(missing_ok=True)
            raise
        db.execute('INSERT INTO versions(project_id,version,created,title,backup_path) VALUES(?,?,?,?,?)',(pid,version,now(),title,str(target)))
        has_errors=db.execute('SELECT COUNT(*) n FROM warnings WHERE project_id=? AND severity="error"',(pid,)).fetchone()['n']
        db.execute('UPDATE projects SET status=?,version=? WHERE id=?',('needs_review' if has_errors else 'fixed',version,pid))
        return {'version':version,'path':str(target),'title':title}


def list_versions(pid):
    with connect() as db:return [dict(r) for r in db.execute('SELECT id,version,created,title FROM versions WHERE project_id=? ORDER BY version DESC',(pid,))]


def restore_version(pid,version):
    """Restore only one project's saved tables; leave other plans and version history intact."""
    with connect() as db:
        saved=db.execute('SELECT * FROM versions WHERE project_id=? AND version=?',(pid,version)).fetchone()
        if not saved:raise ValueError('Сохранённая версия не найдена')
        checkpoint=DATA/str(pid)/'versions'/f'checkpoint_{version}.sqlite3'
        if not checkpoint.is_file():raise ValueError('Снимок этой версии отсутствует на диске')
        with sqlite3.connect(str(checkpoint)) as source:
            source.row_factory=sqlite3.Row
            project=source.execute('SELECT * FROM projects WHERE id=?',(pid,)).fetchone()
            if project is None:raise ValueError('Проект не найден в сохранённой версии')
            tables=('uploads','fx','fact_contracts','fact_clients','positions','position_periods',
                    'missing','warnings','audit','current_portfolios','current_contracts',
                    'comparison_plans','comparison_positions','comparison_periods',
                    'plan_event_batches','plan_events')
            snapshot_tables={r[0] for r in source.execute("SELECT name FROM sqlite_master WHERE type='table'")}
            contents={table:[dict(r) for r in source.execute(f'SELECT * FROM {table} WHERE project_id=?',(pid,))]
                      if table in snapshot_tables else [] for table in tables}
            saved_risk=[dict(r) for r in source.execute('''SELECT ir.* FROM input_risk ir
                JOIN positions p ON p.id=ir.position_id WHERE p.project_id=?''',(pid,))] if 'input_risk' in snapshot_tables else []
        # Protect the live state before altering it, including all current Excel sources.
        safety=save_version(pid,'Автосохранение перед восстановлением v'+str(version))
        position_ids=[r['id'] for r in db.execute('SELECT id FROM positions WHERE project_id=?',(pid,))]
        if position_ids:
            db.executemany('DELETE FROM input_risk WHERE position_id=?',((x,) for x in position_ids))
        for table in reversed(tables):db.execute(f'DELETE FROM {table} WHERE project_id=?',(pid,))
        saved_status=('needs_review' if any(r.get('severity')=='error' for r in contents['warnings']) else 'fixed')
        db.execute('UPDATE projects SET name=?,fact_date=?,periods=?,status=?,version=?,note=? WHERE id=?',
                   (project['name'],project['fact_date'],project['periods'],saved_status,version,project['note'],pid))
        remap={'positions':{},'comparison_positions':{},'plan_event_batches':{}}
        for table in tables:
            target_cols={r['name'] for r in db.execute(f'PRAGMA table_info({table})')}
            for original in contents[table]:
                row={key:value for key,value in original.items() if key in target_cols}
                if table=='position_periods':row['position_id']=remap['positions'][row['position_id']]
                if table=='comparison_periods':row['position_id']=remap['comparison_positions'][row['position_id']]
                if table=='plan_events':row['batch_id']=remap['plan_event_batches'][row['batch_id']]
                if table in ('missing','current_contracts','audit') and row.get('position_id') is not None:
                    row['position_id']=remap['positions'].get(row['position_id'],row['position_id'])
                if table=='current_contracts' and row.get('mapped_id') is not None:
                    row['mapped_id']=remap['positions'].get(row['mapped_id'],row['mapped_id'])
                old_id=row.pop('id',None)
                cols=list(row)
                cursor=db.execute(f'INSERT INTO {table} ({",".join(cols)}) VALUES ({",".join("?" for _ in cols)})',tuple(row.values()))
                if table in remap:remap[table][old_id]=cursor.lastrowid
        for original in saved_risk:
            row={k:v for k,v in original.items() if k!='position_id'}
            row['position_id']=remap['positions'][original['position_id']]
            cols=list(row)
            db.execute(f'INSERT INTO input_risk ({",".join(cols)}) VALUES ({",".join("?" for _ in cols)})',tuple(row.values()))
        db.execute('INSERT INTO audit(project_id,at,action,old,new,reason) VALUES(?,?,?,?,?,?)',
                   (pid,now(),'restore_version',str(safety['version']),str(version),'Восстановление сохранённой версии'))
    sources=DATA/str(pid)/'versions'/f'sources_{version}'
    restored_files=[]
    if sources.is_dir():
        for kind in ('bp','fact','rates'):
            archived=sources/(kind+'.xlsx')
            if archived.is_file():
                shutil.copy2(archived,DATA/str(pid)/(kind+'.xlsx'))
                restored_files.append(kind)
    return {'version':version,'safety_version':safety['version'],'sources_restored':restored_files,
            'legacy_sources':not sources.is_dir()}
