import unittest
from client_comments import describe

class NarrativeComments(unittest.TestCase):
    def row(self,**kw):
        return dict(dict(contract='Новый договор 1',operation='Кредит',ccy='USD',debt=200000,events='["new_contract_base"]',ni=1,pfn=0,nvv=0,security='Обеспеченный',restra='',gr='2',rate=5,revaluation=0,override_reason='',expenses=-100000),**kw)

    def test_new_contract_and_flags(self):
        current=self.row()
        text=describe(current,None)
        for phrase in ('Новый договор','200 000,00 USD','ГР 2','Признание НИ'):
            self.assertIn(phrase,text)
        self.assertNotIn('Факторы',text)

    def test_release_ni_and_reclassification(self):
        old=self.row()
        current=self.row(events='[]',ni=0,gr='1',rate=.5,debt=150000)
        text=describe(current,old)
        for phrase in ('Снятие НИ','из ГР 2 в ГР 1','Снижение задолженности','150 000,00 USD'):
            self.assertIn(phrase,text)
        self.assertNotIn('Новый договор.',text)
