"""Shift template columns while retaining the original workbook parts."""
from io import BytesIO
import re
from zipfile import ZipFile
from xml.etree import ElementTree as ET
from openpyxl.formula.tokenizer import Tokenizer
from openpyxl.utils import column_index_from_string, get_column_letter

NS='http://schemas.openxmlformats.org/spreadsheetml/2006/main'
Q=lambda name:'{'+NS+'}'+name
PREFIX='Комментарий на '


def shift(root, count, remove=False):
    def address(text):
        def replace(match):
            col=column_index_from_string(match[2])
            if col>=5:
                col=col-count if remove else col+count
            return match[1]+get_column_letter(max(1,col))+match[3]
        return re.sub(r'(\$?)([A-Z]{1,3})(\$?\d+)',replace,text)
    for element in root.iter():
        if element.tag==Q('row') and remove:
            for cell in list(element):
                col=column_index_from_string(re.match('[A-Z]+',cell.get('r'))[0])
                if 5<=col<5+count:element.remove(cell)
        for attr in ('r','ref','sqref','topLeftCell'):
            if attr in element.attrib and not element.attrib[attr].isdigit():
                element.set(attr,address(element.attrib[attr]))
        if element.tag==Q('f') and element.text:
            tokens=Tokenizer('='+element.text).items
            for token in tokens:
                if token.type=='OPERAND' and token.subtype=='RANGE':
                    token.value=address(token.value)
            element.text=''.join(t.value for t in tokens)
    cols=root.find(Q('cols'))
    if cols is not None:
        for col in list(cols):
            start,end=int(col.get('min')),int(col.get('max'))
            if remove and start>=5 and end<5+count:
                cols.remove(col)
            elif start>=5:
                col.set('min',str(start-count if remove else start+count))
                col.set('max',str(end-count if remove else end+count))
        if not remove:
            ET.SubElement(cols,Q('col'),min='5',max=str(4+count),width='65',customWidth='1')
    return root


def normalize(source):
    with ZipFile(source) as archive:
        parts={i.filename:(i,archive.read(i.filename)) for i in archive.infolist()}
    count=0
    for path,(info,data) in parts.items():
        if not path.startswith('xl/worksheets/') or not path.endswith('.xml'):continue
        root=ET.fromstring(data)
        first=root.find(Q('sheetData')+'/'+Q('row'))
        if first is None:continue
        count=sum(1 for c in first if ''.join(c.itertext()).startswith(PREFIX))
        if count:
            from client_template_report import serialize
            parts[path]=(info,serialize(shift(root,count,True)))
            break
    if not count:return source
    result=BytesIO()
    with ZipFile(result,'w') as archive:
        for info,data in parts.values():archive.writestr(info,data)
    result.seek(0)
    return result


def append(xml, periods, comments, client_rows):
    if not periods:return
    from client_template_report import Q
    count=len(periods)
    from client_template_report import serialize
    styles_path='xl/styles.xml'
    styles=ET.fromstring(xml.parts[styles_path][1])
    formats=styles.find(Q('cellXfs'))
    style_id=len(formats)
    entry=ET.SubElement(formats,Q('xf'),numFmtId='0',fontId='0',fillId='0',borderId='0',xfId='0',applyAlignment='1')
    ET.SubElement(entry,Q('alignment'),wrapText='1',vertical='top')
    formats.set('count',str(len(formats)))
    xml.parts[styles_path]=(xml.parts[styles_path][0],serialize(styles))
    shift(xml.root,count)
    # Existing cells have moved. Refresh addresses before adding the new columns.
    xml.cells={cell.get('r'):cell for row in xml.data for cell in row}
    for i,period in enumerate(periods,5):
        xml.put(1,i,PREFIX+period,newrow=True)
        for unp,row in client_rows.items():
            xml.put(row,i,comments.get((unp,period)),newrow=True)
            xml.cells[get_column_letter(i)+str(row)].set('s',str(style_id))
    dimension=xml.root.find(Q('dimension'))
    if dimension is not None:dimension.set('ref',f'A1:{get_column_letter(42+count)}{max(xml.rows)}')
