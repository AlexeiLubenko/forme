"""Populate the bank's client RnR template without rewriting untouched XLSX parts.

Amounts in SQLite are BYN, amounts in the report are millions of BYN.
The closing date 01.12 represents November. The baseline has no flow.
"""
from __future__ import annotations

from collections import defaultdict
from io import BytesIO
from datetime import date, timedelta
from decimal import Decimal
import json
import math
import posixpath
import re
from zipfile import ZipFile
from xml.etree import ElementTree as ET

from openpyxl import load_workbook
from openpyxl.formula.tokenizer import Tokenizer
from openpyxl.utils import get_column_letter, column_index_from_string
import engine
from risk import FACTOR_NAMES, gr_value, is_black_zone

NS = 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'
REL = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships'
Q = lambda name: '{'+NS+'}'+name
SEGMENTS = ('Крупнейший', 'Крупный', 'Средний')
MONTHS = ('январь','февраль','март','апрель','май','июнь','июль','август','сентябрь','октябрь','ноябрь','декабрь')


def serialize(root):
    # Compatibility attributes reference prefix names, so those prefixes must survive.
    prefixes={'x14ac':'http://schemas.microsoft.com/office/spreadsheetml/2009/9/ac',
              'x15':'http://schemas.microsoft.com/office/spreadsheetml/2010/11/main',
              'x15ac':'http://schemas.microsoft.com/office/spreadsheetml/2010/11/ac'}
    for prefix,uri in prefixes.items(): ET.register_namespace(prefix,uri)
    data=ET.tostring(root,encoding='utf-8')
    for prefix,uri in prefixes.items():
        if (b'xmlns:'+prefix.encode()+b'=') not in data:
            data=data.replace(b'>',(' xmlns:'+prefix+'="'+uri+'">').encode(),1)
    return data


def segment(value):
    text = str(value or '').strip().casefold()
    if text in ('кшб','крупнейший') or text.startswith('крупнейш'): return 'Крупнейший'
    if text in ('кб','крупный') or text.startswith('крупн'): return 'Крупный'
    if text in ('сб','средний') or text.startswith('средн'): return 'Средний'
    if text == 'ммб' or text.startswith(('малый','микро')): return 'ММБ'
    if text in ('фи','финансовые институты'): return 'ФИ'
    raise ValueError(f'Неизвестный сегмент: {value!r}')


def number(value, label):
    if value in (None, ''): return Decimal(0)
    if isinstance(value, bool) or not isinstance(value, (int, float, Decimal)) or not math.isfinite(float(value)):
        raise ValueError(f'{label}: требуется числовое значение')
    return Decimal(str(value))


def forecast(pid, template_segments):
    """Client totals before thresholding; errors must not disappear into SUM(NULL)."""
    with engine.connect() as db:
        project = db.execute('SELECT * FROM projects WHERE id=?', (pid,)).fetchone()
        if not project: raise ValueError('Проект не найден')
        periods = json.loads(project['periods'])
        if len(periods) < 2: raise ValueError('Сначала постройте прогноз')
        segment_sources={y:engine.client_segments(db,pid,str(y)+'-01-01') for y in (2026,2027)}
        rows = db.execute('''SELECT p.unp,p.client,p.zone,p.segment26,p.segment27,
            pp.period,pp.expenses,pp.reserve,pp.gr,pp.rate
            FROM positions p JOIN position_periods pp ON pp.position_id=p.id AND pp.project_id=p.project_id
            WHERE p.project_id=? ORDER BY pp.period,p.unp,p.id''', (pid,)).fetchall()
    intervals = {}
    for prev, cur in zip(periods, periods[1:]):
        start, end = date.fromisoformat(prev), date.fromisoformat(cur)
        if end <= start:
            raise ValueError('Для отчёта нужны последовательные отчётные даты на первое число')
        intervals[cur] = (start, end-timedelta(days=1))
    totals, info, flags = defaultdict(Decimal), {}, defaultdict(lambda: [False,False])
    segs = {}
    for r in rows:
        if r['period'] not in intervals: continue
        unp = engine.normalize_unp(r['unp'])
        if not unp: raise ValueError('В прогнозе есть клиент без УНП')
        if r['expenses'] is None or r['reserve'] is None:
            raise ValueError(f'Не рассчитан резерв: {unp}, {r["period"]}')
        end = intervals[r['period']][1]
        source_segment = r['segment27'] if end.year >= 2027 else r['segment26']
        try:
            # The uploaded client block owns the segment for the entire report.
            # Source segments only classify clients absent from the template.
            if unp in template_segments:
                seg = template_segments[unp]
            else:
                seg = segment(source_segment or segment_sources.get(end.year,{}).get(unp))
        except ValueError as exc:
            if not r['expenses'] and unp not in template_segments: continue
            raise ValueError(f'{exc}. УНП {unp}, отчётная дата {r["period"]}') from exc
        key = (r['period'],unp)
        if key in segs and segs[key] != seg:
            raise ValueError(f'Разные сегменты одного клиента: {unp}, {r["period"]}')
        segs[key] = seg
        totals[key] += number(r['expenses'], unp)
        info.setdefault(unp, {'name':r['client'] or unp,'segment':seg})
        flags[key][0] |= is_black_zone(r['zone'])
        flags[key][1] |= gr_value(r['gr']) == 2 and abs(float(r['rate'] or 0)-20) < 1e-8
    if not totals: raise ValueError('В проекте нет рассчитанных клиентских расходов')
    return intervals, totals, info, segs, flags


def layout(ws):
    starts = {}
    for row in range(5, ws.max_row+1):
        label = str(ws.cell(row,1).value or '').strip()
        if label in (*SEGMENTS, 'ММБ'): starts[label] = row
    if len(starts) != 4: raise ValueError('Не найдены клиентские блоки КШБ, КБ, СБ и ММБ')
    year = ws.cell(1,29).value
    if not isinstance(year,int): raise ValueError('В AC1 должен быть год отчёта')
    # Validate the supplied form rather than accidentally writing into another report.
    if str(ws.cell(3,30).value).strip() != 'Прогноз' or str(ws.cell(2,4).value).strip() != 'Наименование':
        raise ValueError('Структура файла не соответствует поклиентному шаблону')
    cols = []
    for month in range(1,13):
        left = 5+(month-1)*2
        if str(ws.cell(2,left).value).strip().casefold() != MONTHS[month-1]:
            raise ValueError('Нарушена последовательность месяцев в шаблоне')
        for c in (left,left+1):
            if str(ws.cell(3,c).value).strip() == 'Прогноз': cols.append((c,year,month,month))
    for q in range(1,5):
        c=30+q*2
        if str(ws.cell(3,c).value).strip() == 'Прогноз': cols.append((c,year+1,3*q-2,3*q))
    labels = {}
    for r in range(starts['ММБ']+1,ws.max_row+1):
        text = ' '.join(str(ws.cell(r,1).value or '').strip().split())
        if text: labels.setdefault(text,[]).append(r)
    def find(label):
        found=labels.get(label,[])
        if len(found)!=1: raise ValueError('Не найдена однозначная итоговая строка: '+label)
        return found[0]
    summary = {seg: find('в т.ч. '+short) for seg,short in zip(SEGMENTS,('КШБ','КБ','СБ'))}
    return starts,year,cols,summary,find


class XmlEditor:
    """Keep original workbook XML/styles and cached results of generated formulas."""
    def __init__(self, source, ws, insertions):
        self.ws=ws
        with ZipFile(source) as z: self.parts={i.filename:(i,z.read(i.filename)) for i in z.infolist()}
        book=ET.fromstring(self.parts['xl/workbook.xml'][1])
        rels=ET.fromstring(self.parts['xl/_rels/workbook.xml.rels'][1])
        targets={r.attrib['Id']:r.attrib['Target'] for r in rels}
        sheets=book.find(Q('sheets'))
        self.paths={s.attrib['name']:posixpath.normpath(posixpath.join('xl',targets[s.attrib['{'+REL+'}id']])).lstrip('/') for s in sheets}
        for name,path in list(self.paths.items()): self.paths[name]=path.lstrip('/')
        self.path=self.paths[ws.title]
        self.root=ET.fromstring(self.parts[self.path][1])
        self.data=self.root.find(Q('sheetData'))
        self.inserts=insertions
        self.maprow=lambda r: r+sum(n for at,n in insertions.items() if r>=at)
        if insertions:
            # Update local references and formulas, including references from other sheets.
            for element in self.root.iter():
                for attr in ('ref','sqref','topLeftCell'):
                    if attr in element.attrib: element.attrib[attr]=self.references(element.attrib[attr])
                if element.tag==Q('c'): element.set('r',self.references(element.attrib['r']))
                if element.tag==Q('row'): element.set('r',str(self.maprow(int(element.attrib['r']))))
            for name,path in self.paths.items():
                root=self.root if path==self.path else ET.fromstring(self.parts[path][1])
                for f in root.iter(Q('f')):
                    if f.text: f.text=self.formula(f.text, name==ws.title)
                if path!=self.path: self.parts[path]=(self.parts[path][0],serialize(root))
        if insertions:
            for merged in self.root.iter(Q('mergeCell')):
                match=re.fullmatch(r'A(\d+):A(\d+)',merged.get('ref',''))
                if match:
                    for at,n in insertions.items():
                        if int(match[2])==self.maprow(at)-n-1:
                            merged.set('ref',f'A{match[1]}:A{int(match[2])+n}')
        self.rows={int(r.attrib['r']):r for r in self.data}
        self.cells={c.attrib['r']:c for r in self.data for c in r}
        self.changed=set()

    def references(self,text):
        return re.sub(r'(\$?[A-Z]{1,3}\$?)(\d+)',lambda m:m[1]+str(self.maprow(int(m[2]))),text)

    def formula(self,text,local):
        out=[]
        for token in Tokenizer('='+text).items:
            value=token.value
            if token.type=='OPERAND' and token.subtype=='RANGE':
                if '!' in value:
                    sheet,ref=value.rsplit('!',1)
                    if sheet.strip("'").replace("''", "'")==self.ws.title: value=sheet+'!'+self.references(ref)
                elif local: value=self.references(value)
            out.append(value)
        return ''.join(out)

    def put(self,oldrow,col,value,formula=None,newrow=False):
        row=oldrow if newrow else self.maprow(oldrow)
        address=get_column_letter(col)+str(row)
        element=self.cells.get(address)
        if element is None:
            r=self.rows.get(row)
            if r is None:
                r=ET.Element(Q('row'),{'r':str(row)})
                self.data.append(r);self.rows[row]=r
            element=ET.SubElement(r,Q('c'),{'r':address})
            # Existing form's row formatting is used for added client rows.
            original=self.ws.cell(min(oldrow,self.ws.max_row),col)
            if original.has_style: element.set('s',str(original.style_id))
            self.cells[address]=element
        for child in list(element): element.remove(child)
        element.attrib.pop('t',None)
        if formula is not None:
            ET.SubElement(element,Q('f')).text=formula.lstrip('=')
        if value is None: pass
        elif isinstance(value,str):
            element.set('t','inlineStr');ET.SubElement(ET.SubElement(element,Q('is')),Q('t')).text=value
        else:
            ET.SubElement(element,Q('v')).text=format(value,'f') if isinstance(value,Decimal) else str(value)
        self.changed.add(address)

    def save(self,path):
        self.data[:]=sorted(self.data,key=lambda r:int(r.attrib['r']))
        for row in self.data:
            row[:]=sorted(row,key=lambda c:column_index_from_string(re.match(r'[A-Z]+',c.attrib['r'])[0]))
        self.parts[self.path]=(self.parts[self.path][0],serialize(self.root))
        # Cached formulas are supplied for this report; Excel should also recalculate on open.
        root=ET.fromstring(self.parts['xl/workbook.xml'][1])
        calc=root.find(Q('calcPr'))
        if calc is None: calc=ET.SubElement(root,Q('calcPr'))
        calc.set('fullCalcOnLoad','1')
        self.parts['xl/workbook.xml']=(self.parts['xl/workbook.xml'][0],serialize(root))

        with ZipFile(path,'w') as z:
            for info,data in self.parts.values(): z.writestr(info,data)


def build_report(pid, template_path, output_path):
    from report_comment_columns import normalize
    template_path=normalize(template_path)
    book=load_workbook(template_path,data_only=False)
    cached=load_workbook(template_path,data_only=True)
    try:
        ws=book.active;values=cached[ws.title]
        starts,year,columns,summary,find=layout(ws)
        existing={};slots={};added={};known_segments={}
        for i,seg in enumerate(SEGMENTS):
            end=starts[(*SEGMENTS,'ММБ')[i+1]]
            slots[seg]=[]
            for row in range(starts[seg],end):
                unp=engine.normalize_unp(ws.cell(row,3).value)
                if unp:
                    if unp in existing: raise ValueError('УНП повторяется в шаблоне: '+unp)
                    existing[unp]=row
                    known_segments[unp]=seg
                elif all(ws.cell(row,c).value is None for c in range(2,ws.max_column+1)):
                    slots[seg].append(row)
        for r in range(starts['ММБ'],find('Расходы на резервы по сегментам:')):
            u=engine.normalize_unp(ws.cell(r,3).value)
            if u: known_segments[u]='ММБ'
        intervals,totals,info,segs,flags=forecast(pid,known_segments)
        over_limit={u for (_,u),v in totals.items() if abs(v)>100000}
        for unp,meta in info.items():
            if unp not in known_segments and meta['segment'] in SEGMENTS and unp in over_limit:
                added[unp]=meta['segment']
        insertions={}
        for i,seg in enumerate(SEGMENTS):
            need=sum(s==seg for s in added.values())-len(slots[seg])
            if need>0: insertions[starts[(*SEGMENTS,'ММБ')[i+1]]]=need
        xml=XmlEditor(template_path,ws,insertions)
        extra={};at_count=defaultdict(int)
        for unp,seg in sorted(added.items(),key=lambda item:(SEGMENTS.index(item[1]),item[0])):
            if slots[seg]: existing[unp]=slots[seg].pop(0)
            else:
                end=starts[(*SEGMENTS,'ММБ')[SEGMENTS.index(seg)+1]]
                extra[unp]=xml.maprow(end)-insertions[end]+at_count[end];at_count[end]+=1
            r=extra.get(unp,existing.get(unp))
            for c,v in ((3,unp),(4,info[unp]['name'])): xml.put(r,c,v,newrow=unp in extra)
        listed=set(existing)|set(extra)
        output={}; written=[]
        def read(r,c):
            if (r,c) in output:return output[r,c]
            raw=ws.cell(r,c).value
            if isinstance(raw,str) and raw.startswith('=') and values.cell(r,c).value is None:
                raise ValueError(f'{ws.cell(r,c).coordinate}: формула без сохранённого результата; пересохраните файл в Excel')
            return number(values.cell(r,c).value,ws.cell(r,c).coordinate)
        def put(r,c,v,formula=None):
            output[r,c]=v;xml.put(r,c,v,formula)
        def ref(r,c):return f'{get_column_letter(c)}{xml.maprow(r)}'
        def aggregate(r,c,refs,vals):
            put(r,c,sum(vals,Decimal(0)),'+'.join(ref(a,b) for a,b in refs) or '0')
        for col,cy,first,last in columns:
            start=date(cy,first,1)
            finish=date(cy+1,1,1) if last==12 else date(cy,last+1,1)
            relevant=[p for p,(a,b) in intervals.items() if start<=a and b<finish]
            # No project date for a template column means leave the input as supplied.
            if not relevant:continue
            crossing=[p for p,(a,b) in intervals.items() if a<finish and b>=start and p not in relevant]
            if crossing:raise ValueError('Прогнозный интервал пересекает границу колонки шаблона: '+', '.join(crossing))

            written.append(col)
            for unp in listed:
                if unp not in info:continue  # unmatched supplied clients retain their input
                amount=sum((totals.get((p,unp),Decimal(0)) for p in relevant),Decimal(0))/1000000
                if unp in extra:xml.put(extra[unp],col,amount,newrow=True)
                else:put(existing[unp],col,amount)
            buckets=defaultdict(Decimal)
            for p in relevant:
                for (period,unp),amount in totals.items():
                    if period!=p or segs[period,unp] not in SEGMENTS:continue
                    black,spok=flags[period,unp]
                    category=4 if black else 3 if spok else 1 if unp in listed else 2
                    buckets[segs[period,unp],category]+=amount/1000000
            for seg in SEGMENTS:
                base=summary[seg]
                for category in range(1,5):put(base+category,col,buckets[seg,category])
                aggregate(base,col,[(base+k,col) for k in range(1,5)],[read(base+k,col) for k in range(1,5)])
            medium=find('в т.ч. Средний+')
            aggregate(medium,col,[(summary[s],col) for s in SEGMENTS],[read(summary[s],col) for s in SEGMENTS])
            mmb,fi=find('в т.ч. ММБ'),find('в т.ч. ФИ')
            yl=find('ЮЛ (за месяц)')
            aggregate(yl,col,[(medium,col),(mmb,col),(fi,col)],[read(medium,col),read(mmb,col),read(fi,col)])
            drpa=next(r for r in range(yl+1,yl+4) if 'ДРПА' in str(ws.cell(r,1).value) and 'без' not in str(ws.cell(r,1).value))
            drpa_refs=[(summary[s]+4,col) for s in SEGMENTS]+[(mmb+5,col)]
            aggregate(drpa,col,drpa_refs,[read(*x) for x in drpa_refs])
            put(drpa-1,col,read(yl,col)-read(drpa,col),f'{ref(yl,col)}-{ref(drpa,col)}')
        # Annual client totals combine supplied monthly facts with forecast flows.
        for unp in listed:
            r=extra.get(unp,existing.get(unp)); is_extra=unp in extra
            for cy,annual,variance,plan_col in ((year,30,42,29),(year+1,40,41,39)):
                source_cols=[6+2*i for i in range(12)] if cy==year else [32,34,36,38]
                if not any(c in written for c in source_cols):continue
                vals=[]
                for c in source_cols:
                    if is_extra:
                        element=xml.cells.get(get_column_letter(c)+str(r));v=element.find(Q('v')) if element is not None else None
                        vals.append(Decimal(v.text) if v is not None else Decimal(0))
                    else:vals.append(read(r,c))
                total=sum(vals,Decimal(0));target=r if is_extra else xml.maprow(r)
                formula='+'.join(f'{get_column_letter(c)}{target}' for c in source_cols)
                xml.put(r,annual,total,formula,newrow=is_extra)
                plan=Decimal(0) if is_extra else read(r,plan_col)
                xml.put(r,variance,total-plan,f'{get_column_letter(annual)}{target}-{get_column_letter(plan_col)}{target}',newrow=is_extra)
        # Summary cumulative columns and totals use the preserved MMB and FI inputs.
        calcrows=[r+k for r in summary.values() for k in range(5)]+[find('в т.ч. Средний+'),find('ЮЛ (за месяц)')]
        yl=find('ЮЛ (за месяц)');cum=find('ЮЛ (накопленным)')
        calcrows += [yl+1,yl+2]
        for col in written:
            source_cols=([6+2*i for i in range((col-6)//2+1)] if col<=28 else [c for c in (32,34,36,38) if c<=col])
            for offset in range(3):aggregate(cum+offset,col,[(yl+offset,c) for c in source_cols],[read(yl+offset,c) for c in source_cols])
        for annual,variance,plan_col,source_cols in ((30,42,29,list(range(6,29,2))),(40,41,39,[32,34,36,38])):
            if not any(c in written for c in source_cols):continue
            for r in calcrows:
                aggregate(r,annual,[(r,c) for c in source_cols],[read(r,c) for c in source_cols])
                put(r,variance,read(r,annual)-read(r,plan_col),f'{ref(r,annual)}-{ref(r,plan_col)}')
            for offset in range(3):put(cum+offset,annual,read(yl+offset,annual),ref(yl+offset,annual))
        balances={}
        for unp in listed:
            r=existing.get(unp)
            for period,(start,end) in intervals.items():
                cy=end.year
                if cy not in (year,year+1):continue
                if cy==year:
                    closed=[6+i*2 for i in range(end.month) if ws.cell(3,6+i*2).value=='Факт']
                    plan=[5+i*2 for i in range(end.month)]
                else:
                    closed=[]
                    plan=[31+i*2 for i in range((end.month+2)//3)]
                historical=sum((read(r,c) for c in closed),Decimal(0)) if r else Decimal(0)
                predicted=sum((totals.get((d,unp),0) for d,(_,b) in intervals.items()
                               if b.year==cy and d<=period and (cy!=year or 4+b.month*2 not in closed)),Decimal(0))/1000000
                accumulated=historical+predicted
                # In months preceding the rebudget the template carries actuals in both columns.
                budget=sum((read(r,c) for c in plan),Decimal(0)) if r else Decimal(0)
                balances[unp,period]=(float(accumulated),float(accumulated-budget))
        add_details(xml,pid,listed,intervals,balances)
        from client_comments import collect
        from report_comment_columns import append
        comment_periods, comments = collect(pid)
        client_rows = {unp:xml.maprow(row) for unp,row in existing.items()}
        client_rows.update(extra)
        append(xml,comment_periods,comments,client_rows)
        xml.save(output_path)
        return {'added_clients':len(added),'matched_clients':sum(u in info for u in existing if u not in added),
                'forecast_columns':len(written),'units':'млн BYN'}
    finally:
        book.close();cached.close()

def add_details(xml,pid,listed,intervals,balances):
    """One row per position/date keeps mixed risk groups and offsetting factors visible."""
    from openpyxl import Workbook
    from zipfile import ZipInfo, ZIP_DEFLATED
    book=Workbook(write_only=True)
    sheet=book.create_sheet('Комментарии')
    sheet.freeze_panes='E2'
    for col,width in zip('ABCDEFGHIJKLM',(16,18,36,23,19,18,18,20,20,20,24,24,105)):
        sheet.column_dimensions[col].width=width
    sheet.append(['Отчётная дата','УНП','Клиент','Договор','Операция','ГР ранее','ГР сейчас',
                  'Резерв ранее, млн BYN','Резерв сейчас, млн BYN','РнР, млн BYN','Накоплено по УНП, млн BYN','Отклонение по УНП, млн BYN','Комментарий за период'])
    previous={}
    row_count=1
    with engine.connect() as db:
        rows=db.execute("""SELECT p.unp,p.client,p.contract,p.operation,p.comment,pp.* FROM positions p
            JOIN position_periods pp ON pp.position_id=p.id AND pp.project_id=p.project_id
            WHERE p.project_id=? ORDER BY p.unp,p.id,pp.period""",(pid,))
        for r in rows:
            if engine.normalize_unp(r['unp']) not in listed: continue
            old=previous.get(r['position_id'])
            previous[r['position_id']]=r
            if r['period'] not in intervals:continue
            comment=[]
            if old:
                comment.append(f"ГР {old['gr']} → {r['gr']}, ставка {old['rate']}% → {r['rate']}%.")
                for key,label in [('ni','НИ'),('pfn','ПФН'),('nvv','НВВ'),('security','Обеспечение'),('restra','Реструктуризация')]:
                    if old[key]!=r[key]:comment.append(f"{label}: {old[key] or 'нет'} → {r[key] or 'нет'}.")
            else:comment.append(f"Первая позиция в расчёте. ГР {r['gr']}, ставка {r['rate']}%.")
            factors=json.loads(r['factors'] or '{}')
            factors.update({'revaluation':r['revaluation'],'rounding':r['rounding']})
            events=json.loads(r['events'] or '[]')
            names=dict(FACTOR_NAMES,revaluation='Переоценка',rounding='Остаток сверки')
            parts=[f"{names.get(k,k)} {float(v or 0)/1e6:+.8f}" for k,v in factors.items() if v or k in events]
            comment.append('Факторы, млн BYN: '+', '.join(parts)+'.' if parts else 'Изменений по рассчитанным факторам нет.')
            if r['override_reason']:comment.append('Основание корректировки: '+r['override_reason'])
            if r['comment']:comment.append('Комментарий аналитика: '+r['comment'])
            from openpyxl.cell import WriteOnlyCell
            row=[engine.dd(r['period']),r['unp'],r['client'],r['contract'],r['operation'],old['gr'] if old else None,r['gr'],
                 old['reserve']/1e6 if old and old['reserve'] is not None else None,r['reserve']/1e6,r['expenses']/1e6,*balances.get((engine.normalize_unp(r['unp']),r['period']),(None,None)),' '.join(comment)]
            cells=[]
            for v in row:
                cell=WriteOnlyCell(sheet,value=v)
                if isinstance(v,str):cell.data_type='s'
                cells.append(cell)
            sheet.append(cells)
            row_count+=1
    sheet.auto_filter.ref=f'A1:M{row_count}'
    buf=BytesIO();book.save(buf)
    with ZipFile(buf) as z: payload=z.read('xl/worksheets/sheet1.xml')
    # Generated sheet uses inline text and the default numeric style only.
    title='Комментарии РнР'
    if title in xml.paths:
        path=xml.paths[title];xml.parts[path]=(xml.parts[path][0],payload);return
    path='xl/worksheets/rnrDetails.xml'
    def load(key):return ET.fromstring(xml.parts[key][1])
    def store(key,root):xml.parts[key]=(xml.parts[key][0],serialize(root))
    relkey='xl/_rels/workbook.xml.rels';rels=load(relkey)
    ids={r.get('Id') for r in rels};rid='rIdRnR'
    while rid in ids:rid+='x'
    ET.SubElement(rels,rels[0].tag,Id=rid,Type=REL+'/worksheet',Target='worksheets/rnrDetails.xml');store(relkey,rels)
    wb=load('xl/workbook.xml');ss=wb.find(Q('sheets'))
    ET.SubElement(ss,Q('sheet'),{'name':title,'sheetId':str(max(int(x.get('sheetId')) for x in ss)+1),'{'+REL+'}id':rid})
    store('xl/workbook.xml',wb)
    key='[Content_Types].xml';ct=load(key)
    ET.SubElement(ct,ct.tag.replace('Types','Override'),PartName='/'+path,ContentType='application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml');store(key,ct)
    entry=ZipInfo(path);entry.compress_type=ZIP_DEFLATED;xml.parts[path]=(entry,payload)
