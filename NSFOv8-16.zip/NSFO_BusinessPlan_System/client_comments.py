"""Narrative client events for each forecast date."""
import json
from collections import defaultdict
import engine
from risk import is_new_contract


def describe(current, previous):
    def money(value):
        return f"{float(value or 0):,.2f}".replace(',', ' ').replace('.', ',')
    debt = current['debt'] or 0
    before = previous['debt'] or 0 if previous else 0
    currency = current['ccy'] or ''
    events = json.loads(current['events'] or '[]')
    new = ('new_contract_base' in events or
           (is_new_contract(current['contract']) and before == 0 and debt > 0))
    parts = []
    if new:
        parts.append(f"Новый договор. Задолженность {money(debt)} {currency}.")
    elif debt != before:
        action = 'Увеличение' if debt > before else 'Снижение'
        parts.append(f"{action} задолженности с {money(before)} до {money(debt)} {currency}.")
    for field, name in [('ni','НИ'),('pfn','ПФН'),('nvv','НВВ')]:
        old = previous[field] if previous else 0
        if bool(current[field]) != bool(old):
            parts.append(f"{'Признание' if current[field] else 'Снятие'} {name}.")
    if previous:
        for field, name in [('security','Обеспечение'),('restra','Реструктуризация')]:
            if current[field] != previous[field]:
                parts.append(f"{name} изменена с «{previous[field] or 'нет'}» на «{current[field] or 'нет'}».")
        if current['gr'] != previous['gr'] or current['rate'] != previous['rate']:
            parts.append(f"Переход из ГР {previous['gr']} в ГР {current['gr']}, ставка резерва с {previous['rate']}% до {current['rate']}%.")
    if new or parts:
        parts.append(f"ГР {current['gr']}, резерв {current['rate']}%. НИ {current['ni'] or 0}, ПФН {current['pfn'] or 0}, НВВ {current['nvv'] or 0}.")
    if current['revaluation']:
        parts.append('Изменение резерва вследствие валютной переоценки.')
    if current['override_reason']:
        parts.append('Корректировка ставки. '+current['override_reason'])
    if not parts and current['expenses']:
        parts.append(f"Изменение резерва при ГР {current['gr']} и ставке {current['rate']}%. Причина требует уточнения.")
    if not parts: return ''
    return f"Договор {current['contract']} ({current['operation']}). "+' '.join(parts)


def collect(pid):
    texts = defaultdict(list)
    totals = defaultdict(float)
    previous = {}
    with engine.connect() as db:
        project = db.execute('SELECT periods FROM projects WHERE id=?',(pid,)).fetchone()
        periods = json.loads(project['periods'])[1:]
        rows = db.execute("""SELECT p.contract,p.operation,p.ccy,p.unp,pp.* FROM positions p
            JOIN position_periods pp ON pp.position_id=p.id AND pp.project_id=p.project_id
            WHERE p.project_id=? ORDER BY p.id,pp.period""",(pid,))
        for row in rows:
            old = previous.get(row['position_id'])
            previous[row['position_id']] = row
            if row['period'] not in periods: continue
            key = (engine.normalize_unp(row['unp']),row['period'])
            totals[key] += row['expenses'] or 0
            text = describe(row,old)
            if text: texts[key].append(text)
    return periods, {key:'\n'.join(texts[key]) for key,amount in totals.items() if abs(round(amount,2)) > 100000}
