"""Thread-safe, bounded diagnostic activity log for the local application."""
from collections import deque
from datetime import datetime
import json
import logging
from logging.handlers import RotatingFileHandler

import engine

PATH = engine.DATA / 'activity.log'
LOGGER = logging.getLogger('nsfo.activity')
LOGGER.setLevel(logging.INFO)
LOGGER.propagate = False
if not LOGGER.handlers:
    PATH.parent.mkdir(parents=True, exist_ok=True)
    handler = RotatingFileHandler(PATH, maxBytes=5_000_000, backupCount=3, encoding='utf-8')
    handler.setFormatter(logging.Formatter('%(message)s'))
    LOGGER.addHandler(handler)


def record(action, status='started', project=None, actor=None, detail=None, duration=None):
    event = {'at': datetime.now().astimezone().isoformat(timespec='seconds'),
             'project': project, 'actor': actor, 'action': action, 'status': status}
    if detail is not None:
        event['detail'] = str(detail)[:300]
    if duration is not None:
        event['duration_ms'] = round(duration * 1000)
    LOGGER.info(json.dumps(event, ensure_ascii=False))


def recent(project=None, limit=100):
    """Read the latest entries including rotated files, newest first."""
    limit = max(1, min(int(limit), 200))
    items = deque(maxlen=limit)
    for file in [PATH.with_name(PATH.name + f'.{i}') for i in (3, 2, 1)] + [PATH]:
        if not file.exists():
            continue
        with file.open(encoding='utf-8') as source:
            for line in source:
                try:
                    event = json.loads(line)
                except ValueError:
                    continue
                if project is None or event.get('project') == project:
                    items.append(event)
    return list(reversed(items))
