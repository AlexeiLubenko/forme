@echo off
setlocal EnableExtensions
chcp 65001 >nul 2>&1
pushd "%~dp0" >nul 2>&1
if errorlevel 1 (
    echo ERROR: Cannot access the application folder.
    echo Extract the ZIP file to a writable local folder and try again.
    pause
    exit /b 1
)

echo ============================================================
echo   NSFO 1.4.0 - Automatic Windows Startup
echo ============================================================
echo.
echo Checking Python 3.11.5 or newer...

rem Prefer the Windows Python launcher when it is available.
py -3 -c "import sys; sys.exit(0 if sys.version_info >= (3,11,5) else 1)" >nul 2>&1
if not errorlevel 1 (
    set "PY_CMD=py -3"
    goto :python_ready
)
python -c "import sys; sys.exit(0 if sys.version_info >= (3,11,5) else 1)" >nul 2>&1
if not errorlevel 1 (
    set "PY_CMD=python"
    goto :python_ready
)
python3 -c "import sys; sys.exit(0 if sys.version_info >= (3,11,5) else 1)" >nul 2>&1
if not errorlevel 1 (
    set "PY_CMD=python3"
    goto :python_ready
)

echo ERROR: Python 3.11.5 or newer was not found.
echo Install an approved Python version or contact IT support.
echo The application cannot install Python automatically.
goto :error

:python_ready
echo Python launcher: %PY_CMD%
echo Starting environment checks, first-time setup, and web server...
echo.
%PY_CMD% "%CD%\launch_nsfo.py"
set "APP_EXIT=%ERRORLEVEL%"
if not "%APP_EXIT%"=="0" (
    echo.
    echo ERROR: NSFO could not start. Exit code: %APP_EXIT%
    echo Check the error above and logs\startup.log.
    echo If the port is blocked, contact your IT administrator.
    goto :error
)

echo.
echo NSFO server stopped normally.
popd
exit /b 0

:error
echo.
echo Press any key to keep this window open and review the error.
pause >nul
popd
exit /b 1
