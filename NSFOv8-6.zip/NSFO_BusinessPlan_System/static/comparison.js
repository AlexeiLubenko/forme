let comparisonView = {};
let comparisonRequest = 0;

function openFactorComparison() {
  const index = dates().indexOf(S.period);
  comparisonView = {pid:S.pid, start:dates()[index - 1] || '', end:S.period,
    search:S.factorSearch, side:S.factorSide, page:1, client:''};
  return nav('comparison');
}

function comparisonValue(summary, part, key, delta=false) {
  if (!summary || summary.incomplete) return '<td class="right tiny">—</td>';
  const value = summary[part][key] || 0;
  const digits = part === 'events' ? 0 : 2;
  return `<td class="right ${delta && digits ? moneyClass(value) : ''}">${delta && value>0 ? '+' : ''}${money(value,digits)}</td>`;
}

function comparisonTable(data, part, entries, heading) {
  const rows = entries.map(([key,name]) => {
    if (!key) return `<tr class="factor-group-row"><td colspan="4"><b>${esc(name)}</b></td></tr>`;
    return `<tr><td>${esc(name)}</td>${comparisonValue(data.reference,part,key)}${comparisonValue(data.current,part,key)}${comparisonValue(data.delta,part,key,true)}</tr>`;
  });
  return table([heading, ...['Загруженный БП','Текущий БП','Отклонение'].map(label=>({label,right:true}))], rows);
}

async function uploadComparison(file, source, pid) {
  if (!file) return;
  if (!file.name.toLowerCase().endsWith('.xlsx')) return toast('Выберите книгу Excel в формате .xlsx.',true);
  if (source && !confirm(`Заменить «${source.filename}» файлом «${file.name}» для этого проекта?`)) return;
  const status = $('comparison-status');
  const button = $('comparison-pick');
  button.disabled = true;
  status.textContent = 'Идёт загрузка и расчёт факторов…';
  try {
    const result = await api(`/api/projects/${pid}/comparison/upload`, {
      method:'POST', headers:{'X-Filename':encodeURIComponent(file.name),
        'Content-Type':'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'}, body:file});
    if (S.pid===pid && S.page==='comparison') {
      toast(`Загружено позиций: ${result.positions}`);
      comparisonView.page=1;
      comparisonView.client='';
      await renderComparison();
    }
  } catch (err) {
    status.className = 'notice danger';
    status.textContent = err.message;
  } finally {
    button.disabled = false;
  }
}

async function renderComparison() {
  const pid = S.pid;
  const request = ++comparisonRequest;
  if (comparisonView.pid !== pid) comparisonView = {pid, start:'', end:'', search:'', side:'', page:1, client:''};
  const view = comparisonView;
  const data = await get('comparison', {start:view.start, end:view.end, search:view.search,
    side:view.side, page:view.page||1, client:view.client||''});
  if (request !== comparisonRequest || S.pid !== pid || S.page !== 'comparison') return;
  if (data.selected) [view.start,view.end] = data.selected;
  const source = data.source;
  const admin = S.auth.role==='admin';
  const actions = admin ? `<a class="btn" href="/api/projects/${pid}/comparison/template.xlsx">Скачать шаблон Excel</a>
    <input type="file" accept=".xlsx" id="comparison-file" hidden>
    <button class="btn primary" id="comparison-pick">${source?'Заменить файл':'Загрузить Excel'}</button>` : '';
  const sourceLabel = source
    ? `<b>${esc(source.filename)}</b> · Позиций: ${money(source.positions,0)} · ${esc(source.username)} · ${labelDate(source.uploaded.slice(0,10))} ${esc(source.uploaded.slice(11,16))}`
    : (admin?'Выберите детальную выгрузку «Прогноз НСФО» или заполните шаблон Excel.':'Администратор ещё не загрузил сформированный бизнес-план.');
  let html = pageHead('Сравнение бизнес-планов',data.project) +
    wrap('Сформированный бизнес-план','',`<div class="spaced"><span>${sourceLabel}</span><div class="actions">${actions}</div></div>
    <div id="comparison-status" role="status" class="sub"></div>${source?.legacy_fx?'<p class="sub">Для валютных позиций без столбцов курсов использованы OD и переоценка из прежней выгрузки, с точностью этой выгрузки.</p>':''}`);
  if (data.building) html += '<div class="notice">Выполняется построение текущего плана. После завершения откройте сравнение повторно.</div>';
  if (data.selected) {
    const options = data.intervals.map(item => {
      const suffix = item.current && item.reference ? '' : item.current ? ' · текущий' : ' · загруженный';
      return `<option value="${item.start}/${item.end}" ${view.start===item.start && view.end===item.end?'selected':''}>${labelDate(item.start)} — ${labelDate(item.end)}${suffix}</option>`;
    }).join('');
    html += `<form class="toolbar" id="comparison-filters"><label>Период <select class="control" id="comparison-period">${options}</select></label>
      <input class="input wide" id="comparison-search" aria-label="Клиент, УНП или договор" placeholder="Клиент, УНП или договор" value="${esc(view.search)}">
      <select class="control" id="comparison-side" aria-label="Баланс или внебаланс"><option value="">Баланс + УО</option>
      <option value="баланс" ${view.side==='баланс'?'selected':''}>Баланс</option>
      <option value="внебаланс" ${view.side==='внебаланс'?'selected':''}>Внебаланс</option></select><button class="btn">Применить</button></form>`;
    if (!data.current || !data.reference) {
      html += '<div class="notice">Отклонение доступно, когда в обоих планах совпадают начало и конец периода.</div>';
    } else if (data.current.incomplete) {
      html += `<div class="notice danger">В текущем плане нет расчётного резерва на одну из дат у ${data.current.incomplete} поз. Проверьте исходные данные и пересчитайте прогноз.</div>`;
    }
    const count = x => x ? money(x.positions,0) : '—';
    const main = [['expenses','Расходы на резервы'],...data.factor_groups.map(g=>[g.key,g.name]),['rounding','Остаток сверки (расходы минус четыре фактора)']];
    html += wrap('Расходы по факторам, BYN','Отклонение = текущий БП − загруженный БП. Минус означает дополнительные расходы, плюс — улучшение результата.',
      comparisonTable(data,'totals',main,'Показатель') +
      `<p class="sub">Позиций в выборке · загруженный БП: ${count(data.reference)} · текущий БП: ${count(data.current)}</p>`);
    const details = [];
    for (const group of data.factor_groups) {
      for (const section of group.sections || [{items:group.items}]) {
        if (!section.items.length) continue;
        details.push([null, [group.name,section.name].filter(Boolean).join(' · ')]);
        for (const key of section.items) details.push([key,data.factor_names[key]]);
      }
    }
    const clientRows=(data.client_rows||[]).map(entry => {
      const active=view.client===entry.unp;
      const label=entry.client||entry.unp;
      const source=entry.reference||null, current=entry.current||null;
      const difference=entry.delta && !entry.incomplete ? {totals:entry.delta} : null;
      const factors=['expenses','movement','financial_state','security_effect','revaluation','rounding'];
      const figures=[comparisonValue(source&&{totals:source},'totals','expenses'),
        comparisonValue(current&&{totals:current},'totals','expenses'),
        ...factors.map(key=>comparisonValue(difference,'totals',key,true))].join('');
      return `<tr><td><button class="btn mini" data-comparison-client="${esc(entry.unp)}"
        aria-expanded="${active}" title="Показать подфакторы клиента">${esc(label)}</button>
        <div class="tiny">УНП ${esc(entry.unp)} · позиций: ${money(source?.positions||0,0)} / ${money(current?.positions||0,0)}</div>
        ${entry.incomplete?'<div class="tiny red">Не рассчитан резерв на одну из дат</div>':''}</td>${figures}</tr>`;
    });
    const clientHeader=['Клиент / УНП','Расходы загруженного БП','Расходы текущего БП',
      'Отклонение расходов','Движение КП','Финансовое состояние','Обеспечение','Переоценка','Сверка'];
    const pages=Math.ceil(data.client_total/100);
    html += wrap('Отклонения по клиентам, BYN',
      'Отклонение = текущий БП − загруженный БП. Нажмите на клиента для анализа подфакторов.',
      `${clientRows.length?table(clientHeader,clientRows):empty('Клиенты по заданным условиям не найдены.')}
      ${pages>1?`<div class="spaced" style="margin-top:14px"><button class="btn mini" id="comparison-prev" ${data.client_page<=1?'disabled':''}>Назад</button>
      <span>Страница ${data.client_page} из ${pages} · клиентов: ${data.client_total}</span>
      <button class="btn mini" id="comparison-next" ${data.client_page>=pages?'disabled':''}>Далее</button></div>`:''}`);
    if(data.client_detail){
      const detail=data.client_detail;
      html += wrap('Подфакторы клиента · '+esc(detail.client||detail.unp),
        'УНП '+esc(detail.unp)+' · отклонение = текущий БП − загруженный БП.',
        comparisonTable(detail,'totals',main,'Показатель')+
        comparisonTable(detail,'subfactors',details,'Подфактор')+
        `<details class="section"><summary>События клиента</summary>
        ${comparisonTable(detail,'events',details,'События, шт.')}</details>`);
    }
    html += wrap('Подфакторы','',
      comparisonTable(data,'subfactors',details,'Суммы, BYN') +
      `<details class="section"><summary>Количество событий по подфакторам</summary>${comparisonTable(data,'events',details,'События, шт.')}</details>`);
  } else {
    html += empty('Для расчёта расходов нужны остатки хотя бы на две даты. Загрузите сформированный БП или постройте текущий прогноз.');
  }
  $('content').innerHTML = html;
  if (admin) {
    const input = $('comparison-file');
    $('comparison-pick').onclick = () => input.click();
    input.onchange = () => {const file=input.files[0];input.value='';uploadComparison(file,source,pid);};
  }
  if ($('comparison-filters')) {
    const apply = () => {
      [view.start,view.end] = $('comparison-period').value.split('/');
      view.search = $('comparison-search').value.trim();
      view.side = $('comparison-side').value;
      view.page=1;
      view.client='';
      renderComparison().catch(error);
    };
    $('comparison-filters').onsubmit = e => {e.preventDefault();apply();};
    $('comparison-period').onchange = apply;
    $('comparison-side').onchange = apply;
  }
  document.querySelectorAll('[data-comparison-client]').forEach(button => {
    button.onclick=()=>{view.client=view.client===button.dataset.comparisonClient?'':button.dataset.comparisonClient;
      renderComparison().catch(error);};
  });
  const prev=$('comparison-prev'),next=$('comparison-next');
  if(prev)prev.onclick=()=>{view.page--;view.client='';renderComparison().catch(error)};
  if(next)next.onclick=()=>{view.page++;view.client='';renderComparison().catch(error)};
}
