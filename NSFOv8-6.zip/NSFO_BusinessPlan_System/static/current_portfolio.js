let portfolioView = {};
let portfolioRequest = 0;
const portfolioTags = {new:'Появился',gone:'Выбыл',changed:'Изменились признаки',missing:'Нет точного договора во входном БП',plan_only:'Есть в БП, отсутствует в текущем портфеле'};
const portfolioFields = {ni:'НИ',pfn:'ПФН',nvv:'НВВ',restra:'Реструктуризация',security:'Обеспеченность'};
async function renderCurrentPortfolio(){
  const pid=S.pid, request=++portfolioRequest;
  if(portfolioView.pid!==pid) portfolioView={pid,page:1,kind:'',search:'',links:new Map()};
  const view=portfolioView;
  const data=await get('current-portfolio',{kind:view.kind,search:view.search,page:view.page});
  if(S.pid!==pid||S.page!=='current_portfolio'||request!==portfolioRequest)return;
  let html=pageHead('Сверка портфелей','Договоры и признаки риска на две даты');
  if(!dates().length){
    $('content').innerHTML=html+empty('Сначала постройте БП с выверенным фактом на первое число.');
    return;
  }
  if(view.token!==data.meta?.token){view.links.clear();view.token=data.meta?.token;}
  const first=firstDate();
  const today=new Date();
  const todayISO=[today.getFullYear(),String(today.getMonth()+1).padStart(2,'0'),String(today.getDate()).padStart(2,'0')].join('-');
  const suggested=data.meta?.asof || (todayISO.slice(0,7)===first.slice(0,7) && todayISO>first?todayISO:'');
  html+=wrap('Текущий портфель', 'Начальный портфель — выверенный факт на '+labelDate(first)+'. Текущий портфель загрузите в формате того же файла Excel.',
    `<form id="cp-upload" class="toolbar"><label>Дата среза <input class="input" id="cp-date" type="date" required value="${esc(suggested)}"></label>
     <input type="file" accept=".xlsx" id="cp-file" required><button class="btn primary">Загрузить и сверить</button></form>`);
  if(data.meta){
    const opts=Object.entries(portfolioTags).map(([k,v])=>`<option value="${k}" ${view.kind===k?'selected':''}>${esc(v)} (${data.totals[k]||0})</option>`).join('');
    const rows=data.rows.map((r,i)=>{
      const vals=Object.entries(portfolioFields).map(([k,label])=>{
        const change=r.changes[k];
        if(change) return `<div><b>${label}</b> ${esc(change[0]|| (change[0]===0?'0':'—'))} → ${esc(change[1]|| (change[1]===0?'0':'—'))}</div>`;
        return r.values?`<div>${label} · ${esc(r.values[k] === ''?'—':r.values[k])}</div>`:'';
      }).join('');
      const chosen=r.mapped_id||view.links.get(r.key);
      const match=r.candidates.length?`<select class="control" aria-label="Соответствие во входном БП" data-cp-row="${i}" ${data.meta.applied?'disabled':''}>
        <option value="">Без привязки</option>${r.candidates.map(c=>`<option value="${c.id}" ${+chosen===c.id?'selected':''}>${esc(c.contract)} · позиция ${c.id}</option>`).join('')}</select>`:(r.tags.includes('missing')?'Подходящих строк нет':'—');
      return `<tr><td>${esc(r.client)}<br>${esc(r.unp)}</td><td>${esc(r.contract)}<br>${esc(r.ccy)} · ${esc(r.side)}</td>
        <td>${r.tags.map(k=>esc(portfolioTags[k])).join('<br>')||'Без изменений'}</td><td>${vals||'—'}</td><td>${match}</td></tr>`;
    });
    html+=wrap('Договоры и изменения',esc(data.meta.filename)+' · '+labelDate(data.meta.asof),
      `<form id="cp-filter" class="toolbar"><select id="cp-kind" class="control"><option value="">Все договоры</option>${opts}</select>
       <input class="input" id="cp-search" placeholder="Клиент, УНП или договор" value="${esc(view.search)}"><button class="btn">Найти</button></form>`+
       table(['Клиент / УНП','Договор','Результат сверки','Признаки текущего портфеля','Строка «Новый договор»'],rows)+
       `<div class="toolbar"><button class="btn mini" id="cp-prev" ${view.page<=1?'disabled':''}>Назад</button>
       <span>Страница ${view.page} из ${Math.max(1,Math.ceil(data.count/100))} · договоров ${data.count}</span>
       <button class="btn mini" id="cp-next" ${view.page*100>=data.count?'disabled':''}>Далее</button></div>`);
    html+=wrap('Перенос в прогноз',data.start?'С '+labelDate(data.start)+' до конца горизонта':'В горизонте БП нет следующей прогнозной даты',
      `<p>НИ, ПФН и НВВ переносятся на позиции клиента по УНП. Реструктуризация и обеспечение — на совпавшие договоры и выбранные строки «Новый договор». На внебалансе реструктуризация не применяется.</p>
       <p>Текущие признаки заменят плановые значения на указанных датах. При изменении признаков группа риска и ставка будут пересчитаны.</p>
       ${data.meta.applied?'Применено '+esc(data.meta.applied.replace('T',' ')):`<button class="btn primary" id="cp-apply" ${data.start?'':'disabled'}>Применить к прогнозу</button>`}`);
  }
  $('content').innerHTML=html+'<p id="cp-status" role="status"></p>';
  const show=()=>renderCurrentPortfolio().catch(error);
  const perform=async(button,task)=>{
    const status=$('cp-status');button.disabled=true;status.textContent='Обработка…';
    try{await task();if(S.pid===pid&&S.page==='current_portfolio'){await refreshState();await show();}}
    catch(e){status.textContent=e.message;error(e);}finally{button.disabled=false;}
  };
  $('cp-upload').onsubmit=e=>{
    e.preventDefault();
    const file=$('cp-file').files[0],asof=$('cp-date').value;
    if(data.meta && !confirm('Заменить текущий срез для сверки? Ранее применённые изменения уже сохранены в прогнозе.'))return;
    perform(e.submitter,async()=>{
      await api(`/api/projects/${pid}/current-portfolio/upload?asof=${encodeURIComponent(asof)}`,{method:'POST',headers:{'X-Filename':encodeURIComponent(file.name)},body:file});
      view.kind='';view.page=1;view.search='';
    });
  };
  if(!data.meta)return;
  $('cp-filter').onsubmit=e=>{e.preventDefault();view.kind=$('cp-kind').value;view.search=$('cp-search').value.trim();view.page=1;show();};
  $('cp-kind').onchange=()=>$('cp-filter').requestSubmit();
  $('cp-prev').onclick=()=>{view.page--;show();};$('cp-next').onclick=()=>{view.page++;show();};
  document.querySelectorAll('[data-cp-row]').forEach(select=>select.onchange=()=>{
    const key=data.rows[Number(select.dataset.cpRow)].key;
    if(select.value)view.links.set(key,Number(select.value));else view.links.delete(key);
  });
  if($('cp-apply'))$('cp-apply').onclick=e=>{
    if(!confirm('Применить текущие признаки с '+labelDate(data.start)+' по конец горизонта по всем клиентам текущего портфеля, включая строки за пределами фильтра?'))return;
    perform(e.currentTarget,()=>post('current-portfolio/apply',{token:data.meta.token,links:Object.fromEntries(view.links)}));
  };
}
