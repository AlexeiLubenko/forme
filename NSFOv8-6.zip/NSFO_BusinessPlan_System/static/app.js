const S={auth:null,csrf:'',pid:null,page:'dashboard',state:null,projectList:[],period:null,search:'',pageNum:1,tab:'waiting',kind:'',metric:'period',selectedKeys:new Set(),files:{},busy:false,side:'',riskGr:'',riskSort:'client',factorSearch:'',factorSide:'',clientSearch:'',planDecisions:{},timer:null};
const $=id=>document.getElementById(id);
// Sidebar visibility is a UI preference only. Server-side access checks remain unchanged.
const SIDEBAR_PREF='nsfo-sidebar-hidden';
function setSidebarHidden(hidden, persist=true){
 const app=document.querySelector('.app');
 const toggle=$('sidebar-toggle');
 if(!app||!toggle)return;
 app.classList.toggle('sidebar-hidden',Boolean(hidden));
 toggle.setAttribute('aria-expanded',String(!hidden));
 toggle.setAttribute('aria-label',hidden?'Показать боковую панель':'Скрыть боковую панель');
 toggle.title=hidden?'Показать боковую панель':'Скрыть боковую панель';
 if(persist){try{localStorage.setItem(SIDEBAR_PREF,hidden?'1':'0')}catch(_){}}
}
function initSidebarToggle(){
 let hidden=false;
 try{hidden=localStorage.getItem(SIDEBAR_PREF)==='1'}catch(_){}
 setSidebarHidden(hidden,false);
 $('sidebar-toggle').addEventListener('click',()=>setSidebarHidden(!document.querySelector('.app').classList.contains('sidebar-hidden')));
}

const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));
const money=(v,d=2)=>v===null||v===undefined?'—':Number(v).toLocaleString('ru-RU',{minimumFractionDigits:d,maximumFractionDigits:d});
const fmt=(v,suffix='')=>money(v)+' '+suffix;
const moneyClass=v=>Number(v)<-0.004?'red':Number(v)>0.004?'green':'';
const labelDate=v=>{if(!v)return '';const [y,m,d]=v.split('-');return `${d}.${m}.${y}`};
const el=(v)=>document.createElement(v);
const api=async(url,opts={})=>{if(String(opts.method||'GET').toUpperCase()!=='GET' && url!=='/api/auth/login'){opts.headers={...(opts.headers||{}),'X-CSRF-Token':S.csrf||decodeURIComponent((document.cookie.match(/(?:^|; )nsfo_csrf=([^;]*)/)||[])[1]||'')}}const res=await fetch(url,opts);let data;const text=await res.text();try{data=JSON.parse(text)}catch{throw Error('Некорректный ответ сервера');}if(!res.ok||data.error)throw Error(data.error||'Ошибка '+res.status);return data;};
const get=(route,q={})=>api(`/api/projects/${S.pid}/${route}?`+new URLSearchParams(q));
const post=(route,data)=>api(`/api/projects/${S.pid}/${route}`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)});
const toast=(msg,bad=false)=>{document.querySelectorAll('.toast').forEach(x=>x.remove());const e=el('div');e.className='toast'+(bad?' bad':'');e.textContent=msg;document.body.appendChild(e);setTimeout(()=>e.remove(),6000)};
const error=e=>{console.error(e);toast(e?.message||String(e),true)};
const loading=(msg='Загрузка данных...')=>{const c=$('content');if(c)c.innerHTML=`<div class="card card-pad" style="max-width:500px;margin:50px auto;text-align:center"><h2>${esc(msg)}</h2><div class="progress" style="margin-top:24px"><div></div></div></div>`};
const modal=(title,body,footer='')=>{$('modal-container').innerHTML=`<div class="modal-bg" id="overlay"><div class="modal"><div class="modal-head"><h2>${esc(title)}</h2><button class="modal-close" data-close>✕</button></div>${body}<div class="modal-foot">${footer||'<button class="btn" data-close>Закрыть</button>'}</div></div></div>`;$('overlay').onclick=e=>{if(e.target.id==='overlay'||e.target.closest('[data-close]'))closeModal()};};
const closeModal=()=>{$('modal-container').innerHTML=''};
const btn=(label,action,variant='')=>`<button class="btn ${variant}" data-action="${action}">${label}</button>`;
const badge=(label,color='')=>`<span class="badge ${color}">${esc(label)}</span>`;
const empty=(text)=>`<div class="empty">${esc(text)}</div>`;
const table=(heads,rows,options='')=>`<div class="table-scroll ${options}"><table class="data-table"><thead><tr>${heads.map(x=>`<th class="${x?.right?'right':''}">${esc(typeof x==='string'?x:x.label)}</th>`).join('')}</tr></thead><tbody>${rows.join('')}</tbody></table></div>`;
const pageHead=(title,subtitle,buttons='')=>`<div class="pagehead"><div><div class="eyebrow">Модуль 1 / Бизнес-план</div><h1>${esc(title)}</h1><div class="sub">${esc(subtitle)}</div></div><div class="actions">${buttons}</div></div>`;
const kpi=(label,value,footer)=>`<div class="card kpi"><div class="kpi-label">${esc(label)}</div><div class="kpi-value">${value}</div><div class="kpi-caption">${esc(footer)}</div></div>`;
const periodSel=(id,value)=>`<select class="control" id="${id}">${(S.state?.periods||[]).map(d=>`<option value="${d}" ${d===value?'selected':''}>${labelDate(d)}</option>`).join('')}</select>`;
const wrap=(title,subtitle,content)=>`<div class="card card-pad section"><div class="sectionhead"><div><h2>${title}</h2><p>${subtitle||''}</p></div></div>${content}</div>`;
const statusText={draft:'Черновик',ready:'Расчёт готов',needs_review:'Нужна проверка',fixed:'Зафиксирован',building:'Расчёт выполняется'};
const pageNames={overview:'Обзор',upload:'Загрузка данных',plan_changes:'Плановые изменения',reconcile:'Сверка и договоры',forecast:'Прогноз по договорам',factors:'Факторный анализ',comparison:'Сравнение планов',current_portfolio:'Сверка портфелей',clients:'Поклиентный отчёт',history:'Версии и история',activity:'Журнал действий',dashboard:'Факт vs План',dash_admin:'Управление дашбордом'};
const dates=()=>S.state?.periods||[];
const lastDate=()=>dates().at(-1)||'';
const firstDate=()=>dates()[0]||'';
const defaultPeriod=()=>dates()[1]||dates()[0]||'';
async function refreshState(){if(S.pid){S.state=await get('state');const p=S.state.project;$('project-title').textContent=p.name;$('nav-count').textContent=(S.state?.missing?.waiting||0)+(S.state?.warnings?.debt||0)||'';if(!dates().includes(S.period))S.period=defaultPeriod();}}
async function initialize(){try{
 const who=await api('/api/auth/me');S.auth=who;
 S.csrf=decodeURIComponent((document.cookie.match(/(?:^|; )nsfo_csrf=([^;]*)/)||[])[1]||'');
 document.querySelector('.app').classList.remove('locked');
 document.querySelectorAll('[data-page]').forEach(x=>{
  x.hidden=(who.role==='viewer'&&x.dataset.page!=='dashboard') ||
           (x.dataset.page==='dash_admin'&&who.role!=='admin');
 });
 document.getElementById('project-select').hidden=who.role==='viewer';
 const projects=who.role==='viewer'?{projects:[]}:await api('/api/projects');
 S.projectList=projects.projects;
 S.pid=S.projectList.length?S.projectList[0].id:null;
 await refreshState();nav('dashboard');
 }catch(e){if(e.message==='Требуется вход в систему')return showLogin();error(e);$('content').innerHTML=empty('Не удалось связаться с сервером. Убедитесь, что сервер запущен.')}}
function showLogin(){S.auth=null;document.querySelector('.app').classList.add('locked');
 $('content').innerHTML=`<div class="login-card card card-pad"><div class="eyebrow">АС НСФО · авторизация</div><h1>Вход в систему</h1><p class="sub">Работа с банковскими данными доступна только авторизованным сотрудникам.</p><form id="login-form"><label class="form-label">Логин</label><input class="form-input" id="login-user" autocomplete="username" required><label class="form-label">Пароль</label><input class="form-input" type="password" id="login-pass" autocomplete="current-password" required><button class="btn primary" type="submit" style="margin-top:18px;width:100%">Войти</button><div id="login-error" class="sub" style="margin-top:12px"></div></form></div>`;
 $('login-form').onsubmit=async e=>{e.preventDefault();try{const res=await api('/api/auth/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({username:$('login-user').value,password:$('login-pass').value})});S.csrf=res.csrf;await initialize()}catch(ex){$('login-error').textContent=ex.message}};
}

async function nav(page){if(typeof closeDashFullscreen==='function')closeDashFullscreen(false);if(!S.auth)return showLogin();if((S.auth.role==='viewer'&&page!=='dashboard')||(page==='dash_admin'&&S.auth.role!=='admin'))return nav('dashboard');S.page=page;S.pageNum=1;$('breadcrumb').textContent=pageNames[page];$('module-label').textContent=page==='dashboard'||page==='dash_admin'?'Модуль 2 · Факт vs План':'Модуль 1 · Бизнес-план';document.querySelectorAll('[data-page]').forEach(x=>x.classList.toggle('active',x.dataset.page===page));loading();try{await refreshState();if(!S.pid&&!['overview','upload','dashboard','dash_admin','activity'].includes(page)){return nav('dashboard')}await render()}catch(e){error(e);$('content').innerHTML=`<div class="notice danger">${esc(e.message)}</div>`}}
async function render(){if(S.page==='dashboard')return renderDashboard(false);if(S.page==='dash_admin')return renderDashAdmin();if(S.page==='activity')return renderActivity();if(S.page==='overview')return renderOverview();if(S.page==='upload')return renderUpload();if(S.page==='plan_changes')return renderPlanChanges();if(S.page==='reconcile')return renderReconcile();if(S.page==='forecast')return renderForecast();if(S.page==='factors')return renderFactors();if(S.page==='comparison')return renderComparison();if(S.page==='current_portfolio')return renderCurrentPortfolio();if(S.page==='clients')return renderClients();if(S.page==='history')return renderHistory();}
async function renderActivity(){
 const content=$('content');
 const generation=S.activityGeneration=(S.activityGeneration||0)+1;
 content.innerHTML=pageHead('Журнал действий','Запросы и этапы расчёта с временем выполнения')+'<div id="activity-list" class="card card-pad section">Загрузка журнала...</div>';
 async function update(){
  if(S.page!=='activity'||S.activityGeneration!==generation)return;
  try{
   const data=await api('/api/activity?limit=100');
   if(S.page!=='activity'||S.activityGeneration!==generation)return;
   const rows=data.events.map(event=>`<tr><td>${esc(event.at?.replace('T',' ')||'')}</td><td>${esc(event.actor||'—')}</td><td>${esc(event.project??'—')}</td><td>${esc(event.action)}</td><td>${esc(event.status)}${event.detail?' · '+esc(event.detail):''}</td><td>${event.duration_ms??'—'}</td></tr>`);
   const view=$('activity-list');if(view)view.innerHTML=table(['Время','Пользователь','Проект','Действие','Результат / этап','мс'],rows);
  }catch(e){const view=$('activity-list');if(view)view.textContent=e.message;}
  if(S.page==='activity'&&S.activityGeneration===generation)setTimeout(update,3000);
 }
 update();
}
const noPlan=()=>!S.pid?`<div class="card card-pad">${empty('Создайте рабочий бизнес-план, чтобы начать.')}${btn('Создать бизнес-план','create','primary')}</div>`:null;
async function renderOverview(){if(!S.pid){$('content').innerHTML=pageHead('Рабочее пространство','Начните с создания бизнес-плана')+noPlan();return}
 const p=S.state.project,t=S.state.totals||[],initial=t[0],final=t.at(-1),pCount=S.state?.warnings?.debt||0,waiting=S.state?.missing?.waiting||0,added=(S.state?.missing?.auto||0)+(S.state?.missing?.added||0);
 const datesArr=t.slice(1);const max=Math.max(1,...datesArr.map(x=>Math.abs(x.expenses)));const bars=datesArr.length?datesArr.map(r=>`<div class="bar-group"><div class="bar-label">${labelDate(r.period)}</div><div class="bar-track"><div class="bar-fill ${r.expenses<0?'red':''}" style="width:${Math.max(1,Math.abs(r.expenses)/max*100)}%"></div></div><div class="bar-value ${moneyClass(r.expenses)}">${money(r.expenses)}</div></div>`).join(''):empty('Загрузите исходные данные для построения диаграммы');
 $('content').innerHTML=pageHead('Бизнес-план НСФО',`Версия ${p.version} · ${statusText[p.status]||p.status} · ${p.fact_date?'Факт на '+labelDate(p.fact_date):'Факт не загружен'}`,
 `${btn('Загрузить / заменить файлы','goto-upload')}${btn('Сохранить версию','save-version','primary')}`)+
 `<div class="cards">${kpi('Резервы, исходная дата',initial?money(initial.reserve):'—','BYN · рассчитано по методике')}${kpi('Резервы, конец горизонта',final?money(final.reserve):'—','BYN · последняя дата')}${kpi('Расхождения задолженности',pCount,'Договоры с предупреждением')}${kpi('Ожидают добавления',waiting,'Без повторной загрузки файлов')}</div>`+
 `<div class="cols2 section">${wrap('Расходы по периодам','Положительное значение — восстановление резерва; отрицательное — создание',bars)}${wrap('Результаты выверки','Короткий обзор качества данных',
 `<div class="stack"><div class="spaced"><span>Договоры, ожидающие включения</span>${badge(waiting,waiting?'orange':'green')}</div><div class="spaced"><span>Добавлены из факта</span>${badge(added,'green')}</div><div class="spaced"><span>Расхождения задолженности</span>${badge(pCount,pCount?'red':'green')}</div><div class="spaced"><span>Сверка резервов</span>${badge(S.state?.warnings?.reserve||0,'orange')}</div><div class="spaced"><span>Корректировки ГР / ставки</span>${badge(S.state?.warnings?.classification||0,'purple')}</div><div class="divider-line"></div>${btn('Открыть сверку','goto-reconcile')}</div>`)}</div>`+
 `${wrap('Этапы построения','Данные и действия сохраняются между запусками',`<div class="steps"><div class="step ${S.state.uploads.length===3?'done':'now'}"><b>1</b>Исходные файлы</div><div class="step ${t.length?'done':'now'}"><b>2</b>Сверка</div><div class="step ${t.length?'done':''}"><b>3</b>Прогноз</div><div class="step ${p.status==='fixed'?'done':''}"><b>4</b>Фиксация версии</div></div><div class="notice good">Нормализованный процент — в процентных пунктах: 0,5 означает 0,5%. Исходный «Резерв факт» используется только для сверки, не для расчёта.</div>`)}<p class="footer-note">Система работает локально: Python + SQLite + openpyxl, без Streamlit или Flask.</p>`;
}
async function renderUpload(){const files=S.state?.uploads||[];const cards=[['bp','Входной бизнес-план','Реквизиты и остатки в единицах валюты'],['fact','Выверенный факт','Задолженность и фактический резерв в тыс. BYN'],['rates','Прогнозные курсы','Формат: дата · валюта · курс BYN за единицу']].map(([kind,title,subtitle])=>{
 const found=files.find(f=>f.kind===kind);return `<div class="upload-zone ${found?'filled':''}" data-drop="${kind}"><div class="upload-pict">${found?'✓':'⇧'}</div><b>${title}</b><p>${subtitle}</p><div class="tiny">${found?'Загружено: '+esc(found.original_name):'Перетащите Excel .xlsx из папки сюда'}</div><input type="file" accept=".xlsx" id="file-${kind}" hidden><button class="btn mini" data-action="pick-file" data-kind="${kind}" style="margin-top:13px">${found?'Заменить файл':'Выбрать файл'}</button></div>`}).join('');
 $('content').innerHTML=pageHead('Загрузка исходных данных','Три файла сохраняются в рабочем проекте. Перетаскивание из Проводника Windows.',btn('Новый бизнес-план','create'))+
 `${wrap('Источники бизнес-плана','Загрузите каждый файл в свою область. После загрузки выполните построение.',`<div class="steps"><div class="step now"><b>1</b>Загрузка</div><div class="step"><b>2</b>Сверка</div><div class="step"><b>3</b>Прогноз</div><div class="step"><b>4</b>Отчёты</div></div><div class="upload-grid">${cards}</div><div class="divider-line"></div><div class="toolbar"><label class="mini-label" for="confirmed-fact-date">Дата выверенного факта</label><input class="input" id="confirmed-fact-date" type="date" value="${S.state?.project?.note||''}" title="Факт строго на первое число"><button class="btn mini" data-action="confirm-fact-date">Подтвердить дату</button></div><div class="spaced"><div class="sub">Факт принимается только на первое число месяца. Лимит 768 МБ на файл.</div>${btn('Построить прогноз и выполнить сверку','start-build','primary')}</div><div id="job-status" style="margin-top:15px"></div>`)}`+
 `${wrap('Что делает система после загрузки','Последовательность расчёта',`<div class="stack"><div>① Определяет периоды по именам «Факт на ...» и «Прогноз на ...»</div><div>② Сверяет договоры и задолженность по ключу УНП + договор + валюта + баланс/внебаланс</div><div>③ Добавляет договоры чёрной зоны; остальные сохраняет в реестре ожидания</div><div>④ Выверяет НИ/ПФН/НВВ, договорную реструктуризацию, обеспеченность и группу риска</div><div>⑤ Рассчитывает OD, резерв, расходы и факторный мост</div></div>`)}`;
 wireDropZones();await checkJob();}
function wireDropZones(){document.querySelectorAll('[data-drop]').forEach(zone=>{const kind=zone.dataset.drop;const input=$('file-'+kind);input.onchange=()=>{if(input.files.length)uploadFile(kind,input.files[0])};['dragenter','dragover'].forEach(event=>zone.addEventListener(event,e=>{e.preventDefault();zone.classList.add('dragover')}));['dragleave','drop'].forEach(event=>zone.addEventListener(event,e=>{e.preventDefault();zone.classList.remove('dragover')}));zone.addEventListener('drop',e=>{const file=e.dataTransfer?.files?.[0];if(file)uploadFile(kind,file)})});}
async function uploadFile(kind,file){if(!S.pid){toast('Сначала создайте бизнес-план',true);return}if(!file.name.toLowerCase().endsWith('.xlsx')){toast('Поддерживается только .xlsx',true);return}if(file.size>768*1024*1024){toast('Файл больше 768 МБ',true);return}loading('Загружаем '+file.name+'...');try{const r=await api(`/api/projects/${S.pid}/upload?kind=${kind}`,{method:'POST',headers:{'X-Filename':encodeURIComponent(file.name),'Content-Type':'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'},body:file});toast(`Файл ${r.file} сохранён`);await refreshState();renderUpload()}catch(e){error(e);renderUpload()}}
async function checkJob(){if(!S.pid||S.page!=='upload')return;try{const job=await get('job');const view=$('job-status');if(!view)return;if(job.status==='running'){view.innerHTML=`<div class="notice">${esc(job.stage||'Расчёт выполняется')} · с ${esc(job.started||'')} · обновлено ${esc(job.updated||job.started||'')}</div><div class="progress" style="margin-top:10px"><div></div></div>`;setTimeout(checkJob,2500)}if(job.status==='error')view.innerHTML=`<div class="notice danger">Ошибка расчёта: ${esc(job.error)}</div>`;if(job.status==='done')view.innerHTML=`<div class="notice good">Готово. Позиции: ${money(job.result?.positions,0)}. Ошибок контроля: ${job.result?.errors||0}. <button class="btn mini" data-action="goto-reconcile">Открыть сверку</button></div>`;}catch(e){error(e)}}
async function startBuild(){if(!confirm('Построить прогноз по загруженным файлам? Существующие расчётные позиции текущего проекта будут перестроены. Сохранённые версии останутся в истории.'))return;try{await post('build',{});toast('Расчёт запущен. Статус доступен на странице загрузки.');renderUpload()}catch(e){error(e)}}
const planFeatureNames={ni:'НИ',pfn:'ПФН',nvv:'НВВ'};
const planActionNames={recognition:'Возникновение',removal:'Снятие'};
const planStatusNames={ready:'Готово к применению',conflict:'Нужен выбор аналитика',applied:'Применено',kept_manual:'Сохранена ручная корректировка',client_not_found:'УНП не найден в БП',out_of_horizon:'Нет будущей даты',needs_reapply:'Требуется повторная проверка',pending:'Ожидает подтверждения',active:'Применён',replaced:'Заменён новой версией',cancelled:'Отменён',superseded:'Заменён другой предварительной загрузкой'};
async function uploadPlanChanges(file){
 if(!S.pid){toast('Сначала создайте бизнес-план',true);return}
 if(!file.name.toLowerCase().endsWith('.xlsx')){toast('Поддерживается только Excel .xlsx',true);return}
 if(file.size>768*1024*1024){toast('Файл больше 768 МБ',true);return}
 loading('Проверяем плановые изменения '+file.name+'...');
 try{
  await api(`/api/projects/${S.pid}/plan-changes/upload`,{method:'POST',headers:{'X-Filename':encodeURIComponent(file.name),'Content-Type':'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'},body:file});
  S.planDecisions={};toast('Файл проверен. Проверьте события и конфликты.');await refreshState();nav('plan_changes');
 }catch(e){error(e);renderPlanChanges()}
}
async function applyPlanChanges(batchId){
 const decisions={};document.querySelectorAll('[data-plan-decision]').forEach(x=>{if(x.value)decisions[x.dataset.planDecision]=x.value});
 try{
  const result=await post('plan-changes/apply',{batch_id:batchId,decisions});
  toast(`Применено: ${result.applied}; оставлено ручных корректировок: ${result.kept_manual}; пропущено: ${result.skipped}`);
  S.planDecisions={};await refreshState();renderPlanChanges();
 }catch(e){error(e)}
}
async function renderPlanChanges(){
 if(!dates().length){$('content').innerHTML=pageHead('Плановые изменения','Сначала загрузите бизнес-план, факт и курсы и постройте прогноз')+btn('К загрузке','goto-upload','primary');return}
 const data=await get('plan-changes');const pending=data.pending,active=data.active;
 const eventRows=(pending?.events||[]).map(e=>{
  const shifted=e.applied_period&&e.applied_period!==e.requested_date;
  let status=planStatusNames[e.status]||e.status;
  let decision=e.status==='conflict'?`<select class="control" data-plan-decision="${e.id}"><option value="">Выбрать решение</option><option value="apply">Применить событие из файла</option><option value="keep">Сохранить состояние БП / ручную правку</option></select>`:e.status==='ready'?badge('Автоматически','green'):badge(status,e.status==='out_of_horizon'||e.status==='client_not_found'?'orange':'gray');
  return `<tr><td><b>${esc(e.client||'Клиент не найден')}</b><br><span class="tiny">${esc(e.unp)}</span></td><td>${planFeatureNames[e.feature]} · ${planActionNames[e.action]}</td><td>${labelDate(e.source_date)}</td><td>${labelDate(e.requested_date)}</td><td>${e.applied_period?labelDate(e.applied_period):'—'}${shifted?'<div class="tiny warning-text">Перенос на следующую дату</div>':''}</td><td>${decision}${e.conflict_message?`<div class="tiny warning-text" style="white-space:normal;max-width:380px;margin-top:5px">${esc(e.conflict_message)}</div>`:''}</td></tr>`;
 });
 const historyRows=(data.history||[]).map(b=>`<tr><td>v${b.version}</td><td>${esc(b.original_name)}</td><td>${labelDate((b.uploaded_at||'').slice(0,10))} ${esc((b.uploaded_at||'').slice(11,16))}</td><td>${b.event_count}</td><td>${badge(planStatusNames[b.status]||b.status,b.status==='active'?'green':b.status==='needs_reapply'?'orange':'gray')}</td></tr>`);
 const summary=pending?.summary||{};
 const pendingBlock=pending?`${wrap('Предварительный просмотр','События из нового файла. Никакие прогнозные значения не изменяются до подтверждения.',
  `<div class="cards">${kpi('Новых событий',summary.added||0,'По сравнению с предыдущим файлом')}${kpi('Без изменений',summary.unchanged||0,'Совпали с предыдущей версией')}${kpi('Удалено событий',summary.removed||0,'Будут сняты при замене набора')}</div>`+
  `${eventRows.length?table(['Клиент / УНП','Событие','Дата в файле','Плановая дата (+1 мес.)','Дата применения в БП','Решение / статус'],eventRows):empty('Нет событий для отображения')}`+
  `<div class="actions" style="justify-content:flex-end;margin-top:14px"><button class="btn" id="plan-cancel">Отменить загрузку</button><button class="btn primary" id="plan-apply">Подтвердить и заменить текущий набор</button></div>`
 )}`:empty('Новый файл плановых изменений пока не загружен.');
 const activeBlock=active?`<div class="notice ${active.status==='needs_reapply'?'warning':'good'}"><b>Последний набор событий:</b> ${esc(active.original_name)} · ${active.event_count} событий · ${badge(planStatusNames[active.status]||active.status,active.status==='active'?'green':'orange')}${active.status==='needs_reapply'?'<br>Бизнес-план был перестроен после применения этого файла. Загрузите файл событий повторно, чтобы проверить конфликты и применить его к новой версии прогноза.':''}</div>`:`<div class="notice">Плановые изменения ещё не применялись.</div>`;
 $('content').innerHTML=pageHead('Плановые изменения','Загрузка событий возникновения и снятия НИ, ПФН и НВВ. Применение — с даты из файла плюс один месяц.')+
 `<div class="card card-pad section"><div class="sectionhead"><div><h2>Загрузка файла изменений</h2><p>Ожидается исходная таблица «Таблица 1»: УНП в B, даты возникновения в V:X, даты снятия в Y:AA. Остальные столбцы полностью игнорируются.</p></div><button class="btn mini" data-action="plan-changes-template">Скачать шаблон</button></div>`+
 `<div class="upload-zone" id="plan-changes-drop"><div class="upload-pict">⇧</div><b>Перетащите Excel-файл сюда</b><p>Или выберите файл на компьютере · .xlsx</p><input type="file" accept=".xlsx" id="plan-changes-file" hidden><button class="btn mini" id="plan-changes-pick">Выбрать файл</button></div>`+
 `<div class="notice" style="margin-top:12px">Дата в файле сдвигается на один календарный месяц. Затем используется ближайшая следующая доступная прогнозная дата. Если дата переносится, система показывает предупреждение. Новые месяцы не создаются.</div></div>`+
 `${activeBlock}${pendingBlock}`+
 `${wrap('История файлов','Старые наборы не удаляются. Новый подтверждённый файл заменяет активный набор событий.',historyRows.length?table(['Версия','Файл','Загружен','Событий','Статус'],historyRows):empty('История пока пустая'))}`;
 const input=$('plan-changes-file'),zone=$('plan-changes-drop');
 $('plan-changes-pick').onclick=()=>input.click();input.onchange=()=>{if(input.files.length)uploadPlanChanges(input.files[0])};
 ['dragenter','dragover'].forEach(ev=>zone.addEventListener(ev,e=>{e.preventDefault();zone.classList.add('dragover')}));
 ['dragleave','drop'].forEach(ev=>zone.addEventListener(ev,e=>{e.preventDefault();zone.classList.remove('dragover')}));
 zone.addEventListener('drop',e=>{const f=e.dataTransfer?.files?.[0];if(f)uploadPlanChanges(f)});
 if(pending){$('plan-apply').onclick=()=>applyPlanChanges(pending.id);$('plan-cancel').onclick=async()=>{try{await post('plan-changes/cancel',{batch_id:pending.id});toast('Предварительная загрузка отменена');renderPlanChanges()}catch(e){error(e)}};}
}
const warningNames={debt:'Задолженность',reserve:'Резервы',classification:'Классификация',data:'Контроль данных',fx:'Курсы',factor:'Факторы'};
async function renderReconcile(){if(!dates().length){$('content').innerHTML=pageHead('Сверка с фактом','Сначала загрузите файлы и выполните расчёт')+btn('К загрузке','goto-upload','primary');return}
 const [miss,wrns]=await Promise.all([get('missing',{status:S.tab==='waiting'?'waiting':S.tab==='added'?'added':S.tab==='auto'?'auto':'',page:S.pageNum}),get('warnings',{kind:S.kind,page:1,limit:100})]);
 const tabs=[['waiting','Ожидают включения'],['auto','Добавлены автоматически'],['added','Добавлены вручную'],['all','Все']].map(([k,v])=>`<button class="tab ${S.tab===k?'active':''}" data-set-tab="${k}">${v}</button>`).join('');
 const rows=miss.rows.map(m=>`<tr><td>${m.status==='waiting'?`<input type="checkbox" data-check-key="${esc(m.match_key)}" ${S.selectedKeys.has(m.match_key)?'checked':''}>`:badge(m.status==='auto'?'Авто':'Включён',m.status==='auto'?'green':'blue')}</td><td><b>${esc(m.client)}</b><br><span class="muted">${esc(m.unp)}</span></td><td>${esc(m.contract)}</td><td>${esc(m.ccy)} · ${esc(m.side)}</td><td>${isBlack(m.zone)?badge('Чёрная зона','dark'):esc(m.zone)}</td><td class="right">${money(m.amount_byn)}</td><td>${m.status==='waiting'?`<button class="btn mini" data-add-key="${esc(m.match_key)}">Добавить</button>`:m.status==='added'?`<button class="btn mini danger" data-undo-key="${esc(m.match_key)}">Отменить</button>`:'Автоматически'}</td></tr>`);
 const wTabs=[['','Все ошибки и сверки'],['debt','Задолженность'],['reserve','Резервы'],['classification','ГР и ставка'],['data','Качество данных'],['fx','Курсы']].map(([k,v])=>`<option value="${k}" ${S.kind===k?'selected':''}>${v}</option>`).join('');
 const wrows=wrns.rows.map(w=>{let info={};try{info=JSON.parse(w.details)}catch{}return `<tr><td>${badge(warningNames[w.kind]||w.kind,w.severity==='error'?'red':w.severity==='info'?'purple':'orange')}</td><td>${esc(w.client)}</td><td>${esc(w.contract)}</td><td>${esc(w.message)}${w.kind==='debt'?`<div class="tiny">БП ${money(info.bp_byn)} / факт ${money(info.fact_byn)} / курс ${info.fx||'—'}</div>`:''}</td></tr>`});
 $('content').innerHTML=pageHead('Сверка и договоры','В расчёт автоматически добавляется только чёрная зона; остальные договоры сохраняются до подтверждения.')+
 `<div class="cards">${kpi('Ожидают включения',S.state.missing.waiting||0,'Ручное подтверждение')}${kpi('Добавлены автоматически',S.state.missing.auto||0,'Чёрная зона')}${kpi('Расхождения задолженности',S.state.warnings.debt||0,'Исходный БП не исправляем')}${kpi('Сверка резервов',S.state.warnings.reserve||0,'Рассчитано против факта')}</div>`+
 `<div class="card section"><div class="card-pad"><div class="sectionhead"><div><h2>Реестр договоров</h2><p>Сохранённые позиции из выверенного факта — повторно загружать БП не требуется</p></div><div class="actions"><button class="btn primary" data-action="add-selected">Добавить выбранные (${S.selectedKeys.size})</button></div></div><div class="tabs">${tabs}</div></div>${rows.length?table(['Выбор','Клиент / УНП','Договор','Валюта / баланс','Зона','Сумма факта, BYN','Действие'],rows):empty('Нет договоров в выбранной категории')}<div class="pagination"><span>Всего ${miss.total}</span><button class="btn mini" data-page-prev>Назад</button><b>${S.pageNum}</b><button class="btn mini" data-page-next ${S.pageNum*100>=miss.total?'disabled':''}>Далее</button></div></div>`+
 `<div class="card section"><div class="card-pad sectionhead"><div><h2>Предупреждения и контроль</h2><p>Критические ошибки качества данных отделены от финансовых расхождений</p></div><select id="warning-kind" class="control">${wTabs}</select></div>${wrows.length?table(['Тип','Клиент','Договор','Описание'],wrows):empty('Предупреждений нет')}<div class="pagination">Всего записей: ${wrns.total} (показано до 100)</div></div>`;
 $('warning-kind').onchange=e=>{S.kind=e.target.value;renderReconcile()};}
const isBlack=z=>String(z||'').toLowerCase().includes('черн');
async function addKeys(keys){if(!keys.length){toast('Выберите договоры');return}try{const r=await post('missing/add',{keys});toast(`Добавлено в прогноз: ${r.added}`);S.selectedKeys.clear();await refreshState();renderReconcile()}catch(e){error(e)}}
async function undoKeys(keys){if(!confirm('Отменить включение выбранного договора?'))return;try{const r=await post('missing/undo',{keys});toast(`Возвращено в ожидание: ${r.undone}`);await refreshState();renderReconcile()}catch(e){error(e)}}
async function renderForecast(){if(!dates().length){$('content').innerHTML=pageHead('Прогноз по договорам','Сначала загрузите файлы и выполните расчёт')+btn('К загрузке','goto-upload','primary');return}
 let tabs=`<div class="toolbar"><div class="metric-tabs"><button class="btn mini ${S.metric==='period'?'selected':''}" data-mode="period">Показатели периода</button><button class="btn mini ${S.metric!=='period'?'selected':''}" data-mode="debt">Весь горизонт</button></div><div class="grow"></div><input class="input wide" id="forecast-search" placeholder="Поиск: клиент, УНП, договор" value="${esc(S.search)}"><button class="btn mini" data-action="apply-search">Найти</button></div>`;
 if(S.metric==='period'){
 const report=await get('positions',{period:S.period,search:S.search,page:S.pageNum,limit:50,side:S.side,gr:S.riskGr,sort:S.riskSort});const s=report.rows;
 let rows=s.map(r=>`<tr><td><b>${esc(r.client)}</b><br><span class="tiny">${esc(r.unp)}</span></td><td>${esc(r.contract)}<br>${badge(r.side,r.side==='баланс'?'blue':'orange')}</td><td>${esc(r.ccy)}</td><td class="right editable" data-edit="${r.id}|debt">${money(r.debt)}</td><td class="right">${money(r.od)}</td><td class="editable" data-edit="${r.id}|ni">${r.ni}</td><td class="editable" data-edit="${r.id}|pfn">${r.pfn}</td><td class="editable" data-edit="${r.id}|nvv">${r.nvv}</td><td class="editable" data-edit="${r.id}|restra">${esc(r.restra)||'—'}</td><td class="editable" data-edit="${r.id}|security">${esc(r.security)||'—'}</td><td class="editable ${r.risk_error?'risk-invalid':''}" data-edit="${r.id}|gr" title="${esc(r.risk_error?(r.method_gr&&r.gr?'ГР отличается от методической: '+r.method_gr:'Методическая группа риска не определена'):'Группа риска')}">${r.gr?esc(r.gr):badge('Ошибка ГР','red')}${r.risk_error&&r.gr?'<span class="risk-warning-mark" aria-label="Несоответствие методике">!</span>':''}${r.source_gr_corrected?'<span class="risk-source-corrected" title="Исходная ГР бизнес-плана исправлена по методологии">Исправлена</span>':''}</td><td class="editable" data-edit="${r.id}|rate">${r.rate===null?'—':money(r.rate,1)+'%'}</td><td class="right strong">${money(r.reserve)}</td><td class="right ${moneyClass(r.expenses)}">${money(r.expenses)}</td></tr>`);
 $('content').innerHTML=pageHead('Прогноз по договорам','Редактируйте задолженность и критерии; ГР, ставка, резерв и денежные факторы пересчитываются.')+tabs+
 `<div class="toolbar"><label>Дата: ${periodSel('period-select',S.period)}</label><label>Баланс / УО: <select id="side-select" class="control"><option value="">Все</option><option ${S.side==='баланс'?'selected':''}>баланс</option><option ${S.side==='внебаланс'?'selected':''}>внебаланс</option></select></label><label>Группа риска: <select id="risk-gr-select" class="control"><option value="">Все ГР</option>${['1','2','3','4','5','6','ПОК'].map(g=>`<option value="${g}" ${S.riskGr===g?'selected':''}>${g==='ПОК'?'ПОК':g+' ГР'}</option>`).join('')}<option value="__issues__" ${S.riskGr==='__issues__'?'selected':''}>Все замечания по ГР</option><option value="__corrected__" ${S.riskGr==='__corrected__'?'selected':''}>Исправлена ГР из БП</option><option value="__error__" ${S.riskGr==='__error__'?'selected':''}>Ошибка текущей ГР</option></select></label><label>Сортировка: <select id="risk-sort-select" class="control"><option value="client" ${S.riskSort==='client'?'selected':''}>По клиенту</option><option value="risk_errors" ${S.riskSort==='risk_errors'?'selected':''}>Ошибки сначала</option></select></label><span class="muted">${report.total.toLocaleString('ru-RU')} позиций</span></div><div class="card section">${s.length?table(['Клиент','Договор / тип','Валюта',{label:'Задолженность',right:true},{label:'OD, BYN',right:true},'НИ','ПФН','НВВ','Рестра','Обеспеченность','ГР','% рез',{label:'Резерв, BYN',right:true},{label:'Расходы, BYN',right:true}],rows):empty('Нет позиций')}<div class="pagination"><span>Страница ${S.pageNum}</span><button class="btn mini" data-page-prev>Назад</button><button class="btn mini" data-page-next ${report.total<=S.pageNum*50?'disabled':''}>Далее</button></div></div><p class="footer-note">Поля с подчёркиванием доступны для редактирования. НИ/ПФН/НВВ распространяются на все договоры УНП с выбранной даты; задолженность — только на выбранную дату.</p>`;
 $('period-select').onchange=e=>{S.period=e.target.value;S.pageNum=1;renderForecast()};$('side-select').onchange=e=>{S.side=e.target.value;S.pageNum=1;renderForecast()};$('risk-gr-select').onchange=e=>{S.riskGr=e.target.value;S.pageNum=1;renderForecast()};$('risk-sort-select').onchange=e=>{S.riskSort=e.target.value;S.pageNum=1;renderForecast()};
 }else{
 const metric=S.metric==='period'?'debt':S.metric;const response=await get('horizon',{metric,search:S.search,page:S.pageNum,limit:40});const ms=[['debt','Задолженность'],['od','OD, BYN'],['reserve','Резервы'],['expenses','Расходы'],['gr','Группа риска'],['rate','% рез'],['ni','НИ'],['pfn','ПФН'],['nvv','НВВ'],['security','Обеспеченность']].map(([k,title])=>`<button class="btn mini ${metric===k?'selected':''}" data-metric="${k}">${title}</button>`).join('');
 const rows=response.rows.map(r=>`<tr><td><b>${esc(r.client)}</b><br><span class="tiny">${esc(r.contract)} · ${esc(r.ccy)} · ${esc(r.side)}</span></td>${dates().map(d=>`<td class="right ${['expenses'].includes(metric)?moneyClass(r.values[d]):''} ${['debt','ni','pfn','nvv','rate','gr','security'].includes(metric)?'editable':''}" ${['debt','ni','pfn','nvv','rate','gr','security'].includes(metric)?`data-h-edit="${r.id}|${metric}|${d}"`:''}>${['gr','security'].includes(metric)?esc(r.values[d]??'—'):['ni','pfn','nvv'].includes(metric)?r.values[d]??'—':money(r.values[d],metric==='rate'?1:2)}</td>`).join('')}</tr>`);
 $('content').innerHTML=pageHead('Прогноз · Весь горизонт','Строки — договоры; даты — прогнозные периоды. Кликните на подчёркнутую ячейку для редактирования.')+tabs+
 `<div class="card card-pad"><div class="sectionhead"><h2>Показатель по всем датам</h2>${badge(metric==='debt'?'В валюте договора':metric==='rate'?'В процентах':'BYN','blue')}</div><div class="metric-tabs" style="margin-bottom:20px;flex-wrap:wrap">${ms}</div>${rows.length?table(['Клиент / договор',...dates().map(labelDate)],rows,'horizon'):empty('Договоры не найдены')}<div class="pagination"><button class="btn mini" data-page-prev>Назад</button>Страница ${S.pageNum}<button class="btn mini" data-page-next ${rows.length<40?'disabled':''}>Далее</button></div></div>`;
 }
}
async function showEdit(positionId,field,period=S.period){const fields={debt:'Задолженность в валюте договора',ni:'НИ (0/1)',pfn:'ПФН (0/1)',nvv:'НВВ (0/1)',restra:'Реструктуризация договора',security:'Обеспеченность',gr:'Группа риска',rate:'Процент резервирования'};
 const input=field==='security'?`<select class="form-input" id="edit-value"><option>Высококачественное обеспечение</option><option>Обеспеченный</option><option>Недостаточно обеспеченный</option><option>Необеспеченный</option><option>Обеспеченный (не указан)</option></select>`:`<input class="form-input" id="edit-value" placeholder="Введите новое значение">`;
 modal('Редактирование · '+(fields[field]||field),`<div class="sub">Период: ${labelDate(period)}. ${field==='debt'?'Изменится только выбранная дата.':'Изменение распространится на все последующие даты.'} ${['ni','pfn','nvv'].includes(field)?'Клиентский признак будет обновлён по всем договорам УНП.':''}</div><label class="form-label">Новое значение</label>${input}<label class="form-label">Причина изменения ${['gr','rate'].includes(field)?'(обязательна)':'(необязательно)'}</label><textarea class="form-input" id="edit-reason" rows="3" placeholder="Комментарий аналитика"></textarea><div class="notice" style="margin-top:13px">ГР и процент резервирования будут пересчитаны по методике. Ручное изменение ГР / ставки сохраняется как исключение с причиной.</div>`,
 `<button class="btn" data-close>Отмена</button><button class="btn primary" id="edit-submit">Сохранить и пересчитать</button>`);
 $('edit-submit').onclick=async()=>{try{const value=$('edit-value').value,reason=$('edit-reason').value;await post('edit',{position_id:+positionId,period,field,value,reason});closeModal();toast('Изменение сохранено, расчёт обновлён');await refreshState();renderForecast()}catch(e){error(e)}};
}
async function runFactorRecalc(){
 if(!confirm('Пересчитать все договоры по новой методике факторного анализа? Исходные задолженности и признаки не изменяются; ГР, ставки, резервы и распределение расходов будут повторно рассчитаны по текущим критериям и ручным ставкам.'))return;
 try{
  await post('recalculate',{});
  toast('Пересчёт запущен. Можно оставаться на этой странице.');
  const poll=async()=>{
   try{
    const job=await get('job');
    if(job.status==='running'){
     const hint=$('factor-recalc-status');
     if(hint)hint.textContent=job.stage||'Пересчёт выполняется';
     setTimeout(poll,1500);return;
    }
    if(job.status==='done'){
     toast('Пересчитано договоров: '+(job.result?.positions_recalculated||0));
     await refreshState();if(S.page==='factors')renderFactors();return;
    }
    if(job.status==='error'){error(new Error(job.error||'Ошибка пересчёта'));return;}
   }catch(e){error(e);}
  };
  const hint=$('factor-recalc-status');if(hint)hint.textContent='Пересчёт выполняется';
  setTimeout(poll,800);
 }catch(e){error(e);}
}

async function renderFactors(){if(!dates().length){$('content').innerHTML=pageHead('Факторный анализ','Сначала постройте прогноз');return}
 const result=await get('factors',{period:S.period,search:S.factorSearch,side:S.factorSide});const t=result.totals;
 const factors=[['Движение КП',t.movement],['Финансовое состояние',t.financial_state],['Изменение обеспечения',t.security_effect],['Переоценка',t.revaluation]];
 const max=Math.max(1,...factors.map(x=>Math.abs(x[1])));
 const bridge=factors.map(([label,value])=>`<div class="wf-item"><span class="wf-value ${moneyClass(value)}">${money(value)}</span><div class="wf-barwrap"><div class="wf-bar ${value<0?'neg':''}" style="height:${Math.max(3,Math.abs(value)/max*135)}px"></div></div><span class="wf-label">${label}</span></div>`).join('');
 const sub=[];
 for(const group of (result.factor_groups||[])){
  if(group.key==='revaluation')continue;
  const sections=group.sections||[{name:'',items:group.items||[]}];
  for(const section of sections){
   if(section.name)sub.push(`<tr class="factor-group-row"><td colspan="3"><b>${esc(group.name)} · ${esc(section.name)}</b></td></tr>`);
   else sub.push(`<tr class="factor-group-row"><td colspan="3"><b>${esc(group.name)}</b></td></tr>`);
   for(const key of section.items){
    const name=result.factor_names[key]||key,val=result.subfactors[key]||0;
    sub.push(`<tr><td>${esc(name)}</td><td class="right ${moneyClass(val)}"><b>${money(val)}</b></td><td class="right">${result.events[key]||'—'}</td></tr>`);
   }
  }
 }
 const check=round2(t.expenses-t.movement-t.financial_state-t.security_effect-t.revaluation);
 $('content').innerHTML=pageHead('Факторный анализ','Расходы = движение кредитного портфеля + финансовое состояние + обеспечение + переоценка.',btn('Сравнить планы','compare-factors')+btn('Пересчитать весь прогноз','recalc-factors','outline'))+
 `<div class="toolbar"><label>Период: ${periodSel('factor-period',S.period)}</label><input id="factor-search" class="input wide" placeholder="Клиент, УНП, договор" value="${esc(S.factorSearch)}"><select id="factor-side" class="control"><option value="">Баланс + УО</option><option value="баланс" ${S.factorSide==='баланс'?'selected':''}>Баланс</option><option value="внебаланс" ${S.factorSide==='внебаланс'?'selected':''}>Внебаланс</option></select>${btn('Применить','apply-factors','primary')}</div><div id="factor-recalc-status" class="sub"></div>`+
 `<div class="cards">${kpi('Расходы на резервы',money(t.expenses),'BYN · '+labelDate(S.period))}${kpi('Движение КП',money(t.movement),'BYN')}${kpi('Финансовое состояние',money(t.financial_state),'BYN')}${kpi('Изменение обеспечения',money(t.security_effect),'BYN')}${kpi('Переоценка',money(t.revaluation),'BYN')}</div>`+
 `<div class="cols2">${wrap('Денежный мост','Последовательное разложение по четырём факторам',`<div class="waterfall">${bridge}</div><div class="spaced" style="margin-top:20px"><span class="sub">Сверка факторов</span>${badge(money(check)+' BYN',Math.abs(check)<=0.01?'green':'red')}</div>`)}${wrap('Подфакторы','Реклассификация — снятие реструктуризации — показана отдельно внутри финансового состояния.',table(['Подфактор','Расходы, BYN','События'],sub))}</div>`+
 `<div class="notice good" style="margin-top:15px">Отрицательное значение — создание резерва, положительное — его восстановление. Движение портфеля использует предыдущую ставку; новые договоры — базовые 0,5% для 1 ГР и 5% для 2 ГР и выше. Финансовое состояние рассчитывается до обеспечения.</div>`;
 $('factor-period').onchange=e=>{S.period=e.target.value;renderFactors()};$('factor-side').onchange=e=>{S.factorSide=e.target.value;renderFactors()};}

const round2=x=>Math.round((x+Number.EPSILON)*100)/100;
async function renderClients(){if(!dates().length){$('content').innerHTML=pageHead('Поклиентный отчёт','Сначала постройте прогноз');return}
 const r=await get('clients',{period:S.period,search:S.clientSearch});const rows=r.important.map(x=>`<tr><td><b>${esc(x.client)}</b><br><span class="tiny">${esc(x.unp)}</span></td><td>${isBlack(x.zone)?badge('ДРПА','dark'):badge('Индивидуал','blue')}</td><td class="right ${moneyClass(x.expenses)}"><b>${money(x.expenses)}</b></td><td class="right">${money(x.movement)}</td><td class="right">${money(x.financial_state)}</td><td class="right">${money(x.security_effect)}</td><td class="right">${money(x.revaluation)}</td><td style="max-width:320px;white-space:normal;font-size:11px">${esc(x.comment||x.auto_comment)}</td><td><button class="btn mini" data-comment="${esc(x.unp)}" data-client="${esc(x.client)}" data-auto="${esc(x.auto_comment)}" data-old="${esc(x.comment)}">Комментарий</button></td></tr>`);
 const x=r.standard;rows.push(`<tr style="background:#f5f7fb"><td class="strong">Стандартный портфель <span class="tiny">(${x.clients||0} клиентов)</span></td><td>Агрегировано</td><td class="right strong ${moneyClass(x.expenses)}">${money(x.expenses)}</td><td class="right">${money(x.movement)}</td><td class="right">${money(x.financial_state)}</td><td class="right">${money(x.security_effect)}</td><td class="right">${money(x.revaluation)}</td><td colspan="2">—</td></tr>`);
 $('content').innerHTML=pageHead('Поклиентный отчёт','Индивидуалы: |расходы клиента за период| ≥ 100 000 BYN. Остальные — стандартный портфель.')+
 `<div class="toolbar"><label>Период: ${periodSel('client-period',S.period)}</label><input class="input wide" id="client-search" placeholder="Поиск клиента или УНП" value="${esc(S.clientSearch)}">${btn('Найти','apply-clients','primary')}</div>`+
 `<div class="card section">${table(['Клиент / УНП','Категория','Расходы, BYN','Движение КП','Финансовое состояние','Обеспечение','Переоценка','Комментарий','Действие'],rows)}</div>`+
 `<div class="notice">Автоматический комментарий содержит изменение задолженности в миллионах единиц валюты договора. Ручной комментарий сохраняется и не заменяется автоматическим.</div>`;
 $('client-period').onchange=e=>{S.period=e.target.value;renderClients()};}
function editComment(unp,client,automatic,previous){modal('Комментарий · '+client,`<div class="sub">Клиент: ${esc(unp)}</div><label class="form-label">Автоматическое объяснение</label><div class="explain">${esc(automatic)}</div><label class="form-label">Комментарий аналитика</label><textarea class="form-input" id="comment-text" rows="5">${esc(previous||automatic)}</textarea>`,
 `<button class="btn" data-close>Отмена</button><button class="btn primary" id="comment-save">Сохранить</button>`);
 $('comment-save').onclick=async()=>{try{await post('comment',{unp,comment:$('comment-text').value});closeModal();toast('Комментарий сохранён');renderClients()}catch(e){error(e)}}}
async function renderHistory(){if(!S.pid){$('content').innerHTML=noPlan();return}const versions=await get('versions');const rows=versions.versions.map(x=>`<tr><td>${badge('Версия '+x.version,'green')}</td><td>${esc(x.title)}</td><td>${esc(x.created)}</td><td>${badge('Зафиксирована','green')}</td></tr>`);
 $('content').innerHTML=pageHead('Версии и история','Контрольные снимки бизнес-плана, сохранённые на локальном компьютере.',btn('Сохранить текущую версию','save-version','primary'))+
 `<div class="card section">${rows.length?table(['Версия','Название','Дата фиксации','Статус'],rows):empty('Пока нет сохранённых версий')}<div class="card-pad sub">Каждая зафиксированная версия создаёт отдельный снимок SQLite. Для большого портфеля потребуется дополнительное дисковое пространство.</div></div>`+
 `<div class="card card-pad"><div class="sectionhead"><h2>Выгрузка</h2></div><div class="actions">${btn('Скачать Excel с детализацией','export-excel','primary')}${btn('Открыть отчёт для PDF','open-print')}</div><p class="sub">В Excel: прогноз, существенные клиенты, факторы, сверки, реестр договоров, контроль и история. PDF — краткое резюме.</p></div>`}
async function createProject(){modal('Создание бизнес-плана',`<label class="form-label">Название</label><input class="form-input" id="new-title" value="Бизнес-план НСФО 2027" placeholder="Например: Бизнес-план 2027, версия 1">`,
 `<button class="btn" data-close>Отмена</button><button class="btn primary" id="create-submit">Создать</button>`);
 $('create-submit').onclick=async()=>{try{const r=await api('/api/projects',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name:$('new-title').value})});S.pid=r.id;S.state=null;S.period=null;closeModal();toast('Создан новый бизнес-план');nav('upload')}catch(e){error(e)}};}
async function chooseProject(){const data=await api('/api/projects');modal('Выберите бизнес-план',`<div class="stack search-results">${data.projects.map(p=>`<button class="btn" data-choose-project="${p.id}" style="text-align:left">${esc(p.name)} · ${badge(statusText[p.status]||p.status)}</button>`).join('')||empty('Пока нет бизнес-планов')}</div>`,btn('Создать новый','create'))}
async function saveVersion(){if(!S.pid)return error(Error('Создайте бизнес-план'));const title=prompt('Название сохраняемой версии:','Бизнес-план · проверка '+new Date().toLocaleDateString('ru-RU'));if(!title)return;try{const r=await post('save-version',{title});toast('Зафиксирована версия '+r.version);await refreshState();nav('history')}catch(e){error(e)}}
function downloadFile(ext){if(!S.pid)return;window.location.href=`/api/projects/${S.pid}/export.${ext}`;}
// One delegated event handler keeps rebuilt screens functional.
document.addEventListener('click',async e=>{const navtarget=e.target.closest('[data-page]');if(navtarget){if(!S.auth)return showLogin();return nav(navtarget.dataset.page);}
 if(e.target.closest('#logout-btn')){try{await api('/api/auth/logout',{method:'POST',body:'{}'});S.auth=null;S.pid=null;S.csrf='';showLogin()}catch(x){error(x)}return;}
 const action=e.target.closest('[data-action]');if(action){const a=action.dataset.action;
 if(a==='create')return createProject();if(a==='goto-upload')return nav('upload');if(a==='goto-reconcile')return nav('reconcile');if(a==='save-version')return saveVersion();if(a==='pick-file')return $('file-'+action.dataset.kind).click();if(a==='plan-changes-template')return window.location.href=`/api/projects/${S.pid}/plan-changes/template.xlsx`;if(a==='start-build')return startBuild();if(a==='confirm-fact-date'){try{const r=await post('fact-date',{date:$('confirmed-fact-date').value});toast('Дата факта сохранена: '+labelDate(r.date));await refreshState()}catch(e){error(e)}return;}if(a==='add-selected')return addKeys([...S.selectedKeys]);if(a==='apply-search'){S.search=$('forecast-search').value.trim();S.pageNum=1;return renderForecast()};if(a==='compare-factors'){openFactorComparison();return}if(a==='apply-factors'){S.factorSearch=$('factor-search').value.trim();return renderFactors()};if(a==='recalc-factors')return runFactorRecalc();if(a==='apply-clients'){S.clientSearch=$('client-search').value.trim();return renderClients()};if(a==='export-excel')return downloadFile('xlsx');if(a==='export-pdf')return downloadFile('pdf');if(a==='open-print')return window.open(`/api/projects/${S.pid}/print`,'_blank');}
 const tab=e.target.closest('[data-set-tab]');if(tab){S.tab=tab.dataset.setTab;S.pageNum=1;S.selectedKeys.clear();return renderReconcile()}
 const chk=e.target.closest('[data-check-key]');if(chk){if(chk.checked)S.selectedKeys.add(chk.dataset.checkKey);else S.selectedKeys.delete(chk.dataset.checkKey);return;}
 const add=e.target.closest('[data-add-key]');if(add)return addKeys([add.dataset.addKey]);const undo=e.target.closest('[data-undo-key]');if(undo)return undoKeys([undo.dataset.undoKey]);
 const prev=e.target.closest('[data-page-prev]');if(prev){S.pageNum=Math.max(1,S.pageNum-1);return render()};const next=e.target.closest('[data-page-next]');if(next){S.pageNum++;return render()};
 const mode=e.target.closest('[data-mode]');if(mode){S.metric=mode.dataset.mode;S.pageNum=1;return renderForecast()};const metric=e.target.closest('[data-metric]');if(metric){S.metric=metric.dataset.metric;return renderForecast()};
 const edit=e.target.closest('[data-edit]');if(edit){const [id,field]=edit.dataset.edit.split('|');return showEdit(id,field)};
 const hedge=e.target.closest('[data-h-edit]');if(hedge){const [id,field,date]=hedge.dataset.hEdit.split('|');return showEdit(id,field,date)};
 const comment=e.target.closest('[data-comment]');if(comment)return editComment(comment.dataset.comment,comment.dataset.client,comment.dataset.auto,comment.dataset.old);
 const choose=e.target.closest('[data-choose-project]');if(choose){S.pid=+choose.dataset.chooseProject;S.period=null;S.search='';closeModal();return nav('overview')};
});
$('project-select').onclick=chooseProject;
['dragenter','dragover','drop'].forEach(event=>window.addEventListener(event,e=>e.preventDefault()));
initSidebarToggle();
initialize();
