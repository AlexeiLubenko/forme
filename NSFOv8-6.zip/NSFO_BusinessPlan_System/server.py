"""Local HTTP server for NSFO business-plan forecasting. No third-party web framework."""
from __future__ import annotations
import json, os, tempfile, threading, urllib.parse, traceback, zipfile, datetime, time, webbrowser
from pathlib import Path
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
import engine
import dashboard_service as dash
import access_control as access
import plan_comparison as comparison
import current_portfolio
import activity_log as activity
from exports import build_excel, build_pdf, build_printable_html

ROOT=Path(__file__).resolve().parent
STATIC=ROOT/'static'
BIND=os.getenv('NSFO_HOST','127.0.0.1')
PORT=int(os.getenv('NSFO_PORT','8502'))
MAX_UPLOAD=int(os.getenv('NSFO_MAX_UPLOAD_MB','768'))*1024*1024
LOCK=threading.RLock()
JOBS={}
MIME={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.svg':'image/svg+xml','.png':'image/png'}

class Handler(BaseHTTPRequestHandler):
    server_version='NSFO-Local/1.0'
    def log_message(self,fmt,*args):
        print('%s %s'%(self.address_string(),fmt%args),flush=True)
    def reply(self,obj,status=200):
        if getattr(self, '_activity_action', None):
            detail = obj.get('error') if isinstance(obj, dict) and status >= 400 else None
            activity.record(self._activity_action, 'error' if status >= 400 else 'done',
                            getattr(self, '_activity_project', None),
                            getattr(self, '_activity_user', None), detail,
                            time.monotonic() - self._activity_started)
            self._activity_action = None
        b=json.dumps(obj,ensure_ascii=False,default=str).encode('utf-8')
        self.send_response(status);self.send_header('Content-Type','application/json; charset=utf-8');self.send_header('Content-Length',str(len(b)))
        self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff');self.end_headers();self.wfile.write(b)
    def fail(self,exc):
        self.reply({'error':str(exc)},400)
    def _actor(self):
        return access.current(self.headers.get('Cookie',''))
    def require_access(self, roles=None, csrf=False):
        actor=self._actor()
        if not actor:
            self.reply({'error':'Требуется вход в систему'},401)
            return None
        if roles is not None and actor['role'] not in roles:
            self.reply({'error':'Недостаточно прав доступа'},403)
            return None
        if csrf and not access.csrf_ok(actor,self.headers.get('X-CSRF-Token','')):
            self.reply({'error':'Ошибка CSRF: обновите страницу и войдите заново'},403)
            return None
        return actor
    def _upload_temp(self,prefix='nsfo_dash_'):
        filename=urllib.parse.unquote(self.headers.get('X-Filename','upload.xlsx'))
        if not filename.lower().endswith('.xlsx'):raise ValueError('Поддерживаются только .xlsx')
        length=int(self.headers.get('Content-Length','0'))
        if length<=0 or length>MAX_UPLOAD:raise ValueError('Недопустимый размер файла')
        fd,tmp=tempfile.mkstemp(prefix=prefix,suffix='.xlsx',dir=str(engine.DATA))
        try:
            with os.fdopen(fd,'wb') as out:
                remaining=length
                while remaining>0:
                    data=self.rfile.read(min(128*1024,remaining))
                    if not data:raise IOError('Загрузка прервана')
                    out.write(data);remaining-=len(data)
            if not zipfile.is_zipfile(tmp):raise ValueError('Файл не является XLSX')
            with zipfile.ZipFile(tmp) as z:
                if len(z.infolist())>30000 or sum(i.file_size for i in z.infolist())>3*1024**3:
                    raise ValueError('Недопустимый размер распакованного Excel')
            return tmp,filename[:160]
        except Exception:
            if os.path.exists(tmp):os.unlink(tmp)
            raise
    def json_body(self):
        n=int(self.headers.get('Content-Length','0'))
        if n<0 or n>500000:raise ValueError('Недопустимый размер JSON')
        return json.loads(self.rfile.read(n) or b'{}')
    def parsed(self):
        u=urllib.parse.urlparse(self.path);return u.path,urllib.parse.parse_qs(u.query)
    def start_activity(self, method, path):
        if not path.startswith('/api/') or path=='/api/activity' or path.endswith('/job'):
            return
        self._activity_action = method + ' ' + path
        self._activity_started = time.monotonic()
        parts = path.split('/')
        self._activity_project = int(parts[3]) if len(parts)>3 and parts[2]=='projects' and parts[3].isdigit() else None
        actor = self._actor()
        self._activity_user = actor['username'] if actor else None
        activity.record(self._activity_action, project=self._activity_project, actor=self._activity_user)
    def get_pid(self,path):
        parts=path.strip('/').split('/')
        if len(parts)<3 or parts[:2]!=['api','projects']:raise ValueError('Некорректный адрес проекта')
        return int(parts[2]),parts[3:] if len(parts)>3 else []
    def do_GET(self):
        try:
            path,query=self.parsed();q=lambda k,default='':query.get(k,[default])[0]
            self.start_activity('GET',path)
            if path=='/api/auth/me':
                actor=self.require_access()
                if actor is None:return
                return self.reply({'username':actor['username'],'role':actor['role']})
            if path.startswith('/api/'):
                # Dashboard management (including preview, factor details and
                # file downloads) is reserved for administrators. Editors may
                # read/change all project data but not dashboard sources.
                roles = (None if path=='/api/dashboard'
                         else ('admin','editor') if path in ('/api/dashboard/factors','/api/dashboard/factors.xlsx')
                         else ('admin',) if path.startswith('/api/dashboard/')
                         else ('admin','editor'))
                actor=self.require_access(roles=roles)
                if actor is None:return
            if path=='/api/dashboard':
                return self.reply(dash.dashboard_data(q('year',str(datetime.date.today().year)),q('month',str(datetime.date.today().month)),False))
            if path=='/api/activity':
                return self.reply({'events':activity.recent(limit=q('limit',100))})
            if path=='/api/dashboard/admin':
                return self.reply(dash.admin_state())
            if path=='/api/dashboard/preview':
                if actor['role']!='admin':return self.reply({'error':'Нет доступа'},403)
                return self.reply(dash.dashboard_data(q('year',str(datetime.date.today().year)),q('month',str(datetime.date.today().month)),True))
            if path=='/api/dashboard/factors':
                if actor['role'] not in ('admin','editor'):return self.reply({'error':'Нет доступа'},403)
                return self.reply(dash.factor_detail(q('year',str(datetime.date.today().year)),q('month','1'),q('search'),q('page',1)))
            if path=='/api/dashboard/factors.xlsx':
                if actor['role'] not in ('admin','editor'):return self.reply({'error':'Нет доступа'},403)
                fd,tmp=tempfile.mkstemp(prefix='nsfo_factors_',suffix='.xlsx',dir=str(engine.DATA))
                os.close(fd)
                try:
                    dash.export_factor_excel(q('year',str(datetime.date.today().year)),q('month','1'),tmp,
                                             admin=(q('draft','0')=='1' and actor['role']=='admin'))
                    return self.path_response(tmp,'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                                              'NSFO_Fact_Factors_Details.xlsx')
                finally:
                    if os.path.exists(tmp):os.unlink(tmp)
            if path=='/api/dashboard/factor-errors':
                return self.reply(dash.factor_errors(int(q('run','0'))))
            if path=='/api/dashboard/template.xlsx':
                return self.path_response(ROOT/'examples'/'Шаблон_показателей_дашборда.xlsx',
                    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet','dashboard_metrics_template.xlsx')
            if path=='/api/dashboard/portfolio-template.xlsx':
                # This route is protected by require_access: admin only.
                return self.path_response(ROOT/'examples'/'07_Шаблон_фактического_портфеля_ЮЛ.xlsx',
                    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet','NSFO_UL_fact_portfolio_template.xlsx')
            if path=='/api/projects':return self.reply({'projects':engine.list_projects()})
            if path.startswith('/api/projects/'):
                pid,tail=self.get_pid(path);route='/'.join(tail)
                if route=='state':return self.reply(engine.get_state(pid))
                if route=='job':return self.reply(JOBS.get(pid,{'status':'idle'}))
                if route=='plan-changes':return self.reply(engine.get_plan_changes(pid))
                if route=='plan-changes/template.xlsx':
                    return self.file_response(engine.build_plan_changes_template(),
                        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                        'plan_changes_template.xlsx')
                if route=='positions':return self.reply(engine.list_positions(pid,q('period'),q('search'),q('page',1),q('limit',50),q('side'),q('zone'),q('gr'),q('sort','client')))
                if route=='horizon':return self.reply(engine.period_debt_horizon(pid,q('metric','debt'),q('search'),int(q('limit',40)),int(q('page',1))))
                if route=='missing':return self.reply(engine.list_missing(pid,q('status','waiting'),q('page',1),q('limit',100)))
                if route=='warnings':return self.reply(engine.list_warnings(pid,q('kind'),q('page',1),q('limit',100)))
                if route=='current-portfolio':
                    return self.reply(current_portfolio.report(pid,q('kind'),q('search'),q('page',1)))
                if route=='comparison':
                    return self.reply(comparison.compare(pid,q('start'),q('end'),q('search'),q('side'),
                                                         q('page',1),q('client')))
                if route=='comparison/template.xlsx':
                    return self.path_response(ROOT/'examples'/comparison.TEMPLATE,
                        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet','NSFO_reference_plan.xlsx')
                if route=='factors':return self.reply(engine.factor_summary(pid,q('period'),q('search'),q('zone'),q('side')))
                if route=='clients':return self.reply(engine.client_report(pid,q('period'),q('search'),int(q('limit',200)),int(q('page',1))))
                if route=='versions':return self.reply({'versions':engine.list_versions(pid)})
                if route=='export.xlsx':
                    fd,tmp=tempfile.mkstemp(prefix='nsfo_export_',suffix='.xlsx',dir=str(engine.DATA))
                    os.close(fd)
                    try:
                        build_excel(pid,output_path=tmp)
                        return self.path_response(tmp,'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',f'NSFO_Plan_{pid}.xlsx')
                    finally:
                        if os.path.exists(tmp):os.unlink(tmp)
                if route=='print':
                    content=build_printable_html(pid).encode('utf-8')
                    self.send_response(200)
                    self.send_header('Content-Type','text/html; charset=utf-8')
                    self.send_header('Content-Length',str(len(content)))
                    self.end_headers()
                    return self.wfile.write(content)
                if route=='export.pdf':return self.file_response(build_pdf(pid),'application/pdf',f'NSFO_Report_{pid}.pdf')
                return self.reply({'error':'Неизвестный маршрут'},404)
            if path in ('/','/index.html'):target=STATIC/'index.html'
            else:
                target=(STATIC/path.lstrip('/')).resolve()
                if not target.is_relative_to(STATIC.resolve()):return self.reply({'error':'Запрещённый путь'},403)
            if not target.is_file():return self.reply({'error':'Файл не найден'},404)
            b=target.read_bytes();self.send_response(200);self.send_header('Content-Type',MIME.get(target.suffix,'application/octet-stream'))
            self.send_header('Content-Length',str(len(b)));self.end_headers();self.wfile.write(b)
        except (OSError,ValueError,KeyError,engine.MethodologyError) as e:self.fail(e)
        except Exception as e:
            traceback.print_exc();self.reply({'error':'Внутренняя ошибка: '+str(e)},500)
    def path_response(self,path,content_type,name):
        self.send_response(200)
        self.send_header('Content-Type',content_type)
        self.send_header('Content-Disposition',f'attachment; filename="{name}"')
        self.send_header('Content-Length',str(os.path.getsize(path)))
        self.end_headers()
        with open(path,'rb') as src:
            while True:
                chunk=src.read(128*1024)
                if not chunk:break
                self.wfile.write(chunk)
        if getattr(self, '_activity_action', None):
            activity.record(self._activity_action, 'done', self._activity_project,
                            self._activity_user, duration=time.monotonic()-self._activity_started)
            self._activity_action=None
    def file_response(self,buf,content_type,name):
        self.send_response(200);self.send_header('Content-Type',content_type)
        self.send_header('Content-Disposition',f'attachment; filename="{name}"')
        self.send_header('Content-Length',str(len(buf.getbuffer())));self.end_headers()
        while True:
            b=buf.read(65536)
            if not b:break
            self.wfile.write(b)
        if getattr(self, '_activity_action', None):
            activity.record(self._activity_action, 'done', self._activity_project,
                            self._activity_user, duration=time.monotonic()-self._activity_started)
            self._activity_action=None
    def do_POST(self):
        try:
            path,q=self.parsed()
            self.start_activity('POST',path)
            if path=='/api/auth/login':
                v=self.json_body()
                try:result=access.login(v.get('username'),v.get('password'),self.client_address[0])
                except PermissionError as e:return self.reply({'error':str(e)},401)
                self.send_response(200)
                self.send_header('Content-Type','application/json; charset=utf-8')
                cookie=f'nsfo_session={result["token"]}; HttpOnly; SameSite=Strict; Path=/; Max-Age={access.SESSIONS_HOURS*3600}'
                if os.getenv('NSFO_COOKIE_SECURE')=='1':cookie+='; Secure'
                self.send_header('Set-Cookie',cookie)
                csrf_cookie=f'nsfo_csrf={result["csrf"]}; SameSite=Strict; Path=/; Max-Age={access.SESSIONS_HOURS*3600}'
                if os.getenv('NSFO_COOKIE_SECURE')=='1':csrf_cookie+='; Secure'
                self.send_header('Set-Cookie',csrf_cookie)
                content=json.dumps({k:result[k] for k in ('username','role','csrf')}).encode('utf-8')
                self.send_header('Content-Length',str(len(content)))
                self.send_header('Cache-Control','no-store')
                activity.record('POST /api/auth/login', 'done', actor=result['username'],
                                duration=time.monotonic()-self._activity_started)
                self._activity_action=None
                self.end_headers();return self.wfile.write(content)
            roles = (None if path=='/api/auth/logout'
                     else ('admin',) if path.startswith('/api/dashboard/')
                     else ('admin','editor'))
            actor=self.require_access(roles=roles,csrf=True)
            if actor is None:return
            if path=='/api/auth/logout':
                access.logout(self.headers.get('Cookie',''))
                self.send_response(200)
                self.send_header('Set-Cookie','nsfo_session=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0')
                self.send_header('Set-Cookie','nsfo_csrf=; SameSite=Strict; Path=/; Max-Age=0')
                content=b'{"ok":true}'
                self.send_header('Content-Length',str(len(content)))
                self.send_header('Content-Type','application/json')
                activity.record('POST /api/auth/logout', 'done', actor=actor['username'],
                                duration=time.monotonic()-self._activity_started)
                self._activity_action=None
                self.end_headers();return self.wfile.write(content)
            if path=='/api/dashboard/import':
                tmp,filename=self._upload_temp()
                try:
                    with LOCK:out=dash.import_metrics(tmp,filename,actor['username'])
                    return self.reply(out)
                finally:os.unlink(tmp)
            if path=='/api/dashboard/portfolio':
                qdate=q.get('asof',[''])[0]
                tmp,filename=self._upload_temp()
                try:
                    with LOCK:out=dash.import_portfolio(tmp,filename,qdate,actor['username'])
                    return self.reply(out)
                finally:os.unlink(tmp)
            if path=='/api/dashboard/publish':
                v=self.json_body()
                with LOCK:out=dash.publish(actor['username'],v.get('note',''))
                return self.reply(out)
            if path=='/api/dashboard/restore':
                v=self.json_body()
                with LOCK:out=dash.restore(int(v['version']),actor['username'])
                return self.reply(out)
            if path=='/api/projects':
                v=self.json_body();pid=engine.create_project(v.get('name','Бизнес-план НСФО'));return self.reply({'id':pid})
            pid,tail=self.get_pid(path);route='/'.join(tail)
            if route=='current-portfolio/upload':
                tmp,name=self._upload_temp('nsfo_current_')
                try:
                    with LOCK:result=current_portfolio.stage(pid,tmp,name,q.get('asof',[''])[0],actor['username'])
                    return self.reply(result)
                finally:os.unlink(tmp)
            if route=='current-portfolio/apply':
                v=self.json_body()
                with LOCK:result=current_portfolio.apply(pid,v.get('token'),v.get('links',{}),actor['username'])
                return self.reply(result)
            if route=='comparison/upload':
                if actor['role']!='admin':return self.reply({'error':'Загружать сформированный план может только администратор.'},403)
                tmp,filename=self._upload_temp('nsfo_comparison_')
                try:
                    with LOCK:result=comparison.import_plan(pid,tmp,filename,actor['username'])
                    return self.reply(result)
                finally:os.unlink(tmp)
            if route=='plan-changes/upload':
                name=urllib.parse.unquote(self.headers.get('X-Filename','plan_changes.xlsx'))
                if not name.lower().endswith('.xlsx'):raise ValueError('Поддерживаются только файлы .xlsx')
                length=int(self.headers.get('Content-Length','0'))
                if not 0<length<=MAX_UPLOAD:raise ValueError(f'Размер файла должен быть от 1 байта до {MAX_UPLOAD//1048576} МБ')
                with LOCK:
                    fd,tmp=tempfile.mkstemp(prefix='nsfo_plan_events_',suffix='.xlsx',dir=str(engine.DATA))
                    try:
                        with os.fdopen(fd,'wb') as out:
                            remaining=length
                            while remaining>0:
                                data=self.rfile.read(min(128*1024,remaining))
                                if not data:raise IOError('Загрузка прервана')
                                out.write(data);remaining-=len(data)
                        with open(tmp,'rb') as check:
                            if check.read(2)!=b'PK':raise ValueError('Файл не является XLSX-архивом')
                        return self.reply(engine.stage_plan_changes(pid,tmp,name))
                    finally:
                        if os.path.exists(tmp):os.remove(tmp)
            if route=='upload':
                kind=q.get('kind',[''])[0]
                if kind not in ('bp','fact','rates'):raise ValueError('Недопустимый тип файла')
                name=urllib.parse.unquote(self.headers.get('X-Filename',kind+'.xlsx'))
                if not name.lower().endswith('.xlsx'):raise ValueError('Поддерживаются только файлы .xlsx')
                length=int(self.headers.get('Content-Length','0'))
                if not 0<length<=MAX_UPLOAD:raise ValueError(f'Размер файла должен быть от 1 байта до {MAX_UPLOAD//1048576} МБ')
                with LOCK:
                    fd,tmp=tempfile.mkstemp(prefix='nsfo_',suffix='.xlsx',dir=str(engine.DATA))
                    try:
                        with os.fdopen(fd,'wb') as out:
                            remaining=length
                            while remaining>0:
                                data=self.rfile.read(min(128*1024,remaining))
                                if not data:raise IOError('Загрузка прервана')
                                out.write(data);remaining-=len(data)
                        with open(tmp,'rb') as check:
                            if check.read(2)!=b'PK':raise ValueError('Файл не является XLSX-архивом')
                        return self.reply(engine.upload_path(pid,kind,tmp,name))
                    finally:
                        if os.path.exists(tmp):os.remove(tmp)
            if route=='fact-date':
                v=self.json_body()
                with LOCK:date=engine.confirm_fact_date(pid,v.get('date'))
                return self.reply({'date':date})
            if route=='build':
                # An application-side job, not a background assistant promise.
                if JOBS.get(pid,{}).get('status')=='running':raise ValueError('Расчёт уже выполняется')
                JOBS[pid]={'status':'running','stage':'Ожидание запуска расчёта','started':engine.now()}
                def progress(stage):
                    JOBS[pid]['stage']=stage
                    JOBS[pid]['updated']=engine.now()
                    activity.record('Расчёт БП', 'progress', pid, actor['username'], stage)
                def work():
                    try:
                        with LOCK:result=engine.build(pid,progress=progress)
                        JOBS[pid]={'status':'done','result':result,'finished':engine.now()}
                        activity.record('Расчёт БП', 'done', pid, actor['username'], f'Позиций: {result["positions"]}')
                    except Exception as e:
                        traceback.print_exc()
                        JOBS[pid]={'status':'error','error':str(e),'finished':engine.now()}
                        activity.record('Расчёт БП', 'error', pid, actor['username'], str(e))
                threading.Thread(target=work,daemon=True).start()
                return self.reply({'started':True})
            if route=='missing/add':
                with LOCK:n=engine.add_waiting(pid,self.json_body().get('keys',[]))
                return self.reply({'added':n})
            if route=='missing/undo':
                with LOCK:n=engine.undo_waiting(pid,self.json_body().get('keys',[]))
                return self.reply({'undone':n})
            if route=='recalculate':
                if JOBS.get(pid,{}).get('status')=='running':
                    raise ValueError('Для проекта уже выполняется расчёт')
                JOBS[pid]={'status':'running','stage':'Пересчёт факторного анализа','started':engine.now()}
                def work_recalculate():
                    try:
                        activity.record('Пересчёт факторов', 'progress', pid, actor['username'], 'Начат пересчёт')
                        with LOCK:result=engine.recalculate_project(pid)
                        JOBS[pid]={'status':'done','result':result,'finished':engine.now()}
                        activity.record('Пересчёт факторов', 'done', pid, actor['username'], 'Пересчёт завершён')
                    except Exception as e:
                        traceback.print_exc()
                        JOBS[pid]={'status':'error','error':str(e),'finished':engine.now()}
                        activity.record('Пересчёт факторов', 'error', pid, actor['username'], str(e))
                threading.Thread(target=work_recalculate,daemon=True).start()
                return self.reply({'started':True})
            if route=='edit':
                v=self.json_body()
                with LOCK:result=engine.edit(pid,int(v['position_id']),v['period'],v['field'],v.get('value'),v.get('reason',''))
                return self.reply(result)
            if route=='comment':
                v=self.json_body()
                with LOCK:n=engine.set_comment(pid,v['unp'],v.get('comment',''))
                return self.reply({'updated':n})
            if route=='save-version':
                with LOCK:v=engine.save_version(pid,self.json_body().get('title','Зафиксированная версия'))
                v.pop('path',None);return self.reply(v)
            if route=='plan-changes/apply':
                v=self.json_body()
                with LOCK:result=engine.apply_plan_changes(pid,int(v['batch_id']),v.get('decisions',{}))
                return self.reply(result)
            if route=='plan-changes/cancel':
                v=self.json_body()
                with LOCK:result=engine.cancel_plan_changes(pid,int(v['batch_id']))
                return self.reply(result)
            return self.reply({'error':'Неизвестный маршрут'},404)
        except (OSError,ValueError,KeyError,engine.MethodologyError) as e:self.fail(e)
        except Exception as e:
            traceback.print_exc();self.reply({'error':'Внутренняя ошибка: '+str(e)},500)


def main():
    engine.initialize()
    dash.initialize()
    access.initialize()
    if not access.user_count():
        raise SystemExit('Сначала создайте администратора: python setup_admin.py')
    if BIND not in ('127.0.0.1','localhost','::1') and os.getenv('NSFO_ALLOW_REMOTE_HTTP')!='1':
        raise SystemExit('Не открывайте HTTP напрямую в сети. Используйте HTTPS reverse proxy с NSFO_HOST=127.0.0.1; NSFO_ALLOW_REMOTE_HTTP=1 — только для тестовой сети.')
    server=ThreadingHTTPServer((BIND,PORT),Handler)
    print(f'АС НСФО: http://{BIND}:{PORT}/',flush=True)
    if os.getenv('NSFO_AUTOBROWSER')=='1' and BIND in ('127.0.0.1','localhost','::1'):
        def open_ui_after_bind():
            # The socket is already bound; give serve_forever a moment to start.
            time.sleep(0.7)
            try:
                url=f'http://127.0.0.1:{PORT}/'
                if not webbrowser.open(url):
                    print('Open the browser manually: '+url,flush=True)
            except Exception as exc:
                print('Browser could not be opened automatically: '+str(exc),flush=True)
        threading.Thread(target=open_ui_after_bind,daemon=True).start()
    try:server.serve_forever(poll_interval=.5)
    except KeyboardInterrupt:pass
    finally:server.server_close()

if __name__=='__main__':main()
