"""Bank-approved scenarios for actual-portfolio factor decomposition."""
import unittest
from dataclasses import replace
from risk import Criteria
import fact_factor as f
import dashboard_service as dash


def pos(debt=100_000,rate=.5,gr='1',sec='Обеспеченный',dpd=0,**kw):
    result=dict(key='11|22|BYN|баланс',unp='11',client='Клиент',contract='22',segment='Средний',
      debt_byn=debt,reserve_byn=round(debt*rate/100,2),fx=1.,rate=rate,gr=gr,ni=0,pfn=0,nvv=0,
      restra='',security=sec,micro=0,poc=0,spok=0,written_off=0,operation='Кредит',ccy='BYN',dpd=dpd)
    result.update(kw)
    return result


class FactorRules(unittest.TestCase):
    def check(self,old,new,old_days=0,new_days=0):
        result=f.decompose(old,new,old_days,new_days)
        self.assertEqual(sum(result[k] for k in f.GROUPS),result['expenses'])
        self.assertEqual(sum(result['subfactors'].values()),result['expenses'])
        return result

    def test_delinquency_matrix_regular(self):
        c=Criteria(security='Обеспеченный')
        u=replace(c,security='Необеспеченный')
        p=replace(c,pfn=1)
        pu=replace(p,security='Необеспеченный')
        for days,expected in [(0,0),(7,0),(8,3),(30,3),(31,4),(90,4),(91,5),(180,5),(181,6)]:
            with self.subTest(days=days):self.assertEqual(f.delinquency_floor(c,days),expected)
        self.assertEqual(f.delinquency_floor(p,8),4)
        self.assertEqual(f.delinquency_floor(pu,8),5)
        self.assertEqual(f.delinquency_floor(u,31),5)
        self.assertEqual(f.delinquency_floor(u,91),6)
        self.assertEqual(f.delinquency_floor(replace(c,ni=1),20),3)
    def test_pok_matrix(self):
        c=Criteria(security='Обеспеченный',poc=True,poc_rate=1.7)
        u=replace(c,security='Необеспеченный')
        for days,expected in [(0,0),(8,0),(30,0),(31,4),(90,4),(91,5),(180,5),(181,6)]:
            self.assertEqual(f.delinquency_floor(c,days),expected)
        self.assertEqual(f.delinquency_floor(u,31),5)
        self.assertEqual(f.delinquency_floor(u,91),6)
        self.assertEqual(float(f.effective_rate(c,25,1.7)),1.7)
        self.assertEqual(float(f.effective_rate(c,120,1.7)),50)
    def test_dpd_8_creates_financial_effect(self):
        r=self.check(pos(),pos(rate=20,gr='3',dpd=8),0,8)
        self.assertEqual(r['financial_state'],-1_950_000)
        self.assertEqual(r['subfactors']['dpd_in'],-1_950_000)
    def test_dpd_31_91_181(self):
        cases=[(0,35,.5,30,'4'),(35,120,30,50,'5'),(120,200,50,100,'6')]
        for oldd,newd,oldrate,newrate,newgr in cases:
            oldgr={.5:'1',30:'4',50:'5'}[oldrate]
            with self.subTest(newd=newd):
                r=self.check(pos(rate=oldrate,gr=oldgr),pos(rate=newrate,gr=newgr),oldd,newd)
                self.assertEqual(r['financial_state'],(f.cents(100_000*oldrate/100)-f.cents(100_000*newrate/100)))
    def test_pok_monthly_changing_rate_is_dpd(self):
        old=pos(rate=1.7,gr='ПОК',poc=1)
        new=pos(rate=4.6,gr='ПОК',poc=1)
        r=self.check(old,new,0,5)
        self.assertEqual(r['subfactors']['poc_rate_dpd'],-290_000)
    def test_pok_over_30(self):
        r=self.check(pos(rate=1.7,gr='ПОК',poc=1),pos(rate=30,gr='4',poc=1),0,38)
        self.assertEqual(r['financial_state'],-2_830_000)
    def test_pok_over_90(self):
        r=self.check(pos(rate=30,gr='4',poc=1),pos(rate=50,gr='5',poc=1),40,120)
        self.assertEqual(r['financial_state'],-2_000_000)
    def test_collateral_then_dpd(self):
        r=self.check(pos(sec='Обеспеченный'),pos(sec='Необеспеченный',rate=50,gr='5'),0,45)
        self.assertEqual(r['security_effect'],-450_000)
        self.assertEqual(r['financial_state'],-4_500_000)
        self.assertEqual(r['subfactors']['dpd_in'],-4_500_000)
    def test_spok_new_all_portfolio_movement(self):
        r=self.check(None,pos(rate=20,gr='1',spok=1))
        self.assertEqual(r['movement'],-2_000_000)
        self.assertEqual(r['financial_state'],0)
    def test_securities_new_excess_is_security(self):
        r=self.check(None,pos(rate=20,gr='2',operation='ЦБ для продажи'))
        self.assertEqual(r['movement'],-500_000)
        self.assertEqual(r['security_effect'],-1_500_000)
    def test_high_risk_drawdown_all_portfolio(self):
        balance=pos(rate=30,gr='4',side='баланс')
        r=f.decompose(None,balance,drawn_byn=100_000)
        self.assertEqual(r['movement'],-3_000_000)
        self.assertEqual(r['financial_state'],0)
        self.assertEqual(r['subfactors']['draw_uo_to_active'],-2_500_000)
    def test_high_risk_partial_drawdown(self):
        balance=pos(rate=30,gr='4',debt_byn=100_000)
        r=f.decompose(None,balance,drawn_byn=40_000)
        self.assertEqual(r['movement'],-1_500_000)
        self.assertEqual(r['financial_state'],-1_500_000)
        self.assertEqual(sum(r[k] for k in f.GROUPS),r['expenses'])

    def test_written_off_new_and_existing(self):
        r=self.check(None,pos(rate=100,gr='Списан',written_off=1))
        self.assertEqual(r['movement'],-10_000_000)
        r=self.check(pos(rate=50,gr='5'),pos(rate=100,gr='Списан',written_off=1))
        self.assertEqual(r['financial_state'],-5_000_000)
        self.assertIn('writeoff_in',r['subfactors'])
    def test_segment_transfer(self):
        old=pos(segment='ММБ')
        r=self.check(old,pos(),0,0)
        self.assertEqual(r['movement'],-50_000)
        self.assertEqual(r['financial_state'],0)
    def test_gr_without_cause_is_manual(self):
        with self.assertRaisesRegex(ValueError,'ГР'):
            f.decompose(pos(),pos(rate=5,gr='2'))
    def test_dpd_no_threshold_and_non_pok_is_not_excuse(self):
        with self.assertRaisesRegex(ValueError,'Нельзя объяснить'):
            f.decompose(pos(),pos(rate=5,gr='2'),1,2)
    def test_floating_dpd_baseline(self):
        # Existing GR2 at 5% under past special assignment, 8+ days causes GR3.
        r=self.check(pos(rate=5,gr='2'),pos(rate=20,gr='3'),0,8)
        self.assertEqual(r['financial_state'],-1_500_000)
    def test_fx_only_without_rounding_residual(self):
        r=self.check(pos(debt=100_000,rate=5,gr='2',fx=3,sec='Недостаточно обеспеченный'),
                     pos(debt=110_000,rate=5,gr='2',fx=3.3,sec='Недостаточно обеспеченный'))
        self.assertEqual(r['expenses'],-50_000)
        self.assertEqual(r['revaluation'],-50_000)
        self.assertEqual(r['movement'],0)

if __name__=='__main__':unittest.main()
