"""End-to-end dashboard tests with isolated SQLite and XLSX fixtures."""
from __future__ import annotations
import copy
import tempfile
import unittest
from pathlib import Path
from openpyxl import load_workbook
import engine
import dashboard_service as dash
import access_control as auth

ROOT=Path(__file__).resolve().parents[1]

class DashboardTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.db=engine.DB
        self.data=engine.DATA
        engine.DB=Path(self.tmp.name)/'test.db'
        engine.DATA=Path(self.tmp.name)
        engine.initialize();dash.initialize();auth.initialize()
    def tearDown(self):
        engine.DB=self.db;engine.DATA=self.data
        self.tmp.cleanup()
    def template(self, values):
        wb=load_workbook(ROOT/'examples'/'Шаблон_показателей_дашборда.xlsx')
        ws=wb['Показатели'];ws['B2']=2027
        for (label,scenario,month),value in values.items():
            for row in range(6,30):
                if ws.cell(row,1).value==label and ws.cell(row,2).value==scenario:
                    ws.cell(row,month+2).value=value;break
            else:raise ValueError('Missing row '+label)
        path=Path(self.tmp.name)/'values.xlsx';wb.save(path);wb.close()
        return path
    def factfile(self,asof,debt_change=0):
        wb=load_workbook(ROOT/'examples'/'02_Выверенный_факт_пример.xlsx')
        ws=wb.active
        for row in range(2,ws.max_row+1):
            if ws.cell(row,3).value:
                ws.cell(row,5).value='Средний'
        if debt_change:
            original=ws['Q2'].value
            rate=float(ws['O2'].value)
            ws['Q2']=original+debt_change
            ws['R2']=(original+debt_change)*rate/100
        path=Path(self.tmp.name)/f'{asof}.xlsx';wb.save(path);wb.close();return path

    def test_excel_staging_and_publication_cumulative(self):
        src=self.template({('РнР Банк','БП',1):-10,('РнР Банк','БП',2):-20,
                           ('РнР Банк','Факт',1):-12,('РнР Банк','Факт',2):-15,
                           ('COR Банк','БП',1):2.4,('COR Банк','БП',2):2.5})
        r=dash.import_metrics(src,'values.xlsx','admin')
        self.assertEqual(r['values'],6)
        self.assertIsNone(dash.dashboard_data(2027,2)['version'])
        result=dash.publish('admin');self.assertGreater(result['version'],0)
        view=dash.dashboard_data(2027,2)
        self.assertEqual(view['metrics']['bank_rnr']['plan']['value'],-30)
        self.assertEqual(view['metrics']['bank_rnr']['fact']['value'],-27)
        self.assertEqual(view['metrics']['bank_cor']['plan']['value'],2.5)
        second=self.template({('РнР Банк','Факт',2):-19})
        dash.import_metrics(second,'fixed.xlsx','admin')
        self.assertEqual(dash.dashboard_data(2027,2)['metrics']['bank_rnr']['fact']['value'],-27)
        self.assertEqual(dash.dashboard_data(2027,2,True)['metrics']['bank_rnr']['fact']['value'],-31)
        dash.publish('admin')
        self.assertEqual(dash.dashboard_data(2027,2)['metrics']['bank_rnr']['fact']['value'],-31)
        self.assertEqual(len(dash.admin_state()['versions']),2)
        dash.restore(result['version'],'admin')
        self.assertEqual(dash.dashboard_data(2027,2,True)['metrics']['bank_rnr']['fact']['value'],-27)

    def test_fact_calculations_exact(self):
        def pos(debt,rate,fx=1,gr='1',ni=0,sec='Обеспеченный'):
            return {'key':'u|d|BYN|баланс','unp':'u','client':'X','contract':'d','segment':'Средний',
                    'debt_byn':debt,'reserve_byn':round(debt*rate/100,2),'fx':fx,'rate':rate,'gr':gr,
                    'ni':ni,'pfn':0,'nvv':0,'restra':'','security':sec,'micro':0,'poc':0,
                    'operation':'Кредит','ccy':'BYN'}
        tests=[
            (pos(100000,.5),pos(120000,.5),-100),
            (pos(100000,.5),pos(100000,5,gr='2',ni=1),-4500),
            (pos(100000,5,gr='2',sec='Необеспеченный'),pos(100000,.5,sec='Обеспеченный'),4500),
            (None,pos(100000,20,gr='3'),-20000),
            (pos(100000,20,gr='3'),None,20000),
        ]
        for a,b,expected in tests:
            with self.subTest(a=a,b=b):
                factors=dash._calculate_factor_row(a,b)
                self.assertEqual(factors['expenses']/100,expected)
                self.assertEqual(sum(factors[k] for k in dash.FACTOR_KEYS),factors['expenses'])

    def test_portfolios_join_and_full_reconciliation(self):
        a=self.factfile('2027-01-01',0)
        b=self.factfile('2027-02-01',100)
        r1=dash.import_portfolio(a,'Jan.xlsx','2027-01-01','admin')
        self.assertEqual(r1['runs'],[])
        r2=dash.import_portfolio(b,'Feb.xlsx','2027-02-01','admin')
        self.assertEqual(len(r2['runs']),1)
        self.assertEqual(r2['runs'][0]['errors'],0)
        dash.publish('admin')
        data=dash.dashboard_data(2027,1)
        self.assertAlmostEqual(data['metrics']['medium_rnr']['fact']['value'],-0.0005,places=8)
        self.assertAlmostEqual(data['metrics']['factor_movement']['fact']['value'],-0.0005,places=8)
        details=dash.factor_detail(2027,1)
        self.assertGreater(details['total'],0)

    def test_access_control(self):
        auth.upsert_user('tester','a_long_testing_password_123','viewer')
        l=auth.login('tester','a_long_testing_password_123','127.0.0.1')
        actor=auth.current('nsfo_session='+l['token'])
        self.assertEqual(actor['role'],'viewer')
        self.assertTrue(auth.csrf_ok(actor,l['csrf']))
        self.assertFalse(auth.csrf_ok(actor,'bad_token'))
        auth.logout('nsfo_session='+l['token'])
        self.assertIsNone(auth.current('nsfo_session='+l['token']))

if __name__=='__main__':unittest.main()
