from pathlib import Path
import shutil
from tempfile import TemporaryDirectory
import unittest
from unittest.mock import patch

from openpyxl import load_workbook
import engine


class PokSourceTests(unittest.TestCase):
    def test_credit_and_commitment_use_their_own_rates(self):
        with TemporaryDirectory(dir=engine.ROOT) as temp:
            root = Path(temp)
            with patch.object(engine, 'DB', root/'db'), patch.object(engine, 'DATA', root):
                engine.initialize()
                pid = engine.create_project('ПОК')
                for kind, prefix in [('bp','01'), ('fact','02'), ('rates','03')]:
                    source = next((engine.ROOT/'examples').glob(prefix+'_*.xlsx'))
                    target = root/source.name
                    shutil.copyfile(source,target)
                    if kind in ('bp','fact'):
                        book = load_workbook(target)
                        sheet = book.active
                        columns = {cell.value:cell.column for cell in sheet[1]}
                        if kind=='bp':
                            sheet.cell(2,columns['ГР']).value='ПОК'
                            sheet.cell(2,columns['% рез на 01.10.2026']).value='1,7%'
                            sheet.cell(2,columns['% рез на 01.11.2026']).value=4.6
                        else:
                            sheet.delete_rows(2)  # For D1 only the UO remains.
                            self.assertEqual(sheet.cell(2,columns['Тип операции']).value,'УО')
                            sheet.cell(2,columns['% рез']).value=5
                        book.save(target)
                        book.close()
                    engine.upload_path(pid,kind,str(target),source.name)
                engine.build(pid)
                with engine.connect() as db:
                    rows = db.execute("""SELECT p.operation, pp.gr, pp.rate, pp.reserve, pp.od FROM positions p
                        JOIN position_periods pp ON p.id=pp.position_id WHERE p.project_id=? AND p.contract='D1'
                        AND pp.period>'2026-10-01'""",(pid,)).fetchall()
                    self.assertEqual({(r['operation'],r['gr'],r['rate']) for r in rows},
                                     {('Кредит','ПОК',1.7),('УО','1',0.5)})
                    for row in rows:
                        self.assertEqual(row['reserve'],round(row['od']*row['rate']/100,2))
