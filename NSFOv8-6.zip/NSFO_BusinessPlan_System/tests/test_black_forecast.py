import json
import shutil
import unittest
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch

from openpyxl import load_workbook
import engine


class BlackForecast(unittest.TestCase):
    def test_contract_specific_fact_basis_through_build_edit_and_recalculation(self):
        with TemporaryDirectory(dir=engine.ROOT) as tmp:
            root=Path(tmp)
            with patch.object(engine,'DB',root/'db'), patch.object(engine,'DATA',root):
                engine.initialize()
                pid=engine.create_project('Чёрная зона')
                for kind,prefix in [('bp','01'),('fact','02'),('rates','03')]:
                    source=next((engine.ROOT/'examples').glob(prefix+'_*.xlsx'))
                    target=root/source.name
                    shutil.copy(source,target)
                    if kind=='fact':
                        book=load_workbook(target)
                        sheet=book.active
                        cols={c.value:c.column for c in sheet[1]}
                        for row in range(2,sheet.max_row+1):
                            contract=sheet.cell(row,cols['Номер договора']).value
                            if contract not in ('D1','D3'):
                                continue
                            uo=sheet.cell(row,cols['Тип операции']).value=='УО'
                            if uo or contract=='D3':
                                sheet.cell(row,cols['Зона проблемности']).value='Чёрная зона'
                            sheet.cell(row,cols['ГР']).value=4 if uo else 5
                            sheet.cell(row,cols['% рез']).value=35 if uo else 47.5
                        book.save(target)
                        book.close()
                    engine.upload_path(pid,kind,str(target),source.name)
                engine.build(pid)
                with engine.connect() as db:
                    pos=db.execute("SELECT id FROM positions WHERE project_id=? AND contract='D1' AND side='баланс'",(pid,)).fetchone()[0]
                engine.edit(pid,pos,'2026-11-01','pfn',1,'')
                engine.recalculate_project(pid)
                with engine.connect() as db:
                    rows=db.execute("""SELECT contract,side,src,pp.* FROM position_periods pp JOIN positions p
                        ON p.id=pp.position_id WHERE pp.project_id=? AND contract IN ('D1','D3')""",(pid,)).fetchall()
                    self.assertEqual({(r['contract'],r['side'],r['src']) for r in rows},
                                     {('D1','баланс','bp'),('D1','внебаланс','bp'),('D3','баланс','fact_auto')})
                    for row in rows:
                        gr,rate=('4',35) if row['side']=='внебаланс' else ('5',47.5)
                        self.assertEqual((row['gr'],row['method_gr'],row['rate']),(gr,gr,rate))
                        self.assertEqual(row['reserve'],round(row['od']*rate/100,2))
                        self.assertEqual(json.loads(row['factors']).get('pfn_in',0),0)
