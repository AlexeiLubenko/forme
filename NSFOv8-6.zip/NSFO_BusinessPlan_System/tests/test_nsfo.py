import unittest,sys,tempfile,os,shutil,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from risk import Criteria,classify,quality_breakdown,compute_factors,MethodologyError,is_new_contract
import engine

class RiskRules(unittest.TestCase):
 def c(self,**kw):return Criteria(**{'security':'Обеспеченный',**kw})
 def test_pfn_secured_active_uo(self):
  for op in ('Кредит','УО'):
   self.assertEqual(classify(self.c(pfn=1,operation=op))[:2],(3,20.))
 def test_pfn_unsecured_by_side(self):
  self.assertEqual(classify(self.c(pfn=1,security='Необеспеченный'))[:2],(4,30.))
  self.assertEqual(classify(self.c(pfn=1,security='Необеспеченный',operation='УО'))[:2],(3,20.))
 def test_ni_over_nvv(self):
  self.assertEqual(classify(self.c(ni=1,nvv=1,currency='USD'))[:2],(2,5.))
 def test_nvv_ignored_by_currency_and_uo(self):
  self.assertEqual(classify(self.c(nvv=1,currency='BYN'))[:2],(1,.5))
  self.assertEqual(classify(self.c(nvv=1,currency='USD',operation='УО'))[:2],(1,.5))
 def test_cb_table(self):
  for ni,pfn,sec,expected in [(0,0,'Обеспеченный',(1,.5)),(0,0,'Недостаточно обеспеченный',(1,2.)),(1,0,'Недостаточно обеспеченный',(2,5.)),(1,0,'Необеспеченный',(2,20.)),(0,1,'Обеспеченный',(3,20.)),(0,1,'Необеспеченный',(3,30.)),(1,1,'Необеспеченный',(3,30.))]:
   with self.subTest(ni=ni,pfn=pfn,sec=sec):self.assertEqual(classify(self.c(ni=ni,pfn=pfn,security=sec,operation='ЦБ для продажи'))[:2],expected)
 def test_micro(self):
  self.assertEqual(classify(self.c(micro=True,security='Обеспеченный (не указан)'))[:2],(1,.5))
  self.assertEqual(classify(self.c(micro=True,pfn=1,security='Обеспеченный (не указан)'))[:2],(2,5.))
  self.assertEqual(classify(self.c(micro=True,restra='рестр. 5ГР 50%'))[:2],(5,50.))
 def test_restructuring_gr_then_percent(self):
  self.assertEqual(classify(self.c(restra='Рестр.ГР 4 % 30'))[:2],(4,30.))
  self.assertEqual(classify(self.c(restra='рестр. группа 5 % рез 47,5'))[:2],(5,47.5))
 def test_restructuring_rate_falls_back_to_group(self):
  self.assertEqual(classify(self.c(restra='Рестр. ГР 6'))[:2],(6,100.))
 def test_uw_no_restra(self):
  self.assertEqual(classify(self.c(operation='УО',restra='рестр. 6ГР 100%'))[:2],(1,.5))
 def test_pok(self):
  self.assertEqual(classify(self.c(poc=True,poc_rate=7.))[:2],('ПОК',7.))
  self.assertEqual(classify(self.c(poc=True,operation='УО'))[:2],(1,.5))
 def test_explicit_new_contract_marker(self):
  self.assertTrue(is_new_contract('Новый договор №1'))
  self.assertTrue(is_new_contract('Плановый НОВЫЙ ДОГОВОР №2'))
  self.assertFalse(is_new_contract('Договор 12345'))
  self.assertFalse(is_new_contract('Новый транш'))

 def test_bad_sec(self):
  with self.assertRaises(MethodologyError):classify(self.c(security='Обеспеченный (не указан)'))
 def test_financial_state_then_security_sequential_order(self):
  a=self.c(pfn=0,security='Обеспеченный');b=self.c(pfn=1,security='Необеспеченный')
  out,events=quality_breakdown(a,b,1000000,.5,30.)
  self.assertEqual(out['pfn_in'],-195000.)
  self.assertEqual(out['security_worsening'],-100000.)
  self.assertEqual(round(sum(out.values()),2),-295000.)
 def test_ni_removed_when_pfn_new(self):
  a=self.c(ni=1);b=self.c(pfn=1,ni=0)
  out,events=quality_breakdown(a,b,1000000,5.,20.)
  self.assertEqual(out['ni_out'],0)
  self.assertEqual(out['pfn_in'],0)
  self.assertEqual(out['ni_to_pfn'],-150000.)
  self.assertIn('ni_to_pfn',events)
 def test_restructuring_removal_is_reclassification(self):
  a=self.c(restra='рестр. 4 ГР 30%')
  b=self.c(restra='')
  out,events=quality_breakdown(a,b,1000000,30.,.5)
  self.assertEqual(out['reclassification'],295000.)
  self.assertEqual(out['restruct_in'],0.)
  self.assertIn('reclassification',events)

 def test_reclassification_owns_effect_when_pfn_arrives_under_existing_restructuring(self):
  a=self.c(pfn=0,restra='рестр. 4 ГР 30%')
  b=self.c(pfn=1,restra='')
  out,events=quality_breakdown(a,b,1000000,30.,20.)
  self.assertEqual(out['pfn_in'],0.)
  self.assertEqual(out['reclassification'],100000.)
  self.assertIn('reclassification',events)

 def test_restructuring_recognition_shadows_pfn(self):
  a=self.c(pfn=0,restra='')
  b=self.c(pfn=1,restra='рестр. 4 ГР 30%')
  out,events=quality_breakdown(a,b,1000000,.5,30.)
  self.assertEqual(out['restruct_in'],-295000.)
  self.assertEqual(out['pfn_in'],0.)

 def test_unsecured_to_insufficient_is_improvement(self):
  a=self.c(security='Необеспеченный')
  b=self.c(security='Недостаточно обеспеченный')
  out,events=quality_breakdown(a,b,1000000,5.,5.)
  self.assertEqual(out['security_improvement'],0.)
  self.assertIn('security_improvement',events)

 def test_new_contract_base_and_risk_uplift(self):
  a=self.c(pfn=1)
  prior={'debt':0.,'fx':1.,'od':0.,'rate':20.,'reserve':0.,'criteria':a.as_dict(),'gr':'3'}
  current={'debt':1000000.,'fx':1.,'od':1000000.,'rate':20.,'reserve':200000.,'criteria':a.as_dict(),'gr':'3'}
  out=compute_factors(prior,current,new_contract=True)
  self.assertEqual(out['movement'],-50000.)
  self.assertEqual(out['financial_state'],-150000.)
  self.assertEqual(out['factors']['new_contract_base'],-50000.)
  self.assertEqual(out['factors']['new_contract_risk'],-150000.)
  self.assertEqual(out['rounding'],0.)

 def test_new_contract_gr1_uses_half_percent(self):
  a=self.c()
  prior={'debt':0.,'fx':1.,'od':0.,'rate':.5,'reserve':0.,'criteria':a.as_dict(),'gr':'1'}
  current={'debt':1000000.,'fx':1.,'od':1000000.,'rate':.5,'reserve':5000.,'criteria':a.as_dict(),'gr':'1'}
  out=compute_factors(prior,current,new_contract=True)
  self.assertEqual(out['movement'],-5000.)
  self.assertEqual(out['financial_state'],0.)
  self.assertEqual(out['rounding'],0.)

 def test_fx_formula(self):
  a=self.c(currency='USD');b=self.c(currency='USD')
  prev={'debt':10,'fx':3,'od':30,'rate':5.,'reserve':1.5,'criteria':a.as_dict()}
  now={'debt':15,'fx':3.2,'od':48,'rate':5.,'reserve':2.4,'criteria':b.as_dict()}
  fx=compute_factors(prev,now)
  self.assertEqual(fx['fx'],-.1)
  self.assertEqual(fx['movement'],-.8)
  self.assertEqual(fx['quality'],0)
  self.assertAlmostEqual(fx['expenses'],-.9)

class BaselineRateFallback(unittest.TestCase):
 def test_zero_baseline_uses_later_reporting_rate(self):
  row=[0,None,0.005,5.0]
  cols={'2026-10-01':0,'2026-11-01':1,'2026-12-01':2,'2027-01-01':3}
  self.assertEqual(engine.actual_rate_from_bp(row,cols,'2026-10-01'),(.5,'2026-12-01'))
 def test_missing_or_all_zero_fails_fallback(self):
  row=['0',0,'0,00',None]
  cols={'2026-10-01':0,'2026-11-01':1,'2026-12-01':2,'2027-01-01':3}
  self.assertEqual(engine.actual_rate_from_bp(row,cols,'2026-10-01'),(None,None))
 def test_existing_valid_rate_is_kept(self):
  self.assertEqual(engine.actual_rate_from_bp([5,2],{'2026-10-01':0,'2026-11-01':1},'2026-10-01'),(5.,'2026-10-01'))


class ProjectWorkflow(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  engine.initialize()
  cls.pid=engine.create_project('Автотест НСФО')
  for kind,f in [('bp','01_Входной_БП_пример.xlsx'),('fact','02_Выверенный_факт_пример.xlsx'),('rates','03_Курсы_пример.xlsx')]:
   fd,p=tempfile.mkstemp(suffix='.xlsx');os.close(fd);shutil.copyfile(ROOT/'examples'/f,p)
   engine.upload_path(cls.pid,kind,p,f)
  cls.result=engine.build(cls.pid)
 def test_build(self):
  self.assertEqual(self.result['positions'],8)
  self.assertEqual(self.result['missing'],2)
  self.assertEqual(self.result['errors'],0)
  self.assertEqual(len(self.result['dates']),8)
 def test_missing_state(self):
  self.assertEqual(engine.list_missing(self.pid,'waiting')['total'],1)
  self.assertEqual(engine.list_missing(self.pid,'auto')['total'],1)
 def test_reserve_from_rate(self):
  rows=engine.list_positions(self.pid,'2026-10-01',limit=100)['rows']
  for r in rows:self.assertAlmostEqual(r['reserve'],round(r['od']*r['rate']/100,2),places=2)
 def test_bridge(self):
  t=engine.get_state(self.pid)['totals']
  for x in t[1:]:self.assertAlmostEqual(x['expenses'],x['movement']+x['financial_state']+x['security_effect']+x['revaluation']+x['rounding'],places=2)
 def test_auto_add_only_black(self):
  auto=engine.list_missing(self.pid,'auto')['rows'][0]
  self.assertTrue('черн' in auto['zone'].lower())
  waiting=engine.list_missing(self.pid,'waiting')['rows'][0]
  self.assertNotIn('черн',waiting['zone'].lower())
 def test_add_and_undo(self):
  waiting=engine.list_missing(self.pid,'waiting')['rows'][0]
  old=engine.list_positions(self.pid,'2026-10-01')['total']
  self.assertEqual(engine.add_waiting(self.pid,[waiting['match_key']]),1)
  self.assertEqual(engine.list_positions(self.pid,'2026-10-01')['total'],old+1)
  self.assertEqual(engine.undo_waiting(self.pid,[waiting['match_key']]),1)
  self.assertEqual(engine.list_positions(self.pid,'2026-10-01')['total'],old)
 def test_clientwide_flag_future_only(self):
  p=next(x for x in engine.list_positions(self.pid,'2026-10-01',limit=100)['rows'] if x['unp']=='1001' and x['side']=='баланс')
  engine.edit(self.pid,p['id'],'2026-11-01','pfn',1)
  base=[x for x in engine.list_positions(self.pid,'2026-10-01',limit=100)['rows'] if x['unp']=='1001']
  november=[x for x in engine.list_positions(self.pid,'2026-11-01',limit=100)['rows'] if x['unp']=='1001']
  december=[x for x in engine.list_positions(self.pid,'2026-12-01',limit=100)['rows'] if x['unp']=='1001']
  self.assertTrue(all(x['pfn']==0 for x in base))
  self.assertTrue(all(x['pfn']==1 for x in november+december))
  engine.edit(self.pid,p['id'],'2026-11-01','pfn',0)
 def test_two_factor_integrated(self):
  base=next(x for x in engine.list_positions(self.pid,'2026-10-01',limit=100)['rows'] if x['unp']=='1001' and x['side']=='баланс')
  engine.edit(self.pid,base['id'],'2026-11-01','pfn',1)
  engine.edit(self.pid,base['id'],'2026-11-01','security','Необеспеченный')
  curr=next(x for x in engine.list_positions(self.pid,'2026-11-01',limit=100)['rows'] if x['id']==base['id'])
  factors=json.loads(curr['factors'])
  self.assertAlmostEqual(factors['pfn_in'],-curr['od']*.195,delta=.02)
  self.assertAlmostEqual(factors['security_worsening'],-curr['od']*.10,delta=.02)
  self.assertAlmostEqual(factors['pfn_in']+factors['security_worsening'],curr['quality'],delta=.02)
  self.assertAlmostEqual(curr['financial_state'],factors['pfn_in'],delta=.02)
  self.assertAlmostEqual(curr['security_effect'],factors['security_worsening'],delta=.02)
  engine.edit(self.pid,base['id'],'2026-11-01','security','Обеспеченный')
  engine.edit(self.pid,base['id'],'2026-11-01','pfn',0)
 def test_debt_only_one_date(self):
  p=next(x for x in engine.list_positions(self.pid,'2026-10-01',limit=100)['rows'] if x['unp']=='1001' and x['side']=='баланс')
  old=next(x for x in engine.list_positions(self.pid,'2026-12-01',limit=100)['rows'] if x['id']==p['id'])
  engine.edit(self.pid,p['id'],'2026-11-01','debt',1123456)
  new=next(x for x in engine.list_positions(self.pid,'2026-12-01',limit=100)['rows'] if x['id']==p['id'])
  self.assertEqual(old['debt'],new['debt'])
 def test_override_reason(self):
  p=next(x for x in engine.list_positions(self.pid,'2026-10-01',limit=100)['rows'] if x['unp']=='1001' and x['side']=='баланс')
  with self.assertRaises(MethodologyError):engine.edit(self.pid,p['id'],'2026-11-01','rate',5,'')
 def test_export(self):
  from exports import build_excel
  b=build_excel(self.pid)
  self.assertGreater(len(b.getvalue()),10000)
  import zipfile,io
  with zipfile.ZipFile(io.BytesIO(b.getvalue())) as z:
   xml=z.read('xl/workbook.xml')
   self.assertIn('Прогноз НСФО'.encode('utf-8'),xml)
   wb=__import__('openpyxl').load_workbook(io.BytesIO(b.getvalue()),read_only=True,data_only=True)
   self.assertIn('Факторный анализ',wb.sheetnames)
   headers=[c.value for c in next(wb['Факторный анализ'].iter_rows(min_row=1,max_row=1))]
   self.assertIn('Изменение финансового состояния',headers)
   self.assertIn('Реклассификация: снятие реструктуризации',headers)
   wb.close()
 def test_factor_summary_exposes_four_top_level_factors(self):
  result=engine.factor_summary(self.pid,'2026-11-01')
  self.assertIn('financial_state',result['totals'])
  self.assertIn('security_effect',result['totals'])
  self.assertEqual([g['key'] for g in result['factor_groups']],
                   ['movement','financial_state','security_effect','revaluation'])

 def test_recalculate_project_uses_new_factor_schema(self):
  result=engine.recalculate_project(self.pid)
  self.assertEqual(result['positions_recalculated'],8)
  state=engine.get_state(self.pid)
  for row in state['totals'][1:]:
   self.assertAlmostEqual(row['expenses'],row['movement']+row['financial_state']+
                          row['security_effect']+row['revaluation']+row['rounding'],places=2)

 def test_horizon(self):
  data=engine.period_debt_horizon(self.pid,'debt')
  self.assertEqual(len(data['periods']),8)
  self.assertGreaterEqual(len(data['rows']),8)
 def test_group_filter_and_source_corrections(self):
  period='2026-10-01'
  all_rows=engine.list_positions(self.pid,period,limit=100)['rows']
  one=engine.list_positions(self.pid,period,gr='1',limit=100)
  self.assertEqual(one['total'],sum(r['gr']=='1' for r in all_rows))
  self.assertTrue(all(r['gr']=='1' for r in one['rows']))
  corrected=engine.list_positions(self.pid,period,gr='__corrected__',limit=100)
  self.assertGreater(corrected['total'],0)
  self.assertTrue(all(r['source_gr_corrected'] for r in corrected['rows']))
  issues=engine.list_positions(self.pid,period,gr='__issues__',limit=100)
  self.assertGreaterEqual(issues['total'],corrected['total'])
  self.assertTrue(all(r['risk_error'] or r['source_gr_corrected'] for r in issues['rows']))
  with self.assertRaises(ValueError):engine.list_positions(self.pid,period,gr='999')
 def test_wrong_manual_group_risk_filter(self):
  period='2026-11-01'
  p=next(x for x in engine.list_positions(self.pid,period,limit=100)['rows'] if x['unp']=='1001' and x['side']=='баланс')
  initial=p['gr']
  wrong='6' if initial!='6' else '1'
  engine.edit(self.pid,p['id'],period,'gr',wrong,'Проверка фильтра ошибочной ГР')
  try:
   errors=engine.list_positions(self.pid,period,gr='__error__',limit=100)
   self.assertIn(p['id'],[r['id'] for r in errors['rows']])
   row=next(x for x in errors['rows'] if x['id']==p['id'])
   self.assertEqual(row['method_gr'],initial)
   self.assertEqual(row['risk_error'],1)
   sorted_rows=engine.list_positions(self.pid,period,sort='risk_errors',limit=100)['rows']
   self.assertEqual(sorted_rows[0]['risk_error'],1)
  finally:
   engine.edit(self.pid,p['id'],period,'gr',initial,'Вернуть корректную ГР после теста')
  self.assertNotIn(p['id'],[r['id'] for r in engine.list_positions(self.pid,period,gr='__error__',limit=100)['rows']])
 def test_no_classification_group(self):
  period='2026-11-01'
  p=next(x for x in engine.list_positions(self.pid,period,limit=100)['rows'] if x['unp']=='1001' and x['side']=='баланс')
  old=p['security']
  engine.edit(self.pid,p['id'],period,'security','неизвестная обеспеченность')
  try:
   r=engine.list_positions(self.pid,period,gr='__error__',limit=100)['rows']
   self.assertIn(p['id'],[x['id'] for x in r])
   row=next(x for x in r if x['id']==p['id'])
   self.assertEqual(row['gr'],'')
  finally:
   engine.edit(self.pid,p['id'],period,'security',old)

if __name__=='__main__':unittest.main(verbosity=2)

class PlanChangeWorkflow(unittest.TestCase):
 def setUp(self):
  engine.initialize()
  self.pid=engine.create_project('Тест плановых изменений')
  for kind,f in [('bp','01_Входной_БП_пример.xlsx'),('fact','02_Выверенный_факт_пример.xlsx'),('rates','03_Курсы_пример.xlsx')]:
   fd,p=tempfile.mkstemp(suffix='.xlsx');os.close(fd);shutil.copyfile(ROOT/'examples'/f,p)
   engine.upload_path(self.pid,kind,p,f)
  engine.build(self.pid)
 def tearDown(self):
  with engine.connect() as db:
   for table in ('plan_events','plan_event_batches','fact_contracts','fact_clients','positions','position_periods','missing','warnings','fx','uploads','audit','versions'):
    db.execute(f'DELETE FROM {table} WHERE project_id=?',(self.pid,))
   db.execute('DELETE FROM projects WHERE id=?',(self.pid,))
  shutil.rmtree(engine.DATA/str(self.pid),ignore_errors=True)
 def make_event_file(self, headers, rows):
  from openpyxl import Workbook
  wb=Workbook();ws=wb.active;ws.title='Изменения';ws.append(headers)
  for row in rows:ws.append(row)
  fd,path=tempfile.mkstemp(suffix='.xlsx');os.close(fd);wb.save(path);return path
 def make_wide_source_file(self, data_rows):
  from openpyxl import Workbook
  wb=Workbook();ws=wb.active;ws.title='Таблица 1'
  ws.merge_cells('A1:AA1');ws['A1']='Таблица 1'
  headers=['Итог по клиенту','УНП','Клиент','Зона','Рейтинг','Номер договора','ГР','Задолженность','Актив','УО','Валюта','Сегмент','НИ','ПФН','НВВ','Рестра','Обеспеченность','Ранее: Прогноз фев','Прогноз 2026','Изменение в ребаф','Фильтр']
  for col,value in enumerate(headers,1):ws.cell(2,col,value)
  ws.merge_cells('V2:X2');ws['V2']='Дата возникновения признака которого раньше не было'
  ws.merge_cells('Y2:AA2');ws['Y2']='Дата снятия признака'
  for col,value in enumerate(['НИ','ПФН','НВВ','НИ','ПФН','НВВ'],22):ws.cell(3,col,value)
  for values in data_rows:
   row=list(values)+[None]*(27-len(values))
   ws.append(row[:27])
  fd,path=tempfile.mkstemp(suffix='.xlsx');os.close(fd);wb.save(path);return path
 def positions(self,period):
  return [r for r in engine.list_positions(self.pid,period,limit=200)['rows'] if r['unp']=='1001']
 def test_wide_source_layout_reads_only_b_and_v_to_aa_and_applies_clientwide(self):
  import datetime as dt
  row=[None]*27
  row[0]='Итог';row[1]='1001';row[2]='ООО Демо';row[5]='КД-001'
  # Current flags and all other source columns are deliberately ignored.
  row[12]=1;row[13]=1;row[14]=1;row[6]='6';row[7]=999999999
  row[21]=dt.datetime(2026,10,1)  # V: recognition NI -> 01.11
  row[22]=dt.datetime(2026,12,1)  # W: recognition PFN -> 01.01
  row[24]=dt.datetime(2027,2,1)   # Y: removal NI -> next available 01.04
  path=self.make_wide_source_file([row])
  try:
   parsed=engine.parse_plan_change_file(path)
   self.assertEqual({(e['feature'],e['action']) for e in parsed},
                    {('ni','recognition'),('pfn','recognition'),('ni','removal')})
   staged=engine.stage_plan_changes(self.pid,path,'source_table.xlsx')
   events=staged['pending']['events']
   by={(e['feature'],e['action']):e for e in events}
   self.assertEqual(by[('ni','recognition')]['applied_period'],'2026-11-01')
   self.assertEqual(by[('pfn','recognition')]['applied_period'],'2027-01-01')
   self.assertEqual(by[('ni','removal')]['requested_date'],'2027-03-01')
   self.assertEqual(by[('ni','removal')]['applied_period'],'2027-04-01')
   engine.apply_plan_changes(self.pid,staged['pending']['id'])
   for period,ni,pfn in [('2026-10-01',0,0),('2026-11-01',1,0),('2027-01-01',1,1),('2027-04-01',0,1)]:
    rows=self.positions(period)
    self.assertTrue(rows)
    self.assertTrue(all(r['ni']==ni and r['pfn']==pfn for r in rows))
  finally:os.remove(path)
 def test_wide_source_duplicate_unp_is_rejected(self):
  rows=[]
  for date in ('01.10.2026','01.11.2026'):
   row=[None]*27;row[1]='1001';row[21]=date;rows.append(row)
  path=self.make_wide_source_file(rows)
  try:
   with self.assertRaisesRegex(MethodologyError,'более одного раза'):
    engine.parse_plan_change_file(path)
  finally:os.remove(path)
 def test_downloaded_template_matches_wide_source_layout(self):
  from io import BytesIO
  from openpyxl import load_workbook
  buf=engine.build_plan_changes_template()
  wb=load_workbook(BytesIO(buf.getvalue()),data_only=True)
  ws=wb['Таблица 1']
  self.assertEqual(ws['B2'].value,'УНП')
  self.assertEqual([ws.cell(3,c).value for c in range(22,28)],['НИ','ПФН','НВВ','НИ','ПФН','НВВ'])
  self.assertIn('Дата возникновения',ws['V2'].value)
  self.assertIn('Дата снятия',ws['Y2'].value)
 def test_events_shift_one_month_and_map_to_next_available_period(self):
  headers=['УНП','НИ','ПФН','НВВ','Дата возникновения НИ','Дата снятия НИ','Дата возникновения ПФН']
  path=self.make_event_file(headers,[['1001',1,1,1,'01.10.2026','01.03.2027','01.02.2027']])
  try:
   staged=engine.stage_plan_changes(self.pid,path,'events.xlsx')
   events=staged['pending']['events']
   by=(lambda f,a:next(x for x in events if x['feature']==f and x['action']==a))
   self.assertEqual(by('ni','recognition')['requested_date'],'2026-11-01')
   self.assertEqual(by('ni','recognition')['applied_period'],'2026-11-01')
   self.assertEqual(by('pfn','recognition')['requested_date'],'2027-03-01')
   self.assertEqual(by('pfn','recognition')['applied_period'],'2027-04-01')
   self.assertEqual(by('ni','removal')['applied_period'],'2027-04-01')
   self.assertTrue(all(x['status']=='ready' for x in events))
   engine.apply_plan_changes(self.pid,staged['pending']['id'])
   self.assertTrue(all(x['ni']==0 and x['pfn']==0 for x in self.positions('2026-10-01')))
   self.assertTrue(all(x['ni']==1 and x['pfn']==0 for x in self.positions('2026-11-01')))
   self.assertTrue(all(x['ni']==1 and x['pfn']==0 for x in self.positions('2027-01-01')))
   self.assertTrue(all(x['ni']==0 and x['pfn']==1 for x in self.positions('2027-04-01')))
   self.assertTrue(all(x['ni']==0 and x['pfn']==1 for x in self.positions('2027-07-01')))
  finally:os.remove(path)
 def test_conflict_with_business_plan_requires_analyst_choice(self):
  path=self.make_event_file(['УНП','Дата снятия НИ'],[['1001','01.10.2026']])
  try:
   staged=engine.stage_plan_changes(self.pid,path,'remove_ni.xlsx')
   event=staged['pending']['events'][0]
   self.assertEqual(event['status'],'conflict')
   with self.assertRaises(MethodologyError):engine.apply_plan_changes(self.pid,staged['pending']['id'])
   result=engine.apply_plan_changes(self.pid,staged['pending']['id'],{str(event['id']):'keep'})
   self.assertEqual(result['kept_manual'],1)
   self.assertTrue(all(x['ni']==0 for x in self.positions('2026-11-01')))
  finally:os.remove(path)
 def test_manual_correction_conflict_can_be_preserved(self):
  row=next(x for x in self.positions('2026-11-01'))
  engine.edit(self.pid,row['id'],'2026-11-01','ni',0,'Ручная корректировка аналитика')
  path=self.make_event_file(['УНП','Дата возникновения НИ'],[['1001','01.10.2026']])
  try:
   staged=engine.stage_plan_changes(self.pid,path,'recognize_ni.xlsx')
   event=staged['pending']['events'][0]
   self.assertEqual(event['status'],'conflict')
   self.assertIn('ручная корректировка',event['conflict_message'].lower())
   result=engine.apply_plan_changes(self.pid,staged['pending']['id'],{str(event['id']):'keep'})
   self.assertEqual(result['kept_manual'],1)
   self.assertTrue(all(x['ni']==0 for x in self.positions('2026-11-01')))
  finally:os.remove(path)
 def test_duplicate_unp_is_rejected_and_other_flags_are_ignored(self):
  path=self.make_event_file(['УНП','НИ','ПФН','НВВ','Дата возникновения НИ'],[
   ['1001',1,1,1,'01.10.2026'],['1001',0,0,0,'']])
  try:
   with self.assertRaises(MethodologyError):engine.stage_plan_changes(self.pid,path,'duplicate.xlsx')
  finally:os.remove(path)
 def test_plan_event_sheet_is_in_export(self):
  from exports import build_excel
  path=self.make_event_file(['УНП','Дата возникновения НИ'],[['1001','01.10.2026']])
  try:
   staged=engine.stage_plan_changes(self.pid,path,'events.xlsx')
   engine.apply_plan_changes(self.pid,staged['pending']['id'])
   output=build_excel(self.pid)
   import zipfile
   with zipfile.ZipFile(output) as archive:
    workbook=archive.read('xl/workbook.xml').decode('utf-8')
   self.assertIn('Плановые изменения',workbook)
  finally:os.remove(path)
 def test_new_file_replaces_active_events_and_keeps_history(self):
  first=self.make_event_file(['УНП','Дата возникновения НИ'],[['1001','01.10.2026']])
  second=self.make_event_file(['УНП','Дата возникновения ПФН'],[['1001','01.02.2027']])
  try:
   old=engine.stage_plan_changes(self.pid,first,'first.xlsx')
   old_id=old['pending']['id']
   engine.apply_plan_changes(self.pid,old_id)
   self.assertTrue(all(x['ni']==1 for x in self.positions('2026-11-01')))
   new=engine.stage_plan_changes(self.pid,second,'second.xlsx')
   self.assertEqual(new['pending']['summary']['added'],1)
   self.assertEqual(new['pending']['summary']['removed'],1)
   engine.apply_plan_changes(self.pid,new['pending']['id'])
   self.assertTrue(all(x['ni']==0 and x['pfn']==0 for x in self.positions('2026-11-01')))
   self.assertTrue(all(x['ni']==0 and x['pfn']==1 for x in self.positions('2027-04-01')))
   history=engine.get_plan_changes(self.pid)['history']
   old_batch=next(x for x in history if x['id']==old_id)
   self.assertEqual(old_batch['status'],'replaced')
   self.assertEqual(history[0]['status'],'active')
  finally:
   os.remove(first);os.remove(second)
 def test_two_events_mapped_to_same_forecast_date_are_visible_and_ordered(self):
  path=self.make_event_file(['УНП','Дата возникновения НИ','Дата снятия НИ'],[
   ['1001','01.02.2027','01.03.2027']])
  try:
   staged=engine.stage_plan_changes(self.pid,path,'same_period.xlsx')
   events=staged['pending']['events']
   self.assertEqual(len(events),2)
   self.assertTrue(all(x['applied_period']=='2027-04-01' for x in events))
   self.assertTrue(all('одну дату' in x['conflict_message'] for x in events))
   engine.apply_plan_changes(self.pid,staged['pending']['id'])
   self.assertTrue(all(x['ni']==0 for x in self.positions('2027-04-01')))
  finally:os.remove(path)
