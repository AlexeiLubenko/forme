"""Corporate dashboard fact template matches verified input importer."""
from pathlib import Path
import unittest
from openpyxl import load_workbook
import engine

ROOT = Path(__file__).resolve().parents[1]

class CorporatePortfolioTemplateTests(unittest.TestCase):
    def test_header_matches_original_verified_fact_and_importer(self):
        sample=load_workbook(ROOT/'examples'/'02_Выверенный_факт_пример.xlsx',read_only=True,data_only=True)
        template=load_workbook(ROOT/'examples'/'07_Шаблон_фактического_портфеля_ЮЛ.xlsx',read_only=True,data_only=True)
        try:
            header_original=next(sample.active.iter_rows(min_row=1,max_row=1,values_only=True))
            header_actual=next(template['Данные'].iter_rows(min_row=1,max_row=1,values_only=True))
            self.assertEqual(header_actual,header_original)
            self.assertEqual(len(header_actual),55)
            self.assertIn('Инструкция',template.sheetnames)
            sheet, row, head=engine.find_sheet_header(template,['УНП','Номер договора','Тип операции','Код валюты','Сегмент','Резерв факт','% рез'])
            self.assertEqual(sheet.title,'Данные')
            self.assertEqual(row,1)
            expected=['Задолженность, тыс BYN','Курс','ГР','НИ','ПФН','НВВ','Рестра','Обеспеченность']
            for e in expected:self.assertIn(e,head)
            self.assertFalse(any(any(v is not None for v in rr) for rr in sheet.iter_rows(min_row=2,max_row=5,values_only=True)))
        finally:
            template.close();sample.close()

if __name__=='__main__': unittest.main()
