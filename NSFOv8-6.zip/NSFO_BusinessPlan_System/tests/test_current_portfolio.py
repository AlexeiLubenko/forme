from pathlib import Path
from tempfile import TemporaryDirectory
import shutil
import unittest

from openpyxl import Workbook
import current_portfolio as cp
import engine


class CurrentPortfolio(unittest.TestCase):
    def setUp(self):
        tmp=TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        self.addCleanup(setattr,engine,'DB',engine.DB)
        engine.DB=Path(tmp.name)/'project.db'
        shutil.copyfile(engine.ROOT/'examples/demo_nsfo.sqlite3',engine.DB)
        engine.initialize()
        self.file=Path(tmp.name)/'current.xlsx'
        with engine.connect() as db:
            db.execute("UPDATE positions SET contract='Новый договор Б',match_key='1004|НОВЫЙ ДОГОВОР Б|BYN|баланс' WHERE id=3")

    def upload(self,extra=None):
        book=Workbook()
        sheet=book.active
        sheet.append(cp.HEADERS)
        sheet.append(['1001','D1','Кредит','USD',1,0,0,'','Не обеспеченый'])
        sheet.append(['1004','Реальный Б','Кредит','BYN',0,1,0,'рестр. 5 ГР','Недообеспеченный'])
        if extra:sheet.append(extra)
        book.save(self.file)
        return cp.stage(1,self.file,'Текущий.xlsx','2026-10-24','editor')

    def test_preview_mapping_and_horizon(self):
        with engine.connect() as db:
            before=list(map(tuple,db.execute("SELECT * FROM position_periods WHERE period='2026-10-01' ORDER BY position_id")))
        self.upload()
        result=cp.report(1)
        new=next(r for r in result['rows'] if r['contract']=='Реальный Б')
        self.assertIn('new',new['tags'])
        self.assertIn('missing',new['tags'])
        self.assertEqual(new['candidates'],[{'id':3,'contract':'Новый договор Б'}])
        existing=next(r for r in result['rows'] if r['contract']=='D1' and r['side']=='баланс')
        self.assertEqual(existing['changes']['ni'],[0,1])
        self.assertEqual(existing['changes']['security'],['Обеспеченный','Необеспеченный'])
        token=result['meta']['token']
        with self.assertRaises(ValueError):cp.apply(1,token,{new['key']:1},'editor')
        cp.apply(1,token,{new['key']:3},'editor')
        self.assertTrue(cp.apply(1,token,{},'editor')['already'])
        with engine.connect() as db:
            self.assertEqual(before,list(map(tuple,db.execute("SELECT * FROM position_periods WHERE period='2026-10-01' ORDER BY position_id"))))
            for pos in (1,2):
                values=db.execute("SELECT DISTINCT ni FROM position_periods WHERE position_id=? AND period>'2026-10-01'",(pos,)).fetchall()
                self.assertEqual([v[0] for v in values],[1])
            values=db.execute("SELECT DISTINCT pfn,restra,security,rate FROM position_periods WHERE position_id=3 AND period>'2026-10-01'").fetchall()
            self.assertEqual(list(map(tuple,values)),[(1,'рестр. 5 ГР','Недостаточно обеспеченный',50)])
            self.assertEqual(db.execute("SELECT DISTINCT security FROM position_periods WHERE position_id=2 AND period>'2026-10-01'").fetchone()[0],'Обеспеченный')

    def test_conflicting_upload_keeps_review(self):
        self.upload()
        token=cp.report(1)['meta']['token']
        with self.assertRaisesRegex(ValueError,'УНП'):
            self.upload(['1001','X','Кредит','USD',0,1,0,'','Обеспеченный'])
        self.assertEqual(cp.report(1)['meta']['token'],token)
        self.upload()
        with self.assertRaisesRegex(ValueError,'изменился'):cp.apply(1,token,{},'editor')
