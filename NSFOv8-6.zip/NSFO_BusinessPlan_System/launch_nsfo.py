"""One-click, offline-first NSFO 1.4.0 Windows startup (stdlib only).

- Uses an existing working Python when possible.
- Repairs/creates a private .venv with verified bundled pure-Python wheels.
- Performs the first admin setup interactively (never generates a shared password).
- Opens a browser only after the HTTP server has bound successfully.
- Keeps errors visible in the .bat window and writes logs/startup.log.

No admin privileges, system package modifications, pip, or internet required.
"""
from __future__ import annotations

import argparse
import base64
import csv
import hashlib
from importlib import metadata
import os
from pathlib import Path
import shutil
import socket
import subprocess
import sys
import sysconfig
import traceback
import urllib.error
import urllib.request
import venv
import webbrowser
import zipfile

ROOT = Path(__file__).resolve().parent
ENV = ROOT / '.venv'
WHEELS = ROOT / 'wheels'
LOG = ROOT / 'logs' / 'startup.log'
MIN_PY = (3, 11, 5)
REQUIRED = (
    ('openpyxl', 'openpyxl', (3, 0, 10)),
    ('et-xmlfile', 'et_xmlfile', (1, 1, 0)),
)
OFFLINE_WHEELS = (
    'openpyxl-3.1.5-py2.py3-none-any.whl',
    'et_xmlfile-2.0.0-py3-none-any.whl',
)


def log(message: str) -> None:
    print(message, flush=True)
    try:
        LOG.parent.mkdir(parents=True, exist_ok=True)
        with LOG.open('a', encoding='utf-8') as f:
            f.write(message + '\n')
    except OSError:
        # A read-only application folder will be reported during the DB check.
        pass


def version_tuple(value: str) -> tuple[int, ...]:
    import re
    return tuple(int(v) for v in re.findall(r'^\d+|(?<=\.)\d+', value)) or (0,)


def dependencies_ok(python: Path | None = None) -> bool:
    if python is not None:
        try:
            p = subprocess.run([str(python), str(ROOT / 'launch_nsfo.py'), '--check'],
                               cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                               text=True, timeout=45)
            if p.returncode == 0:
                return True
            log('Private environment is incomplete. It will be repaired.')
            return False
        except (OSError, subprocess.TimeoutExpired) as exc:
            log('Cannot validate the private environment: ' + str(exc))
            return False
    if sys.version_info < MIN_PY:
        return False
    for distribution, module, minimum in REQUIRED:
        try:
            v = metadata.version(distribution)
            if version_tuple(v) < minimum:
                return False
            __import__(module)
        except (metadata.PackageNotFoundError, ImportError, OSError, ValueError, AttributeError):
            return False
    return True


def private_python() -> Path:
    return ENV / ('Scripts/python.exe' if os.name == 'nt' else 'bin/python')


def verified_offline_wheels() -> list[Path]:
    manifest = WHEELS / 'SHA256SUMS.txt'
    if not manifest.is_file():
        raise RuntimeError('Bundled offline packages are missing (wheels/SHA256SUMS.txt).')
    expected = {}
    for line in manifest.read_text(encoding='ascii').splitlines():
        if line.strip() and not line.startswith('#'):
            digest, filename = line.split(None, 1)
            expected[filename.strip()] = digest.lower()
    found = []
    for name in OFFLINE_WHEELS:
        wheel = WHEELS / name
        if not wheel.is_file():
            raise RuntimeError('Missing offline package: ' + wheel.name)
        if hashlib.sha256(wheel.read_bytes()).hexdigest() != expected.get(name):
            raise RuntimeError('Invalid offline package SHA256: ' + wheel.name)
        found.append(wheel)
    return found


def safe_wheel_install(path: Path, target: Path) -> None:
    """Install only the two explicitly bundled pure-Python wheels, validating RECORD."""
    root = target.resolve()
    with zipfile.ZipFile(path) as z:
        infos = z.infolist()
        if len(infos) > 5000 or sum(i.file_size for i in infos) > 15 * 1024 * 1024:
            raise RuntimeError('Invalid package size: ' + path.name)
        names = set()
        entries = []
        for info in infos:
            name = info.filename
            parts = Path(name).parts
            if (name.startswith('/') or '\\' in name or '..' in parts or ':' in name
                    or name.endswith('.pth') or any(p.endswith('.data') for p in parts)):
                raise RuntimeError('Invalid wheel path: ' + name)
            allowed = ('openpyxl/', 'openpyxl-3.1.5.dist-info/',
                       'et_xmlfile/', 'et_xmlfile-2.0.0.dist-info/')
            if not name.startswith(allowed):
                raise RuntimeError('Unexpected wheel entry: ' + name)
            names.add(name)
            entries.append(info)
        record = next((n for n in names if n.endswith('.dist-info/RECORD')), None)
        if record is None:
            raise RuntimeError('Missing wheel RECORD: ' + path.name)
        record_rows = list(csv.reader(z.read(record).decode('utf-8').splitlines()))
        for name, digest, size in record_rows:
            if name not in names:
                raise RuntimeError('Incomplete wheel RECORD: ' + name)
            payload = z.read(name)
            if size and len(payload) != int(size):
                raise RuntimeError('Invalid wheel file size: ' + name)
            if digest:
                check = base64.urlsafe_b64encode(hashlib.sha256(payload).digest()).rstrip(b'=').decode()
                if digest != 'sha256=' + check:
                    raise RuntimeError('Wheel checksum mismatch: ' + name)
        for info in entries:
            if info.is_dir():
                continue
            out = (root / info.filename).resolve()
            if not out.is_relative_to(root):
                raise RuntimeError('Unsafe package destination: ' + info.filename)
            out.parent.mkdir(parents=True, exist_ok=True)
            out.write_bytes(z.read(info))
    log('Installed offline: ' + path.name)


def ensure_private_environment() -> Path:
    python = private_python()
    if python.is_file() and dependencies_ok(python):
        log('Using the existing private Python environment.')
        return python
    log('Required packages are missing. Preparing private .venv (offline).')
    if not python.is_file():
        venv.EnvBuilder(with_pip=False, system_site_packages=False).create(ENV)
    if not python.is_file():
        raise RuntimeError('Cannot create .venv. Check write permissions and Python venv support.')
    check = subprocess.run([str(python), '-c',
                            "import sysconfig; print(sysconfig.get_paths()['purelib'])"],
                           capture_output=True, text=True, timeout=30)
    if check.returncode:
        raise RuntimeError('Private Python could not locate its site-packages: ' + check.stderr)
    target = Path(check.stdout.strip()).resolve()
    if not target.is_relative_to(ENV.resolve()):
        raise RuntimeError('Unsafe private installation directory: ' + str(target))
    for wheel in verified_offline_wheels():
        safe_wheel_install(wheel, target)
    if not dependencies_ok(python):
        raise RuntimeError('Dependency verification failed after offline installation.')
    return python


def check_folder_writable() -> None:
    storage = ROOT / 'storage'
    storage.mkdir(exist_ok=True)
    path = storage / '.nsfo_write_check'
    try:
        path.write_text('ok', encoding='ascii')
        path.unlink()
    except OSError as exc:
        raise RuntimeError('Cannot write to the storage folder. Extract the ZIP to a writable '
                           'local directory or ask IT to adjust permissions.') from exc


def open_existing_if_running(should_open: bool) -> bool:
    host = os.getenv('NSFO_HOST', '127.0.0.1')
    if host not in ('127.0.0.1', 'localhost', '::1'):
        return False
    port = int(os.getenv('NSFO_PORT', '8502'))
    try:
        import http.client
        conn = http.client.HTTPConnection('127.0.0.1', port, timeout=1.5)
        conn.request('GET', '/')
        reply = conn.getresponse()
        is_nsfo = reply.getheader('Server', '').startswith('NSFO-Local/')
        reply.read(128)
        conn.close()
    except (OSError, ValueError):
        return False
    if not is_nsfo:
        # Only the default local port may fall back automatically. Explicit
        # NSFO_PORT and remote/proxied installations retain a stable endpoint.
        if 'NSFO_PORT' not in os.environ:
            for candidate in range(8503, 8511):
                with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as probe:
                    try:
                        probe.bind(('127.0.0.1', candidate))
                    except OSError:
                        continue
                os.environ['NSFO_PORT'] = str(candidate)
                log(f'Port {port} is occupied. Using free local port {candidate} instead.')
                return False
        raise RuntimeError(f'Port {port} is already used by another service. '
                           'Close the conflicting application or set NSFO_PORT.')
    url = f'http://127.0.0.1:{port}/'
    log('NSFO is already running: ' + url)
    if should_open:
        webbrowser.open(url)
    return True


def first_admin_setup() -> None:
    import engine
    import access_control
    engine.initialize()
    access_control.initialize()
    if access_control.user_count():
        log('Administrator account exists. No setup required.')
        return
    log('First run: create an administrator account (password is not saved in source code).')
    rc = subprocess.call([sys.executable, str(ROOT / 'setup_admin.py')], cwd=str(ROOT))
    if rc:
        raise RuntimeError('Administrator setup was cancelled or failed.')
    if not access_control.user_count():
        raise RuntimeError('Administrator account was not created.')


def main() -> int:
    parser = argparse.ArgumentParser(description='Start NSFO 1.4.0 with offline dependency checks.')
    parser.add_argument('--check', action='store_true', help='Validate Python and required packages only.')
    parser.add_argument('--no-browser', action='store_true', help='Run the server without opening a browser.')
    parser.add_argument('--no-admin-setup', action='store_true', help='Require an existing admin without prompting.')
    args = parser.parse_args()
    if args.check:
        return 0 if dependencies_ok() else 1
    try:
        log('--- NSFO 1.4.0 startup ---')
        log('Python: ' + sys.version.split()[0] + ' [' + sys.executable + ']')
        if sys.version_info < MIN_PY:
            raise RuntimeError('Python 3.11.5 or later is required.')
        check_folder_writable()
        if not dependencies_ok():
            python = ensure_private_environment()
            log('Restarting the launcher with verified private dependencies.')
            cmd = [str(python), str(ROOT / 'launch_nsfo.py')]
            if args.no_browser:
                cmd.append('--no-browser')
            if args.no_admin_setup:
                cmd.append('--no-admin-setup')
            if os.name != 'nt':
                # Replace the process instead of leaving an orphaned server child.
                os.chdir(ROOT)
                os.execv(str(python), cmd)
            return subprocess.call(cmd, cwd=str(ROOT))
        if open_existing_if_running(not args.no_browser):
            return 0
        if not args.no_admin_setup:
            first_admin_setup()
        log('Starting HTTP server. Keep this window open while using NSFO.')
        bind_host = os.getenv('NSFO_HOST', '127.0.0.1')
        port = int(os.getenv('NSFO_PORT', '8502'))
        log(f'Local address: http://127.0.0.1:{port}/')
        if not args.no_browser:
            os.environ['NSFO_AUTOBROWSER'] = '1'
        import server
        server.main()
        return 0
    except KeyboardInterrupt:
        log('NSFO was stopped by the user.')
        return 0
    except Exception as exc:
        log('STARTUP ERROR: ' + str(exc))
        if isinstance(exc, OSError):
            if getattr(exc, 'winerror', None) == 10013:
                log('Windows blocked the local TCP port (WinError 10013). Ask IT for permission.')
            elif getattr(exc, 'winerror', None) == 10048:
                log('The network port is already in use (WinError 10048).')
        trace = traceback.format_exc()
        log(trace)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
