"""Fact-only reserve bridge for the NSFO dashboard.

Never use forecasting ``risk.compute_factors`` here: actual portfolio changes
have client-wide delinquency, write-offs, SPOK and ledger-specific rules.
Amounts are BYN; all allocated monetary amounts are integer BYN kopecks.
"""
from __future__ import annotations
from dataclasses import dataclass, replace
from decimal import Decimal, ROUND_HALF_UP
from risk import Criteria, classify, gr_value, normal_security, MethodologyError, RATE_BY_GR

GROUPS = ('movement', 'financial_state', 'security_effect', 'revaluation')
SUB_LABELS = {
 'debt_change':'Изменение задолженности',
 'draw_uo_to_active':'Выборка с УО на актив',
 'draw_active_to_uo':'Выборка с актива на УО',
 'new_contract_base':'Новый договор: базовый резерв',
 'new_spok':'Новый договор СПОК',
 'new_pok':'Новый договор ПОК',
 'new_writtenoff':'Новый списанный договор',
 'new_contract_risk':'Новый договор: превышение базовой ставки (фин. состояние)',
 'new_securities_security':'Ценные бумаги: превышение базовой ставки (обеспечение)',
 'contract_exit':'Выбытие договора',
 'segment_transfer':'Переход между сегментами',
 'restruct_in':'Возникновение / изменение реструктуризации',
 'reclassification':'Реклассификация: снятие реструктуризации',
 'ni_to_pfn':'Переход НИ → ПФН',
 'pfn_to_ni':'Переход ПФН → НИ',
 'pfn_in':'Возникновение ПФН', 'pfn_out':'Снятие ПФН',
 'ni_in':'Возникновение НИ','ni_out':'Снятие НИ',
 'nvv_in':'Возникновение НВВ','nvv_out':'Снятие НВВ',
 'security_worsening':'Ухудшение обеспеченности',
 'security_improvement':'Улучшение обеспеченности',
 'dpd_in':'Рост просрочки', 'dpd_out':'Снижение просрочки',
 'poc_rate_dpd':'Пересмотр ставки ПОК из-за просрочки',
 'writeoff_in':'Списание договора', 'writeoff_out':'Возврат списанного договора',
 'revaluation':'Валютная переоценка',
 'actual_reserve_difference':'Изменение учётного резерва сверх расчёта по ставке',
}
SUB_GROUP = {
 **{k:'movement' for k in ('debt_change','draw_uo_to_active','draw_active_to_uo','new_contract_base','new_spok','new_pok','new_writtenoff','contract_exit','segment_transfer')},
 **{k:'financial_state' for k in ('new_contract_risk','restruct_in','reclassification','ni_to_pfn','pfn_to_ni','pfn_in','pfn_out','ni_in','ni_out','nvv_in','nvv_out','dpd_in','dpd_out','poc_rate_dpd','writeoff_in','writeoff_out','actual_reserve_difference')},
 **{k:'security_effect' for k in ('new_securities_security','security_worsening','security_improvement')},
 'revaluation':'revaluation',
}
assert set(SUB_LABELS)==set(SUB_GROUP)


def d(x):
    return Decimal(str(x or 0))


def cents(x):
    return int((d(x)*100).quantize(Decimal('1'), rounding=ROUND_HALF_UP))


def reserve_at(debt, percent):
    return cents(d(debt)*d(percent)/100)


def security_unsecured(c):
    return normal_security(c.security, micro=bool(c.micro))=='unsecured'


def delinquency_floor(c:Criteria, days:int):
    """Client-wide DPD floor for numeric GR, POК uses it only after 30 days."""
    if days <= 7:
        return 0
    unsecured=security_unsecured(c)
    if days <= 30:
        if c.poc: return 0  # POК-specific 31+ rule; under 31 use contractual rate.
        return (5 if unsecured else 4) if c.pfn else 3
    if days <= 90:return 5 if unsecured else 4
    if days <= 180:return 6 if unsecured else 5
    return 6


def effective_rate(c:Criteria, days:int, prior_pok_rate:float, writtenoff=False):
    if writtenoff:return Decimal(100)
    floor=delinquency_floor(c, days)
    if c.poc and floor==0:return d(prior_pok_rate)
    if c.poc:
        return d(RATE_BY_GR[floor])
    gr,rate,_=classify(c)
    if not isinstance(gr,int):raise MethodologyError('Нет числовой группы риска для обычного договора')
    return d(RATE_BY_GR[max(gr,floor)]) if floor>gr else d(rate)


def criteria(row):
    return Criteria(ni=int(row['ni'] or 0),pfn=int(row['pfn'] or 0),nvv=int(row['nvv'] or 0),
                    restra=row['restra'] or '',security=row['security'] or '',
                    operation=row['operation'] or '',currency=row['ccy'],micro=bool(row['micro']),
                    poc=bool(row['poc']),poc_rate=row['rate'] if row['poc'] else None)


def _key_security(before,after):
    rank={'high':0,'secured':1,'micro_unknown':1,'insufficient':2,'unsecured':3}
    b=normal_security(before, micro=True);a=normal_security(after,micro=True)
    return 'security_worsening' if rank.get(a,3)>rank.get(b,3) else 'security_improvement'


def _result(sub,old,new,description):
    grouped={k:0 for k in GROUPS}
    for key,amount in sub.items():grouped[SUB_GROUP[key]]+=amount
    target=(cents(old['reserve_byn']) if old else 0)-(cents(new['reserve_byn']) if new else 0)
    if sum(grouped.values())!=target:
        raise ValueError(f'Нарушена сходимость: 4 фактора={sum(grouped.values())} коп., учётный резерв={target} коп.')
    return {**grouped,'expenses':target,'subfactors':{k:v for k,v in sub.items() if v},'explanation':description}


def decompose(old,new,old_dpd=0,new_dpd=0,drawn_byn=0):
    """Four-factor decomposition with exact integer-cent reconciliation.

    A role of DPD is established by a changed client-wide number of days.
    A rate change with no explaining criteria is rejected, never attributed
    to a generic balancing/override factor.
    """
    old_in=bool(old) and old['segment'] in ('Средний','Крупный','Крупнейший')
    new_in=bool(new) and new['segment'] in ('Средний','Крупный','Крупнейший')
    if not (old_in or new_in):return None
    sub={}
    def add(key,amount):
        if amount:sub[key]=sub.get(key,0)+amount

    if old and new and old_in!=new_in:
        add('segment_transfer',cents(old['reserve_byn']) if old_in else -cents(new['reserve_byn']))
        return _result(sub,old if old_in else None,new if new_in else None,'Изменение сегмента Средний+')
    if old is None:
        total=cents(new['reserve_byn'])
        calculated=reserve_at(new['debt_byn'],new['rate'])
        add('actual_reserve_difference',calculated-total)
        if new.get('written_off'):
            add('new_writtenoff',-calculated)
        elif new.get('spok'):
            add('new_spok',-calculated)
        elif new.get('poc'):
            add('new_pok',-calculated)
        else:
            grp=gr_value(new['gr'])
            if not isinstance(grp,int) or grp not in RATE_BY_GR:
                raise ValueError('Новый договор без допустимой числовой ГР')
            baserate=d(.5 if grp==1 else 5)
            base=reserve_at(new['debt_byn'],baserate)
            add('new_contract_base',-base)
            remainder=calculated-base
            # If an off-balance exposure was drawn down into this new
            # balance-side position, the rate uplift on the transferred share
            # belongs to credit-portfolio movement, even for GR3+.
            if drawn_byn:
                moved=reserve_at(min(d(new['debt_byn']),d(drawn_byn)),new['rate'])-reserve_at(min(d(new['debt_byn']),d(drawn_byn)),baserate)
                add('draw_uo_to_active' if new.get('side','баланс')=='баланс' else 'draw_active_to_uo',-moved)
                remainder-=moved
            if remainder:
                if 'цб' in new['operation'].casefold():add('new_securities_security',-remainder)
                elif grp>2:add('new_contract_risk',-remainder)
                else:raise ValueError('Новый договор ГР 1–2 с нестандартной ставкой: требуется объясняющий критерий/СПОК')
        return _result(sub,None,new,'Новый договор')
    if new is None:
        add('contract_exit',cents(old['reserve_byn']))
        return _result(sub,old,None,'Выбытие договора')

    if d(old['fx'])<=0 or d(new['fx'])<=0:raise ValueError('Курс не может быть нулевым')
    old_res=cents(old['reserve_byn']);new_res=cents(new['reserve_byn'])
    old_od=d(old['debt_byn']);new_od=d(new['debt_byn']);old_rate=d(old['rate']);new_rate=d(new['rate'])
    old_calculated=reserve_at(old_od,old_rate)
    new_calculated=reserve_at(new_od,new_rate)
    # The ledger reserve is authoritative. Isolate any amount beyond the
    # nominal rate calculation before distributing the rate-driven effects.
    add('actual_reserve_difference',(old_res-old_calculated)-(new_res-new_calculated))
    fx_od=old_od*d(new['fx'])/d(old['fx'])
    fx_res=reserve_at(fx_od,old_rate)
    movement_res=reserve_at(new_od,old_rate)
    add('revaluation',old_calculated-fx_res)
    add('debt_change',fx_res-movement_res)
    rate_delta=movement_res-new_calculated
    if not rate_delta:
        if old['gr']!=new['gr'] and old_dpd==new_dpd and all(old.get(k)==new.get(k) for k in ('ni','pfn','nvv','restra','written_off')) and normal_security(old['security'],bool(old['micro']))==normal_security(new['security'],bool(new['micro'])):
            raise ValueError('ГР изменена без изменения НИ/ПФН/НВВ, обеспечения, рестра или просрочки')
        return _result(sub,old,new,'Изменение задолженности / валюты без изменения ставки')

    if old.get('written_off',0)!=new.get('written_off',0):
        if old.get('written_off',0):
            add('writeoff_out',rate_delta)
        else:
            add('writeoff_in',rate_delta)
        return _result(sub,old,new,'Переход в/из состояния «Списан»')

    before=criteria(old);after=criteria(new)
    # Counterfactual model for NI/PFN/NVV/restruct -> collateral -> DPD.
    # Existing same-DPD preferential group may overshadow lower-priority changes.
    flags_changed=any(old[k]!=new[k] for k in ('ni','pfn','nvv','restra'))
    security_changed=normal_security(old['security'],bool(old['micro']))!=normal_security(new['security'],bool(new['micro']))
    dpd_changed=old_dpd!=new_dpd
    if old['gr']!=new['gr'] and not(flags_changed or security_changed or dpd_changed or old['poc']!=new['poc']):
        raise ValueError('Изменилась ГР без объясняющего критерия или увеличения/снижения просрочки')
    if not(flags_changed or security_changed or dpd_changed):
        raise ValueError('Изменение ставки без объясняющего признака: необходима ручная проверка')
    if old['poc']!=new['poc']:
        raise ValueError('Изменение статуса ПОК без утверждённой методики перехода')

    current=before
    candidate=effective_rate(current,old_dpd,float(old_rate))
    model_old=candidate
    model_effects={}
    def apply(field_values,key,days=old_dpd):
        nonlocal candidate,current
        nxt=replace(current,**field_values)
        nxt_rate=effective_rate(nxt,days,float(old_rate))
        amount=reserve_at(new_od,candidate)-reserve_at(new_od,nxt_rate)
        model_effects[key]=model_effects.get(key,0)+amount
        current=nxt;candidate=nxt_rate

    if before.restra!=after.restra and str(after.restra or '').strip():
        apply({'restra':after.restra},'restruct_in')
    ntop=bool(before.ni) and not bool(before.pfn) and not bool(after.ni) and bool(after.pfn)
    pton=bool(before.pfn) and not bool(before.ni) and not bool(after.pfn) and bool(after.ni)
    if ntop:apply({'ni':after.ni,'pfn':after.pfn},'ni_to_pfn')
    elif pton:apply({'ni':after.ni,'pfn':after.pfn},'pfn_to_ni')
    else:
        for field in ('pfn','ni'):
            if getattr(before,field)!=getattr(after,field):
                apply({field:getattr(after,field)},field+('_in' if getattr(after,field) else '_out'))
    if before.nvv!=after.nvv:apply({'nvv':after.nvv},'nvv_in' if after.nvv else 'nvv_out')
    if before.restra!=after.restra and str(before.restra or '').strip() and not str(after.restra or '').strip():
        apply({'restra':after.restra},'reclassification')
    if security_changed:
        apply({'security':after.security},_key_security(before.security,after.security))
    # The final step is delinquency. This is deliberately after collateral changes.
    if dpd_changed:
        nxt_rate=effective_rate(current,new_dpd,float(old_rate))
        name='dpd_in' if new_dpd>old_dpd else 'dpd_out'
        model_effects[name]=model_effects.get(name,0)+(reserve_at(new_od,candidate)-reserve_at(new_od,nxt_rate))
        candidate=nxt_rate
    for key,v in model_effects.items():add(key,v)

    model_total=sum(model_effects.values())
    unexplained=rate_delta-model_total
    if unexplained:
        # POК has a floating portfolio rate (e.g. 1.7 -> 4.6): it is a DPD
        # effect only if client-wide delinquency actually changed.
        old_floor=delinquency_floor(before,old_dpd)
        new_floor=delinquency_floor(after,new_dpd)
        # Observable crossing of a client-wide DPD risk threshold is an
        # explaining event even if a prior historical GR had a nonstandard
        # nominal rate: the whole remaining rate change belongs to DPD.
        if dpd_changed and (old.get('poc',0) or old_floor!=new_floor):
            add('poc_rate_dpd' if old.get('poc',0) else ('dpd_in' if new_dpd>old_dpd else 'dpd_out'),unexplained)
        else:
            raise ValueError(f'Нельзя объяснить изменение ставки до 0,01 BYN: {unexplained} коп.; проверьте ГР/просрочку/критерии')
    # The quality-rate effect on a drawn-down portion is accounted for as
    # portfolio movement, while the remaining exposure follows NI/PFN/DPD/
    # collateral attribution. Integer-cent reallocations preserve exact sums.
    if drawn_byn and new_od>0:
        numerator=min(d(drawn_byn),new_od)
        denominator=new_od
        transfer= 'draw_uo_to_active' if new.get('side','баланс')=='баланс' else 'draw_active_to_uo'
        for key in list(sub):
            if SUB_GROUP[key] not in ('financial_state','security_effect'):continue
            part=int((Decimal(sub[key])*numerator/denominator).quantize(Decimal('1'),rounding=ROUND_HALF_UP))
            if part:
                sub[key]-=part
                add(transfer,part)
                if not sub[key]:del sub[key]
    # Protect against accepting incompatible new numeric risk group below DPD floor.
    if not new.get('written_off',0) and not new.get('poc',0):
        target=gr_value(new['gr'])
        floor=delinquency_floor(after,new_dpd)
        if floor and isinstance(target,int) and target<floor:
            raise ValueError(f'ГР {target} ниже обязательной {floor} по просрочке {new_dpd} дней')
    return _result(sub,old,new,'Изменение по утверждённой последовательности факторов')
