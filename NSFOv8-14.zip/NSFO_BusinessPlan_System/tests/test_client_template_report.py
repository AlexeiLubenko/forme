import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from openpyxl import load_workbook
import engine
from client_template_report import build_report

class ClientReport(unittest.TestCase):
    def test_categories_threshold_comments_and_inputs(self):
        with tempfile.TemporaryDirectory() as d, patch.object(engine,'DB',Path(d)/'db'):
            engine.initialize()
            pid=engine.create_project('Тест')
            dates=['2026-11-01','2026-12-01','2027-01-01']
            with engine.connect() as db:
                db.execute('update projects set periods=? where id=?',(json.dumps(dates),pid))
                for u,amount,zone,gr,rate in [('1',50000,'',1,0.5),('2',-100001,'',2,5),('3',100000,'',1,.5),('4',1300,'черная',2,20),('5',500,'',2,20)]:
                    pos=db.execute('insert into positions(project_id,unp,client,contract,operation,segment26,segment27,zone) values(?,?,?,?,?,?,?,?)',(pid,u,'Имя '+u,'Д'+u,'Кредит','КШБ','КШБ',zone)).lastrowid
                    for i,date in enumerate(dates):
                        db.execute('insert into position_periods(project_id,position_id,period,gr,rate,reserve,expenses,factors) values(?,?,?,?,?,?,?,?)',(pid,pos,date,str(gr),rate,1000000-amount*i,amount if i else 0,json.dumps({'debt_change':amount if i else 0})))
            book=load_workbook(next((engine.ROOT/'examples').glob('09*')))
            w=book.active
            for k,v in {'C5':'1','D5':'Имя 1','X5':.25,'AC5':.2,'Z277':.12,'Z283':.04,'Z291':.123,'Z292':.456}.items():w[k]=v
            inp=Path(d)/'in.xlsx';out=Path(d)/'out.xlsx'
            book.save(inp);build_report(pid,inp,out)
            w=load_workbook(out,data_only=True)
            s=w.active
            self.assertEqual(s['C6'].value,'2')
            self.assertIsNone(s['C7'].value)
            for cell,value in {'Z263':-.050001,'Z264':.1,'Z265':.0005,'Z266':.0013,'Z285':.211799,'AD5':.35,'AP5':.15,'Z291':.123,'Z292':.456}.items():
                self.assertAlmostEqual(s[cell].value,value,msg=cell)
            details=list(w['Комментарии РнР'].values)
            self.assertEqual(len(details),5)
            self.assertIn('ГР 1 → 1',details[1][-1])
            self.assertIn('задолженности',details[1][-1])

            self.assertAlmostEqual(details[1][-3],.30)
            # A second export updates the same detail sheet and preserves the client list.
            repeated=Path(d)/'repeat.xlsx'
            build_report(pid,out,repeated)
            again=load_workbook(repeated,data_only=True)
            self.assertEqual(again.sheetnames,w.sheetnames)
            self.assertAlmostEqual(again.active['AD5'].value,.35)
            self.assertEqual(list(again['Комментарии РнР'].values),details)
            again.close();w.close()
