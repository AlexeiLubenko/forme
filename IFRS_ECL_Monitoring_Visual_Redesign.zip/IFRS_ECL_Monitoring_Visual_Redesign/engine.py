"""Auditable IFRS/ECL demo calculation engine. Educational implementation of user-defined methodology,
NOT an approved IFRS-9 calculation, with explicit exceptions and assumptions.
All monetary values are BYN; schedule cash flows are in original currency.
"""
from __future__ import annotations
from collections import defaultdict
from datetime import datetime,date,timedelta
from calendar import monthrange,isleap
import math

RESERVE_COLS=[71,73,75,77,79,81,83,85,87,89,91,93,95,97,99,101]


def num(v,default=0.):
    if v is None or str(v).strip()=='':return default
    if isinstance(v,str):
        v=v.replace('\u00a0','').replace(' ','').replace(',','.')
    try: x=float(v)
    except (ValueError,TypeError): raise ValueError('Ожидалось число, получено: '+str(v)[:60])
    if not math.isfinite(x):raise ValueError('Число не является конечным')
    return x

def dt(x):
    if isinstance(x,(date,datetime)):return x.date() if isinstance(x,datetime) else x
    s=str(x).strip()
    for form in ('%Y-%m-%d','%d.%m.%Y','%Y-%m-%d %H:%M:%S'):
        try:return datetime.strptime(s,form).date()
        except ValueError:pass
    raise ValueError('Неверная дата: '+s)

def month_end(ym):
    y,m=map(int,ym[:7].split('-'))
    return date(y,m,monthrange(y,m)[1])

def months_between(begin,end):
    y,m=map(int,begin[:7].split('-')); Y,M=map(int,end[:7].split('-'))
    if (Y-y)*12+M-m>60:raise ValueError('Для одного запуска поддерживается максимум 60 месяцев')
    result=[]
    while (y,m)<=(Y,M):
        result.append('%04d-%02d'%(y,m));m+=1
        if m==13:y+=1;m=1
    return result

def clean_id(x):
    s=str(x or '').strip()
    return s[:-2] if s.endswith('.0') and s[:-2].isdigit() else s

def fact_from_sheet(raw,headers):
    """Parse a single 105-column fact row by header's numeric prefix; not by position."""
    vals={}
    for header,value in zip(headers,raw):
        st=str(header).strip(); prefix=st.split('.',1)[0]
        if prefix.isdecimal():vals[int(prefix)]=value
    def g(n):return vals.get(n)
    if not clean_id(g(3)):raise ValueError('Отсутствует CRM ID')
    d={
     'date':dt(g(1)).isoformat(),'status':str(g(2) or '').strip().lower(),
     'crm':clean_id(g(3)),'unp':clean_id(g(4)),'client':str(g(5) or '').strip(),
     'subportfolio':str(g(9) or '').strip(), 'rating':num(g(14),0),
     'stage':int(num(g(24),0)),'contract':clean_id(g(26)), 'tranche':clean_id(g(27)),
     'currency':str(g(30) or 'BYN').strip().upper(),'fx':num(g(31),1),
     'eps':num(g(42)), 'ead':num(g(45)), 'el':num(g(48)), 'k':num(g(49)),
     'pd_contract':num(g(50)), 'pd_pit':num(g(51)), 'ccf':num(g(54),1),'lgd':num(g(55)),
     'poci':str(g(63) or '').strip().lower() in ('да','yes','1','true'),
     'red_zone':str(g(66) or '').strip(),
     'active':sum(num(g(n)) for n in (70,72,74,76)),
     'uo':num(g(86)),'uo_reserve':num(g(87)),
     'off':num(g(88)),'off_reserve':num(g(89)),
     'source':str(g(25) or '').strip(),
     'risk_signals':{str(n):str(g(n) or '').strip() for n in range(16,23)},'expiry':str(g(40) or '').strip(),
     'reserve_parts':{str(n):num(g(n)) for n in RESERVE_COLS},
    }
    if d['stage'] not in (1,2,3):raise ValueError('Стадия должна быть 1, 2 или 3')
    if not d['contract']:raise ValueError('Отсутствует номер договора')
    return d

def validate_fact(rows):
    problems=[]; seen=set(); stage_by_crm={}
    for r in rows:
        key=(r['date'],r['crm'],r['contract'],r['tranche'],r['currency'])
        if key in seen:problems.append({'severity':'error','crm':r['crm'],'contract':r['contract'],'reason':'Повтор идентификатора позиции: '+str(key)})
        seen.add(key)
        elcalc=sum(r['reserve_parts'].values())
        if abs(elcalc-r['el'])>0.01+1e-8:problems.append({'severity':'error','crm':r['crm'],'contract':r['contract'],'reason':'EL не равен сумме 16 резервов: %.2f vs %.2f'%(r['el'],elcalc)})
        if abs(r['el']-r['ead']*r['k'])>0.01+1e-8:problems.append({'severity':'error','crm':r['crm'],'contract':r['contract'],'reason':'EL != EAD × k: %.2f vs %.2f'%(r['el'],r['ead']*r['k'])})
        if r['ead']<0 or r['el']<0 or any(v<0 for v in r['reserve_parts'].values()):problems.append({'severity':'error','crm':r['crm'],'contract':r['contract'],'reason':'Отрицательная задолженность или резерв'})
        if not 0<=r['k']<=1:problems.append({'severity':'error','crm':r['crm'],'contract':r['contract'],'reason':'Коэффициент вне диапазона 0..1'})
        if r['ead']==0 and r['el']!=0:problems.append({'severity':'error','crm':r['crm'],'contract':r['contract'],'reason':'При EAD=0 положительный EL'})
        if r['ead']>0 and r['el']==0:problems.append({'severity':'warning','crm':r['crm'],'contract':r['contract'],'reason':'Положительный EAD при EL=0'})
        if r['poci'] and r['stage']==1:problems.append({'severity':'error','crm':r['crm'],'contract':r['contract'],'reason':'POCI не может быть в стадии 1'})
        if r['crm'] in stage_by_crm and stage_by_crm[r['crm']]!=r['stage']:problems.append({'severity':'error','crm':r['crm'],'contract':r['contract'],'reason':'Разные стадии у одного клиента'})
        stage_by_crm[r['crm']]=r['stage']
        if r['eps']<=0 or r['lgd']<0 or r['lgd']>1 or r['pd_pit']<0 or r['pd_pit']>1 or r['pd_contract']<0 or r['pd_contract']>1:
            problems.append({'severity':'error','crm':r['crm'],'contract':r['contract'],'reason':'Некорректный параметр EPS/PD/LGD'})
        if r['uo']==0 and r['uo_reserve']>0 or r['off']==0 and r['off_reserve']>0:
            problems.append({'severity':'error','crm':r['crm'],'contract':r['contract'],'reason':'Положительный резерв при нулевом объёме обязательства'})
    return problems

def select_fx(ccy,target,fact_rows,fx_rows):
    if ccy=='BYN':return 1.0,'BYN'
    target=dt(target)
    # Actual on exact date takes priority; otherwise forward fill from forecast (next future or last).
    observed=[r for r in fact_rows if r['currency']==ccy and dt(r['date'])==target and r['fx']>0]
    if observed:return observed[0]['fx'],'фактический курс'
    forecast=sorted([(dt(r['Дата']),num(r['Курс'])) for r in fx_rows if str(r.get('Валюта','')).strip().upper()==ccy],key=lambda x:x[0])
    if forecast:
        after=[(d,v) for d,v in forecast if d>=target]
        if after:return after[0][1], 'прогнозный: ближайшая будущая дата'
        return forecast[-1][1],'прогнозный: последний известный'
    older=[r for r in fact_rows if r['currency']==ccy and dt(r['date'])<=target and r['fx']>0]
    if older:
        newest=max(older,key=lambda r:r['date'])
        return newest['fx'],'фактический: последний доступный (нет прогноза)'
    raise ValueError('Нет курса '+ccy)

def schedule_key(r):return (r['unp'],r['tranche'],r['currency'])
def fact_key(r):return (r['crm'],r['contract'],r['tranche'],r['currency'])

def schedule_details(r,items,as_of,target,fx,stage=None,eps=None):
    """Returns detailed audit rows, EAD/EL forecast and assumptions. Items source currency, FX to BYN.
    Method stage1: include cash flows before target with t_b=0 until final maturity; stage2/3: remaining only.
    """
    as_of=dt(as_of);target=dt(target);s=int(stage or r['stage']); ep=float(eps if eps is not None else r['eps']); lgd=r['lgd']
    if ep<=0:raise ValueError('EPS должен быть >0')
    flows=[]
    for item in items:
        paydate=dt(item['Дата платежа'])
        if paydate<=as_of:continue
        cf=sum(num(item.get(c)) for c in ('Срочный ОД','Срочные проценты','Просроченный ОД','Просроченные проценты'))*fx
        if cf<0:raise ValueError('Отрицательный поток')
        if cf>0:flows.append((paydate,cf))
    flows.sort(key=lambda x:x[0])
    if not flows:return {'method':'нет будущих потоков','ead':0.,'reserve':0.,'rate':0.,'rows':[],'warnings':['Нет будущих платежей']}
    if all(d<=target for d,cf in flows):return {'method':'погашен по графику','ead':0.,'reserve':0.,'rate':0.,'rows':[],'warnings':[]}
    first=flows[0][0]
    year_days=366 if isleap(target.year) else 365
    details=[];total_base=0.;sum_q=0.;sum_weight=0.;total_remaining=0.;sum_vbs_a=0.;sum_q_a=0.;sum_weight_a=0.
    for payment,cf in flows:
        raw_days=(payment-target).days; db=max(0,raw_days)
        days_a=max(0,(payment-as_of).days);t_a=days_a/year_days
        t_b=db/year_days
        # Date on/before target discount coefficient exactly 1.
        discount=1. if db==0 else (1+ep)**((db-1)/year_days)
        # Current-stage 'VBS' audit follows bank's discount from first future payment.
        df_original=(1+ep)**((payment-first).days/year_days)
        vbs_current=cf/df_original
        pd1=t_a*r['pd_pit'];q_a=pd1/df_original
        sum_vbs_a+=vbs_current;sum_q_a+=q_a;sum_weight_a+=t_a*q_a
        base=cf/discount
        pd2=t_b*r['pd_pit'];q=pd2/discount
        if s==1 and not r['poci']:
            # Already-matured cash flows still included in base, q=0, until all dates expire.
            total_base+=base
        elif db>0:
            total_base+=base;total_remaining+=cf
        sum_q+=q if db>0 else 0
        sum_weight+=(t_b*q) if db>0 else 0
        details.append({'payment_date':payment.isoformat(),'cash_flow_byn':cf,'days_to_report':days_a,'t_a':t_a,'pd1':pd1,
          'discount_original':df_original,'pd1_discounted':q_a,'days_to_target':db,'t_b':t_b,
          'discount':discount,'vbs_reference':vbs_current,'base_end':base,'pd2':pd2,'q_pd_end':q,
          'included_in_base':(s==1 and not r['poci']) or db>0})
    if r['poci']:
        pd=1. if s==3 else r['pd_contract']
        base=total_remaining if s==3 else total_base
        reserve=base*pd*lgd; method='POCI '+str(s)+' (EAD × PD договор/LGD)' if s==2 else 'POCI 3 (EAD × LGD)'
    elif s==1:
        pd=(sum_weight/sum_q) if sum_q else 0.
        base=total_base;reserve=base*pd*lgd;method='Стадия 1, средневзвешенное PD по формуле банка'
    elif s==2:
        pd=r['pd_pit'];base=total_base;reserve=base*pd*lgd;method='Стадия 2, PD PIT × LGD'
    else:
        pd=1.;base=total_remaining;reserve=base*lgd;method='Стадия 3, прогнозный EAD × LGD'
    rate=pd*lgd
    warnings=[]
    if rate>1+1e-12 or reserve>base+0.01:raise ValueError('Расчётная ставка или резерв превышают базу по графику: проверь среднее PD')
    if (s==1 and not r['poci']):warnings.append('Допущение: платежи до конца месяца входят в базу с t_b=0 до полного погашения')
    return {'method':method,'ead':base,'reserve':reserve,'rate':rate,'pd_used':pd, 'mean_pd_current':sum_weight_a/sum_q_a if sum_q_a else 0.,
      'sum_vbs_reference':sum_vbs_a,'sum_discounted_pd_current':sum_q_a,'sum_discounted_pd_forecast':sum_q,'rows':details,'warnings':warnings}

def parse_schedule(rows):
    result=defaultdict(list)
    for row in rows:
        u=clean_id(row.get('УНП'));t=clean_id(row.get('Номер транша'));c=str(row.get('Валюта','BYN')).upper().strip()
        if not u or not t:continue
        result[(u,t,c)].append(row)
    return result

def parse_volumes(rows):
    out={}
    for r in rows:
        key=(clean_id(r.get('УНП')),clean_id(r.get('Номер договора')),str(r.get('Тип позиции','')).strip(),str(r.get('Валюта','BYN')).strip().upper())
        for k,v in r.items():
            if '|Объем' in k and v is not None and str(v).strip():out[key+(k[:7],)]=(num(v),str(r.get('Форма объёма','Номинал')).strip())
    return out

def future_volume(r,component,month,volume_lookup):
    key=(r['unp'],r['contract'],component,r['currency'],month)
    if key in volume_lookup:
        amount,form=volume_lookup[key]
        # 'EAD после CCF': never multiply by CCF twice.
        base=amount if form=='EAD после CCF' else amount*r['ccf']
        return base,'консервативный прогноз ('+form+')'
    raw=r['uo'] if component=='УО' else r['off']
    return raw*r['ccf'],'текущий объем × CCF (запасной сценарий)'

def forecast_row(r,sc_map,all_fact,fx_rows,volume_lookup,month,target=None,stage=None,eps=None):
    target=dt(target) if target else month_end(month)
    as_of=dt(r['date']);fx,fx_src=select_fx(r['currency'],target,all_fact,fx_rows)
    item=sc_map.get(schedule_key(r),[])
    components=[];trace=[];warnings=[]
    # Active EAD already contains any applicable CCF effects for other components; derive active from row components.
    active_ead=max(0.,r['ead']-r['uo']*r['ccf']-r['off']*r['ccf'])
    if active_ead>0.00001:
        if item:
            # Same original-currency flows keyed by unique tranche+currency.
            calc=schedule_details(r,item,as_of,target,fx,stage=stage,eps=eps)
            base=calc['ead'];reserve=calc['reserve'];method=calc['method'];trace=calc['rows'];warnings+=calc['warnings']
        else:
            base=active_ead
            if r['poci']:
                rate=(1.0 if int(stage or r['stage'])==3 else r['pd_contract'])*r['lgd']
                method='нет графика POCI: EAD факт × '+('LGD' if int(stage or r['stage'])==3 else 'PD договора × LGD')
            elif int(stage or r['stage'])==3:
                rate=r['lgd'];method='нет графика, стадия 3: EAD факт × LGD'
            else:
                rate=r['k'];method='нет графика: EAD факт × коэффициент из ст.49'
            reserve=base*rate
            warnings.append('Нет графика для активной позиции — резервный сценарий')
        components.append({'type':'Кредит','ead':base,'el':reserve,'method':method,
           'pd_used':calc.get('pd_used') if item else None, 'mean_pd_current':calc.get('mean_pd_current') if item else None,
           'vbs_current_reference':calc.get('sum_vbs_reference') if item else None})
    for component,raw in [('УО',r['uo']),('Внебаланс',r['off'])]:
        if raw<=0:continue
        base,method=future_volume(r,component,month,volume_lookup)
        if component=='Внебаланс' and r.get('expiry'):
            try:
                if dt(r['expiry'])<=target:base=0.;method='договор завершён на прогнозную дату'
            except ValueError:pass
        if int(stage or r['stage'])==3:rate=r['lgd']
        else:rate=r['k']
        components.append({'type':component,'ead':base,'el':base*rate,'method':method+'; ставка '+('LGD' if int(stage or r['stage'])==3 else 'k из ст.49')})
    return {'crm':r['crm'],'unp':r['unp'],'client':r['client'],'status':r['status'],'contract':r['contract'],
       'tranche':r['tranche'],'currency':r['currency'],'month':month,'date':target.isoformat(),
       'stage':int(stage or r['stage']),'poci':r['poci'],'fx':fx,'fx_source':fx_src,'pd_pit':r['pd_pit'],
       'pd_contract':r['pd_contract'],'lgd':r['lgd'],'eps':eps if eps is not None else r['eps'],
       'ead':sum(x['ead'] for x in components),'el':sum(x['el'] for x in components),
       'components':components,'trace':trace,'warnings':warnings}

def build_forecast(fact_rows,schedules,fx_rows,volume_rows,begin,end):
    months=months_between(begin,end);sc=parse_schedule(schedules);vol=parse_volumes(volume_rows)
    results=[];warnings=[];seen=set()
    for r in fact_rows:
        if r['status'] not in ('ю','ип'):continue  # Forecast only for corporate and entrepreneurs.
        for month in months:
            try:
                line=forecast_row(r,sc,fact_rows,fx_rows,vol,month)
            except (ValueError,ZeroDivisionError) as ex:
                warnings.append({'crm':r['crm'],'contract':r['contract'],'month':month,'warnings':['РАСЧЁТ НЕ ПОЛУЧЕН: '+str(ex)]})
                continue
            results.append(line)
            if line['warnings']:warnings.append({'crm':r['crm'],'contract':r['contract'],'month':month,'warnings':line['warnings']})
    return {'months':months,'lines':results,'warnings':warnings,'summary':summarize_forecast(results)}

def summarize_forecast(lines):
    groups=defaultdict(lambda:{'ead':0.,'el':0.,'count':0})
    for r in lines:
        g=groups[r['month']];g['ead']+=r['ead'];g['el']+=r['el'];g['count']+=1
    return [{'month':k,**v} for k,v in sorted(groups.items())]

def component_rows(rows):
    out=[]
    for r in rows:
        uo_r=r['uo_reserve'];off_r=r['off_reserve'];credit_r=r['el']-uo_r-off_r
        credit_e=r['ead']-r['uo']*r['ccf']-r['off']*r['ccf']
        for typ,ead,el in [('Кредит',credit_e,credit_r),('УО',r['uo']*r['ccf'],uo_r),('Внебаланс',r['off']*r['ccf'],off_r)]:
            if abs(ead)>1e-8 or abs(el)>1e-8:
                out.append({'crm':r['crm'],'unp':r['unp'],'client':r['client'],'contract':r['contract'],
                 'component':typ,'currency':r['currency'],'ead':ead,'el':el,'stage':r['stage']})
    return out

def wide_plan(rows):
    out=[]
    for r in rows:
        for k,v in r.items():
            if not k.endswith('|EL'):continue
            ym=k[:7]
            ead_key=ym+'|EAD'
            if ead_key not in r:continue
            if v is None or str(v).strip()=='':continue
            out.append({'month':ym,'crm':clean_id(r.get('CRM ID')),'unp':clean_id(r.get('УНП')),'client':str(r.get('Клиент','')),
                'contract':clean_id(r.get('Номер договора')),'component':str(r.get('Тип позиции','')).strip(),
                'currency':str(r.get('Валюта','BYN')).upper().strip(),'status':str(r.get('Статус клиента','')).lower().strip(), 'ead':num(r.get(ead_key)),'el':num(v)})
    return out

def match_contract(unp,contract,matches):
    for r in matches:
        if r['unp']==unp and r['actual']==contract and r['confirmed']:
            return r['planned']
    return contract

def compare_to_plan(rows,plan_rows,month,matches,forecast=False,segment='all'):
    l=defaultdict(lambda:[0.,0.,'']);p=defaultdict(lambda:[0.,0.,''])
    for r in rows:
        if forecast:
            if r['month']!=month:continue
            for c in r['components']:
                key=(r['unp'],match_contract(r['unp'],r['contract'],matches),c['type'],r['currency'])
                l[key][0]+=c['ead'];l[key][1]+=c['el'];l[key][2]=r['client']
        else:
            for c in component_rows([r]):
                key=(r['unp'],match_contract(r['unp'],r['contract'],matches),c['component'],c['currency'])
                l[key][0]+=c['ead'];l[key][1]+=c['el'];l[key][2]=c['client']
    for r in wide_plan(plan_rows):
        if r['month']!=month:continue
        if segment!='all' and r.get('status'):
            if not ((segment=='corp' and r['status'] in ('ю','ип')) or (segment=='retail' and r['status']=='ф') or (segment=='banks' and r['status']=='б')):continue
        if forecast and r.get('status') and r['status'] not in ('ю','ип'):continue
        key=(r['unp'],r['contract'],r['component'],r['currency'])
        p[key][0]+=r['ead'];p[key][1]+=r['el'];p[key][2]=r['client']
    lines=[]
    for key in sorted(set(l)|set(p)):
        present_actual=key in l;present_plan=key in p
        a=l[key];b=p[key]
        lines.append({'unp':key[0],'client':a[2] or b[2],'contract':key[1],'component':key[2],'currency':key[3],
           'ead_actual':a[0],'el_actual':a[1],'ead_plan':b[0],'el_plan':b[1],
           'delta_ead':a[0]-b[0],'delta_el':a[1]-b[1],
           'match_status':'сопоставлено' if present_actual and present_plan else ('только факт/прогноз' if present_actual else 'только БП')})
    return {'month':month,'lines':lines,'totals':{'ead_actual':sum(x['ead_actual'] for x in lines),'el_actual':sum(x['el_actual'] for x in lines),
          'ead_plan':sum(x['ead_plan'] for x in lines),'el_plan':sum(x['el_plan'] for x in lines),
          'delta_el':sum(x['delta_el'] for x in lines),'delta_ead':sum(x['delta_ead'] for x in lines)}}

FACTOR_NAMES=['Новые выдачи','Погашения','Задолженность','Выборка (УО → актив)','Изменение стадии',
              'Изменение PD PIT','Изменение LGD','Валютный курс','Изменение ЭПС','Естественное сокращение срока','Изменение CCF','Прочие / неидентифицировано']

def _model_reserve(r,sc,fx,vol,allrows,asof,stage=None,eps=None):
    rr={**r,'date':dt(asof).isoformat()}
    return forecast_row(rr,sc,allrows,fx,vol,dt(asof).strftime('%Y-%m'),dt(asof),stage,eps)['el']

def factor_bridge(before,after,schedules,fx_rows=None,volume_rows=None):
    """Illustrative audit-friendly sequential factor decomposition; exact balance reconciled by 'Прочие'.
    Stage/EPS/time counterfactuals are ESTIMATES from current schedule, not recognized IFRS drivers.
    """
    fx_rows=fx_rows or [];volume_rows=volume_rows or []
    sc=parse_schedule(schedules);vol=parse_volumes(volume_rows);a={fact_key(r):r for r in before};b={fact_key(r):r for r in after}
    contributions=defaultdict(float);detail=[]
    for k in sorted(set(a)|set(b)):
        old=a.get(k);cur=b.get(k);fs=defaultdict(float)
        if old is None:fs['Новые выдачи']+=cur['el']
        elif cur is None:fs['Погашения']-=old['el']
        else:
            # Sequential: debt first, stage next; avoid counting currency and CCF twice.
            prevk=old['k'];delta_ead=cur['ead']-old['ead']
            f_fx=0.
            if old['currency']!='BYN' and old['fx']>0:
                f_fx=old['ead']*(cur['fx']/old['fx']-1)*prevk
            f_ccf=(old['uo']+old['off'])*(cur['ccf']-old['ccf'])*prevk
            old_active=old['active'];new_active=cur['active'];draw=min(max(0,new_active-old_active),max(0,old['uo']-cur['uo']))
            old_active_rate=(old['el']-old['uo_reserve']-old['off_reserve'])/old_active if old_active>0 else prevk
            old_uo_rate=old['uo_reserve']/old['uo'] if old['uo']>0 else 0.
            f_draw=draw*(old_active_rate-old_uo_rate)
            fs['Валютный курс']+=f_fx;fs['Изменение CCF']+=f_ccf;fs['Выборка (УО → актив)']+=f_draw
            fs['Задолженность']+=delta_ead*prevk-f_fx-f_ccf-f_draw
            if old['stage']!=cur['stage']:
                try:fs['Изменение стадии']+=_model_reserve(cur,sc,fx_rows,vol,after,cur['date'],stage=cur['stage'])-_model_reserve(cur,sc,fx_rows,vol,after,cur['date'],stage=old['stage'])
                except (ValueError,ZeroDivisionError):pass
            if old['pd_pit']!=cur['pd_pit'] and cur['stage']==2 and not cur['poci']:
                fs['Изменение PD PIT']+=cur['ead']*(cur['pd_pit']-old['pd_pit'])*cur['lgd']
            elif cur['poci'] and old['pd_contract']!=cur['pd_contract']:
                fs['Изменение PD PIT']+=cur['ead']*(cur['pd_contract']-old['pd_contract'])*cur['lgd']
            eff_pd=1 if cur['stage']==3 else (cur['pd_contract'] if cur['poci'] else cur['pd_pit'])
            fs['Изменение LGD']+=cur['ead']*(cur['lgd']-old['lgd'])*eff_pd
            if abs(old['eps']-cur['eps'])>1e-10:
                try:fs['Изменение ЭПС']+=_model_reserve(cur,sc,fx_rows,vol,after,cur['date'],eps=cur['eps'])-_model_reserve(cur,sc,fx_rows,vol,after,cur['date'],eps=old['eps'])
                except (ValueError,ZeroDivisionError):pass
            # Historical schedule is not preserved, so natural maturity effect left in residual for fact-vs-fact.
            fs['Естественное сокращение срока']+=0.
            fs['Прочие / неидентифицировано']+=(cur['el']-old['el'])-sum(fs.values())
        for name,val in fs.items():contributions[name]+=val
        detail.append({'crm':(cur or old)['crm'],'client':(cur or old)['client'],'contract':(cur or old)['contract'],
         'tranche':(cur or old)['tranche'],'currency':(cur or old)['currency'],
         'before_el':old['el'] if old else 0.,'after_el':cur['el'] if cur else 0.,'delta':(cur['el'] if cur else 0.)-(old['el'] if old else 0.),'factors':dict(fs),
         'events':list(filter(None,[('Стадия %s → %s'%(old['stage'],cur['stage'])) if old and cur and old['stage']!=cur['stage'] else '',
                    ('Рейтинг %s → %s'%(old['rating'],cur['rating'])) if old and cur and old['rating']!=cur['rating'] else '',
                    ('Зона проблемности %s → %s'%(old['red_zone'],cur['red_zone'])) if old and cur and old['red_zone']!=cur['red_zone'] else '']))})
    old_el=sum(r['el'] for r in before);new_el=sum(r['el'] for r in after);delta=new_el-old_el
    ordered=[{'name':n,'value':contributions[n]} for n in FACTOR_NAMES]
    residual=delta-sum(x['value'] for x in ordered)
    return {'before_el':old_el,'after_el':new_el,'delta_el':delta,'factors':ordered,
        'reconciliation':residual,'detail':sorted(detail,key=lambda x:abs(x['delta']),reverse=True),
        'method_note':'Предварительная последовательная факторная модель. Стадия/ЭПС — контрфакт по текущему графику. Остаток сверки в Прочие. Исторический график не хранится.'}

def actual_summary(rows):
    bystatus=defaultdict(lambda:{'ead':0.,'el':0.,'rows':0,'clients':set()})
    bystage=defaultdict(lambda:{'ead':0.,'el':0.,'clients':set()})
    byclient=defaultdict(lambda:{'ead':0.,'el':0.,'client':'','status':'','stage':0})
    for r in rows:
        group='ЮЛ + ИП' if r['status'] in ('ю','ип') else ('Физлица' if r['status']=='ф' else 'Банки')
        s=bystatus[group];s['ead']+=r['ead'];s['el']+=r['el'];s['rows']+=1;s['clients'].add(r['crm'])
        st=bystage[r['stage']];st['ead']+=r['ead'];st['el']+=r['el'];st['clients'].add(r['crm'])
        c=byclient[r['crm']];c['client']=r['client'];c['status']=group;c['stage']=r['stage'];c['ead']+=r['ead'];c['el']+=r['el']
    return {'ead':sum(r['ead'] for r in rows),'el':sum(r['el'] for r in rows),'clients':len(byclient),'positions':len(rows),
      'segments':[{'name':k,'ead':v['ead'],'el':v['el'],'clients':len(v['clients']),'rows':v['rows']} for k,v in bystatus.items()],
      'stages':[{'stage':k,'ead':v['ead'],'el':v['el'],'clients':len(v['clients'])} for k,v in sorted(bystage.items())],
      'clients_detail':[{'crm':k,**v} for k,v in sorted(byclient.items(),key=lambda x:-x[1]['el'])]}
