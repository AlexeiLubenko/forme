@echo off
chcp 65001 > nul
setlocal
pushd "%~dp0"
if errorlevel 1 (
 echo Cannot change to app directory
 pause
 exit /b 1
)
python --version
if errorlevel 1 (
 echo Python 3.11 or newer must be available via python
 pause
 exit /b 1
)
python app.py --port 8501
if errorlevel 1 (
 echo.
 echo Start failed. See error above. Local ports may be blocked in bank environment.
 pause
)
popd
