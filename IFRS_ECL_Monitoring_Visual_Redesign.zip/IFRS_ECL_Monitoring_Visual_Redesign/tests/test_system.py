import io,json,sys,tempfile,threading,unittest,urllib.request,urllib.error
from pathlib import Path
from http.server import ThreadingHTTPServer
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from demo_seed import build_seed
from engine import (fact_from_sheet,validate_fact,build_forecast,factor_bridge,parse_schedule,parse_volumes,forecast_row,
                    select_fx,compare_to_plan,actual_summary,schedule_details)
from store import Repository
from app import Application,Handler

class DemoTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.seed=build_seed();cls.headers=json.loads((ROOT/'fact_headers.json').read_text())
        cls.base=[fact_from_sheet(x,cls.headers) for x in cls.seed['fact_base']]
        cls.fact=[fact_from_sheet(x,cls.headers) for x in cls.seed['fact_current']]
        cls.sch=parse_schedule(cls.seed['schedules']);cls.vol=parse_volumes(cls.seed['volumes'])
        cls.forecast=build_forecast(cls.fact,cls.seed['schedules'],cls.seed['fx_forecast'],cls.seed['volumes'],'2026-11','2027-04')
    def find(self,crm,contract=None,currency=None):
        return next(r for r in self.fact if r['crm']==crm and (contract is None or r['contract']==contract) and
                    (currency is None or r['currency']==currency))
    def test_headers105(self):
        self.assertEqual(len(self.headers),105)
        self.assertTrue(self.headers[44].startswith('45. EAD'))
    def test_fact_reconciles(self):
        self.assertEqual(validate_fact(self.fact),[])
        self.assertEqual(validate_fact(self.base),[])
        self.assertAlmostEqual(actual_summary(self.fact)['el'],1064102.50)
        self.assertAlmostEqual(actual_summary(self.base)['el'],548808)
    def test_multi_currency_same_tranche(self):
        r=[x for x in self.fact if x['contract']=='КД-2026/145' and x['tranche']=='КД-2026/145_1']
        self.assertEqual(sorted(x['currency'] for x in r),['BYN','USD'])
    def test_poci_stage2_pd_contract(self):
        r=self.find('1004');r2=forecast_row(r,self.sch,self.fact,self.seed['fx_forecast'],self.vol,'2026-11')
        part=r2['components'][0]
        self.assertAlmostEqual(part['el'],part['ead']*r['pd_contract']*r['lgd'],places=5)
        self.assertNotAlmostEqual(part['el'],part['ead']*r['pd_pit']*r['lgd'],places=2)
    def test_stage3_lgd_not_100pct(self):
        r=self.find('1003');line=forecast_row(r,self.sch,self.fact,self.seed['fx_forecast'],self.vol,'2026-12')
        self.assertAlmostEqual(line['el'],line['ead']*r['lgd'],places=5)
        self.assertAlmostEqual(line['ead'],255000,places=2)
    def test_poci3_lgd(self):
        r=self.find('1008');line=forecast_row(r,self.sch,self.fact,self.seed['fx_forecast'],self.vol,'2026-11')
        self.assertAlmostEqual(line['el'],line['ead']*r['lgd'],places=5)
    def test_stage1_meanPD_expression(self):
        r=self.find('1005');line=forecast_row(r,self.sch,self.fact,self.seed['fx_forecast'],self.vol,'2026-11')
        trace=line['trace'];pd_calc=sum(t['t_b']*t['q_pd_end'] for t in trace)/sum(t['q_pd_end'] for t in trace)
        comp=line['components'][0]
        self.assertAlmostEqual(comp['pd_used'],pd_calc,places=10)
        self.assertAlmostEqual(comp['el'],sum(t['base_end'] for t in trace)*pd_calc*r['lgd'],places=5)
    def test_stage2_pd_pit(self):
        r=self.find('1002');line=forecast_row(r,self.sch,self.fact,self.seed['fx_forecast'],self.vol,'2026-11')
        credit=next(p for p in line['components'] if p['type']=='Кредит')
        self.assertAlmostEqual(credit['el'],credit['ead']*r['pd_pit']*r['lgd'])
    def test_no_schedule_fallback(self):
        r=self.find('1006');line=forecast_row(r,self.sch,self.fact,self.seed['fx_forecast'],self.vol,'2026-11')
        self.assertAlmostEqual(line['el'],r['ead']*r['k'])
        self.assertTrue(line['warnings'])
    def test_unutilized_balance_ccf_not_double(self):
        r=next(x for x in self.fact if x['contract']=='КД-2026/145' and x['uo']>0)
        line=forecast_row(r,self.sch,self.fact,self.seed['fx_forecast'],self.vol,'2026-11')
        self.assertAlmostEqual(line['ead'],5000000*r['ccf'])
        self.assertAlmostEqual(line['el'],5000000*r['ccf']*r['k'])
    def test_guarantee_expiry(self):
        r=self.find('3001')
        line=forecast_row(r,self.sch,self.fact,self.seed['fx_forecast'],self.vol,'2027-01')
        self.assertEqual(line['ead'],0.)
        self.assertEqual(line['el'],0.)
    def test_forecast_corporate_only(self):
        self.assertEqual(len(self.forecast['lines']),10*6)
        self.assertTrue(all(r['status'] in ('ю','ип') for r in self.forecast['lines']))
    def test_schedule_matures_to_zero(self):
        r=self.find('1003');line=forecast_row(r,self.sch,self.fact,self.seed['fx_forecast'],self.vol,'2027-03')
        self.assertEqual(line['el'],0.)
    def test_currency_fx(self):
        v,source=select_fx('USD','2026-11-15',self.fact,self.seed['fx_forecast'])
        self.assertEqual(v,3.02)
        v,source=select_fx('USD','2029-11-30',self.fact,self.seed['fx_forecast'])
        self.assertEqual(v,3.22)
        v,source=select_fx('USD','2026-11-05',self.fact,self.seed['fx_forecast'])
        self.assertEqual(v,3.0)
    def test_new_deal_match(self):
        current=[r for r in self.fact if r['status'] in ('ю','ип')]
        comp=compare_to_plan(current,self.seed['plan'],'2026-11',self.seed['matches'],segment='corp')
        new1=[r for r in comp['lines'] if r['contract']=='Новый договор №1']
        self.assertEqual(len(new1),3)
        self.assertTrue(all(r['match_status']=='сопоставлено' for r in new1))
        new2=[r for r in comp['lines'] if r['contract']=='Новый договор №2']
        self.assertEqual(len(new2),1);self.assertEqual(new2[0]['match_status'],'только БП')
        self.assertAlmostEqual(comp['totals']['el_actual']-comp['totals']['el_plan'],comp['totals']['delta_el'])
    def test_factor_bridge_reconciles(self):
        r=factor_bridge(self.base,self.fact,self.seed['schedules'],self.seed['fx_forecast'],self.seed['volumes'])
        self.assertAlmostEqual(r['delta_el'],515294.5)
        self.assertAlmostEqual(sum(x['value'] for x in r['factors']),r['delta_el'],places=5)
        self.assertLess(abs(r['reconciliation']),0.01)
    def test_quality_flags(self):
        r=dict(self.fact[0]);r['el']+=100
        self.assertTrue(any('EL' in q['reason'] for q in validate_fact([r])))
    def test_existing_excel_import_and_baseline(self):
        with tempfile.TemporaryDirectory() as d:
            repo=Repository(d)
            a=repo.add('FACT',ROOT/'examples'/'01_fact_base_2026-10-30.xlsx')
            b=repo.add('FACT',ROOT/'examples'/'02_fact_current_2026-11-05.xlsx')
            c=repo.add('PLAN',ROOT/'examples'/'03_business_plan_approved.xlsx')
            self.assertEqual(repo.baseline_release()['report_date'],'2026-10-30')
            self.assertEqual(repo.current_release('FACT')['id'],b['id'])
            self.assertEqual(len(repo.get_kind('FACT')),13)
            self.assertEqual(len(repo.get_kind('PLAN')),15)
            self.assertEqual(repo.list_releases()[0]['id'],c['id'])
    def test_http_endpoints_and_post_run(self):
        with tempfile.TemporaryDirectory() as d:
            from bootstrap_demo import run
            repo=run(d);api=Application(d)
            server=ThreadingHTTPServer(('127.0.0.1',0),Handler);server.api=api
            thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
            base='http://127.0.0.1:%d'%server.server_port
            try:
                def get(path):return json.load(urllib.request.urlopen(base+path,timeout=10))
                self.assertTrue(get('/api/health')['ok'])
                self.assertAlmostEqual(get('/api/state')['delta_el'],515294.5)
                self.assertEqual(get('/api/fact?segment=banks')['total'],1)
                self.assertEqual(len(get('/api/forecast?month=2026-11')['rows']),10)
                c=get('/api/compare?mode=forecast_fact&month=2026-11')
                self.assertEqual(c['mode'],'forecast_fact')
                req=urllib.request.Request(base+'/api/run',json.dumps({'begin':'2026-11','end':'2026-12'}).encode(),
                      headers={'X-IFRS-App':'browser','Content-Type':'application/json'},method='POST')
                self.assertTrue(json.load(urllib.request.urlopen(req,timeout=15))['ok'])
                self.assertEqual(len(get('/api/forecast')['months']),2)
                self.assertGreater(len(urllib.request.urlopen(base+'/api/example?name=03_business_plan_approved.xlsx',timeout=5).read()),1000)
            finally:server.shutdown();server.server_close()

if __name__=='__main__':unittest.main()
