import sys,importlib.util,socket
print('Python:',sys.version.replace('\n',' '))
print('openpyxl installed:',bool(importlib.util.find_spec('openpyxl')))
print('pandas installed (optional):',bool(importlib.util.find_spec('pandas')))
print('sqlite3 installed:',bool(importlib.util.find_spec('sqlite3')))
try:
 s=socket.socket();s.bind(('127.0.0.1',0));print('localhost bind: OK port',s.getsockname()[1]);s.close()
except OSError as e:print('localhost bind: FAILED:',e)
