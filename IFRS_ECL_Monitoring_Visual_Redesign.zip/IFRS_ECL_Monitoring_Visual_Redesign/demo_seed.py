"""Deterministic wholly fictional sample source data. Rebuild XLSX using build_examples.py (artifact_tool)."""
import json
from pathlib import Path
from engine import RESERVE_COLS
ROOT=Path(__file__).resolve().parent
DATES=('2026-10-30','2026-11-05')
CLIENTS={
 '1001':('190123456','ООО «Альфа»','ю','Промышленность'),
 '1002':('190234567','ОАО «Бета»','ю','Торговля'),
 '1003':('190345678','ООО «Гамма»','ю','Строительство'),
 '1004':('190456789','ООО «Прометей»','ю','Транспорт'),
 '1005':('190567890','ИП «Дельта»','ип','ИП'),
 '1006':('190678901','ООО «Эпсилон»','ю','Логистика'),
 '1007':('190789012','ООО «Дзета»','ю','Машиностроение'),
 '1008':('190890123','ООО «Тета»','ю','Сельское хозяйство'),
 '2001':('','Иванов И.И.','ф','Ипотека'),
 '2002':('','Петрова А.С.','ф','Потребительский'),
 '3001':('190900001','АО «Банк Омега»','б','Банки'),
}

def make_row(date,crm,contract,tranche='',ccy='BYN',active=0,uo=0,off=0,ccf=.5,k=.04,stage=1,
             rating=4,pd=.04,pd_contract=.045,lgd=.40,eps=.12,poci=False,red='',fx=1,expiry='2027-08-31',signals=None):
    unp,name,status,subport=CLIENTS[crm]
    a=[None]*105
    def put(n,x):a[n-1]=x
    put(1,date);put(2,status);put(3,crm);put(4,unp);put(5,name);put(6,unp)
    put(7,'620100');put(8,subport);put(9,subport if status=='ф' else 'Корпоративный')
    put(10,'Крупный' if status=='ю' else 'Розница');put(11,'Средний риск');put(12,'Да');put(13,'ЮЛ' if status=='ю' else '')
    put(14,rating);put(15,date)
    for n in range(16,23):put(n,'Нет')
    if signals:
        for n,v in signals.items():put(n,v)
    put(23,'');put(24,stage);put(25,'Демо АБС');put(26,contract);put(27,tranche)
    put(28,'КЛ' if uo else 'КР');put(29,'Кредитная линия' if uo else 'Срочный кредит')
    put(30,ccy);put(31,fx)
    for n in range(32,38):put(n,0 if n!=37 else '0 дней')
    put(38,'2026-06-01');put(39,'2026-09-01');put(40,expiry);put(41,'');put(42,eps);put(43,.13)
    put(44,'Фиксированная')
    ead=active+(uo+off)*ccf
    put(45,ead);put(46,'');put(47,'');put(48,round(ead*k,2));put(49,k);put(50,pd_contract);put(51,pd)
    put(52,max(pd,pd_contract));put(53,0);put(54,ccf);put(55,lgd);put(56,lgd);put(57,lgd);put(58,lgd)
    put(59,'Нет');put(60,'');put(61,'Автоматический');put(62,'Нет');put(63,'Да' if poci else '')
    put(64,rating);put(65,date);put(66,red);put(67,'Нет');put(68,'Возобновляемая' if uo else '');put(69,'Кредит')
    principal=round(active*.96,2);interest=round(active-principal,2)
    put(70,principal);put(71,round(principal*k,2));put(72,interest);put(73,round(interest*k,2))
    for n in [74,75,76,77,78,79,80,81,82,83,84,85,90,91,92,93,94,95,96,97,98,99,100,101,102]:put(n,0)
    put(86,uo);put(87,round(uo*ccf*k,2));put(88,off);put(89,round(off*ccf*k,2))
    put(103,'Долгосрочный');put(104,'До года');put(105,'Стандартный')
    # Round only in source output: enforce exact EL = sum of all 16 columns.
    put(48,round(sum(float(a[j-1] or 0) for j in RESERVE_COLS),2))
    return a

base=[
 make_row(DATES[0],'1001','КД-OLD01','КД-OLD01_1',active=1500000,k=.021,stage=1,rating=4,pd=.025,lgd=.41,signals={17:'Нет'}),
 make_row(DATES[0],'1002','КД-77','КД-77_1',active=750000,uo=360000,ccf=.4,k=.067,stage=2,rating=6,pd=.07,lgd=.45),
 make_row(DATES[0],'1003','КД-33','КД-33_1',active=400000,k=.6,stage=3,rating=8,pd=1,lgd=.6,red='Да'),
 make_row(DATES[0],'1004','КД-POCI04','КД-POCI04_1',active=500000,k=.066,stage=2,rating=7,pd=.08,pd_contract=.12,lgd=.55,poci=True),
 make_row(DATES[0],'1005','КД-44','КД-44_1',ccy='EUR',fx=3.35,active=335000,k=.026,stage=1,rating=3,pd=.03,lgd=.4),
 make_row(DATES[0],'1007','КД-PAID','КД-PAID_1',active=150000,k=.04,stage=1,rating=3,pd=.035,lgd=.4),
 make_row(DATES[0],'1008','КД-POCI3','КД-POCI3_1',active=270000,k=.55,stage=3,rating=10,pd=1,pd_contract=.30,lgd=.55,poci=True),
 make_row(DATES[0],'2001','Ф-001',active=500000,k=.012,stage=1,rating=2,pd=.025,lgd=.3),
 make_row(DATES[0],'2002','Ф-002',active=80000,k=.04,stage=2,rating=6,pd=.08,lgd=.5),
 make_row(DATES[0],'3001','ГАР-БАНК-01',off=800000,ccf=.5,k=.03,stage=1,rating=4,pd=.035,lgd=.4,expiry='2027-01-31'),
]
current=[
 make_row(DATES[1],'1001','КД-OLD01','КД-OLD01_1',active=1470000,k=.065,stage=2,rating=6,pd=.085,lgd=.43,eps=.13,red='Да',signals={17:'Да',20:'Да'}),
 make_row(DATES[1],'1001','КД-2026/145','КД-2026/145_1',ccy='BYN',active=2000000,k=.065,stage=2,rating=6,pd=.085,lgd=.43,eps=.13,red='Да'),
 make_row(DATES[1],'1001','КД-2026/145','КД-2026/145_1',ccy='USD',fx=3.0,active=3000000,k=.065,stage=2,rating=6,pd=.085,lgd=.43,eps=.13,red='Да'),
 make_row(DATES[1],'1001','КД-2026/145','',ccy='BYN',uo=5000000,ccf=.5,k=.065,stage=2,rating=6,pd=.085,lgd=.43,eps=.13,red='Да'),
 make_row(DATES[1],'1002','КД-77','КД-77_1',active=860000,uo=250000,ccf=.5,k=.062,stage=2,rating=5,pd=.065,lgd=.43),
 make_row(DATES[1],'1003','КД-33','КД-33_1',active=350000,k=.6,stage=3,rating=8,pd=1,lgd=.6,red='Да'),
 make_row(DATES[1],'1004','КД-POCI04','КД-POCI04_1',active=485000,k=.0605,stage=2,rating=7,pd=.08,pd_contract=.11,lgd=.55,poci=True),
 make_row(DATES[1],'1005','КД-44','КД-44_1',ccy='EUR',fx=3.4,active=340000,k=.028,stage=1,rating=3,pd=.03,lgd=.40),
 make_row(DATES[1],'1006','КД-56','КД-56_2',active=220000,k=.032,stage=1,rating=4,pd=.035,lgd=.4),
 make_row(DATES[1],'1008','КД-POCI3','КД-POCI3_1',active=260000,k=.55,stage=3,rating=10,pd=1,pd_contract=.30,lgd=.55,poci=True),
 make_row(DATES[1],'2001','Ф-001',active=495000,k=.012,stage=1,rating=2,pd=.025,lgd=.3),
 make_row(DATES[1],'2002','Ф-002',active=84000,k=.04,stage=2,rating=6,pd=.08,lgd=.5),
 make_row(DATES[1],'3001','ГАР-БАНК-01',off=760000,ccf=.5,k=.031,stage=1,rating=4,pd=.035,lgd=.4,expiry='2027-01-31'),
]

MONTHS=['2026-11','2026-12','2027-01','2027-02','2027-03','2027-04']
plan_positions=[
 ('1001','Новый договор №1','Кредит','BYN',2000000,.065),
 ('1001','Новый договор №1','УО','BYN',2500000,.065),
 ('1001','Новый договор №1','Кредит','USD',3000000,.065),
 ('1001','Новый договор №2','Кредит','BYN',1200000,.032),
 ('1001','КД-OLD01','Кредит','BYN',1500000,.035),
 ('1002','КД-77','Кредит','BYN',850000,.064),
 ('1002','КД-77','УО','BYN',125000,.064),
 ('1003','КД-33','Кредит','BYN',330000,.6),
 ('1004','КД-POCI04','Кредит','BYN',490000,.061),
 ('1005','КД-44','Кредит','EUR',340000,.028),
 ('1006','КД-56','Кредит','BYN',200000,.033),
 ('1008','КД-POCI3','Кредит','BYN',255000,.55),
 ('2001','Ф-001','Кредит','BYN',495000,.012),
 ('2002','Ф-002','Кредит','BYN',84000,.04),
 ('3001','ГАР-БАНК-01','Внебаланс','BYN',380000,.031),
]
plan=[]
for crm,contract,typ,ccy,ead,k in plan_positions:
    unp,name,status,_=CLIENTS[crm]
    row={'CRM ID':crm,'УНП':unp,'Клиент':name,'Номер договора':contract,'Тип позиции':typ,'Валюта':ccy,'Единица':'BYN','Статус клиента':status}
    for idx,m in enumerate(MONTHS):
        # approved plan is a distinct source, independent of forecasts.
        factor=max(.10,1-idx*(.09 if typ!='УО' else .07))
        if contract=='Новый договор №2':factor=min(1,.2+idx*.16)
        val=round(ead*factor,2)
        row[m+'|EAD']=val;row[m+'|EL']=round(val*k,2)
    plan.append(row)

# Separate immutable initial forecast. EAD stocks in these source cells are never rewritten by forecast runs.
forecast_original=[]
for src in plan:
    if src.get('Статус клиента') not in ('ю','ип'):continue
    entry={k:v for k,v in src.items() if '|' not in k}
    for idx,m in enumerate(MONTHS):
        entry[m+'|EAD']=round(src[m+'|EAD']*(1.02 if src['Тип позиции']=='Кредит' else 0.98),2)
        entry[m+'|EL']=round(src[m+'|EL']*1.08,2)
    forecast_original.append(entry)

schedule=[]
def add_sched(crm,contract,tranche,ccy,amounts):
    unp=CLIENTS[crm][0]
    for date,p,i in amounts:
        schedule.append({'УНП':unp,'Номер договора':contract,'Номер транша':tranche,'Валюта':ccy,'Дата платежа':date,
          'Срочный ОД':p,'Срочные проценты':i,'Просроченный ОД':0,'Просроченные проценты':0})
add_sched('1001','КД-OLD01','КД-OLD01_1','BYN',[('2026-12-15',300000,12000),('2027-01-31',400000,9000),('2027-04-15',770000,7000)])
add_sched('1001','КД-2026/145','КД-2026/145_1','BYN',[('2026-12-31',400000,15000),('2027-02-28',700000,10000),('2027-05-31',900000,8000)])
add_sched('1001','КД-2026/145','КД-2026/145_1','USD',[('2026-12-31',200000,8000),('2027-02-28',350000,7000),('2027-05-31',450000,5000)])
add_sched('1002','КД-77','КД-77_1','BYN',[('2026-11-30',100000,10000),('2026-12-31',200000,7000),('2027-02-28',300000,5000),('2027-04-30',260000,4000)])
add_sched('1003','КД-33','КД-33_1','BYN',[('2026-12-15',100000,5000),('2027-01-31',100000,3000),('2027-02-28',150000,2000)])
add_sched('1004','КД-POCI04','КД-POCI04_1','BYN',[('2026-12-31',185000,3000),('2027-03-31',300000,3000)])
add_sched('1005','КД-44','КД-44_1','EUR',[('2026-12-20',25000,600),('2027-01-31',30000,550),('2027-04-30',45000,450)])
add_sched('1008','КД-POCI3','КД-POCI3_1','BYN',[('2026-12-15',100000,1000),('2027-03-31',160000,1000)])
fx=[]
for month in MONTHS:
    d=month+'-'+str(__import__('calendar').monthrange(int(month[:4]),int(month[5:]))[1]).zfill(2)
    n=MONTHS.index(month)
    for c,rate_start,step in [('USD',3.02,.04),('EUR',3.42,.03)]:fx.append({'Дата':d,'Валюта':c,'Курс':round(rate_start+n*step,4),'Источник':'Демонстрационный сценарий'})
vol=[]
for crm,contract,component,ccy,nominal,delta,expiry in [
 ('1001','КД-2026/145','УО','BYN',5000000,450000,''),
 ('1002','КД-77','УО','BYN',250000,20000,''),
 ('3001','ГАР-БАНК-01','Внебаланс','BYN',760000,20000,'2027-01-31')]:
    unp=CLIENTS[crm][0]
    row={'УНП':unp,'Номер договора':contract,'Тип позиции':component,'Валюта':ccy,'Форма объёма':'Номинал','Дата окончания':expiry}
    for i,m in enumerate(MONTHS):
        end=m+'-'+str(__import__('calendar').monthrange(int(m[:4]),int(m[5:]))[1]).zfill(2)
        row[m+'|Объем']=0 if expiry and end>=expiry else max(0,nominal-delta*i)
    vol.append(row)

def build_seed():
    return {'fact_base':base,'fact_current':current,'plan':plan,'forecast_original':forecast_original,'schedules':schedule,'fx_forecast':fx,'volumes':vol,
        'matches':[{'unp':'190123456','planned':'Новый договор №1','actual':'КД-2026/145','confirmed':True,'note':'Учебное подтверждение аналитиком'}],
        'months':MONTHS}

if __name__=='__main__':
    data=build_seed();ROOT.joinpath('demo_seed.json').write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
    print({k:len(v) if isinstance(v,list) else '-' for k,v in data.items()})
