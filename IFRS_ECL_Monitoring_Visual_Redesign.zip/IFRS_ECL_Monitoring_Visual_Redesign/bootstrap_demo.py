"""Import shipped filled Excel examples to local DB and produce audit forecast."""
from pathlib import Path
from store import Repository,ROOT
from engine import build_forecast

def run(storage=None):
    repo=Repository(storage)
    if repo.list_releases():return repo
    files=[
      ('FACT','01_fact_base_2026-10-30.xlsx','Факт — база ноября'),
      ('FACT','02_fact_current_2026-11-05.xlsx','Факт — 05 ноября'),
      ('PLAN','03_business_plan_approved.xlsx','Бизнес-план утверждённый'),
      ('FORECAST_BASE','09_forecast_original_approved.xlsx','Исходный прогноз утверждённый'),
      ('SCHEDULE','04_repayment_schedules.xlsx','Графики погашения на 05.11.2026'),
      ('FX','05_forecast_fx.xlsx','Прогнозные курсы'),
      ('VOLUME','06_conservative_volumes.xlsx','Консервативный прогноз объёмов')]
    for typ,name,label in files:
        print('IMPORT',typ,name)
        repo.add(typ,ROOT/'examples'/name,label)
    plan=repo.current_release('PLAN')
    repo.add_match(plan['id'],'190123456','Новый договор №1','КД-2026/145',True,'Пример ручного подтверждения — учебная сделка')
    result=build_forecast(repo.get_kind('FACT'),repo.get_kind('SCHEDULE'),repo.get_kind('FX'),repo.get_kind('VOLUME'),'2026-11','2027-04')
    run_id=repo.save_run(result,'2026-11','2027-04')
    print('Ready. run_id=',run_id,'lines=',len(result['lines']))
    return repo
if __name__=='__main__':run()
