"""Offline browser UI for IFRS/ECL demo; Python stdlib web server + openpyxl import.
Only for localhost, one analyst. No login, HTTPS, multiuser or production security hardening.
"""
from __future__ import annotations
from email.parser import BytesParser
from email.policy import default
from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
from urllib.parse import urlsplit,parse_qs
from pathlib import Path
from tempfile import NamedTemporaryFile
import argparse,json,sys,mimetypes,traceback,csv,io

from store import Repository,ROOT
from engine import actual_summary,validate_fact,build_forecast,compare_to_plan,factor_bridge
from bootstrap_demo import run as bootstrap
STATIC=ROOT/'static';SAMPLE=ROOT/'examples';MAX_BYTES=100*1024*1024


def select_segment(r,segment):
    if segment in ('','all'):return True
    return ((segment=='corp' and r['status'] in ('ю','ип')) or
            (segment=='retail' and r['status']=='ф') or
            (segment=='banks' and r['status']=='б'))


def cjson(x):return json.dumps(x,ensure_ascii=False,default=str,allow_nan=False).encode('utf-8')

class Application:
    def __init__(self,home=None):self.repo=Repository(home)
    def state(self):
        repo=self.repo;baseline,current,binfo,cinfo=repo.fact_pair()
        s=actual_summary(current);sb=actual_summary(baseline)
        plans=repo.get_kind('PLAN');match=[x for x in repo.matches() if x['plan_release']==(repo.current_release('PLAN') or {}).get('id')]
        comparison=compare_to_plan(current,plans,cinfo['report_date'][:7],match) if cinfo and plans else None
        run=repo.run();runs=repo.runs()
        return {'releases':repo.list_releases(),'current_release':cinfo,'baseline_release':binfo,'summary':s,'baseline_summary':sb,
           'delta_el':s['el']-sb['el'],'plan_totals':comparison['totals'] if comparison else {},
           'qa':validate_fact(current),'runs':runs,'latest_run':{k:v for k,v in run.items() if k!='result'} if run else None,
           'latest_run_monthly':run['result']['summary'] if run else [],'matches':repo.matches(),'notes':repo.notes(),
           'sample_files':sorted(p.name for p in SAMPLE.glob('*.xlsx'))}
    def rows(self,segment='all',search='',page=1,size=50):
        r=self.repo.get_kind('FACT');search=search.casefold();filtered=[x for x in r if select_segment(x,segment) and
           (search in (x['client']+' '+x['crm']+' '+x['contract']+' '+x['unp']).casefold())]
        page=max(1,int(page));size=max(1,min(200,int(size)))
        return {'total':len(filtered),'page':page,'size':size,'rows':filtered[(page-1)*size:page*size]}
    def forecast(self,run_id=None,month=None,search='',page=1,size=60):
        run=self.repo.run(int(run_id) if run_id else None)
        if not run:return {'run':None,'rows':[],'summary':[],'warnings':[],'total':0}
        rr=run['result'];lines=rr['lines'];search=search.casefold()
        indices=[i for i,x in enumerate(lines) if (not month or x['month']==month) and
              search in (x['crm']+x['client']+x['contract']+x['tranche']+x['currency']).casefold()]
        page=max(1,int(page));size=max(1,min(200,int(size)))
        out=[]
        for i in indices[(page-1)*size:page*size]:
            z=dict(lines[i]);z['trace_count']=len(z.pop('trace',[]));z['index']=i;out.append(z)
        return {'run':{k:v for k,v in run.items() if k!='result'},'rows':out,'summary':rr['summary'],
                'warnings':rr['warnings'][:120],'total':len(indices),'months':rr['months'],'page':page,'size':size}
    def trace(self,run_id,index):
        run=self.repo.run(int(run_id))
        if not run:raise ValueError('Расчёт не найден')
        lines=run['result']['lines'];idx=int(index)
        if idx<0 or idx>=len(lines):raise ValueError('Позиция не найдена')
        return lines[idx]
    def comparison(self,mode='fact',month=None,segment='all'):
        repo=self.repo;plan=repo.get_kind('PLAN')
        prid=(repo.current_release('PLAN') or {}).get('id')
        matches=[x for x in repo.matches() if x['plan_release']==prid]
        if mode=='fact':
            cur=repo.get_kind('FACT');month=month or ((repo.current_release('FACT') or {}).get('report_date','')[:7])
            return {**compare_to_plan([r for r in cur if select_segment(r,segment)],plan,month,matches,segment=segment),
                   'mode':'fact','note':'Факт на рабочую дату против утверждённого месячного БП: предварительное сравнение'}
        run=repo.run()
        if not run:raise ValueError('Сначала построй прогноз')
        month=month or run['begin_month'];lines=run['result']['lines']
        if mode=='forecast_base':
            ref=repo.get_kind('FORECAST_BASE')
            if not ref:raise ValueError('Не загружен исходный прогноз')
            return {**compare_to_plan([r for r in lines if r['month']==month],ref,month,matches,forecast=True,segment='corp'),
                'mode':'forecast_base','note':'Расчётный прогноз EL − неизменяемый исходный прогноз (сравнение только на общих месяцах)'}
        if mode=='forecast_fact':
            current=repo.get_kind('FACT')
            factmonth=(repo.current_release('FACT') or {}).get('report_date','')[:7]
            if month!=factmonth:raise ValueError('Прогноз с фактом сравнивается только в текущем месяце факта: '+factmonth)
            from engine import component_rows
            pseudo=[]
            for c in component_rows([r for r in current if r['status'] in ('ю','ип')]):
                pseudo.append({'CRM ID':c['crm'],'УНП':c['unp'],'Клиент':c['client'],'Номер договора':c['contract'],
                  'Тип позиции':c['component'],'Валюта':c['currency'],'Статус клиента':'ю',month+'|EAD':c['ead'],month+'|EL':c['el']})
            return {**compare_to_plan([r for r in lines if r['month']==month],pseudo,month,[],forecast=True,segment='corp'),
                    'mode':'forecast_fact','note':'Прогноз на конец месяца минус ежедневный факт: сравниваются разные даты; предварительная оценка движения до конца месяца'}
        return {**compare_to_plan([r for r in lines if r['month']==month],plan,month,matches,forecast=True,segment=segment),
                   'mode':'forecast','note':'Прогноз EL на конец выбранного месяца против утверждённого месячного БП'}
    def factors(self,segment='corp'):
        base,cur,b,c=self.repo.fact_pair()
        if not base or not cur:return {'factors':[],'detail':[],'delta_el':0,'reconciliation':0}
        base=[r for r in base if select_segment(r,segment)];cur=[r for r in cur if select_segment(r,segment)]
        result=factor_bridge(base,cur,self.repo.get_kind('SCHEDULE'),self.repo.get_kind('FX'),self.repo.get_kind('VOLUME'))
        notes=self.repo.notes();latest={}
        for note in notes:
            key=(note['crm'],note['contract'])
            if key not in latest:latest[key]=note['note']
        for r in result['detail']:
            fs=sorted(r['factors'].items(),key=lambda x:abs(x[1]),reverse=True)
            parts=[f'{name}: {val:+,.2f} BYN' for name,val in fs if abs(val)>0.005][:3]
            r['auto_comment']='; '.join(r['events']+parts) or 'Без существенных изменений'
            r['analyst_comment']=latest.get((r['crm'],r['contract']),'')
        result.update({'segment':segment,'baseline_date':b['report_date'] if b else None,'current_date':c['report_date'] if c else None})
        return result

class Handler(BaseHTTPRequestHandler):
    protocol_version='HTTP/1.0';server_version='IFRS-ECL-Demo/2.0'
    @property
    def api(self):return self.server.api
    def log_message(self,fmt,*args):print('[LOCAL] '+str(self.command)+' '+urlsplit(self.path).path+' '+(str(args[1]) if len(args)>1 else ''),file=sys.stderr)
    def reply(self,obj,status=200,ctype='application/json; charset=utf-8',extra=None):
        raw=cjson(obj) if not isinstance(obj,(bytes,bytearray)) else obj
        self.send_response(status);self.send_header('Content-Type',ctype)
        self.send_header('X-Content-Type-Options','nosniff');self.send_header('Cache-Control','no-store')
        self.send_header('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; object-src 'none'; frame-ancestors 'none'")
        for k,v in (extra or {}).items():self.send_header(k,v)
        self.send_header('Content-Length',str(len(raw)));self.end_headers();self.wfile.write(raw)
    def fail(self,error):
        print('Error: '+str(error)[:500],file=sys.stderr)
        self.reply({'error':str(error)},status=400)
    def qp(self):return {k:v[0] for k,v in parse_qs(urlsplit(self.path).query).items()}
    def _read(self):
        length=int(self.headers.get('Content-Length','0'))
        if length<=0 or length>MAX_BYTES:raise ValueError('Некорректный размер запроса (макс. 100 МБ)')
        raw=self.rfile.read(length)
        if len(raw)!=length:raise ValueError('Неполные данные запроса')
        return raw
    def _origin(self):
        if self.headers.get('X-IFRS-App')!='browser':raise ValueError('Отсутствует заголовок приложения')
        origin=self.headers.get('Origin','');host=self.headers.get('Host','')
        if origin and origin not in ('http://'+host,'https://'+host):raise ValueError('Неверный Origin')
    def json_body(self):return json.loads(self._read().decode('utf-8'))
    def do_GET(self):
        try:
            path=urlsplit(self.path).path;q=self.qp()
            if path in ('/','/index.html'):
                return self.reply((STATIC/'index.html').read_bytes(),ctype='text/html; charset=utf-8')
            if path in ('/static/app.js','/static/style.css'):
                f=STATIC/path.split('/')[-1];return self.reply(f.read_bytes(),ctype=mimetypes.guess_type(str(f))[0]+'; charset=utf-8')
            if path=='/api/health':return self.reply({'ok':True,'name':'МСФО ECL — демонстрационная система'})
            if path=='/api/state':return self.reply(self.api.state())
            if path=='/api/fact':return self.reply(self.api.rows(q.get('segment','all'),q.get('q',''),q.get('page',1),q.get('size',50)))
            if path=='/api/forecast':return self.reply(self.api.forecast(q.get('run'),q.get('month'),q.get('q',''),q.get('page',1),q.get('size',60)))
            if path=='/api/trace':return self.reply(self.api.trace(q.get('run',''),q.get('index','')))
            if path=='/api/compare':return self.reply(self.api.comparison(q.get('mode','fact'),q.get('month'),q.get('segment','all')))
            if path=='/api/factors':return self.reply(self.api.factors(q.get('segment','corp')))
            if path=='/api/example':
                name=q.get('name','')
                if not name or Path(name).name!=name or not name.endswith('.xlsx'):raise ValueError('Неверное имя файла')
                file=SAMPLE/name
                if not file.is_file():raise ValueError('Файл не найден')
                return self.reply(file.read_bytes(),ctype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                                  extra={'Content-Disposition':"attachment; filename*=UTF-8''"+__import__('urllib.parse',fromlist=['quote']).quote(name)})
            if path=='/api/export':
                what=q.get('type','fact')
                if what=='fact':data=[{k:v for k,v in r.items() if k not in ('reserve_parts','risk_signals')} for r in self.api.repo.get_kind('FACT') if select_segment(r,q.get('segment','all'))]
                elif what=='forecast':
                    run=self.api.repo.run();data=[{k:v for k,v in r.items() if k not in ('components','warnings','trace')} for r in (run['result']['lines'] if run else []) if not q.get('month') or r['month']==q.get('month')]
                elif what=='factors':
                    data=self.api.factors(q.get('segment','corp'))['detail'];data=[{**{k:v for k,v in r.items() if k not in ('factors','events')},**r['factors']} for r in data]
                else:data=self.api.comparison(q.get('mode','fact'),q.get('month'))['lines']
                if not data:raise ValueError('Нет строк для экспорта')
                buf=io.StringIO();cols=list(dict.fromkeys(k for d in data for k in d))
                wr=csv.DictWriter(buf,fieldnames=cols,delimiter=';',extrasaction='ignore');wr.writeheader();wr.writerows(data)
                return self.reply(b'\xef\xbb\xbf'+buf.getvalue().encode('utf-8'),ctype='text/csv; charset=utf-8',
                                   extra={'Content-Disposition':'attachment; filename=ifrs_'+what+'.csv'})
            return self.reply({'error':'Страница не найдена'},404)
        except Exception as e:self.fail(e)
    def do_POST(self):
        temp=None
        try:
            self._origin();path=urlsplit(self.path).path
            if path=='/api/upload':
                content_type=self.headers.get('Content-Type','')
                if not content_type.startswith('multipart/form-data;'):raise ValueError('Ожидается форма загрузки Excel')
                raw=self._read();msg=BytesParser(policy=default).parsebytes(('Content-Type: '+content_type+'\r\nMIME-Version: 1.0\r\n\r\n').encode()+raw)
                fields={};filename=None;content=None
                for part in msg.iter_parts():
                    key=part.get_param('name',header='content-disposition')
                    if key=='file':filename=part.get_filename();content=part.get_payload(decode=True)
                    else:fields[key]=(part.get_payload(decode=True) or b'').decode('utf-8')
                if not filename or content is None:raise ValueError('Не указан Excel-файл')
                suffix=Path(filename).suffix.lower()
                if suffix not in ('.xlsx','.xlsm'):raise ValueError('Только .xlsx/.xlsm')
                with NamedTemporaryFile(dir=self.api.repo.home,suffix=suffix,delete=False) as f:
                    temp=Path(f.name);f.write(content)
                out=self.api.repo.add(fields.get('kind',''),temp,fields.get('label','') or Path(filename).stem)
                self.reply({'ok':True,'release':out,'message':'Источник загружен и сохранён'})
                return
            payload=self.json_body()
            if path=='/api/run':
                b=str(payload.get('begin',''));e=str(payload.get('end',''))
                actual=self.api.repo.get_kind('FACT')
                if not actual:raise ValueError('Сначала загрузите факт')
                res=build_forecast(actual,self.api.repo.get_kind('SCHEDULE'),self.api.repo.get_kind('FX'),self.api.repo.get_kind('VOLUME'),b,e)
                run_id=self.api.repo.save_run(res,b,e)
                return self.reply({'ok':True,'run_id':run_id,'summary':res['summary'],'warnings':len(res['warnings'])})
            if path=='/api/match':
                prid=(self.api.repo.current_release('PLAN') or {}).get('id')
                if not prid:raise ValueError('Нет загруженного БП')
                self.api.repo.add_match(prid,str(payload.get('unp','')),str(payload.get('planned','')),str(payload.get('actual','')),True,str(payload.get('note','')))
                return self.reply({'ok':True})
            if path=='/api/baseline':
                self.api.repo.set_baseline(int(payload['id']));return self.reply({'ok':True,'message':'База изменена, существующие расчёты не переписаны'})
            if path=='/api/note':
                self.api.repo.note(str(payload['crm']),str(payload['contract']),str(payload.get('note','')))
                return self.reply({'ok':True})
            self.reply({'error':'Маршрут не найден'},404)
        except Exception as e:self.fail(e)
        finally:
            if temp and temp.exists():temp.unlink()

def main():
    ap=argparse.ArgumentParser(description='Local IFRS ECL demo browser app')
    ap.add_argument('--port',type=int,default=8501);ap.add_argument('--storage',type=Path,default=ROOT/'storage')
    ap.add_argument('--no-demo',action='store_true');args=ap.parse_args()
    if not args.no_demo:bootstrap(args.storage)
    app=Application(args.storage)
    try:
        s=ThreadingHTTPServer(('127.0.0.1',args.port),Handler);s.api=app
    except OSError as e:
        print('Не удалось открыть 127.0.0.1:%s: %s. В банке может требоваться разрешение ИТ/ИБ на локальный порт.'%(args.port,e))
        raise SystemExit(2)
    print('Система МСФО запущена: http://127.0.0.1:%d/'%args.port,flush=True)
    try:s.serve_forever()
    except KeyboardInterrupt:pass
    finally:s.server_close()
if __name__=='__main__':main()
