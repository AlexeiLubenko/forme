"""SQLite persistence. Local single-analyst prototype; preserve original uploads."""
from __future__ import annotations
from datetime import datetime
from pathlib import Path
from hashlib import sha256
from contextlib import contextmanager
import json,sqlite3,shutil
from engine import fact_from_sheet,validate_fact,dt,clean_id

ROOT=Path(__file__).resolve().parent
REQUIRED={
'FACT':{'1','2','3','4','24','26','30','31','42','45','48','49','50','51','54','55','63','71','73','87','89'},
'PLAN':{'CRM ID','УНП','Номер договора','Тип позиции','Валюта'},
'FORECAST_BASE':{'CRM ID','УНП','Номер договора','Тип позиции','Валюта'},
'SCHEDULE':{'УНП','Номер договора','Номер транша','Валюта','Дата платежа','Срочный ОД','Срочные проценты','Просроченный ОД','Просроченные проценты'},
'FX':{'Дата','Валюта','Курс'},
'VOLUME':{'УНП','Номер договора','Тип позиции','Валюта','Форма объёма'},
}

class Repository:
    def __init__(self,home=None):
        self.home=Path(home or ROOT/'storage').resolve();self.home.mkdir(parents=True,exist_ok=True)
        self.orig=self.home/'originals';self.orig.mkdir(exist_ok=True)
        self.path=self.home/'ifrs_demo.sqlite'
        with self.connect() as db:
            db.executescript('''
              CREATE TABLE IF NOT EXISTS releases(id INTEGER PRIMARY KEY,kind TEXT NOT NULL,label TEXT NOT NULL,
                 report_date TEXT,original_name TEXT,original_path TEXT,sha TEXT,created_at TEXT,rows_count INTEGER,qa_json TEXT);
              CREATE INDEX IF NOT EXISTS ix_releases_kind ON releases(kind,report_date,id);
              CREATE TABLE IF NOT EXISTS source_rows(release_id INTEGER,rownum INTEGER,data TEXT NOT NULL,
                  PRIMARY KEY(release_id,rownum));
              CREATE TABLE IF NOT EXISTS forecast_runs(id INTEGER PRIMARY KEY,created_at TEXT,begin_month TEXT,end_month TEXT,
                  fact_release INTEGER,schedule_release INTEGER,fx_release INTEGER,volume_release INTEGER, result_json TEXT);
              CREATE TABLE IF NOT EXISTS matches(id INTEGER PRIMARY KEY,plan_release INTEGER,unp TEXT,planned TEXT,actual TEXT,
                  confirmed INTEGER,note TEXT,updated_at TEXT);
              CREATE TABLE IF NOT EXISTS comments(id INTEGER PRIMARY KEY,crm TEXT,contract TEXT,note TEXT,updated_at TEXT);
              CREATE TABLE IF NOT EXISTS settings(name TEXT PRIMARY KEY,value TEXT);
            ''')
    @contextmanager
    def connect(self):
        c=sqlite3.connect(str(self.path),timeout=30)
        c.row_factory=sqlite3.Row
        try:
            yield c
            c.commit()
        except BaseException:
            c.rollback()
            raise
        finally:
            c.close()
    @staticmethod
    def now():return datetime.now().isoformat(timespec='seconds')
    def list_releases(self):
        with self.connect() as c:
            return [dict(r) for r in c.execute('SELECT id,kind,label,report_date,original_name,created_at,rows_count,qa_json FROM releases ORDER BY id DESC')]
    def current_release(self,kind):
        with self.connect() as c:
            order='report_date DESC,id DESC' if kind=='FACT' else 'id DESC'
            row=c.execute('SELECT * FROM releases WHERE kind=? ORDER BY '+order+' LIMIT 1',(kind,)).fetchone()
            return dict(row) if row else None
    def baseline_release(self):
        current=self.current_release('FACT')
        if not current:return None
        with self.connect() as c:
            override=c.execute('SELECT value FROM settings WHERE name="baseline_override"').fetchone()
            if override:
                x=c.execute('SELECT * FROM releases WHERE id=? AND kind="FACT"',(int(override[0]),)).fetchone()
                if x:return dict(x)
            x=c.execute('''SELECT * FROM releases WHERE kind='FACT' AND report_date < ?
                        ORDER BY report_date DESC,id DESC LIMIT 1''',(current['report_date'][:7]+'-01',)).fetchone()
            return dict(x) if x else None
    def set_baseline(self,release_id):
        with self.connect() as c:
            if not c.execute('SELECT 1 FROM releases WHERE id=? AND kind="FACT"',(release_id,)).fetchone():
                raise ValueError('Снимок факта для базы не найден')
            c.execute('INSERT OR REPLACE INTO settings(name,value) VALUES("baseline_override",?)',(str(release_id),))
    def read(self,release_id):
        if not release_id:return []
        with self.connect() as c:return [json.loads(row[0]) for row in c.execute('SELECT data FROM source_rows WHERE release_id=? ORDER BY rownum',(release_id,))]
    def get_kind(self,kind):
        x=self.current_release(kind)
        return self.read(x['id']) if x else []
    def fact_pair(self):
        c=self.current_release('FACT');b=self.baseline_release()
        return self.read(b['id']) if b else [],self.read(c['id']) if c else [],b,c
    def add(self,kind,path,label='',date_override=None):
        """Validate one Excel worksheet, retain original, import rows atomically; no silent row drops."""
        kind=str(kind).upper()
        if kind not in REQUIRED:raise ValueError('Неизвестный тип источника')
        path=Path(path)
        if path.suffix.lower() not in ('.xlsx','.xlsm'):raise ValueError('Нужен Excel .xlsx или .xlsm')
        from openpyxl import load_workbook
        wb=load_workbook(str(path),read_only=True,data_only=True)
        try:
            sheet=wb.worksheets[0];it=sheet.iter_rows(values_only=True)
            header=[str(x).strip() if x is not None else '' for x in next(it)]
            if kind=='FACT':
                actual={h.split('.',1)[0].strip() for h in header if h.split('.',1)[0].strip().isdigit()}
            else:actual=set(header)
            missing=REQUIRED[kind]-actual
            if missing:raise ValueError('В Excel отсутствуют обязательные столбцы: '+', '.join(sorted(missing)))
            if kind=='FACT' and len(header)<105:raise ValueError('Факт должен содержать 105 столбцов')
            if kind in ('PLAN','FORECAST_BASE','VOLUME') and not any('|'+('EL' if kind in ('PLAN','FORECAST_BASE') else 'Объем') in x for x in header):
                raise ValueError('Нет помесячных блоков в заголовке Excel')
            sha=sha256(path.read_bytes()).hexdigest()
            original=self.orig/(sha+'_'+''.join(c for c in path.name if c.isascii() and (c.isalnum() or c in '.-_'))[:80])
            if not original.name.endswith(path.suffix.lower()):original=self.orig/(sha+path.suffix.lower())
            tmp_rows=[];first_date=None;errors=[]
            for i,raw in enumerate(it,2):
                if all(x is None for x in raw):continue
                try:
                    if kind=='FACT':
                        item=fact_from_sheet(raw,header)
                        if first_date is None:first_date=item['date']
                        if item['date']!=first_date:raise ValueError('Разные отчётные даты в одном файле')
                    else:
                        item={h:(v.isoformat() if isinstance(v,(datetime,__import__('datetime').date)) else v) for h,v in zip(header,raw) if h}
                        if kind=='SCHEDULE':
                            if not item.get('УНП') or not item.get('Номер транша') or not item.get('Дата платежа'):
                                raise ValueError('Отсутствует УНП, транш или дата платежа')
                    tmp_rows.append((i,json.dumps(item,ensure_ascii=False,allow_nan=False,default=str)))
                except Exception as ex:
                    if len(errors)<10:errors.append('Строка '+str(i)+': '+str(ex))
            if errors:raise ValueError('Файл не принят: '+ '; '.join(errors))
            if not tmp_rows:raise ValueError('Нет строк данных')
            if date_override and first_date and date_override!=first_date:raise ValueError('Дата файла не совпала с указанной')
            report_date=first_date if kind=='FACT' else None
            qa=validate_fact([json.loads(d) for _,d in tmp_rows]) if kind=='FACT' else []
            if not original.exists():shutil.copyfile(path,original)
            with self.connect() as db:
                cur=db.execute('''INSERT INTO releases(kind,label,report_date,original_name,original_path,sha,created_at,rows_count,qa_json)
                    VALUES(?,?,?,?,?,?,?,?,?)''',(kind,label or path.stem,report_date,path.name,str(Path('originals')/original.name),sha,self.now(),len(tmp_rows),json.dumps(qa,ensure_ascii=False)))
                rid=cur.lastrowid
                db.executemany('INSERT INTO source_rows(release_id,rownum,data) VALUES(?,?,?)',[(rid,ln,v) for ln,v in tmp_rows])
            return {'id':rid,'kind':kind,'label':label or path.stem,'report_date':report_date,'rows_count':len(tmp_rows),'qa_count':len(qa)}
        finally:wb.close()
    def save_run(self,result,begin,end):
        current={k:self.current_release(k) for k in ('FACT','SCHEDULE','FX','VOLUME')}
        with self.connect() as c:
            cur=c.execute('''INSERT INTO forecast_runs(created_at,begin_month,end_month,fact_release,schedule_release,fx_release,volume_release,result_json)
                        VALUES(?,?,?,?,?,?,?,?)''',(self.now(),begin,end,*(current[k]['id'] if current[k] else None for k in ('FACT','SCHEDULE','FX','VOLUME')),
                       json.dumps(result,ensure_ascii=False,allow_nan=False)))
            return cur.lastrowid
    def runs(self):
        with self.connect() as c:return [dict(r) for r in c.execute('''SELECT id,created_at,begin_month,end_month,fact_release,schedule_release,fx_release,volume_release
             FROM forecast_runs ORDER BY id DESC LIMIT 100''')]
    def run(self,run_id=None):
        with self.connect() as c:
            row=(c.execute('SELECT * FROM forecast_runs WHERE id=?',(run_id,)).fetchone() if run_id else
                 c.execute('SELECT * FROM forecast_runs ORDER BY id DESC LIMIT 1').fetchone())
            if not row:return None
            x=dict(row);x['result']=json.loads(x.pop('result_json'));return x
    def matches(self):
        with self.connect() as c:return [dict(x) for x in c.execute('SELECT * FROM matches ORDER BY id DESC')]
    def add_match(self,plan_release,unp,planned,actual,confirmed=True,note=''):
        if not planned or not actual or not unp:raise ValueError('Заполни УНП и оба номера договора')
        with self.connect() as c:
            if any(r['unp']==str(unp) and r['planned']==planned and r['confirmed'] and r['plan_release']==plan_release for r in self.matches()):
                raise ValueError('Эта плановая сделка уже сопоставлена; сначала измените существующее соответствие')
            c.execute('INSERT INTO matches(plan_release,unp,planned,actual,confirmed,note,updated_at) VALUES(?,?,?,?,?,?,?)',
                (plan_release,str(unp),planned,actual,int(confirmed),note,self.now()))
    def note(self,crm,contract,value):
        with self.connect() as c:c.execute('INSERT INTO comments(crm,contract,note,updated_at) VALUES(?,?,?,?)',(crm,contract,value[:2000],self.now()))
    def notes(self):
        with self.connect() as c:return [dict(r) for r in c.execute('SELECT * FROM comments ORDER BY id DESC LIMIT 200')]
