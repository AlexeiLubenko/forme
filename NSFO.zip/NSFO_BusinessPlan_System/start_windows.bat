@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo ==============================================
echo   АС НСФО — модуль бизнес-плана
 echo ==============================================
python -c "import openpyxl" >nul 2>&1
if errorlevel 1 (
  echo Не найден модуль openpyxl. Установка в банковском контуре выполняется через ИТ.
  pause
  exit /b 1
)
echo Локальный адрес: http://127.0.0.1:8502
start "" "http://127.0.0.1:8502"
python server.py
if errorlevel 1 (
  echo Не удалось запустить веб-сервис. Проверьте Python и разрешение на localhost.
  pause
)
