import sys,sqlite3,http.server
print('Python',sys.version)
try:
 import openpyxl
 print('openpyxl',openpyxl.__version__)
except ImportError:print('ERROR: openpyxl not installed')
print('SQLite',sqlite3.sqlite_version)
print('Приложение привязано к http://127.0.0.1:8502')
