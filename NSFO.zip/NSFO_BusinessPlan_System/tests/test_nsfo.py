import unittest,sys,tempfile,os,shutil,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from risk import Criteria,classify,quality_breakdown,compute_factors,MethodologyError
import engine

class RiskRules(unittest.TestCase):
 def c(self,**kw):return Criteria(**{'security':'Обеспеченный',**kw})
 def test_pfn_secured_active_uo(self):
  for op in ('Кредит','УО'):
   self.assertEqual(classify(self.c(pfn=1,operation=op))[:2],(3,20.))
 def test_pfn_unsecured_by_side(self):
  self.assertEqual(classify(self.c(pfn=1,security='Необеспеченный'))[:2],(4,30.))
  self.assertEqual(classify(self.c(pfn=1,security='Необеспеченный',operation='УО'))[:2],(3,20.))
 def test_ni_over_nvv(self):
  self.assertEqual(classify(self.c(ni=1,nvv=1,currency='USD'))[:2],(2,5.))
 def test_nvv_ignored_by_currency_and_uo(self):
  self.assertEqual(classify(self.c(nvv=1,currency='BYN'))[:2],(1,.5))
  self.assertEqual(classify(self.c(nvv=1,currency='USD',operation='УО'))[:2],(1,.5))
 def test_cb_table(self):
  for ni,pfn,sec,expected in [(0,0,'Обеспеченный',(1,.5)),(0,0,'Недостаточно обеспеченный',(1,2.)),(1,0,'Недостаточно обеспеченный',(2,5.)),(1,0,'Необеспеченный',(2,20.)),(0,1,'Обеспеченный',(3,20.)),(0,1,'Необеспеченный',(3,30.)),(1,1,'Необеспеченный',(3,30.))]:
   with self.subTest(ni=ni,pfn=pfn,sec=sec):self.assertEqual(classify(self.c(ni=ni,pfn=pfn,security=sec,operation='ЦБ для продажи'))[:2],expected)
 def test_micro(self):
  self.assertEqual(classify(self.c(micro=True,security='Обеспеченный (не указан)'))[:2],(1,.5))
  self.assertEqual(classify(self.c(micro=True,pfn=1,security='Обеспеченный (не указан)'))[:2],(2,5.))
  self.assertEqual(classify(self.c(micro=True,restra='рестр. 5ГР 50%'))[:2],(5,50.))
 def test_uw_no_restra(self):
  self.assertEqual(classify(self.c(operation='УО',restra='рестр. 6ГР 100%'))[:2],(1,.5))
 def test_pok(self):
  self.assertEqual(classify(self.c(poc=True,poc_rate=7.))[:2],('ПОК',7.))
  self.assertEqual(classify(self.c(poc=True,operation='УО'))[:2],(1,.5))
 def test_bad_sec(self):
  with self.assertRaises(MethodologyError):classify(self.c(security='Обеспеченный (не указан)'))
 def test_two_factor_average(self):
  a=self.c(pfn=0,security='Обеспеченный');b=self.c(pfn=1,security='Необеспеченный')
  out,events=quality_breakdown(a,b,1000000,.5,30.)
  self.assertEqual(out['pfn_in'],-222500.)
  self.assertEqual(out['security'],-72500.)
  self.assertEqual(round(sum(out.values()),2),-295000.)
 def test_ni_removed_when_pfn_new(self):
  a=self.c(ni=1);b=self.c(pfn=1,ni=0)
  out,events=quality_breakdown(a,b,1000000,5.,20.)
  self.assertEqual(out['ni_out'],0)
  self.assertEqual(out['pfn_in'],-150000.)
  self.assertIn('ni',events)
 def test_fx_formula(self):
  a=self.c(currency='USD');b=self.c(currency='USD')
  prev={'debt':10,'fx':3,'od':30,'rate':5.,'reserve':1.5,'criteria':a.as_dict()}
  now={'debt':15,'fx':3.2,'od':48,'rate':5.,'reserve':2.4,'criteria':b.as_dict()}
  fx=compute_factors(prev,now)
  self.assertEqual(fx['fx'],-.1)
  self.assertEqual(fx['movement'],-.8)
  self.assertEqual(fx['quality'],0)
  self.assertAlmostEqual(fx['expenses'],-.9)

class ProjectWorkflow(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  engine.initialize()
  cls.pid=engine.create_project('Автотест НСФО')
  for kind,f in [('bp','01_Входной_БП_пример.xlsx'),('fact','02_Выверенный_факт_пример.xlsx'),('rates','03_Курсы_пример.xlsx')]:
   fd,p=tempfile.mkstemp(suffix='.xlsx');os.close(fd);shutil.copyfile(ROOT/'examples'/f,p)
   engine.upload_path(cls.pid,kind,p,f)
  cls.result=engine.build(cls.pid)
 def test_build(self):
  self.assertEqual(self.result['positions'],8)
  self.assertEqual(self.result['missing'],2)
  self.assertEqual(self.result['errors'],0)
  self.assertEqual(len(self.result['dates']),8)
 def test_missing_state(self):
  self.assertEqual(engine.list_missing(self.pid,'waiting')['total'],1)
  self.assertEqual(engine.list_missing(self.pid,'auto')['total'],1)
 def test_reserve_from_rate(self):
  rows=engine.list_positions(self.pid,'2026-10-01',limit=100)['rows']
  for r in rows:self.assertAlmostEqual(r['reserve'],round(r['od']*r['rate']/100,2),places=2)
 def test_bridge(self):
  t=engine.get_state(self.pid)['totals']
  for x in t[1:]:self.assertAlmostEqual(x['expenses'],x['movement']+x['quality']+x['revaluation']+x['rounding'],places=2)
 def test_auto_add_only_black(self):
  auto=engine.list_missing(self.pid,'auto')['rows'][0]
  self.assertTrue('черн' in auto['zone'].lower())
  waiting=engine.list_missing(self.pid,'waiting')['rows'][0]
  self.assertNotIn('черн',waiting['zone'].lower())
 def test_add_and_undo(self):
  waiting=engine.list_missing(self.pid,'waiting')['rows'][0]
  old=engine.list_positions(self.pid,'2026-10-01')['total']
  self.assertEqual(engine.add_waiting(self.pid,[waiting['match_key']]),1)
  self.assertEqual(engine.list_positions(self.pid,'2026-10-01')['total'],old+1)
  self.assertEqual(engine.undo_waiting(self.pid,[waiting['match_key']]),1)
  self.assertEqual(engine.list_positions(self.pid,'2026-10-01')['total'],old)
 def test_clientwide_flag_future_only(self):
  p=next(x for x in engine.list_positions(self.pid,'2026-10-01',limit=100)['rows'] if x['unp']=='1001' and x['side']=='баланс')
  engine.edit(self.pid,p['id'],'2026-11-01','pfn',1)
  base=[x for x in engine.list_positions(self.pid,'2026-10-01',limit=100)['rows'] if x['unp']=='1001']
  november=[x for x in engine.list_positions(self.pid,'2026-11-01',limit=100)['rows'] if x['unp']=='1001']
  december=[x for x in engine.list_positions(self.pid,'2026-12-01',limit=100)['rows'] if x['unp']=='1001']
  self.assertTrue(all(x['pfn']==0 for x in base))
  self.assertTrue(all(x['pfn']==1 for x in november+december))
  engine.edit(self.pid,p['id'],'2026-11-01','pfn',0)
 def test_two_factor_integrated(self):
  base=next(x for x in engine.list_positions(self.pid,'2026-10-01',limit=100)['rows'] if x['unp']=='1001' and x['side']=='баланс')
  engine.edit(self.pid,base['id'],'2026-11-01','pfn',1)
  engine.edit(self.pid,base['id'],'2026-11-01','security','Необеспеченный')
  curr=next(x for x in engine.list_positions(self.pid,'2026-11-01',limit=100)['rows'] if x['id']==base['id'])
  factors=json.loads(curr['factors'])
  self.assertAlmostEqual(factors['pfn_in'],-curr['od']*.2225,delta=.02)
  self.assertAlmostEqual(factors['security'],-curr['od']*.0725,delta=.02)
  self.assertAlmostEqual(factors['pfn_in']+factors['security'],curr['quality'],delta=.02)
  engine.edit(self.pid,base['id'],'2026-11-01','security','Обеспеченный')
  engine.edit(self.pid,base['id'],'2026-11-01','pfn',0)
 def test_debt_only_one_date(self):
  p=next(x for x in engine.list_positions(self.pid,'2026-10-01',limit=100)['rows'] if x['unp']=='1001' and x['side']=='баланс')
  old=next(x for x in engine.list_positions(self.pid,'2026-12-01',limit=100)['rows'] if x['id']==p['id'])
  engine.edit(self.pid,p['id'],'2026-11-01','debt',1123456)
  new=next(x for x in engine.list_positions(self.pid,'2026-12-01',limit=100)['rows'] if x['id']==p['id'])
  self.assertEqual(old['debt'],new['debt'])
 def test_override_reason(self):
  p=next(x for x in engine.list_positions(self.pid,'2026-10-01',limit=100)['rows'] if x['unp']=='1001' and x['side']=='баланс')
  with self.assertRaises(MethodologyError):engine.edit(self.pid,p['id'],'2026-11-01','rate',5,'')
 def test_export(self):
  from exports import build_excel
  b=build_excel(self.pid)
  self.assertGreater(len(b.getvalue()),10000)
  import zipfile,io
  with zipfile.ZipFile(io.BytesIO(b.getvalue())) as z:
   xml=z.read('xl/workbook.xml')
   self.assertIn('Прогноз НСФО'.encode('utf-8'),xml)
 def test_horizon(self):
  data=engine.period_debt_horizon(self.pid,'debt')
  self.assertEqual(len(data['periods']),8)
  self.assertGreaterEqual(len(data['rows']),8)

if __name__=='__main__':unittest.main(verbosity=2)
