"""Local HTTP server for NSFO business-plan forecasting. No third-party web framework."""
from __future__ import annotations
import json, os, tempfile, threading, urllib.parse, traceback
from pathlib import Path
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
import engine
from exports import build_excel, build_pdf, build_printable_html

ROOT=Path(__file__).resolve().parent
STATIC=ROOT/'static'
BIND=os.getenv('NSFO_HOST','127.0.0.1')
PORT=int(os.getenv('NSFO_PORT','8502'))
MAX_UPLOAD=int(os.getenv('NSFO_MAX_UPLOAD_MB','768'))*1024*1024
LOCK=threading.RLock()
JOBS={}
MIME={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.svg':'image/svg+xml','.png':'image/png'}

class Handler(BaseHTTPRequestHandler):
    server_version='NSFO-Local/1.0'
    def log_message(self,fmt,*args):
        print('%s %s'%(self.address_string(),fmt%args),flush=True)
    def reply(self,obj,status=200):
        b=json.dumps(obj,ensure_ascii=False,default=str).encode('utf-8')
        self.send_response(status);self.send_header('Content-Type','application/json; charset=utf-8');self.send_header('Content-Length',str(len(b)))
        self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff');self.end_headers();self.wfile.write(b)
    def fail(self,exc):
        self.reply({'error':str(exc)},400)
    def json_body(self):
        n=int(self.headers.get('Content-Length','0'))
        if n<0 or n>500000:raise ValueError('Недопустимый размер JSON')
        return json.loads(self.rfile.read(n) or b'{}')
    def parsed(self):
        u=urllib.parse.urlparse(self.path);return u.path,urllib.parse.parse_qs(u.query)
    def get_pid(self,path):
        parts=path.strip('/').split('/')
        if len(parts)<3 or parts[:2]!=['api','projects']:raise ValueError('Некорректный адрес проекта')
        return int(parts[2]),parts[3:] if len(parts)>3 else []
    def do_GET(self):
        try:
            path,query=self.parsed();q=lambda k,default='':query.get(k,[default])[0]
            if path=='/api/projects':return self.reply({'projects':engine.list_projects()})
            if path.startswith('/api/projects/'):
                pid,tail=self.get_pid(path);route='/'.join(tail)
                if route=='state':return self.reply(engine.get_state(pid))
                if route=='job':return self.reply(JOBS.get(pid,{'status':'idle'}))
                if route=='positions':return self.reply(engine.list_positions(pid,q('period'),q('search'),q('page',1),q('limit',50),q('side'),q('zone'),q('gr')))
                if route=='horizon':return self.reply(engine.period_debt_horizon(pid,q('metric','debt'),q('search'),int(q('limit',40)),int(q('page',1))))
                if route=='missing':return self.reply(engine.list_missing(pid,q('status','waiting'),q('page',1),q('limit',100)))
                if route=='warnings':return self.reply(engine.list_warnings(pid,q('kind'),q('page',1),q('limit',100)))
                if route=='factors':return self.reply(engine.factor_summary(pid,q('period'),q('search'),q('zone'),q('side')))
                if route=='clients':return self.reply(engine.client_report(pid,q('period'),q('search'),int(q('limit',200)),int(q('page',1))))
                if route=='versions':return self.reply({'versions':engine.list_versions(pid)})
                if route=='export.xlsx':
                    fd,tmp=tempfile.mkstemp(prefix='nsfo_export_',suffix='.xlsx',dir=str(engine.DATA))
                    os.close(fd)
                    try:
                        build_excel(pid,output_path=tmp)
                        return self.path_response(tmp,'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',f'NSFO_Plan_{pid}.xlsx')
                    finally:
                        if os.path.exists(tmp):os.unlink(tmp)
                if route=='print':
                    content=build_printable_html(pid).encode('utf-8')
                    self.send_response(200)
                    self.send_header('Content-Type','text/html; charset=utf-8')
                    self.send_header('Content-Length',str(len(content)))
                    self.end_headers()
                    return self.wfile.write(content)
                if route=='export.pdf':return self.file_response(build_pdf(pid),'application/pdf',f'NSFO_Report_{pid}.pdf')
                return self.reply({'error':'Неизвестный маршрут'},404)
            if path in ('/','/index.html'):target=STATIC/'index.html'
            else:
                target=(STATIC/path.lstrip('/')).resolve()
                if not target.is_relative_to(STATIC.resolve()):return self.reply({'error':'Запрещённый путь'},403)
            if not target.is_file():return self.reply({'error':'Файл не найден'},404)
            b=target.read_bytes();self.send_response(200);self.send_header('Content-Type',MIME.get(target.suffix,'application/octet-stream'))
            self.send_header('Content-Length',str(len(b)));self.end_headers();self.wfile.write(b)
        except (OSError,ValueError,KeyError,engine.MethodologyError) as e:self.fail(e)
        except Exception as e:
            traceback.print_exc();self.reply({'error':'Внутренняя ошибка: '+str(e)},500)
    def path_response(self,path,content_type,name):
        self.send_response(200)
        self.send_header('Content-Type',content_type)
        self.send_header('Content-Disposition',f'attachment; filename="{name}"')
        self.send_header('Content-Length',str(os.path.getsize(path)))
        self.end_headers()
        with open(path,'rb') as src:
            while True:
                chunk=src.read(128*1024)
                if not chunk:break
                self.wfile.write(chunk)
    def file_response(self,buf,content_type,name):
        self.send_response(200);self.send_header('Content-Type',content_type)
        self.send_header('Content-Disposition',f'attachment; filename="{name}"')
        self.send_header('Content-Length',str(len(buf.getbuffer())));self.end_headers()
        while True:
            b=buf.read(65536)
            if not b:break
            self.wfile.write(b)
    def do_POST(self):
        try:
            path,q=self.parsed()
            if path=='/api/projects':
                v=self.json_body();pid=engine.create_project(v.get('name','Бизнес-план НСФО'));return self.reply({'id':pid})
            pid,tail=self.get_pid(path);route='/'.join(tail)
            if route=='upload':
                kind=q.get('kind',[''])[0]
                if kind not in ('bp','fact','rates'):raise ValueError('Недопустимый тип файла')
                name=urllib.parse.unquote(self.headers.get('X-Filename',kind+'.xlsx'))
                if not name.lower().endswith('.xlsx'):raise ValueError('Поддерживаются только файлы .xlsx')
                length=int(self.headers.get('Content-Length','0'))
                if not 0<length<=MAX_UPLOAD:raise ValueError(f'Размер файла должен быть от 1 байта до {MAX_UPLOAD//1048576} МБ')
                with LOCK:
                    fd,tmp=tempfile.mkstemp(prefix='nsfo_',suffix='.xlsx',dir=str(engine.DATA))
                    try:
                        with os.fdopen(fd,'wb') as out:
                            remaining=length
                            while remaining>0:
                                data=self.rfile.read(min(128*1024,remaining))
                                if not data:raise IOError('Загрузка прервана')
                                out.write(data);remaining-=len(data)
                        with open(tmp,'rb') as check:
                            if check.read(2)!=b'PK':raise ValueError('Файл не является XLSX-архивом')
                        return self.reply(engine.upload_path(pid,kind,tmp,name))
                    finally:
                        if os.path.exists(tmp):os.remove(tmp)
            if route=='fact-date':
                v=self.json_body()
                with LOCK:date=engine.confirm_fact_date(pid,v.get('date'))
                return self.reply({'date':date})
            if route=='build':
                # An application-side job, not a background assistant promise.
                if JOBS.get(pid,{}).get('status')=='running':raise ValueError('Расчёт уже выполняется')
                JOBS[pid]={'status':'running','stage':'Сверка и расчёт','started':engine.now()}
                def work():
                    try:
                        with LOCK:result=engine.build(pid)
                        JOBS[pid]={'status':'done','result':result,'finished':engine.now()}
                    except Exception as e:
                        traceback.print_exc()
                        JOBS[pid]={'status':'error','error':str(e),'finished':engine.now()}
                threading.Thread(target=work,daemon=True).start()
                return self.reply({'started':True})
            if route=='missing/add':
                with LOCK:n=engine.add_waiting(pid,self.json_body().get('keys',[]))
                return self.reply({'added':n})
            if route=='missing/undo':
                with LOCK:n=engine.undo_waiting(pid,self.json_body().get('keys',[]))
                return self.reply({'undone':n})
            if route=='edit':
                v=self.json_body()
                with LOCK:result=engine.edit(pid,int(v['position_id']),v['period'],v['field'],v.get('value'),v.get('reason',''))
                return self.reply(result)
            if route=='comment':
                v=self.json_body()
                with LOCK:n=engine.set_comment(pid,v['unp'],v.get('comment',''))
                return self.reply({'updated':n})
            if route=='save-version':
                with LOCK:v=engine.save_version(pid,self.json_body().get('title','Зафиксированная версия'))
                v.pop('path',None);return self.reply(v)
            return self.reply({'error':'Неизвестный маршрут'},404)
        except (OSError,ValueError,KeyError,engine.MethodologyError) as e:self.fail(e)
        except Exception as e:
            traceback.print_exc();self.reply({'error':'Внутренняя ошибка: '+str(e)},500)


def main():
    engine.initialize()
    server=ThreadingHTTPServer((BIND,PORT),Handler)
    print(f'АС НСФО: http://{BIND}:{PORT}/',flush=True)
    try:server.serve_forever(poll_interval=.5)
    except KeyboardInterrupt:pass
    finally:server.server_close()

if __name__=='__main__':main()
