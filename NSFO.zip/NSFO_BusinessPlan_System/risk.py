"""Methodology-approved NSFO risk classification and signed reserve factor analysis.

Amounts: debt in original currency units, OD/reserves/factors in BYN units;
percent rates: 0.5 means 0.5%, never 0.005.
"""
from __future__ import annotations
from dataclasses import dataclass, replace
import re
from itertools import permutations

class MethodologyError(ValueError):
    pass

SECURITY = {
    'высококачественное обеспечение': 'high',
    'высокообеспеченный': 'high',
    'обеспеченный': 'secured',
    'недостаточно обеспеченный': 'insufficient',
    'необеспеченный': 'unsecured',
    'обеспеченный (не указан)': 'micro_unknown',
}
RATE_BY_GR = {1: .5, 2: 5., 3: 20., 4: 30., 5: 50., 6: 100.}
FACTOR_NAMES = {
    'ni_in': 'Признание НИ', 'ni_out': 'Снятие НИ',
    'pfn_in': 'Признание ПФН', 'pfn_out': 'Снятие ПФН',
    'nvv_in': 'Признание НВВ', 'nvv_out': 'Снятие НВВ',
    'restruct': 'Изменение реструктуризации', 'security': 'Изменение обеспеченности',
    'override': 'Ручное изменение ставки',
}


def flag(value):
    if value is None or str(value).strip() == '': return 0
    if str(value).strip().lower() in ('нет','false','no','0','0.0'): return 0
    if str(value).strip().lower() in ('да','true','yes','1','1.0'): return 1
    raise MethodologyError(f'Неопределённое значение признака: {value!r}; допустимо 0, 1, пусто')


def rate_percent(value):
    if value is None or str(value).strip() == '': return None
    try: result=float(str(value).replace('%','').replace(',','.').strip())
    except (ValueError, TypeError): raise MethodologyError('Некорректный процент резервирования: '+str(value))
    if 0 < result < .5: result *= 100  # 0.005 => 0.5%; 0.02 => 2%
    if not .5 <= result <= 100: raise MethodologyError(f'Ставка {result:g}% вне допустимого диапазона 0,5–100%')
    return round(result, 8)


def gr_value(v):
    if v is None or str(v).strip()=='': return None
    s=str(v).strip().upper()
    if 'ПОК' in s: return 'ПОК'
    m=re.search(r'\d+',s)
    return int(m.group()) if m else None


def normal_security(value, micro=False):
    t=' '.join(str(value or '').strip().lower().replace('ё','е').split())
    aliases={'высококачественный':'high','высокообеспеченный':'high','высококачественное обеспечение':'high','обеспеченный':'secured','недостаточно обеспеченный':'insufficient','необеспеченный':'unsecured','обеспеченный (не указан)':'micro_unknown'}
    result=aliases.get(t)
    if result == 'micro_unknown' and not micro:
        raise MethodologyError('«Обеспеченный (не указан)» допустим только для микрокредитов')
    if not result and not micro:
        raise MethodologyError(f'Неизвестная обеспеченность: {value!r}')
    return result or 'micro_unknown'


def micro_flag(v):
    t=str(v or '').strip().lower()
    return t in ('да','1','1.0','true','микрокредит','мк') or (bool(t) and 'микро' in t)


def is_black_zone(zone):
    z=str(zone or '').strip().lower().replace('ё','е')
    return 'черн' in z or z in ('black','чз')


def currency(v):
    s=str(v or '').strip().upper()
    return {'933':'BYN','840':'USD','978':'EUR','643':'RUB','974':'BYR','BYR':'BYN'}.get(s,s)


def side_for_operation(operation):
    return 'баланс' if str(operation or '').strip().casefold() in ('кредит','цб для продажи') else 'внебаланс'


def match_key(unp, contract, ccy, side):
    return '|'.join([' '.join(str(unp or '').upper().split()),' '.join(str(contract or '').upper().split()),currency(ccy),side_for_operation(side) if side not in ('баланс','внебаланс') else side])

@dataclass(frozen=True)
class Criteria:
    ni:int=0; pfn:int=0; nvv:int=0
    restra:str=''; security:str=''; operation:str='Кредит'
    currency:str='BYN'; micro:bool=False; poc:bool=False
    poc_rate:float|None=None

    def as_dict(self):
        return {'ni':self.ni,'pfn':self.pfn,'nvv':self.nvv,'restra':self.restra,
          'security':self.security,'operation':self.operation,'currency':self.currency,
          'micro':self.micro,'poc':self.poc,'poc_rate':self.poc_rate}


def classify(c:Criteria):
    """Return (GR, percent, explanation), or raise rather than silently invent a risk group."""
    active = side_for_operation(c.operation)=='баланс'
    ccy=currency(c.currency)
    if c.poc:
        if not active: return 1, .5, 'ПОК: УО/внебаланс → 1 ГР, 0,5%'
        if c.poc_rate is None: raise MethodologyError('ПОК: нет ставки по договору в факте или в других датах БП')
        return 'ПОК', rate_percent(c.poc_rate), 'ПОК: ставка конкретного договора'
    sec=normal_security(c.security,c.micro)
    restra=str(c.restra or '').strip()
    if restra and active:
        m=re.search(r'([456])\s*(?:[- ]?\s*гр|группа)',restra.lower())
        if not m:
            raise MethodologyError(f'Неизвестная реструктуризация: {restra!r}; нужна 4/5/6 ГР')
        gr=int(m.group(1))
        return gr,RATE_BY_GR[gr],'Реструктуризация договора; приоритет над ПФН и НИ'
    # Re-structuring on UO does not participate, even if source has erroneous value
    ni=flag(c.ni);pfn=flag(c.pfn); nvv=flag(c.nvv)
    if c.micro:
        gr=2 if (ni or pfn) else 1
        return gr,RATE_BY_GR[gr],'Микрокредит: обеспечение не влияет; НИ/ПФН'
    if 'цб' in str(c.operation).lower():
        if pfn: return (3,30. if sec=='unsecured' else 20.,'ЦБ: ПФН')
        if ni: return (2,20. if sec=='unsecured' else 5.,'ЦБ: НИ')
        return (1, .5 if sec in ('high','secured') else 2.,'ЦБ: без НИ и ПФН')
    # ordinary active/contingent exposures
    if pfn:
        if sec=='high': return 1,.5,'ПФН, высококачественное обеспечение'
        if sec in ('secured','insufficient'): return 3,20.,'ПФН, обеспечен/недостаточно обеспечен'
        if sec=='unsecured': return (4,30.,'ПФН, необеспеченный актив') if active else (3,20.,'ПФН, необеспеченное УО')
    if ni:
        if sec=='high': return 1,.5,'НИ, высококачественное обеспечение'
        if sec in ('secured','insufficient'): return 2,5.,'НИ, обеспечен/недостаточно обеспечен'
        return 3,20.,'НИ, необеспечен'
    if nvv and active and ccy != 'BYN':
        if sec in ('secured','insufficient'): return 2,5.,'НВВ, валютный актив'
        if sec=='unsecured': return 3,20.,'НВВ, валютный необеспеченный актив'
        # Underlying high-security NВВ combination has no explicit approved rule.
        raise MethodologyError('НВВ + высококачественное обеспечение не описано в матрице')
    if sec in ('high','secured'): return 1,.5,'Без действующих признаков риска, обеспечен'
    return 2,5.,'Без действующих признаков риска, недостаточно обеспечен/необеспечен'


def quality_breakdown(before:Criteria, after:Criteria, current_od:float, rate0:float, rate1:float):
    """Two-way path average for independently influential criteria; stronger indicators shadow weaker ones.

    Uses the *current* OD for intermediate rate effects, per approved formula.
    Returns (per-factor amounts, event list). Manual override rate changes are isolated.
    """
    changed=[]; events=[]
    for f in ('ni','pfn','nvv','restra','security'):
        if getattr(before,f)!=getattr(after,f):
            events.append(f)
            if f=='ni' and after.pfn: continue  # specifically NI removal as PFN arrives: NI factor 0
            if f=='nvv' and (after.pfn or after.ni or after.currency=='BYN' or side_for_operation(after.operation)!='баланс'):continue
            if f in ('ni','pfn','nvv') and after.restra and side_for_operation(after.operation)=='баланс': continue
            if f=='security' and after.micro and not after.restra:continue
            changed.append(f)
    # Source changes that are fully masked by methodical condition naturally give 0 in subsequent paths.
    def rate(c):
        try:return classify(c)[1]
        except MethodologyError:
            return None
    base_rate=rate(before); end_rate=rate(after)
    terms={f:0. for f in FACTOR_NAMES}
    if not changed:
        terms['override']=-current_od*(rate1-rate0)/100
        return {k:round(v,2) for k,v in terms.items()},events
    if len(changed)>2:
        raise MethodologyError('Одновременно более двух независимо действующих факторов: '+', '.join(changed))
    paths=[]
    for path in permutations(changed):
        c=before; contributions={f:0. for f in changed};ok=True
        rprev=rate(c)
        for field in path:
            n=replace(c, **{field:getattr(after,field)})
            rnext=rate(n)
            if rprev is None or rnext is None: ok=False;break
            contributions[field] += -current_od*(rnext-rprev)/100
            c=n;rprev=rnext
        if ok: paths.append(contributions)
    if not paths:
        # For previously invalid state (e.g. incomplete security in temporary state) keep exact quality
        # in named unallocated adjustment, rather than fabricate intermediate group.
        terms['override']=-current_od*(rate1-rate0)/100
        return {k:round(v,2) for k,v in terms.items()},events
    for f in changed:
        value=sum(p[f] for p in paths)/len(paths)
        key= f+('_in' if getattr(after,f) else '_out') if f in ('ni','pfn','nvv') else ('restruct' if f=='restra' else 'security')
        terms[key]+=value
    # difference between observed rate path and matrix-to-matrix path (e.g. manual override)
    calculated=sum(terms.values())
    actual=-current_od*(rate1-rate0)/100
    terms['override'] += actual-calculated
    terms={k:round(v,2) for k,v in terms.items()}
    # Preserve exact cent accuracy after rounding
    terms['override']=round(terms['override'] + round(actual-sum(terms.values()),2),2)
    return terms,events


def compute_factors(prior, current):
    """prior/current dicts with debt,fx,od,rate, reserve,criteria keys. Returns exact reconciliation."""
    fx=-(prior['debt']*(current['fx']-prior['fx'])*prior['rate']/100)
    movement=-(current['od']-prior['od'])*prior['rate']/100 - fx
    quality=-current['od']*(current['rate']-prior['rate'])/100
    sub,events=quality_breakdown(Criteria(**prior['criteria']),Criteria(**current['criteria']),current['od'],prior['rate'],current['rate'])
    expenses=prior['reserve']-current['reserve']
    fx=round(fx,2);movement=round(movement,2); quality=round(quality,2);expenses=round(expenses,2)
    # Cents adjustment from intermediate per-period reserve roundings; explicit, never hidden in quality.
    residual=round(expenses-fx-movement-quality,2)
    sub_sum=round(sum(sub.values()),2)
    if abs(sub_sum-quality)>0.01:
        sub['override']=round(sub['override']+quality-sub_sum,2)
    return {'movement':movement,'fx':fx,'quality':quality,'expenses':expenses,'rounding':residual,'factors':sub,'events':events}
