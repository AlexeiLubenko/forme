"""Streaming wide NSFO forecast workbook export (runtime openpyxl)."""
import json, re
from datetime import datetime
from io import BytesIO
from openpyxl import Workbook
from openpyxl.cell import WriteOnlyCell
from openpyxl.styles import Font,PatternFill,Alignment,Border,Side
from openpyxl.utils import get_column_letter
from engine import connect, dd, _prior_period
from risk import FACTOR_NAMES

BASE_HEADERS=['Ключ','Индивидуал / ДРПА','Рабочая строка','Комментарий','Ключ сверки','Баланс/внебаланс',
'Сегмент 2026','Сегмент 2027','Наименование клиента','Тип операции','УНП','Номер договора',
'Номер договора верхнего уровня','Валюта','РД','Продукт','Микрокредит','КМ','CRM_ID',
'Отрасль','Зона проблемности','Дата начала договора','Дата окончания договора',
'Предельная дата выборки','СПОК']
FIELDS=['Задолженность','OD','НИ','ПФН','НВВ','Рестра','Обеспеченность','ГР','%рез',
'Ушла НИ','Пришла НИ','Ушел ПФН','Пришел ПФН','Ушло НВВ','Пришло НВВ',
'Изменение рестры','Изменилась обеспеченность','Ухудшение качества','Переоценка','Изменение портфеля']
KFACTOR={'Ушла НИ':'ni_out','Пришла НИ':'ni_in','Ушел ПФН':'pfn_out','Пришел ПФН':'pfn_in',
'Ушло НВВ':'nvv_out','Пришло НВВ':'nvv_in','Изменение рестры':'restruct','Изменилась обеспеченность':'security'}
BGC='#16243B';CYAN='#E6F1FF';NUM_FMT='#,##0.00;[Red](#,##0.00);–'

def header_cells(ws,headers):
    row=[]
    for h in headers:
        c=WriteOnlyCell(ws,value=h)
        c.font=Font(name='Aptos',size=10,bold=True,color='FFFFFF')
        c.fill=PatternFill('solid',fgColor='15263F')
        c.alignment=Alignment(wrap_text=True,vertical='center')
        row.append(c)
    ws.append(row)

def amount_cell(ws,v,editable=False):
    c=WriteOnlyCell(ws,value=v)
    c.font=Font(name='Aptos',size=10,color='0000FF' if editable else '101828')
    if isinstance(v,(int,float)):c.number_format=NUM_FMT
    if editable:c.fill=PatternFill('solid',fgColor='EDF5FF')
    return c

def build_excel(pid,output_path=None):
    with connect() as db:
        project=db.execute('SELECT * FROM projects WHERE id=?',(pid,)).fetchone()
        if not project:raise ValueError('Нет проекта')
        periods=json.loads(project['periods'])
        if not periods:raise ValueError('Нет рассчитанного прогноза')
        wb=Workbook(write_only=True)
        s=wb.create_sheet('Прогноз НСФО')
        s.sheet_view.showGridLines=False
        base=BASE_HEADERS
        headers=base+[f'{name}_{dd(period)}' for period in periods for name in FIELDS]
        headers += [f'Резерв_{dd(period)}' for period in periods]
        headers += [f'Расходы_{dd(period)}' for period in periods[1:]]
        header_cells(s,headers)
        s.freeze_panes='K2'
        for j in range(1,len(headers)+1):
            s.column_dimensions[get_column_letter(j)].width=(19 if j<=len(base) else 15)
        for p in db.execute('SELECT * FROM positions WHERE project_id=? ORDER BY unp,contract,id',(pid,)):
            rows={r['period']:r for r in db.execute('SELECT * FROM position_periods WHERE position_id=? AND project_id=? ORDER BY period',(p['id'],pid))}
            black='ДРПА' if 'черн' in (p['zone'] or '').lower() else ''
            important=any(abs(r['expenses'] or 0)>=100000 for r in rows.values())
            label='/'.join(x for x in ('Индивидуал' if important else '',black) if x)
            vals=[str(p['id']),label,'Добавлен из факта' if p['src']!='bp' else '',p['comment'],p['match_key'],p['side'],p['segment26'],p['segment27'],p['client'],p['operation'],p['unp'],p['contract'],p['parent_contract'],p['ccy'],p['rd'],p['product'],'Да' if p['micro'] else 'Нет',p['km'],p['crm'],p['sector'],p['zone'],p['start_date'],p['end_date'],p['limit_date'],p['spok']]
            for dt in periods:
                r=rows.get(dt)
                if not r: vals += [None]*len(FIELDS);continue
                f=json.loads(r['factors'] or '{}')
                vals += [r['debt'],r['od'],r['ni'],r['pfn'],r['nvv'],r['restra'],r['security'],r['gr'],r['rate'],
                    *[f.get(KFACTOR[name],0.) for name in FIELDS[9:17]],r['quality'],r['revaluation'],r['movement']]
            vals += [rows[t]['reserve'] if t in rows else None for t in periods]
            vals += [rows[t]['expenses'] if t in rows else None for t in periods[1:]]
            s.append([amount_cell(s,value,editable=(j in (3,) or (j>=len(base) and (j-len(base))%len(FIELDS) in (0,2,3,4,5,6)))) for j,value in enumerate(vals)])
        # Client summary per period, with period-specific 100k threshold
        per=wb.create_sheet('Поклиентные расходы')
        h=['УНП','Клиент','Зона','ДРПА','Комментарий']+[f'Расходы_{dd(d)} (BYN)' for d in periods[1:]]
        header_cells(per,h); per.freeze_panes='C2'
        per.column_dimensions['B'].width=38;per.column_dimensions['E'].width=70
        query='''SELECT p.unp,MAX(p.client) client,MAX(p.zone) zone,MAX(p.comment) comment, pp.period,
          SUM(pp.expenses) expenses FROM positions p JOIN position_periods pp ON p.id=pp.position_id
          WHERE p.project_id=? GROUP BY p.unp,pp.period ORDER BY p.unp,pp.period'''
        clients={}
        for r in db.execute(query,(pid,)):
            rec=clients.setdefault(r['unp'],{'client':r['client'],'zone':r['zone'],'comment':r['comment'],'vals':{}})
            rec['vals'][r['period']]=r['expenses']
        standard={d:0. for d in periods[1:]}
        for unp,r in clients.items():
            important=any(abs(r['vals'].get(d,0))>=100000 for d in periods[1:])
            if important:
                per.append([unp,r['client'],r['zone'],'Да' if 'черн' in (r['zone'] or '').lower() else '',r['comment']]+[round(r['vals'].get(d,0.),2) for d in periods[1:]])
            else:
                for d in periods[1:]:standard[d]+=r['vals'].get(d,0.)
        per.append(['','Стандартный портфель','','','']+[round(standard[d],2) for d in periods[1:]])
        # Factor bridge and subfactors
        fws=wb.create_sheet('Факторный анализ');header_cells(fws,['Период','Движение КП','Изменение качества','Переоценка','Расходы','Сверка','Снятие НИ','Признание НИ','Снятие ПФН','Признание ПФН','Снятие НВВ','Признание НВВ','Реструктуризация','Обеспеченность','Ручная ставка'])
        for d in periods[1:]:
            summ=db.execute('SELECT SUM(movement) movement,SUM(quality) quality,SUM(revaluation) revaluation,SUM(expenses) expenses FROM position_periods WHERE project_id=? AND period=?',(pid,d)).fetchone()
            factors={k:0. for k in FACTOR_NAMES}
            for r in db.execute('SELECT factors FROM position_periods WHERE project_id=? AND period=?',(pid,d)):
                for k,v in json.loads(r['factors'] or '{}').items():factors[k]+=v
            fws.append([dd(d),round(summ['movement'] or 0.,2),round(summ['quality'] or 0.,2),round(summ['revaluation'] or 0.,2),round(summ['expenses'] or 0.,2),round((summ['expenses'] or 0.)-(summ['movement'] or 0.)-(summ['quality'] or 0.)-(summ['revaluation'] or 0.),2)]+[round(factors[k],2) for k in FACTOR_NAMES])
        for sheetname,sql,cols in [
            ('Сверка задолженности',"SELECT client,contract,details,message FROM warnings WHERE project_id=? AND kind='debt'",['Клиент','Договор','Задолженность БП, BYN','Факт, BYN','Отклонение, BYN','Курс']),
            ('Сверка резервов',"SELECT client,contract,details,message FROM warnings WHERE project_id=? AND kind='reserve'",['Клиент','Договор','Рассчитанный резерв, BYN','Резерв факт, BYN','Отклонение, BYN']),
        ]:
            w=wb.create_sheet(sheetname);header_cells(w,cols)
            for r in db.execute(sql,(pid,)):
                x=json.loads(r['details'] or '{}')
                if sheetname=='Сверка задолженности':w.append([r['client'],r['contract'],x.get('bp_byn'),x.get('fact_byn'),x.get('diff_byn'),x.get('fx')])
                else:w.append([r['client'],r['contract'],x.get('calc_byn'),x.get('fact_byn'),x.get('diff_byn')])
        w=wb.create_sheet('Реестр договоров');header_cells(w,['УНП','Клиент','Договор','Валюта','Баланс','Зона','Сумма факта, BYN','Статус','Добавлено'])
        for r in db.execute('SELECT * FROM missing WHERE project_id=? ORDER BY status,client',(pid,)):
            w.append([r['unp'],r['client'],r['contract'],r['ccy'],r['side'],r['zone'],r['amount_byn'],r['status'],r['added']])
        w=wb.create_sheet('Контроль данных');header_cells(w,['Тип','Серьёзность','Клиент','Договор','Описание'])
        for r in db.execute('SELECT kind,severity,client,contract,message FROM warnings WHERE project_id=? AND kind NOT IN ("debt","reserve")',(pid,)):
            w.append([r['kind'],r['severity'],r['client'],r['contract'],r['message']])
        w=wb.create_sheet('История изменений');header_cells(w,['Время','Действие','Позиция','Период','Поле','Было','Стало','Причина'])
        for r in db.execute('SELECT at,action,position_id,period,field,old,new,reason FROM audit WHERE project_id=? ORDER BY id',(pid,)):
            w.append([r['at'],r['action'],r['position_id'],r['period'],r['field'],r['old'],r['new'],r['reason']])
        if output_path is not None:
            wb.save(str(output_path))
            return output_path
        b=BytesIO();wb.save(b);b.seek(0);return b


def build_pdf(pid):
    """Optional reportlab PDF; Excel export works without it."""
    try:
        from reportlab.pdfgen.canvas import Canvas
        from reportlab.lib.pagesizes import A4
        from reportlab.pdfbase import pdfmetrics
        from reportlab.pdfbase.ttfonts import TTFont
    except ImportError:raise ValueError('Для экспорта PDF необходимо установить reportlab; Excel доступен без него')
    with connect() as db:
        p=db.execute('SELECT * FROM projects WHERE id=?',(pid,)).fetchone()
        if not p:raise ValueError('Нет бизнес-плана')
        periods=json.loads(p['periods'])
        stats=db.execute('''SELECT period,SUM(reserve) reserve,SUM(expenses) expenses,SUM(movement) movement,SUM(quality) quality,SUM(revaluation) fx
          FROM position_periods WHERE project_id=? GROUP BY period ORDER BY period''',(pid,)).fetchall()
    path='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
    if PathCheck(path):pdfmetrics.registerFont(TTFont('DejaVuSansNSFO',path));font='DejaVuSansNSFO'
    else:font='Helvetica'
    b=BytesIO();c=Canvas(b,pagesize=A4);width,height=A4
    c.setFillColorRGB(.07,.13,.24);c.rect(0,height-105,width,105,fill=1,stroke=0)
    c.setFont(font,16);c.setFillColorRGB(1,1,1);c.drawString(40,height-51,'Прогноз резервов НСФО')
    c.setFont(font,10);c.drawString(40,height-75,str(p['name'])[:65])
    y=height-145
    c.setFillColorRGB(.12,.17,.26);c.setFont(font,10)
    c.drawString(40,y,'Дата');c.drawString(145,y,'Резерв, BYN');c.drawString(295,y,'Расходы, BYN');y-=25
    for r in stats:
        if y<80:c.showPage();c.setFont(font,10);y=height-50
        c.drawString(40,y,dd(r['period']));c.drawRightString(275,y,f"{r['reserve'] or 0:,.2f}");c.drawRightString(475,y,f"{r['expenses'] or 0:,.2f}")
        y-=23
    c.setFont(font,8);c.drawString(40,35,'Сформировано АС НСФО. Расходы = резерв предыдущей даты - резерв текущей даты.')
    c.save();b.seek(0);return b

def PathCheck(p):
    import os
    return os.path.exists(p)

def build_printable_html(pid):
    """Pure stdlib fallback for PDF via browser Print → Save as PDF."""
    from html import escape
    def fmt(x):return f'{x or 0:,.2f}'.replace(',',' ')
    with connect() as db:
        p=db.execute('SELECT * FROM projects WHERE id=?',(pid,)).fetchone()
        if not p:raise ValueError('Нет проекта')
        periods=json.loads(p['periods'])
        totals=list(db.execute('''SELECT period,SUM(od) od,SUM(reserve) reserve,SUM(expenses) expenses,
            SUM(movement) movement,SUM(quality) quality,SUM(revaluation) revaluation
            FROM position_periods WHERE project_id=? GROUP BY period ORDER BY period''',(pid,)))
        important=db.execute('''SELECT pp.period,p.unp,MAX(p.client) client,MAX(p.zone) zone,SUM(pp.expenses) expense
            FROM positions p JOIN position_periods pp ON p.id=pp.position_id
            WHERE p.project_id=? GROUP BY pp.period,p.unp HAVING ABS(SUM(pp.expenses))>=100000
            ORDER BY pp.period,ABS(SUM(pp.expenses)) DESC LIMIT 250''',(pid,)).fetchall()
    def tr(vals):return '<tr>'+''.join('<td>'+escape(str(v))+'</td>' for v in vals)+'</tr>'
    totals_rows=''.join(tr([dd(r['period']),fmt(r['od']),fmt(r['reserve']),fmt(r['expenses']),fmt(r['movement']),fmt(r['quality']),fmt(r['revaluation'])]) for r in totals)
    clients_rows=''.join(tr([dd(r['period']),r['client'],r['unp'],'ДРПА' if 'черн' in (r['zone'] or '').lower() else 'Индивидуал',fmt(r['expense'])]) for r in important)
    return f'''<!doctype html><html lang="ru"><head><meta charset="utf-8"><title>Прогноз НСФО — {escape(p['name'])}</title>
    <style>body{{font-family:Arial,Segoe UI,sans-serif;color:#213147;margin:30px}}h1{{font-size:23px}}h2{{font-size:16px;margin-top:30px}}
    .meta{{color:#66768b;font-size:12px}}table{{border-collapse:collapse;width:100%;font-size:10px}}
    td,th{{padding:9px 7px;border-bottom:1px solid #dee5ee;text-align:right}}
    th{{background:#1c3150;color:#fff}}td:first-child,th:first-child{{text-align:left}}
    button{{border:0;border-radius:7px;background:#315fe5;color:white;padding:10px 16px;cursor:pointer}}
    @media print{{button{{display:none}}body{{margin:12mm}}thead{{display:table-header-group}}tr{{break-inside:avoid}}}}
    </style></head><body><button onclick="window.print()">Сохранить в PDF / печать</button>
    <h1>Прогноз резервов НСФО</h1><p>{escape(p['name'])}</p>
    <p class="meta">Модуль 1 · Факт на {dd(p['fact_date'])} · Создано {escape(p['created'])} · Версия {p['version']}</p>
    <h2>Резервы, расходы и денежные факторы</h2><table><thead><tr><th>Период</th><th>OD, BYN</th><th>Резерв, BYN</th><th>Расходы, BYN</th><th>Движение КП</th><th>Качество</th><th>Переоценка</th></tr></thead><tbody>{totals_rows}</tbody></table>
    <h2>Существенные клиенты — |расходы| ≥ 100 000 BYN за период</h2>
    <table><thead><tr><th>Период</th><th>Клиент</th><th>УНП</th><th>Классификация</th><th>Расходы, BYN</th></tr></thead><tbody>{clients_rows}</tbody></table>
    <p class="meta">Расходы = резерв предыдущей даты − резерв текущей даты. Курс и ставка — по утверждённой методике НСФО.</p>
    </body></html>'''
