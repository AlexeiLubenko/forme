"""Streaming XLSX-to-SQLite NSFO business-plan forecast engine.

Runtime dependencies: Python 3.11+, openpyxl (already installed on the bank terminal).
No Flask, Streamlit, pandas or external database service is required.
"""
from __future__ import annotations
import os, json, sqlite3, re, datetime as dt, time, math
from pathlib import Path
from collections import defaultdict
from contextlib import contextmanager
from openpyxl import load_workbook
from risk import Criteria, MethodologyError, classify, currency, flag, rate_percent, gr_value, micro_flag, is_black_zone, side_for_operation, match_key, compute_factors, FACTOR_NAMES

ROOT=Path(__file__).resolve().parent
DATA=ROOT/'storage'; DATA.mkdir(exist_ok=True)
DB=DATA/'nsfo.sqlite3'
PERIOD_REGEX=re.compile(r'(?:Факт на|Прогноз на|Задолженность_)\s*(\d{2}\.\d{2}\.\d{4})',re.I)

@contextmanager
def connect():
    con=sqlite3.connect(str(DB),timeout=90)
    con.row_factory=sqlite3.Row
    con.execute('PRAGMA foreign_keys=ON')
    con.execute('PRAGMA busy_timeout=90000')
    try:yield con;con.commit()
    except:con.rollback();raise
    finally:con.close()


def initialize():
    with connect() as db:
        db.executescript('''
        PRAGMA journal_mode=WAL;
        PRAGMA synchronous=NORMAL;
        CREATE TABLE IF NOT EXISTS projects(id INTEGER PRIMARY KEY, name TEXT NOT NULL, created TEXT NOT NULL,
            fact_date TEXT, periods TEXT DEFAULT '[]', status TEXT DEFAULT 'draft', version INTEGER DEFAULT 0, note TEXT DEFAULT '');
        CREATE TABLE IF NOT EXISTS uploads(project_id INTEGER,kind TEXT,original_name TEXT,path TEXT,uploaded TEXT,
            PRIMARY KEY(project_id,kind));
        CREATE TABLE IF NOT EXISTS fx(project_id INTEGER,period TEXT,currency TEXT,rate REAL,
            PRIMARY KEY(project_id,period,currency));
        CREATE TABLE IF NOT EXISTS fact_contracts(project_id INTEGER,match_key TEXT,unp TEXT,contract TEXT,ccy TEXT,side TEXT,
            operation TEXT,client TEXT,crm TEXT,rd TEXT,upper_contract TEXT,security TEXT,restra TEXT,
            ni INTEGER,pfn INTEGER,nvv INTEGER,zone TEXT,micro TEXT,gr TEXT,rate REAL,
            debt REAL,reserve REAL,fx REAL,row_count INTEGER DEFAULT 1,issues TEXT DEFAULT '[]',
            PRIMARY KEY(project_id,match_key));
        CREATE TABLE IF NOT EXISTS fact_clients(project_id INTEGER,unp TEXT,ni INTEGER,pfn INTEGER,nvv INTEGER,
            zone TEXT,client TEXT,crm TEXT,PRIMARY KEY(project_id,unp));
        CREATE TABLE IF NOT EXISTS positions(id INTEGER PRIMARY KEY,project_id INTEGER NOT NULL,match_key TEXT,src TEXT,
            unp TEXT,contract TEXT,parent_contract TEXT,ccy TEXT,side TEXT,operation TEXT,client TEXT,crm TEXT,rd TEXT,
            product TEXT,micro INTEGER,poc INTEGER,zone TEXT,security TEXT,restra TEXT,
            ni INTEGER,pfn INTEGER,nvv INTEGER,poc_rate REAL,segment26 TEXT,segment27 TEXT,
            start_date TEXT,end_date TEXT,limit_date TEXT,spok TEXT,sector TEXT,km TEXT,
            comment TEXT DEFAULT '', comment_manual INTEGER DEFAULT 0, source_row INTEGER DEFAULT 0,
            classification_error TEXT DEFAULT '', added_at TEXT DEFAULT '');
        CREATE INDEX IF NOT EXISTS positions_project_key ON positions(project_id,match_key);
        CREATE INDEX IF NOT EXISTS positions_unp ON positions(project_id,unp);
        CREATE INDEX IF NOT EXISTS positions_client ON positions(project_id,client);
        CREATE TABLE IF NOT EXISTS position_periods(project_id INTEGER,position_id INTEGER,period TEXT,
            debt REAL,fx REAL,od REAL,ni INTEGER,pfn INTEGER,nvv INTEGER,restra TEXT,security TEXT,
            gr TEXT,rate REAL,reserve REAL,expenses REAL DEFAULT 0,movement REAL DEFAULT 0,
            revaluation REAL DEFAULT 0,quality REAL DEFAULT 0,rounding REAL DEFAULT 0,
            factors TEXT DEFAULT '{}',events TEXT DEFAULT '[]',override_reason TEXT DEFAULT '',
            PRIMARY KEY(project_id,position_id,period));
        CREATE INDEX IF NOT EXISTS pp_project_period ON position_periods(project_id,period);
        CREATE TABLE IF NOT EXISTS missing(id INTEGER PRIMARY KEY,project_id INTEGER,match_key TEXT,
            unp TEXT,contract TEXT,client TEXT,ccy TEXT,side TEXT,operation TEXT,zone TEXT,
            amount_byn REAL,fx REAL,status TEXT,position_id INTEGER,created TEXT,added TEXT,
            UNIQUE(project_id,match_key));
        CREATE INDEX IF NOT EXISTS missing_status ON missing(project_id,status);
        CREATE TABLE IF NOT EXISTS warnings(id INTEGER PRIMARY KEY,project_id INTEGER,kind TEXT,severity TEXT,
            match_key TEXT,client TEXT,contract TEXT,message TEXT,details TEXT DEFAULT '{}');
        CREATE INDEX IF NOT EXISTS warnings_project ON warnings(project_id,kind);
        CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY,project_id INTEGER,at TEXT,action TEXT,
            position_id INTEGER,period TEXT,field TEXT,old TEXT,new TEXT,reason TEXT DEFAULT '');
        CREATE TABLE IF NOT EXISTS versions(id INTEGER PRIMARY KEY,project_id INTEGER,version INTEGER,
            created TEXT,title TEXT,backup_path TEXT);
        ''')


def now():return dt.datetime.now().isoformat(timespec='seconds')
def js(obj):return json.dumps(obj,ensure_ascii=False,default=str,separators=(',',':'))
def val(x):
    if x is None or (isinstance(x,str) and not x.strip()):return 0.0
    if isinstance(x,(int,float)):return float(x)
    try:return float(str(x).replace(' ','').replace('\xa0','').replace(',','.'))
    except:raise MethodologyError(f'Ожидалось число, получено {x!r}')
def normalize_header(s):return ' '.join(str(s or '').strip().casefold().replace('ё','е').split())
def iso_date(x):
    if isinstance(x,(dt.date,dt.datetime)):return x.strftime('%Y-%m-%d')
    s=str(x or '').strip()
    if not s:return ''
    for fmt in ('%d.%m.%Y','%Y-%m-%d'):
        try:return dt.datetime.strptime(s,fmt).strftime('%Y-%m-%d')
        except ValueError:pass
    return s

def dd(iso):
    try:return dt.datetime.strptime(iso,'%Y-%m-%d').strftime('%d.%m.%Y')
    except:return iso


def find_sheet_header(wb, required):
    for sheet in wb.worksheets:
        for rowi,row in enumerate(sheet.iter_rows(min_row=1,max_row=12,values_only=True),start=1):
            heads={normalize_header(c):j for j,c in enumerate(row) if c is not None}
            if all(normalize_header(h) in heads for h in required):return sheet,rowi,list(row)
    raise MethodologyError('Не найдена шапка с полями: '+', '.join(required))

def get(row,heads,head,default=None):
    k=heads.get(normalize_header(head))
    return row[k] if k is not None and k<len(row) else default

def get_col(row,col):return row[col-1] if len(row)>=col else None

def warn(db,pid,kind,message,severity='warning',key='',client='',contract='',details=None):
    db.execute('INSERT INTO warnings(project_id,kind,severity,match_key,client,contract,message,details) VALUES(?,?,?,?,?,?,?,?)',
        (pid,kind,severity,key,client,contract,message,js(details or {})))



def confirm_fact_date(pid,date):
    date=iso_date(date)
    try: parsed=dt.date.fromisoformat(date)
    except ValueError:raise MethodologyError('Укажите корректную дату в формате YYYY-MM-DD')
    if parsed.day!=1:raise MethodologyError('Выверенный факт должен быть только на 1-е число месяца')
    with connect() as db:
        db.execute('UPDATE projects SET note=? WHERE id=?',(date,pid))
    return date

def create_project(name):
    with connect() as db:
        row=db.execute('INSERT INTO projects(name,created) VALUES(?,?)',(str(name).strip() or 'Бизнес-план НСФО',now()))
        pid=row.lastrowid
        (DATA/str(pid)).mkdir(exist_ok=True)
        return pid


def upload_path(pid,kind,path,original_name):
    if kind not in ('bp','fact','rates'):raise ValueError('Неизвестный тип файла')
    path=Path(path)
    with connect() as db:
        exists=db.execute('SELECT id FROM projects WHERE id=?',(pid,)).fetchone()
        if not exists:raise ValueError('Бизнес-план не найден')
        target=DATA/str(pid)/(kind+'.xlsx'); target.parent.mkdir(exist_ok=True)
        os.replace(path,target)
        db.execute('INSERT OR REPLACE INTO uploads VALUES(?,?,?,?,?)',(pid,kind,str(original_name),str(target),now()))
    return {'kind':kind,'file':original_name,'size':target.stat().st_size}


def load_rates(db,pid,path):
    book=load_workbook(path,read_only=True,data_only=True)
    try:
        ws,headrow,head=find_sheet_header(book,['Дата','Валюта'])
        h={normalize_header(v):j for j,v in enumerate(head) if v is not None}
        idx_rate=next((j for j,v in enumerate(head) if v is not None and ('курс' in normalize_header(v))),None)
        if idx_rate is None:raise MethodologyError('В файле курсов нет столбца с курсом')
        count=0
        for row in ws.iter_rows(min_row=headrow+1,values_only=True):
            date=iso_date(get(row,h,'Дата'));ccy=currency(get(row,h,'Валюта'))
            if not date or not ccy:continue
            raw=row[idx_rate]
            if raw is None or raw=='':continue
            r=val(raw)
            if r<=0:raise MethodologyError(f'Курс {ccy} на {date} должен быть положительным')
            db.execute('INSERT OR REPLACE INTO fx VALUES(?,?,?,?)',(pid,date,ccy,r));count+=1
        return count
    finally:book.close()


def load_fact(db,pid,path):
    book=load_workbook(path,read_only=True,data_only=True)
    ws,headrow,head=find_sheet_header(book,['УНП','Номер договора','Тип операции','Код валюты'])
    h={normalize_header(v):j for j,v in enumerate(head) if v is not None}
    count=0;issues=0
    try:
        # aggregate key via SQL to keep memory bounded
        for rowno,row in enumerate(ws.iter_rows(min_row=headrow+1,values_only=True),headrow+1):
            unp=str(get(row,h,'УНП') or '').strip();contract=str(get(row,h,'Номер договора') or '').strip()
            if not unp or not contract:continue
            operation=str(get(row,h,'Тип операции') or '').strip()
            ccy=currency(get(row,h,'Код валюты'))
            side=side_for_operation(operation)
            k=match_key(unp,contract,ccy,side)
            client=str(get(row,h,'Клиент') or '').strip()
            ni=flag(get(row,h,'НИ'));pfn=flag(get(row,h,'ПФН'));nvv=flag(get(row,h,'НВВ'))
            sec=str(get(row,h,'Обеспеченность') or '').strip()
            restra=str(get(row,h,'Рестра') or '').strip()
            zone=str(get(row,h,'Зона проблемности') or '').strip()
            crm=str(get(row,h,'ID CRM') or '').strip()
            debt=val(get(row,h,'Задолженность, тыс BYN'))*1000
            reserve=val(get(row,h,'Резерв факт'))*1000
            fx=val(get(row,h,'Курс'))
            if fx<=0:raise MethodologyError(f'Факт, строка {rowno}: отсутствует положительный курс {ccy}')
            gr=str(get(row,h,'ГР') or '')
            rawrate=get(row,h,'% рез')
            try: rate=rate_percent(rawrate)
            except MethodologyError:rate=None
            # Check client flags for conflicting values, rather than silently selecting one.
            previous=db.execute('SELECT ni,pfn,nvv FROM fact_clients WHERE project_id=? AND unp=?',(pid,unp)).fetchone()
            if previous and (previous['ni'],previous['pfn'],previous['nvv'])!=(ni,pfn,nvv):
                issues+=1
                warn(db,pid,'data',f'Противоречивые НИ/ПФН/НВВ по УНП {unp}, строка {rowno}', 'error', k,client,contract)
            db.execute('''INSERT INTO fact_clients VALUES(?,?,?,?,?,?,?,?)
                ON CONFLICT(project_id,unp) DO UPDATE SET zone=CASE WHEN excluded.zone LIKE '%черн%' THEN excluded.zone ELSE fact_clients.zone END''',
                (pid,unp,ni,pfn,nvv,zone,client,crm))
            prev=db.execute('SELECT security,restra,rate FROM fact_contracts WHERE project_id=? AND match_key=?',(pid,k)).fetchone()
            if prev and (str(prev['security'])!=sec or str(prev['restra'])!=restra):
                issues+=1
                warn(db,pid,'data',f'В нескольких строках одного договора различаются реструктуризация/обеспеченность: {contract}', 'error',k,client,contract)
            db.execute('''INSERT INTO fact_contracts(project_id,match_key,unp,contract,ccy,side,operation,client,crm,rd,upper_contract,security,restra,ni,pfn,nvv,zone,micro,gr,rate,debt,reserve,fx)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                ON CONFLICT(project_id,match_key) DO UPDATE SET debt=debt+excluded.debt,reserve=reserve+excluded.reserve,row_count=row_count+1''',
                (pid,k,unp,contract,ccy,side,operation,client,crm,str(get(row,h,'РД') or ''),str(get(row,h,'Номер договора верхнего уровня') or contract),sec,restra,ni,pfn,nvv,zone,'микро' if 'микро' in str(get(row,h,'Вид кредита') or '').lower() else '',gr,rate,debt,reserve,fx))
            count+=1
            if count%3000==0:db.commit()
        return {'rows':count,'issues':issues}
    finally:book.close()


def read_bp_positions(db,pid,path):
    book=load_workbook(path,read_only=True,data_only=True)
    ws,headrow,head=find_sheet_header(book,['УНП','Номер договора','Валюта','Наименование клиента'])
    h={normalize_header(v):j for j,v in enumerate(head) if v is not None}
    dates={}
    for j,title in enumerate(head):
        t=str(title or '')
        match=re.search(r'^(?:Факт|Прогноз)\s+на\s+(\d{2}\.\d{2}\.\d{4})$',t,re.I)
        if match:
            date=iso_date(match.group(1))
            # only first fact on first of month, user supplies first-day report
            if dt.date.fromisoformat(date).day!=1:continue
            dates[date]=j
    if not dates:raise MethodologyError('Во входном БП не найдены столбцы «Факт на 01.MM.YYYY» и «Прогноз на 01.MM.YYYY»')
    periods=sorted(dates)
    baseline=periods[0]
    if 'факт' not in str(head[dates[baseline]]).casefold():raise MethodologyError('Первая дата должна быть фактической на 1 число')
    # use column AO or visible source rates only for validation and POK fallback
    rate_cols={}
    for j,title in enumerate(head):
        match=re.search(r'%\s*рез\s*на\s*(\d{2}\.\d{2}\.\d{4})',str(title or ''),re.I)
        if match:rate_cols[iso_date(match.group(1))]=j
    n=0
    try:
        for rowno,row in enumerate(ws.iter_rows(min_row=headrow+1,values_only=True),headrow+1):
            unp=str(get(row,h,'УНП') or '').strip();contract=str(get(row,h,'Номер договора') or '').strip()
            if not unp or not contract:continue
            operation=str(get_col(row,1) or '').strip()
            ccy=currency(get(row,h,'Валюта'))
            side=side_for_operation(operation)
            k=match_key(unp,contract,ccy,side)
            matched=db.execute('SELECT * FROM fact_contracts WHERE project_id=? AND match_key=?',(pid,k)).fetchone()
            clientdata=db.execute('SELECT * FROM fact_clients WHERE project_id=? AND unp=?',(pid,unp)).fetchone()
            client=str(matched['client'] if matched and matched['client'] else get(row,h,'Наименование клиента') or '')
            zone=str(clientdata['zone'] if clientdata and clientdata['zone'] else get(row,h,'Зона проблемности') or '')
            ni,pfn,nvv=(clientdata['ni'],clientdata['pfn'],clientdata['nvv']) if clientdata else (flag(get(row,h,'НИ')),flag(get(row,h,'ПФН')),flag(get(row,h,'НВВ')))
            restra=str(matched['restra'] if matched else get(row,h,'Реструктуризация') or '')
            security=str(matched['security'] if matched else get(row,h,'Обеспеченность') or '')
            if side=='внебаланс' and restra:
                warn(db,pid,'data','Реструктуризация УО проигнорирована: признак относится только к активу','warning',k,client,contract)
                restra=''
            micro=micro_flag(get(row,h,'Микрокредит'))
            gr_input=gr_value(get(row,h,'ГР'))
            poc=(gr_input=='ПОК' or bool(matched and gr_value(matched['gr'])=='ПОК'))
            poc_rate=matched['rate'] if poc and matched and side=='баланс' else None
            if poc and side=='баланс' and poc_rate is None:
                for d,i in rate_cols.items():
                    try:v=rate_percent(row[i])
                    except MethodologyError:v=None
                    if v is not None:poc_rate=v;break
            criteria=Criteria(ni,pfn,nvv,restra,security,operation,ccy,micro,poc,poc_rate)
            error='';gr=None;rate=None
            try:gr,rate,reason=classify(criteria)
            except MethodologyError as e:error=str(e);warn(db,pid,'classification',error,'error',k,client,contract)
            declared_rate=get(row,h,'% рез на '+dd(baseline))
            # fallback first rate for user malformed header
            if declared_rate is not None:
                try:
                    declared_rate=rate_percent(declared_rate)
                    if rate is not None and abs(declared_rate-rate)>.001:
                        warn(db,pid,'classification',f'Ставка БП {declared_rate:g}% скорректирована по методике до {rate:g}%', 'info',k,client,contract)
                except MethodologyError as e: warn(db,pid,'data',str(e),'warning',k,client,contract)
            if gr is not None and gr_input is not None and str(gr_input)!=str(gr):
                warn(db,pid,'classification',f'ГР БП {gr_input} заменена методической ГР {gr}', 'info',k,client,contract)
            old_date=get(row,h,'Дата окончания договора');new_date=get(row,h,'Новая дата окончания')
            end_date=iso_date(new_date) if new_date not in (None,'') else iso_date(old_date)
            old_limit=get(row,h,'Предельная дата выборки');new_limit=get(row,h,'Новая дата выборки')
            limit_date=iso_date(new_limit) if new_limit not in (None,'') else iso_date(old_limit)
            rec=db.execute('''INSERT INTO positions(project_id,match_key,src,unp,contract,parent_contract,ccy,side,operation,client,crm,rd,product,micro,poc,zone,security,restra,ni,pfn,nvv,poc_rate,segment26,segment27,start_date,end_date,limit_date,spok,sector,km,source_row,classification_error)
              VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)''',
                (pid,k,'bp',unp,contract,str(get(row,h,'Номер договора верхнего уровня (ГС)') or contract),ccy,side,operation,client,str(matched['crm'] if matched and matched['crm'] else get(row,h,'CRM-ID') or ''),str(get(row,h,'РД') or ''),str(get(row,h,'Вид кредита') or ''),int(micro),int(poc),zone,security,restra,ni,pfn,nvv,poc_rate,str(get(row,h,'Сегмент 2026') or ''),str(get(row,h,'Сегмент 2027') or ''),iso_date(get(row,h,'Дата начала договора')),end_date,limit_date,str(get(row,h,'СПОК') or ''),str(get(row,h,'ОКЭДЫ') or ''),str(get(row,h,'КМ') or ''),rowno,error))
            posid=rec.lastrowid
            for period,j in dates.items():
                try: debt=val(row[j] if j<len(row) else None)
                except MethodologyError as e:
                    warn(db,pid,'data',f'Строка {rowno}, дата {period}: {e}','error',k,client,contract);debt=0.0
                db.execute('''INSERT INTO position_periods(project_id,position_id,period,debt,fx,od,ni,pfn,nvv,restra,security,gr,rate,reserve) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)''',
                    (pid,posid,period,debt,0,0,ni,pfn,nvv,restra,security,str(gr) if gr is not None else '',rate,0))
            n+=1
            if n%2000==0:db.commit()
        return baseline,periods,n
    finally:book.close()


def get_fx(db,pid,position,period,baseline):
    ccy=position['ccy'];k=position['match_key']
    if ccy=='BYN':return 1.
    if period==baseline:
        fc=db.execute('SELECT fx FROM fact_contracts WHERE project_id=? AND match_key=?',(pid,k)).fetchone()
        if fc and fc['fx'] and fc['fx']>0:return fc['fx']
    row=db.execute('SELECT rate FROM fx WHERE project_id=? AND period=? AND currency=?',(pid,period,ccy)).fetchone()
    if row and row['rate']>0:return row['rate']
    raise MethodologyError(f'Не найден курс {ccy} на {dd(period)}')


def add_missing_position(db,pid,key,reason='manual'):
    m=db.execute('SELECT * FROM missing WHERE project_id=? AND match_key=?',(pid,key)).fetchone()
    if not m:raise ValueError('Договор не найден в реестре')
    if m['status'] in ('auto','added'):return m['position_id']
    f=db.execute('SELECT * FROM fact_contracts WHERE project_id=? AND match_key=?',(pid,key)).fetchone()
    if not f:raise ValueError('Договор отсутствует в сохранённом факте')
    project=db.execute('SELECT periods FROM projects WHERE id=?',(pid,)).fetchone()
    periods=json.loads(project['periods'])
    # Automatic addition uses *actual currency debt* constant for every future date.
    debt=f['debt']/f['fx']
    poc=gr_value(f['gr'])=='ПОК'; micro=bool(f['micro'])
    restra=f['restra'] if f['side']=='баланс' else ''
    criteria=Criteria(f['ni'],f['pfn'],f['nvv'],restra,f['security'],f['operation'],f['ccy'],micro,poc,f['rate'] if poc else None)
    error=''
    try:gr,rate,_=classify(criteria)
    except MethodologyError as exc:gr,rate=None,None;error=str(exc);warn(db,pid,'classification',error,'error',key,f['client'],f['contract'])
    rec=db.execute('''INSERT INTO positions(project_id,match_key,src,unp,contract,parent_contract,ccy,side,operation,client,crm,rd,product,micro,poc,zone,security,restra,ni,pfn,nvv,poc_rate,added_at,classification_error)
      VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)''',
      (pid,key,'fact_auto' if reason=='auto' else 'fact_manual',f['unp'],f['contract'],f['upper_contract'] or f['contract'],f['ccy'],f['side'],f['operation'],f['client'],f['crm'],f['rd'],'',int(micro),int(poc),f['zone'],f['security'],restra,f['ni'],f['pfn'],f['nvv'],f['rate'] if poc else None,now(),error))
    posid=rec.lastrowid
    for p in periods:
        db.execute('''INSERT INTO position_periods(project_id,position_id,period,debt,fx,od,ni,pfn,nvv,restra,security,gr,rate,reserve)
          VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)''',(pid,posid,p,debt,0,0,f['ni'],f['pfn'],f['nvv'],f['restra'],f['security'],str(gr) if gr is not None else '',rate,0))
    db.execute('UPDATE missing SET status=?,position_id=?,added=? WHERE id=?',('auto' if reason=='auto' else 'added',posid,now(),m['id']))
    db.execute('INSERT INTO audit(project_id,at,action,position_id,reason) VALUES(?,?,?,?,?)',(pid,now(),'add_missing',posid,reason))
    return posid


def reconcile(db,pid,baseline):
    n=0
    facts=db.execute('SELECT * FROM fact_contracts WHERE project_id=?',(pid,))
    for f in facts:
        rows=db.execute('''SELECT p.id,pp.debt FROM positions p JOIN position_periods pp ON pp.position_id=p.id AND pp.period=?
          WHERE p.project_id=? AND p.match_key=?''',(baseline,pid,f['match_key'])).fetchall()
        if rows:
            plan=sum(r['debt'] for r in rows)*f['fx']
            diff=round(plan-f['debt'],2)
            if abs(diff)>.01:
                warn(db,pid,'debt',f'Расхождение задолженности: {diff:+,.2f} BYN','warning',f['match_key'],f['client'],f['contract'],
                    {'bp_byn':round(plan,2),'fact_byn':round(f['debt'],2),'diff_byn':diff,'fx':f['fx'],'ccy':f['ccy']})
        else:
            black=is_black_zone(f['zone'])
            db.execute('''INSERT INTO missing(project_id,match_key,unp,contract,client,ccy,side,operation,zone,amount_byn,fx,status,created)
              VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)''',
              (pid,f['match_key'],f['unp'],f['contract'],f['client'],f['ccy'],f['side'],f['operation'],f['zone'],f['debt'],f['fx'],'waiting',now()))
            if black:add_missing_position(db,pid,f['match_key'],'auto')
            n+=1
    return n


def calc_one(db,pid,posid,baseline,periods,enable_warnings=True):
    pos=db.execute('SELECT * FROM positions WHERE id=? AND project_id=?',(posid,pid)).fetchone()
    if not pos:return
    prev=None
    for period in periods:
        r=db.execute('SELECT * FROM position_periods WHERE project_id=? AND position_id=? AND period=?',(pid,posid,period)).fetchone()
        if not r:continue
        criteria=Criteria(r['ni'],r['pfn'],r['nvv'],r['restra'],r['security'],pos['operation'],pos['ccy'],bool(pos['micro']),bool(pos['poc']),pos['poc_rate'])
        try:gr,methodrate,why=classify(criteria)
        except MethodologyError as exc:
            if enable_warnings:warn(db,pid,'classification',f'{dd(period)}: {exc}','error',pos['match_key'],pos['client'],pos['contract'])
            gr=None;methodrate=None
        override=r['override_reason']
        if override and r['gr'] and r['rate'] is not None:
            grout=r['gr'];rate=r['rate']
        else:
            grout=str(gr) if gr is not None else '';rate=methodrate
        try:fx=get_fx(db,pid,pos,period,baseline)
        except MethodologyError as exc:
            fx=None
            if enable_warnings:warn(db,pid,'fx',f'{dd(period)}: {exc}','error',pos['match_key'],pos['client'],pos['contract'])
        od=round(r['debt']*fx,2) if fx is not None else None
        reserve=round(od*rate/100,2) if (rate is not None and od is not None) else None
        current={'debt':r['debt'],'fx':fx,'od':od,'rate':rate,'reserve':reserve,'criteria':criteria.as_dict()}
        if prev is not None and rate is not None and fx is not None and prev['rate'] is not None:
            try:factors=compute_factors(prev,current)
            except MethodologyError as exc:
                if enable_warnings:warn(db,pid,'factor',f'{dd(period)}: {exc}','error',pos['match_key'],pos['client'],pos['contract'])
                # Do not hide failure inside an ordinary valid factor.
                factors={'movement':0,'fx':0,'quality':0,'expenses':round(prev['reserve']-reserve,2),'rounding':0,'factors':{},'events':[]}
        else:
            factors={'movement':0,'fx':0,'quality':0,'expenses':0,'rounding':0,'factors':{},'events':[]}
        db.execute('''UPDATE position_periods SET fx=?,od=?,gr=?,rate=?,reserve=?,expenses=?,movement=?,revaluation=?,quality=?,rounding=?,factors=?,events=?
          WHERE project_id=? AND position_id=? AND period=?''',
          (fx,od,grout,rate,reserve,factors['expenses'],factors['movement'],factors['fx'],factors['quality'],factors['rounding'],js(factors['factors']),js(factors['events']),pid,posid,period))
        prev=current if rate is not None and fx is not None else None


def build(pid):
    initialize()
    with connect() as db:
        files={r['kind']:r['path'] for r in db.execute('SELECT * FROM uploads WHERE project_id=?',(pid,))}
        missing={'bp','fact','rates'}-files.keys()
        if missing:raise MethodologyError('Сначала загрузите: '+', '.join(sorted(missing)))
        db.execute('UPDATE projects SET status=? WHERE id=?',('building',pid))
        for table in ('fact_contracts','fact_clients','positions','position_periods','missing','warnings','fx'):
            db.execute(f'DELETE FROM {table} WHERE project_id=?',(pid,))
        db.commit()
        nfx=load_rates(db,pid,files['rates']);db.commit()
        fact=load_fact(db,pid,files['fact']);db.commit()
        baseline,periods,nplan=read_bp_positions(db,pid,files['bp'])
        confirmed=db.execute('SELECT note FROM projects WHERE id=?',(pid,)).fetchone()['note']
        if confirmed and confirmed != baseline:
            raise MethodologyError(f'Дата выверенного факта {dd(confirmed)} не совпадает с исходной датой БП {dd(baseline)}')
        db.execute('UPDATE projects SET fact_date=?,periods=? WHERE id=?',(baseline,js(periods),pid));db.commit()
        missing_count=reconcile(db,pid,baseline);db.commit()
        count=0
        for (posid,) in db.execute('SELECT id FROM positions WHERE project_id=? ORDER BY id',(pid,)):
            calc_one(db,pid,posid,baseline,periods)
            count+=1
            if count%1000==0:db.commit()
        # Compare calculated reserve vs actual fact reserve only for matched positions.
        for f in db.execute('SELECT * FROM fact_contracts WHERE project_id=?',(pid,)):
            rr=db.execute('''SELECT SUM(pp.reserve) r FROM positions p JOIN position_periods pp ON pp.position_id=p.id
                WHERE p.project_id=? AND p.match_key=? AND pp.period=?''',(pid,f['match_key'],baseline)).fetchone()
            if rr['r'] is None:continue
            diff=round(rr['r']-f['reserve'],2)
            if abs(diff)>.01:
                warn(db,pid,'reserve',f'Расчётный резерв отличается от фактического: {diff:+,.2f} BYN','warning',f['match_key'],f['client'],f['contract'],
                  {'calc_byn':round(rr['r'],2),'fact_byn':f['reserve'],'diff_byn':diff})
        error_count=db.execute("SELECT count(*) n FROM warnings WHERE project_id=? AND severity='error'",(pid,)).fetchone()['n']
        db.execute('UPDATE projects SET status=?,version=version+1 WHERE id=?',('needs_review' if error_count else 'ready',pid))
        db.commit()
        return {'positions':count,'fact_rows':fact['rows'],'business_plan_rows':nplan,'dates':periods,'missing':missing_count,
                'fx_rows':nfx,'errors':error_count,'status':'needs_review' if error_count else 'ready'}


def add_waiting(pid,keys):
    with connect() as db:
        project=db.execute('SELECT * FROM projects WHERE id=?',(pid,)).fetchone();periods=json.loads(project['periods'])
        count=0
        for key in keys:
            r=db.execute('SELECT status FROM missing WHERE project_id=? AND match_key=?',(pid,key)).fetchone()
            if r and r['status']=='waiting':
                posid=add_missing_position(db,pid,key)
                calc_one(db,pid,posid,project['fact_date'],periods)
                count+=1
        return count


def undo_waiting(pid,keys):
    with connect() as db:
        n=0
        for key in keys:
            row=db.execute('SELECT * FROM missing WHERE project_id=? AND match_key=?',(pid,key)).fetchone()
            if not row or row['status']!='added':continue
            posid=row['position_id'];db.execute('DELETE FROM position_periods WHERE project_id=? AND position_id=?',(pid,posid))
            db.execute('DELETE FROM positions WHERE project_id=? AND id=?',(pid,posid))
            db.execute('UPDATE missing SET status=?,position_id=NULL,added=NULL WHERE id=?',('waiting',row['id']))
            db.execute('INSERT INTO audit(project_id,at,action,position_id,reason) VALUES(?,?,?,?,?)',(pid,now(),'undo_missing',posid,key))
            n+=1
        return n

EDIT_FIELDS=('debt','ni','pfn','nvv','restra','security','gr','rate')

def edit(pid,position_id,period,field,value,reason=''):
    if field not in EDIT_FIELDS:raise MethodologyError('Редактирование поля не поддерживается')
    with connect() as db:
        proj=db.execute('SELECT * FROM projects WHERE id=?',(pid,)).fetchone()
        dates=json.loads(proj['periods']);
        if period not in dates:raise MethodologyError('Нет выбранной отчётной даты')
        pos=db.execute('SELECT * FROM positions WHERE id=? AND project_id=?',(position_id,pid)).fetchone()
        if not pos:raise MethodologyError('Договор не найден')
        if field in ('ni','pfn','nvv'): v=flag(value)
        elif field=='debt': v=val(value)
        elif field=='rate': v=rate_percent(value)
        elif field=='gr':
            v=gr_value(value)
            if v not in (1,2,3,4,5,6,'ПОК'):raise MethodologyError('Недопустимая ГР')
            v=str(v)
        else:v=str(value or '').strip()
        if field=='restra' and pos['side']=='внебаланс' and v:raise MethodologyError('Реструктуризация не может быть установлена на УО')
        if field in ('gr','rate') and not str(reason).strip():raise MethodologyError('Для ручного изменения группы риска или ставки обязательно укажите причину')
        dates_to_change=[period] if field=='debt' else dates[dates.index(period):]
        posids=[position_id]
        if field in ('ni','pfn','nvv'):
            posids=[row['id'] for row in db.execute('SELECT id FROM positions WHERE project_id=? AND unp=?',(pid,pos['unp']))]
        for id_ in posids:
            for d in dates_to_change:
                old=db.execute(f'SELECT {field} FROM position_periods WHERE project_id=? AND position_id=? AND period=?',(pid,id_,d)).fetchone()
                if old is None:continue
                if field in ('gr','rate'):
                    if field=='gr':
                        db.execute('UPDATE position_periods SET gr=?,override_reason=? WHERE project_id=? AND position_id=? AND period=?',(v,reason,pid,id_,d))
                    else:
                        db.execute('UPDATE position_periods SET rate=?,override_reason=? WHERE project_id=? AND position_id=? AND period=?',(v,reason,pid,id_,d))
                else:
                    if field in ('ni','pfn','nvv','restra','security'):
                        db.execute(f'UPDATE position_periods SET {field}=?,override_reason="" WHERE project_id=? AND position_id=? AND period=?',(v,pid,id_,d))
                    else:
                        db.execute(f'UPDATE position_periods SET {field}=? WHERE project_id=? AND position_id=? AND period=?',(v,pid,id_,d))
                db.execute('INSERT INTO audit(project_id,at,action,position_id,period,field,old,new,reason) VALUES(?,?,?,?,?,?,?,?,?)',
                    (pid,now(),'edit',id_,d,field,str(old[field]),str(v),reason))
        for id_ in posids:calc_one(db,pid,id_,proj['fact_date'],dates,enable_warnings=False)
        db.execute('UPDATE projects SET status=? WHERE id=?',('draft',pid))
        return {'positions_recalculated':len(posids),'dates_updated':len(dates_to_change)}


def set_comment(pid,unp,comment):
    with connect() as db:
        ids=[r['id'] for r in db.execute('SELECT id FROM positions WHERE project_id=? AND unp=?',(pid,unp))]
        for id_ in ids:db.execute('UPDATE positions SET comment=?,comment_manual=1 WHERE id=?',(str(comment),id_))
        db.execute('INSERT INTO audit(project_id,at,action,field,new) VALUES(?,?,?,?,?)',(pid,now(),'comment',unp,str(comment)))
        return len(ids)


def list_projects():
    with connect() as db:
        return [dict(r) for r in db.execute('SELECT id,name,created,fact_date,status,version FROM projects ORDER BY id DESC')]


def get_state(pid):
    with connect() as db:
        p=db.execute('SELECT * FROM projects WHERE id=?',(pid,)).fetchone()
        if not p:raise ValueError('Проект не найден')
        periods=json.loads(p['periods']);uploads=[dict(r) for r in db.execute('SELECT kind,original_name,uploaded FROM uploads WHERE project_id=?',(pid,))]
        totals=[]
        for r in db.execute('''SELECT period,COUNT(*) positions,COALESCE(SUM(od),0) od,COALESCE(SUM(reserve),0) reserve,
          COALESCE(SUM(expenses),0) expenses,COALESCE(SUM(movement),0) movement,COALESCE(SUM(quality),0) quality,
          COALESCE(SUM(revaluation),0) revaluation, COALESCE(SUM(rounding),0) rounding
          FROM position_periods WHERE project_id=? GROUP BY period ORDER BY period''',(pid,)):
            totals.append(dict(r))
        wrns={r['kind']:r['n'] for r in db.execute('SELECT kind,count(*) n FROM warnings WHERE project_id=? GROUP BY kind',(pid,))}
        wrns_error={r['kind']:r['n'] for r in db.execute('SELECT kind,count(*) n FROM warnings WHERE project_id=? AND severity="error" GROUP BY kind',(pid,))}
        miss={r['status']:r['n'] for r in db.execute('SELECT status,count(*) n FROM missing WHERE project_id=? GROUP BY status',(pid,))}
        return {'project':dict(p),'periods':periods,'uploads':uploads,'totals':totals,'warnings':wrns,'warnings_error':wrns_error,'missing':miss}


def list_positions(pid,period,search='',page=1,limit=50,side='',zone='',gr=''):
    page=max(1,int(page));limit=max(1,min(200,int(limit)));conditions=['p.project_id=?','pp.period=?'];args=[pid,period]
    if search:
        conditions.append('(p.client LIKE ? OR p.unp LIKE ? OR p.contract LIKE ?)')
        args+=['%'+search+'%']*3
    if side:conditions.append('p.side=?');args.append(side)
    if zone:conditions.append('p.zone LIKE ?');args.append('%'+zone+'%')
    if gr:conditions.append('pp.gr=?');args.append(gr)
    where=' AND '.join(conditions)
    with connect() as db:
        count=db.execute('SELECT count(*) n FROM positions p JOIN position_periods pp ON pp.position_id=p.id AND pp.project_id=p.project_id WHERE '+where,args).fetchone()['n']
        rows=db.execute('''SELECT p.id,p.client,p.unp,p.contract,p.parent_contract,p.ccy,p.side,p.operation,p.zone,p.src,p.rd,p.micro,p.comment,
          pp.period,pp.debt,pp.fx,pp.od,pp.ni,pp.pfn,pp.nvv,pp.restra,pp.security,pp.gr,pp.rate,pp.reserve,pp.expenses,
          pp.movement,pp.quality,pp.revaluation,pp.factors,pp.override_reason
          FROM positions p JOIN position_periods pp ON pp.position_id=p.id AND pp.project_id=p.project_id
          WHERE '''+where+' ORDER BY p.client,p.contract,p.id LIMIT ? OFFSET ?',args+[limit,(page-1)*limit]).fetchall()
        return {'total':count,'page':page,'limit':limit,'rows':[dict(r) for r in rows]}


def list_missing(pid,status='waiting',page=1,limit=100):
    page=max(1,int(page));limit=min(200,max(1,int(limit)))
    with connect() as db:
        where='project_id=?'+(' AND status=?' if status else '')
        args=[pid]+([status] if status else [])
        total=db.execute('SELECT count(*) n FROM missing WHERE '+where,args).fetchone()['n']
        rows=db.execute('SELECT * FROM missing WHERE '+where+' ORDER BY status,client,contract LIMIT ? OFFSET ?',args+[limit,(page-1)*limit]).fetchall()
        return {'total':total,'rows':[dict(r) for r in rows]}


def list_warnings(pid,kind='',page=1,limit=100):
    page=max(1,int(page));limit=min(200,max(1,int(limit)))
    with connect() as db:
        where='project_id=?'+(' AND kind=?' if kind else '')
        args=[pid]+([kind] if kind else [])
        total=db.execute('SELECT count(*) n FROM warnings WHERE '+where,args).fetchone()['n']
        rows=db.execute('SELECT * FROM warnings WHERE '+where+' ORDER BY CASE severity WHEN "error" THEN 0 WHEN "warning" THEN 1 ELSE 2 END,id LIMIT ? OFFSET ?',args+[limit,(page-1)*limit]).fetchall()
        return {'total':total,'rows':[dict(r) for r in rows]}


def factor_summary(pid,period,search='',zone='',side=''):
    # filters apply to the same set of positions and recompute bridge; all filtering is server-side
    args=[pid,period];conditions=['p.project_id=?','pp.period=?']
    if search:conditions.append('(p.unp LIKE ? OR p.client LIKE ? OR p.contract LIKE ?)');args+=['%'+search+'%']*3
    if zone:conditions.append('p.zone LIKE ?');args.append('%'+zone+'%')
    if side:conditions.append('p.side=?');args.append(side)
    factors=defaultdict(float);events=defaultdict(int)
    with connect() as db:
        sql='''SELECT pp.*,p.unp,p.ccy,p.client,p.contract FROM position_periods pp
          JOIN positions p ON p.id=pp.position_id WHERE '''+' AND '.join(conditions)
        sums={'od':0.,'reserve':0.,'expenses':0.,'movement':0.,'revaluation':0.,'quality':0.,'rounding':0.}
        clients=set()
        for r in db.execute(sql,args):
            clients.add(r['unp'])
            for k in sums:sums[k]+=r[k] or 0
            for k,v in json.loads(r['factors'] or '{}').items():factors[k]+=v
            for k in json.loads(r['events'] or '[]'):events[k]+=1
    return {'period':period,'totals':{k:round(v,2) for k,v in sums.items()},'subfactors':{k:round(v,2) for k,v in factors.items()},
            'events':dict(events),'clients':len(clients),'factor_names':FACTOR_NAMES}


def client_report(pid,period,search='',limit=200,page=1):
    # group per UНП and use abs monthly expenses >=100000; all other clients in one standard group
    with connect() as db:
        allrows=db.execute('''SELECT p.unp,MAX(p.client) client,MAX(p.zone) zone,MAX(p.comment) comment,
          SUM(pp.expenses) expenses,SUM(pp.reserve) reserve,SUM(pp.movement) movement,SUM(pp.quality) quality,SUM(pp.revaluation) revaluation,
          SUM(pp.od) od FROM positions p JOIN position_periods pp ON p.id=pp.position_id
          WHERE p.project_id=? AND pp.period=? GROUP BY p.unp ORDER BY ABS(SUM(pp.expenses)) DESC''',(pid,period))
        important=[];standard={'client':'Стандартный портфель','unp':'','expenses':0.,'reserve':0.,'movement':0.,'quality':0.,'revaluation':0.,'od':0.,'zone':'','comment':''};standard_count=0
        for r in allrows:
            row=dict(r)
            if abs(row['expenses'])>=100000:
                if not search or search.lower() in (row['client']+' '+row['unp']).lower():important.append(row)
            else:
                for key in ('expenses','reserve','movement','quality','revaluation','od'):standard[key]+=row[key] or 0.
                standard_count+=1
        important=important[(max(1,page)-1)*limit:max(1,page)*limit]
        for row in important:
            debt_changes=[]
            for c in db.execute('''SELECT p.ccy, SUM(CASE WHEN a.period=? THEN a.debt ELSE 0 END) debt_prev,
                SUM(CASE WHEN a.period=? THEN a.debt ELSE 0 END) debt_cur
                FROM positions p JOIN position_periods a ON a.position_id=p.id
                WHERE p.project_id=? AND p.unp=? AND a.period IN (?,?) GROUP BY p.ccy''',
                (_prior_period(db,pid,period),period,pid,row['unp'],_prior_period(db,pid,period),period)):
                delta=(c['debt_cur'] or 0)-(c['debt_prev'] or 0)
                if abs(delta)>.000001:debt_changes.append(f'{delta/1e6:+.3f} млн {c["ccy"]}')
            label='; '.join(debt_changes)
            factors=[]
            for k,name in (('movement','Движение КП'),('quality','Изменение качества'),('revaluation','Переоценка')):
                if abs(row[k] or 0)>.005:factors.append(name)
            row['auto_comment']=('. '.join([('Изменение задолженности: '+label) if label else 'Задолженность без изменений',
                'Факторы: '+(', '.join(factors) if factors else 'без изменений')])+'.')
        for k in ('expenses','reserve','movement','quality','revaluation','od'):standard[k]=round(standard[k],2)
        standard['clients']=standard_count
        return {'period':period,'important':important,'standard':standard,'threshold':100000}


def _prior_period(db,pid,period):
    p=db.execute('SELECT periods FROM projects WHERE id=?',(pid,)).fetchone()
    periods=json.loads(p['periods']);i=periods.index(period)
    return periods[i-1] if i>0 else periods[0]


def period_debt_horizon(pid,metric='debt',search='',limit=50,page=1):
    if metric not in ('debt','od','reserve','expenses','gr','rate','ni','pfn','nvv','security'):raise ValueError('Недопустимый показатель')
    with connect() as db:
        periods=json.loads(db.execute('SELECT periods FROM projects WHERE id=?',(pid,)).fetchone()['periods'])
        c=' AND (p.client LIKE ? OR p.unp LIKE ? OR p.contract LIKE ?)' if search else ''
        args=[pid]+(['%'+search+'%']*3 if search else [])
        ids=[dict(r) for r in db.execute('SELECT id,client,contract,ccy,side,unp,src,zone FROM positions p WHERE p.project_id=?'+c+' ORDER BY p.client,p.contract LIMIT ? OFFSET ?',args+[limit,(max(1,page)-1)*limit])]
        values=defaultdict(dict)
        if ids:
            q=','.join('?' for _ in ids)
            for row in db.execute(f'SELECT position_id,period,{metric} v FROM position_periods WHERE project_id=? AND position_id IN ({q})',(pid,*[x['id'] for x in ids])):
                values[row['position_id']][row['period']]=row['v']
        for r in ids:r['values']=values[r['id']]
        return {'periods':periods,'metric':metric,'rows':ids}


def save_version(pid,title):
    """Immutable snapshot for current project; may be disk-intensive for very large portfolios."""
    with connect() as db:
        p=db.execute('SELECT version FROM projects WHERE id=?',(pid,)).fetchone()
        if not p:raise ValueError('Нет проекта')
        version=db.execute('SELECT coalesce(MAX(version),0)+1 n FROM versions WHERE project_id=?',(pid,)).fetchone()['n']
        version_dir=DATA/str(pid)/'versions';version_dir.mkdir(exist_ok=True,parents=True)
        target=version_dir/f'checkpoint_{version}.sqlite3'
        # SQLite's backup API provides a consistent snapshot even with WAL enabled.
        with sqlite3.connect(str(target)) as backup:db.backup(backup)
        db.execute('INSERT INTO versions(project_id,version,created,title,backup_path) VALUES(?,?,?,?,?)',(pid,version,now(),title,str(target)))
        has_errors=db.execute('SELECT COUNT(*) n FROM warnings WHERE project_id=? AND severity="error"',(pid,)).fetchone()['n']
        db.execute('UPDATE projects SET status=?,version=? WHERE id=?',('needs_review' if has_errors else 'fixed',version,pid))
        return {'version':version,'path':str(target),'title':title}


def list_versions(pid):
    with connect() as db:return [dict(r) for r in db.execute('SELECT id,version,created,title FROM versions WHERE project_id=? ORDER BY version DESC',(pid,))]
