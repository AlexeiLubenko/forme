"""Focused monetary-regression cases for the agreed attribution v2."""
import copy, tempfile, unittest
from pathlib import Path
from core import parse_excel, summarize_pair, RESERVE_NUMS
from factor_engine import FACTORS, SUBFACTORS
import server

ROOT=Path(__file__).parent
EXAMPLES=ROOT/'examples'
STATS={
 'ЮЛ и ИП|1':{'el':3000.,'ead':100000.},
 'ЮЛ и ИП|2':{'el':8000.,'ead':100000.},
 'ЮЛ и ИП|3':{'el':40000.,'ead':100000.},
 'Банки|1':{'el':3000.,'ead':100000.},
 'Физические лица|1':{'el':3000.,'ead':100000.},
}

def record(crm,contract,tranche='',currency='BYN',stage=1,ead=1000,el=30,active=None,uo=0,fx=1,
           individual='',client='ООО Тест',status='ю',rating=4,sub='Кредиты'):
    if active is None:active=ead-uo
    parts={str(k):0. for k in RESERVE_NUMS};parts['71']=el
    if uo:
        parts['87']=uo*.02;parts['71']=el-parts['87']
    return {'date':'2026-11-05','status':status,'crm':crm,'unp':crm,'client':client,'subportfolio':sub,
         'rating':rating,'stage':stage,'contract':contract,'tranche':tranche,'currency':currency,
         'fx':fx,'ead':ead,'el':el,'rate':el/ead if ead else 0.,'pd':.05,'lgd':.4,
         'individual':individual,'maturity':'2027-11-05','risk_fields':{'14':str(rating),'17':'Нет'},
         'active':active,'uo':uo,'off':0.,'uo_reserve':parts['87'], 'off_reserve':0.,
         'reserves':parts,'signals':{},'line':2}

def calc(a,b):
    for r in a:r['date']='2026-10-30'
    for r in b:r['date']='2026-11-05'
    return summarize_pair({'date':'2026-10-30','count':len(a),'rows':a,'warnings':[]},
         {'date':'2026-11-05','count':len(b),'rows':b,'warnings':[]},
          base_stage_rates=STATS,current_stage_rates=STATS)

def check(test,report):
    test.assertAlmostEqual(report['totals']['expenses'],sum(report['factors'].values()),places=6)
    test.assertAlmostEqual(report['factors']['Движение КП'],sum(report['subfactors'].values()),places=6)
    for r in report['positions']:
        test.assertAlmostEqual(r['expenses'],sum(r['factors'].values()),places=6)
        test.assertAlmostEqual(r['factors']['Движение КП'],sum(r['subfactors'].values()),places=6)

class NewFactors(unittest.TestCase):
    def test_existing_stage_and_amount_split(self):
        a=[record('1','D-1',stage=1,ead=100000,el=3000)]
        b=[record('1','D-1',stage=2,ead=120000,el=12000,rating=7)]
        r=calc(a,b);check(self,r)
        self.assertAlmostEqual(r['factors']['Переход 1 → 2'],-5500.)
        self.assertAlmostEqual(r['factors']['Движение КП'],-3500.)
        self.assertEqual(r['transitions'][0]['reasons'][0]['label'],'Рейтинг')
    def test_new_client_stage2_current_stage1(self):
        a=[];b=[record('NEW','K-1',stage=2,ead=100000,el=15000)]
        r=calc(a,b);check(self,r)
        self.assertAlmostEqual(r['factors']['Новые выдачи'],-3000)
        self.assertAlmostEqual(r['factors']['Переход 1 → 2'],-12000)
        self.assertTrue(r['transitions'][0]['synthetic'])
    def test_new_client_stage3_current_stage1(self):
        r=calc([],[record('NEW','K-2',stage=3,ead=100000,el=40000)]);check(self,r)
        self.assertAlmostEqual(r['factors']['Новые выдачи'],-3000)
        self.assertAlmostEqual(r['factors']['Выход в дефолт'],-37000)
    def test_new_tranche_existing_contract_is_movement(self):
        a=[record('T','D-1','D-1_1',ead=1000,el=30)]
        b=[record('T','D-1','D-1_1',ead=1000,el=30),record('T','D-1','D-1_2',ead=500,el=15)]
        r=calc(a,b);check(self,r)
        self.assertEqual(r['factors']['Новые выдачи'],0.)
        self.assertAlmostEqual(r['factors']['Движение КП'],-15.)
    def test_new_contract_existing_client_is_new_issuance(self):
        a=[record('C','D-1',ead=1000,el=30)]
        b=[record('C','D-1',ead=1000,el=30),record('C','D-2',ead=1000,el=50)]
        r=calc(a,b);check(self,r)
        self.assertAlmostEqual(r['factors']['Новые выдачи'],-50)
    def test_individual_exclusive(self):
        a=[record('I','A',stage=1,ead=10000,el=300)]
        b=[record('I','A',stage=3,ead=15000,el=800,individual='Да')]
        r=calc(a,b);check(self,r)
        self.assertAlmostEqual(r['factors']['Индивидуальная оценка'],-500.)
        self.assertAlmostEqual(sum(abs(x) for f,x in r['factors'].items() if f!='Индивидуальная оценка'),0.)
    def test_fx_revalues_old_exposure_then_new_volume(self):
        a=[record('X','USD',currency='USD',fx=3.,ead=30.,el=3.)]
        b=[record('X','USD',currency='USD',fx=3.2,ead=48.,el=4.8)]
        r=calc(a,b);check(self,r)
        self.assertAlmostEqual(r['factors']['Переоценка'],-.2)
        self.assertAlmostEqual(r['factors']['Движение КП'],-1.6)
    def test_drawdown_same_contract_2_positions(self):
        def row(tranche,active,uo):
            return record('D','D-1',tranche,ead=active+uo,el=active*.05+uo*.02,active=active,uo=uo)
        a=[row('D-1_1',2_000_000,0),row('',0,8_000_000)]
        b=[row('D-1_1',5_000_000,0),row('',0,5_000_000)]
        r=calc(a,b);check(self,r)
        self.assertAlmostEqual(r['subfactors']['Выборка: УО → актив'],-90000)
        self.assertAlmostEqual(r['factors']['Движение КП'],-90000)
    def test_fl_subportfolio_factor_matches_expense(self):
        a=[record('F','F1',ead=10000,el=100,status='ф',sub='Ипотека')]
        b=[record('F','F1',ead=10000,el=150,status='ф',sub='Ипотека')]
        r=calc(a,b);check(self,r)
        self.assertAlmostEqual(r['fl_subportfolios'][0]['expenses'],sum(r['fl_subportfolios'][0]['factors'].values()))
    def test_demo_stream_and_scoped_exports(self):
        orig=(server.DB,server.STORAGE,server.BASE_PATH)
        with tempfile.TemporaryDirectory() as d:
            server.DB=Path(d)/'db.sqlite3';server.STORAGE=Path(d);server.BASE_PATH=Path(d)/'base.xlsx'
            try:
                server.save_base(EXAMPLES/'01_fact_base_2026-10-30.xlsx','base.xlsx')
                server.save_run(EXAMPLES/'02_fact_current_2026-11-05.xlsx','daily.xlsx')
                r=server.read_report();self.assertEqual(r['method_version'],'2.0')
                check(self,{'totals':r['totals'],'factors':r['factors'],'subfactors':r['subfactors'],'positions':[]})
                sc=server.factor_scope(r,'ЮЛ и ИП',['1001'])
                self.assertAlmostEqual(sc['reconciliation'],0.,places=5)
                self.assertAlmostEqual(sc['movement_reconciliation'],0.,places=5)
                self.assertTrue(server.stage_transitions(r,'ЮЛ и ИП',['1001']))
                view,_=server.scoped_report(r,'ЮЛ и ИП',['1001'])
                from large_export import export_to_path
                from openpyxl import load_workbook
                path=Path(d)/'export.xlsx';export_to_path(view,server.DB,path,{'segment':'ЮЛ и ИП','clients':['1001']})
                wb=load_workbook(path,read_only=True)
                self.assertIn('Подфакторы движения КП',wb.sheetnames)
                self.assertIn('Переходы_стадий',wb.sheetnames)
                self.assertEqual({p.name for p in Path(d).glob('*.xlsx')},{'base.xlsx','export.xlsx'})
            finally:server.DB,server.STORAGE,server.BASE_PATH=orig

if __name__=='__main__':unittest.main()
