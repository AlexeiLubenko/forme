"""Optional UI smoke test for drag-and-drop. Requires playwright and local Chromium."""
from pathlib import Path
from playwright.sync_api import sync_playwright

ROOT=Path(__file__).resolve().parent
html=(ROOT/'static/index.html').read_text(encoding='utf8')
html=html.replace('<link rel="stylesheet" href="/style.css">','<style>'+(ROOT/'static/style.css').read_text(encoding='utf8')+'</style>')
html=html.replace('<script src="/app.js"></script>','<script>'+(ROOT/'static/app.js').read_text(encoding='utf8')+'</script>')

with sync_playwright() as playwright:
    browser=playwright.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
    page=browser.new_page(viewport={'width':1430,'height':1040},accept_downloads=True)
    errors=[]
    page.on('pageerror',lambda error:errors.append(str(error)))
    page.goto('about:blank')
    page.evaluate('''() => {
      window.__uploads=[];
      window.fetch=async (uri, opts={}) => {
        let url=String(uri);
        if(url.includes('/api/base') || url.includes('/api/run')){
          window.__uploads.push({url, name:decodeURIComponent(opts.headers['X-Filename']), size:opts.body.size});
          let value=url.includes('/api/base')?{date:'2026-10-30',rows:10,warnings:0}:{date:'2026-11-05',expenses:-60000};
          return {ok:true,headers:{get:()=>"application/json"},json:async()=>value};
        }
        let value=url.includes('/api/state')?{archive:{bases:[],reports:[]},has_base:false,has_reports:false}:{active:false,rows:0};
        return {ok:true,headers:{get:()=>"application/json"},json:async()=>value};
      };
    }''')
    page.set_content(html,wait_until='load')
    page.wait_for_selector('#page-uploads.active')
    assert page.locator('#btnBase').is_disabled()
    assert page.locator('#btnRun').is_disabled()
    # Drag a file from the OS into the first panel.
    page.evaluate('''() => {
      const dt=new DataTransfer();
      dt.items.add(new File([new Uint8Array(1024)],'Факт_начало_2026-10-30.xlsx',{type:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'}));
      for(const name of ['dragenter','dragover','drop']){
        document.getElementById('baseDropzone').dispatchEvent(new DragEvent(name,{bubbles:true,cancelable:true,dataTransfer:dt}));
      }
    }''')
    assert page.locator('#baseFilename').inner_text()=='Факт_начало_2026-10-30.xlsx'
    assert page.locator('#btnBase').is_enabled()
    assert page.locator('#btnRun').is_disabled()
    page.locator('#baseDropzone').screenshot(path=str(ROOT/'preview_dragdrop_base.png'))
    # Invalid CSV cannot replace selected XLSX.
    page.evaluate('''() => {
      const dt=new DataTransfer();dt.items.add(new File(['invalid'],'report.csv',{type:'text/csv'}));
      document.getElementById('baseDropzone').dispatchEvent(new DragEvent('drop',{bubbles:true,cancelable:true,dataTransfer:dt}));
    }''')
    assert page.locator('#baseFilename').inner_text()=='Факт_начало_2026-10-30.xlsx'
    # File selector works too, including names with spaces and Cyrillic.
    with page.expect_file_chooser() as chooser:
        page.locator('#currentDropzone').click()
    chooser.value.set_files(str(ROOT/'examples/02_fact_current_2026-11-05.xlsx'))
    assert page.locator('#btnRun').is_enabled()
    # File drop outside a zone should not navigate.
    page.evaluate('''() => {
       const dt=new DataTransfer();dt.items.add(new File(['a'],'unwanted.xlsx'));
       document.body.dispatchEvent(new DragEvent('drop',{bubbles:true,cancelable:true,dataTransfer:dt}));
    }''')
    assert page.locator('#page-uploads.active').count()==1
    # Upload path uses the dropped file as the raw POST body.
    page.locator('#btnBase').click()
    page.wait_for_function('window.__uploads.length===1')
    page.wait_for_function('!document.getElementById("baseDropzone").classList.contains("is-uploading")')
    assert page.evaluate('window.__uploads[0].name')=='Факт_начало_2026-10-30.xlsx'
    assert page.evaluate('window.__uploads[0].size')==1024
    assert page.locator('#btnBase').is_disabled()
    page.locator('#btnRun').click()
    page.wait_for_function('window.__uploads.length===2')
    page.wait_for_function('!document.getElementById("currentDropzone").classList.contains("is-uploading")')
    assert page.evaluate('window.__uploads[1].name')=='02_fact_current_2026-11-05.xlsx'
    assert page.locator('#btnRun').is_disabled()
    page.locator('.nav[data-page="uploads"]').click()
    page.screenshot(path=str(ROOT/'preview_dragdrop_uploads.png'),full_page=True)
    assert not errors, errors
    print('PASS: drag/drop, invalid files, chooser, non-zone drop, upload actions, two URLs, no JS errors')
    browser.close()
