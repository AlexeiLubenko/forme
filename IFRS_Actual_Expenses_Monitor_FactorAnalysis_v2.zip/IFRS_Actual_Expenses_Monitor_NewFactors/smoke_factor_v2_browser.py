"""Offline browser smoke test: real JS+DOM/CSS with API-shaped saved results."""
from pathlib import Path
from playwright.sync_api import sync_playwright
from server import read_report,archive,get_positions,get_banks,get_significant,factor_scope,search_clients,stage_transitions
from copy import deepcopy
ROOT=Path(__file__).parent
r=read_report();state=archive()
scopes={}
for s in ('Все','ЮЛ и ИП','Физические лица','Банки'):
    scopes[s]=factor_scope(r,s)
client_scopes={'1001':factor_scope(r,'ЮЛ и ИП',['1001'])}
for sub in r['fl_subportfolios']:
    client_scopes['sub:'+sub['subportfolio']]=factor_scope(r,'Физические лица',subportfolio=sub['subportfolio'])
transitions=stage_transitions(r)
mock={'state':{'archive':state,'has_base':True,'has_reports':True},
      'report':{k:v for k,v in r.items() if k!='positions'},
      'scopes':scopes,'client_scopes':client_scopes,
      'transitions':transitions,'transition_summary':r.get('transition_summary',{}),
      'transition_by_segment':r.get('transition_by_segment',{}),
      'transition_by_fl':r.get('transition_by_fl_subportfolio',{}),
      'positions':get_positions(r,'ЮЛ и ИП','',1,30),
      'positions_client':get_positions(r,'ЮЛ и ИП','',1,30,['1001']),
      'significant':get_significant(r,1,30),
      'significant_client':get_significant(r,1,30,clients=['1001']),
      'banks':get_banks(r,1,50),
      'client_search':search_clients(r,'ЮЛ и ИП','Альфа')}
html=(ROOT/'static/index.html').read_text(encoding='utf8').replace('<link rel="stylesheet" href="/style.css">','<style>'+(ROOT/'static/style.css').read_text(encoding='utf8')+'</style>').replace('<script src="/app.js"></script>','<script>'+(ROOT/'static/app.js').read_text(encoding='utf8')+'</script>')
errors=[]
with sync_playwright() as pw:
    browser=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
    page=browser.new_page(viewport={'width':1510,'height':980})
    page.on('pageerror',lambda err:errors.append(str(err)))
    page.goto('about:blank')
    page.evaluate('''m=>{
      window.__MOCK=m;
      window.fetch=async function(uri,opt){
        let url=new URL(String(uri),'http://localhost'),q=url.searchParams,data={};
        const s=q.get('segment')||'Все';const id=q.get('crm'),sub=q.get('subportfolio');
        if(url.pathname==='/api/state')data=m.state;
        else if(url.pathname==='/api/report')data=m.report;
        else if(url.pathname==='/api/factor-scope')data=(id?m.client_scopes[id]:sub?m.client_scopes['sub:'+sub]:m.scopes[s])||m.scopes[s];
        else if(url.pathname==='/api/client-search')data={clients:m.client_search};
        else if(url.pathname==='/api/transitions'){
          let rows=m.transitions.filter(t=>(s==='Все'||t.segment===s)&&(!id||t.crm===id));
          let summary=(s==='Физические лица'&&sub?m.transition_by_fl[sub]:id?{'1 → 2':{'clients':1,'expenses':-377295,'ead0':1500000,'ead1':8970000}}:(s==='Все'?m.transition_summary:m.transition_by_segment[s]))||{};
          data={rows:rows,summary:summary};
        }
        else if(url.pathname==='/api/positions')data=id?m.positions_client:m.positions;
        else if(url.pathname==='/api/significant')data=id?m.significant_client:m.significant;
        else if(url.pathname==='/api/banks')data=m.banks;
        else if(url.pathname==='/api/stage-cause')data={saved:true};
        else data={};
        return {ok:true,headers:{get:()=>"application/json"},json:async()=>data,text:async()=>JSON.stringify(data)};
      }
    }''',mock)
    page.set_content(html,wait_until='load')
    page.wait_for_timeout(700)
    assert page.locator('#mainKpis .kpi').count()==4
    page.locator('.nav[data-page="factors"]').click()
    page.wait_for_timeout(300)
    assert page.locator('#factorKpis .kpi').count()==4
    assert 'Движение КП' in page.locator('#factorBars').inner_text()
    assert 'Выборка: УО → актив' in page.locator('#factorSubfactors').inner_text()
    page.screenshot(path=str(ROOT/'preview_new_factors_all.png'),full_page=True)
    page.locator('#factorSegment').select_option('ЮЛ и ИП')
    page.locator('#factorClientSearch').fill('Альфа')
    page.locator('#factorClientSearch').press('Enter')
    page.wait_for_timeout(200)
    assert page.locator('#factorClientSuggestions button').count()>=1
    page.locator('#factorClientSuggestions button').first.click()
    page.wait_for_timeout(250)
    assert 'Альфа' in page.locator('#factorScopeLabel').inner_text()
    assert page.locator('#factorTransitions .stage-cause-select').count()>=1
    page.screenshot(path=str(ROOT/'preview_new_factors_client.png'),full_page=True)
    sel=page.locator('#factorTransitions .stage-cause-select').first
    sel.select_option('Рейтинг')
    page.wait_for_timeout(150)
    assert 'сохранена' in page.locator('#flash').inner_text().lower()
    page.locator('#factorSegment').select_option('Физические лица')
    page.locator('#factorSubportfolio').select_option('Ипотека')
    page.wait_for_timeout(200)
    assert 'Ипотека' in page.locator('#factorScopeLabel').inner_text()
    page.screenshot(path=str(ROOT/'preview_new_factors_fl.png'),full_page=True)
    page.locator('#factorSegment').select_option('Банки')
    page.wait_for_timeout(200)
    assert page.locator('#factorKpis .kpi').count()==4
    page.screenshot(path=str(ROOT/'preview_new_factors_banks.png'),full_page=True)
    assert not errors,errors
    print('PASS UI: overview, factors, client filter, stage causes, FL subportfolio, banks')
    browser.close()
