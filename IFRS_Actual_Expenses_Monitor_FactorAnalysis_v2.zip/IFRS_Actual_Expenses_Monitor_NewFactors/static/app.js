'use strict';
let report=null, historyCache=null, page='overview', detailSegment='ЮЛ и ИП', positionPage=1, searchText='', lastRun=null;
let factorScope=null, factorClients=new Map(), factorSubportfolio='',factorRequestSerial=0,stagePage=1;
const $=id=>document.getElementById(id);
const fmt=(n,d=2)=>Number(n||0).toLocaleString('ru-RU',{minimumFractionDigits:d,maximumFractionDigits:d});
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const sign=n=>Number(n)>0?'+':'';
const money=n=>`${sign(n)}${fmt(n)} BYN`;
const hue=n=>n<0?'negative':n>0?'positive':'';
const el=(label,val,sub,highlight=false,icon='▥')=>`<div class="kpi ${highlight?'highlight':''}"><span class="kicon">${icon}</span><div class="klabel">${esc(label)}</div><div class="kvalue ${highlight?'negative':''}">${esc(val)}</div><div class="ksub">${esc(sub)}</div></div>`;
function alertBox(msg,error=false){let box=$('flash');box.textContent=msg;box.classList.toggle('error',error);box.hidden=false;setTimeout(()=>{box.hidden=true;},6500);}
async function api(path,opts){let response=await fetch(path,opts);let ct=response.headers.get('content-type')||'';let data=ct.includes('json')?await response.json():await response.text();if(!response.ok)throw Error(data.error||('HTTP '+response.status));return data;}
function switchPage(next){page=next;document.querySelectorAll('.page').forEach(p=>p.classList.toggle('active',p.id==='page-'+next));document.querySelectorAll('.nav').forEach(n=>n.classList.toggle('active',n.dataset.page===next));let labels={overview:'Обзор расходов',factors:'Факторный анализ',uploads:'Загрузка фактов',history:'История отчётов'};$('breadcrumb').textContent=labels[next];$('emptyState').hidden=!!report||next==='uploads'||next==='history';if(next==='factors')renderFactors();if(next==='history')renderHistory();}
window.switchPage=switchPage;
for(const n of document.querySelectorAll('.nav'))n.addEventListener('click',()=>switchPage(n.dataset.page));
$('viewSegment').addEventListener('change',renderOverview);
$('factorSegment').addEventListener('change',()=>{factorClients.clear();factorSubportfolio='';stagePage=1;renderFactors();});
$('factorSubportfolio').addEventListener('change',event=>{factorSubportfolio=event.target.value;stagePage=1;renderFactors();});
// The browser keeps the File object in memory until upload. No FileReader or XLSX parsing
// happens on the client, so the existing streamed 400k-row backend is unchanged.
const selectedUploads={base:null,current:null};
const uploadBusy={base:false,current:false};
const MAX_EXCEL_SIZE=768*1024*1024;
const uploadUi={
  base:{input:'baseFile',drop:'baseDropzone',selected:'baseSelected',name:'baseFilename',size:'baseFileSize',title:'baseDropTitle',button:'btnBase',clear:'baseClear'},
  current:{input:'currentFile',drop:'currentDropzone',selected:'currentSelected',name:'currentFilename',size:'currentFileSize',title:'currentDropTitle',button:'btnRun',clear:'currentClear'}
};
function validateExcelFile(file){
 if(!file||!file.name)return 'Перетащите один файл Excel в формате .xlsx, не папку.';
 if(!/\.xlsx$/i.test(file.name)||file.name.startsWith('~$'))return 'Поддерживаются только файлы .xlsx (временные файлы Excel ~$ не подходят).';
 if(!file.size)return 'Файл пустой. Выберите заполненный отчёт .xlsx.';
 if(file.size>MAX_EXCEL_SIZE)return 'Файл больше 768 МБ. Размер превышает ограничение загрузки.';
 return null;
}
function showSelectedUpload(type){
 const cfg=uploadUi[type],file=selectedUploads[type],busy=uploadBusy[type];
 const zone=$(cfg.drop),selected=$(cfg.selected);
 zone.classList.toggle('is-ready',!!file);
 zone.classList.toggle('is-uploading',busy);
 zone.setAttribute('aria-busy',String(busy));
 zone.setAttribute('aria-disabled',String(busy));
 $(cfg.title).textContent=file?'Файл выбран — можно загружать':'Перетащите Excel-файл сюда';
 selected.hidden=!file;
 if(file){
   $(cfg.name).textContent=file.name;
   $(cfg.size).textContent=`${(file.size/1024/1024).toLocaleString('ru-RU',{maximumFractionDigits:2})} МБ · файл готов к загрузке`;
 }
 $(cfg.button).disabled=busy||!file;
 $(cfg.clear).disabled=busy;
}
function setSelectedUpload(type,file){
 if(uploadBusy[type])return false;
 const error=validateExcelFile(file);
 if(error){alertBox(error,true);return false;}
 selectedUploads[type]=file;
 showSelectedUpload(type);
 return true;
}
function clearSelectedUpload(type){
 if(uploadBusy[type])return;
 selectedUploads[type]=null;
 $(uploadUi[type].input).value='';
 showSelectedUpload(type);
}
function setUploadBusy(type,busy){uploadBusy[type]=busy;showSelectedUpload(type);}
function initializeDropzones(){
 for(const type of ['base','current']){
   const cfg=uploadUi[type],input=$(cfg.input),zone=$(cfg.drop);
   let dragDepth=0;
   // A programmatic input.click() must not bubble back to the zone's click handler.
   input.addEventListener('click',event=>event.stopPropagation());
   input.addEventListener('change',()=>{
     if(input.files.length)setSelectedUpload(type,input.files[0]);
     // Clearing the input permits the same file to be picked twice, e.g. after a failure.
     input.value='';
   });
   zone.addEventListener('click',()=>{if(!uploadBusy[type])input.click();});
   zone.addEventListener('keydown',event=>{
     if(event.key==='Enter'||event.key===' '){event.preventDefault();if(!uploadBusy[type])input.click();}
   });
   zone.addEventListener('dragenter',event=>{
     if(!event.dataTransfer?.types?.includes('Files'))return;
     event.preventDefault();if(uploadBusy[type])return;
     dragDepth++;zone.classList.add('is-dragover');
   });
   zone.addEventListener('dragover',event=>{
     if(!event.dataTransfer?.types?.includes('Files'))return;
     event.preventDefault();event.dataTransfer.dropEffect=uploadBusy[type]?'none':'copy';
     if(!uploadBusy[type])zone.classList.add('is-dragover');
   });
   zone.addEventListener('dragleave',event=>{
     if(!event.dataTransfer?.types?.includes('Files'))return;
     dragDepth=Math.max(0,dragDepth-1);
     if(!dragDepth)zone.classList.remove('is-dragover');
   });
   zone.addEventListener('drop',event=>{
     if(!event.dataTransfer?.types?.includes('Files'))return;
     event.preventDefault();event.stopPropagation();
     dragDepth=0;zone.classList.remove('is-dragover');
     if(uploadBusy[type])return;
     if(event.dataTransfer.files.length!==1){alertBox('Перетащите один Excel-файл .xlsx за раз.',true);return;}
     setSelectedUpload(type,event.dataTransfer.files[0]);
   });
   $(cfg.clear).addEventListener('click',()=>clearSelectedUpload(type));
   showSelectedUpload(type);
 }
 // Dropping a local file outside of a dropzone must not navigate away and lose work.
 for(const eventName of ['dragover','drop'])document.addEventListener(eventName,event=>{
   if(event.dataTransfer?.types?.includes('Files'))event.preventDefault();
 });
}
initializeDropzones();
async function init(){try{let state=await api('/api/state');historyCache=state.archive;renderHistory();if(state.has_reports){await loadReport(state.archive.reports[0].id);}else{$('emptyState').hidden=false;switchPage('uploads');}renderBaseInfo();}catch(e){alertBox(e.message,true);}}
function renderBaseInfo(){let b=historyCache?.bases?.[0];$('baseInfo').textContent=b?`Сохранена база на ${b.date} · версия №${b.id} · ${b.filename}`:'База пока не загружена';}
async function refreshCurrent(){try{const s=await api('/api/state');historyCache=s.archive;renderBaseInfo();renderHistory();if(s.has_reports)await loadReport(s.archive.reports[0].id);else switchPage('uploads');alertBox('Данные обновлены');}catch(e){alertBox(e.message,true);}}
window.refreshCurrent=refreshCurrent;
async function uploadExcel(endpoint,file,btn,label){
 btn.disabled=true;btn.textContent='Загрузка файла...';
 let poll=setInterval(async()=>{try{let status=await api('/api/progress');if(status.active)btn.textContent=`${status.stage} · ${Number(status.rows||0).toLocaleString('ru-RU')} строк`;}catch(e){}},1200);
 try{
   // Raw streamed file upload: does not create one huge multipart body in the Python server.
   return await api(endpoint,{method:'POST',headers:{'Content-Type':'application/octet-stream','X-Filename':encodeURIComponent(file.name)},body:file});
 }finally{clearInterval(poll);btn.disabled=true;btn.textContent=label;}
}
async function uploadBase(){let file=selectedUploads.base;if(!file)return alertBox('Перетащите или выберите Excel-файл базы',true);setUploadBusy('base',true);try{let res=await uploadExcel('/api/base',file,$('btnBase'),'Сохранить факт на начало');selectedUploads.base=null;alertBox(`База за ${res.date} сохранена, строк: ${res.rows}. Замечаний: ${res.warnings}.`);await refreshCurrent();}catch(e){alertBox(e.message,true);}finally{setUploadBusy('base',false);}}
window.uploadBase=uploadBase;
async function uploadCurrent(){let file=selectedUploads.current;if(!file)return alertBox('Перетащите или выберите ежедневный Excel',true);setUploadBusy('current',true);try{let res=await uploadExcel('/api/run',file,$('btnRun'),'Рассчитать расходы и факторы');selectedUploads.current=null;alertBox(`Расчёт за ${res.date} сохранён, расходы: ${money(res.expenses)}`);await refreshCurrent();switchPage('overview');}catch(e){alertBox(e.message,true);}finally{setUploadBusy('current',false);}}
window.uploadCurrent=uploadCurrent;
async function loadReport(id){report=await api('/api/report?id='+encodeURIComponent(id));factorClients.clear();factorScope=null;factorSubportfolio='';$('headerDate').textContent=report.current_date+' · №'+report.id;renderOverview();renderFactors();$('emptyState').hidden=true;}
function table(headers,rows,empty='Нет данных'){if(!rows.length)return `<div class="empty-table">${esc(empty)}</div>`;return `<div class="table-wrap"><table><thead><tr>${headers.map(h=>`<th ${h.num?'class="num"':''}>${esc(h.text||h)}</th>`).join('')}</tr></thead><tbody>${rows.join('')}</tbody></table></div>`;}
function cell(x,num=false){return `<td class="${num?'num':''}">${x}</td>`;}
function miniDelta(x){return `<span class="${hue(x)}">${esc(money(x))}</span>`;}
function renderOverview(){if(!report)return;let choice=$('viewSegment').value;let t=choice==='Все'?report.totals:report.segments[choice];$('mainKpis').innerHTML=[el('EL на начало месяца',fmt(t.el0),'BYN · '+report.base_date,false,'▣'),el('EL текущий',fmt(t.el1),'BYN · '+report.current_date,false,'▤'),el('Расходы на резервы',money(t.expenses),'EL начало − EL текущий',true,'↘'),el('Позиции для анализа',String(report.controls.positions),'Все типы клиентов',false,'▥')].join('');
 let max=Math.max(...Object.values(report.segments).map(x=>Math.abs(x.expenses)),1);$('segmentChart').innerHTML=Object.entries(report.segments).map(([name,r])=>`<div class="bar-group"><div class="bar-name">${esc(name)}</div><div class="bar-rail"><div class="bar-fill" style="width:${(Math.abs(r.expenses)/max*100).toFixed(3)}%;background:${r.expenses<0?'#ef7b8c':'#358dd8'}"></div></div><div class="bar-amount ${hue(r.expenses)}">${esc(money(r.expenses))}</div></div>`).join('')+`<p class="footer-note">Положительное значение — снижение резерва, отрицательное — увеличение резерва.</p>`;
 let totals=choice==='Все'?Object.entries(report.segments):[[choice,t]],maxel=Math.max(...totals.map(x=>Math.max(x[1].el0,x[1].el1)),1);
 $('reserveChart').innerHTML=totals.map(([name,r])=>`<div style="margin:12px 0"><b style="font-size:12px">${esc(name)}</b><div style="display:grid;grid-template-columns:1fr;gap:7px;margin-top:9px"><div class="bar-group" style="margin:0"><span class="hint" style="width:56px">Начало</span><div class="bar-rail"><div class="bar-fill" style="width:${r.el0/maxel*100}%"></div></div><b class="bar-amount">${fmt(r.el0)}</b></div><div class="bar-group" style="margin:0"><span class="hint" style="width:56px">Факт</span><div class="bar-rail"><div class="bar-fill" style="width:${r.el1/maxel*100}%;background:#9a80e9"></div></div><b class="bar-amount">${fmt(r.el1)}</b></div></div></div>`).join('');
 $('significantTable').innerHTML=table([{text:'CRM'},{text:'Клиент'},{text:'Расходы, BYN',num:true}],report.significant.slice(0,8).map(x=>`<tr>${cell(esc(x.crm))}${cell(esc(x.client))}${cell(miniDelta(x.expenses),true)}</tr>`),'Существенных клиентов нет');
 const rows=report.ratings||[], bad=report.rating_counts?.['Ухудшение']??rows.filter(x=>x.movement==='Ухудшение').length,good=report.rating_counts?.['Улучшение']??(rows.length-bad);
 $('ratingTable').innerHTML=`<div class="rating-cards"><div class="stat-mini"><small>Изменили рейтинг</small><b>${report.rating_count??rows.length}</b></div><div class="stat-mini"><small>Ухудшение</small><b class="negative">${bad}</b></div><div class="stat-mini"><small>Улучшение</small><b class="positive">${good}</b></div></div>`+table([{text:'Клиент'},{text:'До → После'},{text:'Расходы BYN',num:true}],rows.slice(0,7).map(x=>`<tr>${cell(esc(x.client))}${cell(`<span class="mini-badge ${x.movement==='Ухудшение'?'bad':'good'}">${x.before} → ${x.after}</span>`)}${cell(miniDelta(x.expenses),true)}</tr>`),'Изменений рейтингов нет');
 let check=report.controls;let errors=check.warnings.filter(x=>x.level==='error').length;let warns=check.warning_count??check.warnings.length;
 $('overviewControls').innerHTML=`<div class="panel-head"><h2>Контроль качества расчёта</h2><span class="hint">Факторная сверка до 0,01 BYN</span></div><div class="control-grid"><div class="check-pill">Сверка расходов и факторов: ${fmt(check.reconciliation)} BYN</div><div class="check-pill">Сверка сегментов: ${fmt(check.segment_reconciliation)} BYN</div><div class="check-pill warning">Примеры ошибок: ${errors}</div><div class="check-pill warning">Всего замечаний: ${warns}</div></div>`;
}
function factorData(){if(factorScope)return factorScope.factors;let seg=$('factorSegment').value;return seg==='Все'?report.factors:report.segment_factors[seg];}
function factorTotal(){if(factorScope)return factorScope.totals;let seg=$('factorSegment').value;return seg==='Все'?report.totals:report.segments[seg];}
function factorSubData(){if(factorScope)return factorScope.subfactors;let seg=$('factorSegment').value;return seg==='Все'?report.subfactors:report.segment_subfactors[seg];}
function factorRequestParams(){
  const p=new URLSearchParams({id:report.id,segment:$('factorSegment').value});
  for(const crm of factorClients.keys())p.append('crm',crm);
  if(factorSubportfolio)p.set('subportfolio',factorSubportfolio);
  return p;
}
function factorChangeUi(){
 const seg=$('factorSegment').value;
 $('clientFilterArea').hidden=!(seg==='ЮЛ и ИП'||seg==='Банки');
 $('subportfolioFilterArea').hidden=seg!=='Физические лица';
 const select=$('factorSubportfolio');
 if(seg==='Физические лица'){
   const opts=[['','Все субпортфели'],...(report.fl_subportfolios||[]).map(s=>[s.subportfolio,s.subportfolio])];
   select.innerHTML=opts.map(([v,label])=>`<option value="${esc(v)}">${esc(label)}</option>`).join('');
   select.value=factorSubportfolio;
 }
 $('factorClientChips').innerHTML=Array.from(factorClients).map(([crm,name])=>`<button data-crm="${esc(crm)}" title="Убрать клиента">${esc(name)} · ${esc(crm)} ×</button>`).join('');
 for(const chip of $('factorClientChips').querySelectorAll('button'))chip.addEventListener('click',()=>{
   factorClients.delete(chip.dataset.crm);stagePage=1;renderFactors();
 });
}
async function searchFactorClients(){
 if(!report)return;
 const seg=$('factorSegment').value;
 if(!['ЮЛ и ИП','Банки'].includes(seg))return;
 const text=$('factorClientSearch').value.trim();
 const params=new URLSearchParams({id:report.id,segment:seg,search:text});
 try {
   const data=await api('/api/client-search?'+params);
   const box=$('factorClientSuggestions');
   box.innerHTML=data.clients.map(c=>`<button data-crm="${esc(c.crm)}" data-name="${esc(c.client)}">${esc(c.client)} · CRM ${esc(c.crm)} · ${esc(money(c.expenses))}</button>`).join('')||'<span class="footer-note">Клиенты не найдены</span>';
   for(const node of box.querySelectorAll('button'))node.addEventListener('click',()=>{
     if(factorClients.size>=100&&!factorClients.has(node.dataset.crm))return alertBox('Можно выбрать до 100 клиентов',true);
     factorClients.set(node.dataset.crm,node.dataset.name);stagePage=1;
     box.innerHTML='';renderFactors();
   });
 }catch(e){alertBox(e.message,true);}
}
window.searchFactorClients=searchFactorClients;
function clearFactorClients(){factorClients.clear();stagePage=1;$('factorClientSuggestions').innerHTML='';renderFactors();}
window.clearFactorClients=clearFactorClients;
$('factorClientSearch').addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();searchFactorClients();}});
function waterfall(factors,total){
 const entries=Object.entries(factors).filter(([,v])=>Math.abs(v)>=.005).slice(0,10);
 const W=730,H=330,padTop=27,padBottom=68,plotH=H-padTop-padBottom;
 let acc=0,points=[0];entries.forEach(([,v])=>{acc+=v;points.push(acc)});
 const lo=Math.min(...points),hi=Math.max(...points);
 const margin=Math.max(1,(hi-lo)*.09);const low=lo-margin,high=hi+margin;
 const y=value=>padTop+(high-value)/(high-low)*plotH;
 const step=(W-85)/Math.max(1,entries.length),barWidth=Math.min(48,step*.66);
 let svg=[`<svg class="waterfall-svg" viewBox="0 0 ${W} ${H}" xmlns="http://www.w3.org/2000/svg">`];
 for(let i=0;i<5;i++){const v=low+(high-low)*i/4;svg.push(`<line x1="35" y1="${y(v)}" x2="${W-23}" y2="${y(v)}" stroke="#e5ebf5" stroke-width="1"/>`);svg.push(`<text x="30" y="${y(v)+4}" fill="#93a2b8" text-anchor="end" font-size="10">${fmt(v/1000,0)}к</text>`)}
 svg.push(`<line x1="35" y1="${y(0)}" x2="${W-23}" y2="${y(0)}" stroke="#91a6c9" stroke-dasharray="4 4"/>`);
 for(let i=0;i<entries.length;i++){
   const [name,v]=entries[i],before=points[i],after=points[i+1];const x=44+i*step;
   const top=Math.min(y(before),y(after)),height=Math.max(3,Math.abs(y(before)-y(after)));
   svg.push(`<rect x="${x}" y="${top}" width="${barWidth}" height="${height}" rx="3" fill="${v<0?'#e7788a':'#49b894'}"/>`);
   if(i<entries.length-1)svg.push(`<path d="M${x+barWidth} ${y(after)} H${x+step}" stroke="#adbdd3" stroke-dasharray="3 3" fill="none"/>`);
   const abbreviations={'Движение КП':'Движ. КП','Новые выдачи':'Новые','Переход 1 → 2':'1→2',
     'Выход в дефолт':'Дефолт','Переход 2 → 1':'2→1','Переход 3 → 2':'3→2',
     'Переход 3 → 1':'3→1','Переоценка':'Переоц.','Индивидуальная оценка':'Индив.','Прочие':'Прочие'};
   const label=abbreviations[name]||name.slice(0,10);
   svg.push(`<text x="${x+barWidth/2}" y="${H-43}" fill="#526b91" font-size="11" text-anchor="middle">${label}</text>`);
   svg.push(`<text x="${x+barWidth/2}" y="${H-25}" fill="${v<0?'#b84158':'#07846b'}" font-size="10" text-anchor="middle">${v>=0?'+':''}${fmt(v/1000,1)}к</text>`);
 }
 svg.push(`<text x="${W-15}" y="${H-5}" text-anchor="end" fill="#243d65" font-size="12" font-weight="700">Итого: ${fmt(total.expenses)} BYN</text>`);
 svg.push('</svg>');return svg.join('');
}

async function renderFactors(){
 if(!report)return;
 factorChangeUi();const serial=++factorRequestSerial;
 try {
   const data=await api('/api/factor-scope?'+factorRequestParams());
   if(serial!==factorRequestSerial)return;
   factorScope=data;
   const t=data.totals,fs=data.factors,subs=data.subfactors;
   $('factorScopeLabel').textContent='Факторный мост: '+data.scope;
   $('factorKpis').innerHTML=[el('EL на начало месяца',fmt(t.el0),'BYN',false,'▣'),
     el('Текущий EL',fmt(t.el1),'BYN',false,'▤'),
     el('Расходы на резервы',money(t.expenses),'EL начало − EL факт',true,'↘'),
     el('Сверка факторов',fmt(data.reconciliation)+' BYN','Допуск 0,01 BYN',false,'✓')].join('');
   let max=Math.max(1,...Object.values(fs).map(x=>Math.abs(x)));
   $('factorBars').innerHTML=Object.entries(fs).map(([name,value])=>`<div class="factor-line"><div class="factor-name">${esc(name)}</div><div class="factor-track"><div class="factor-fill ${value<0?'neg':''}" style="width:${Math.abs(value)/max*100}%"></div></div><div class="factor-value ${hue(value)}">${sign(value)}${fmt(value)}</div></div>`).join('');
   $('waterfall').innerHTML=waterfall(fs,t);
   const mmax=Math.max(1,...Object.values(subs).map(x=>Math.abs(x)));
   $('factorSubfactors').innerHTML=Object.entries(subs).map(([name,value])=>`<div class="factor-line"><div class="factor-name">${esc(name)}</div><div class="factor-track"><div class="factor-fill ${value<0?'neg':''}" style="width:${Math.abs(value)/mmax*100}%"></div></div><div class="factor-value ${hue(value)}">${sign(value)}${fmt(value)}</div></div>`).join('')+`<p class="footer-note">Сверка движения КП: ${fmt(data.movement_reconciliation)} BYN</p>`;
   await renderStageTransitions(serial);
   renderDetail();
 }catch(e){if(serial===factorRequestSerial)alertBox(e.message,true);}
}
async function renderStageTransitions(serial){
 const seg=$('factorSegment').value;
 const p=new URLSearchParams({id:report.id,segment:seg,page:stagePage,limit:30});
 if(factorSubportfolio)p.set('subportfolio',factorSubportfolio);
 for(const c of factorClients.keys())p.append('crm',c);
 const data=await api('/api/transitions?'+p);
 if(serial!==factorRequestSerial)return;
 const sum=data.summary||{};
 $('factorStageSummary').innerHTML=Object.entries(sum).map(([name,v])=>`<div class="mini-stage-item"><span>${esc(name)} · ${v.clients} клиент(ов)</span><strong class="${hue(v.expenses)}">${esc(money(v.expenses))}</strong></div>`).join('')||'<span class="footer-note">Переходов стадий нет</span>';
 const rows=data.rows.filter(x=>seg==='Все'||x.segment===seg).filter(x=>!(seg==='Физические лица'));
 $('factorTransitions').innerHTML=table([
   {text:'CRM / Клиент'},{text:'Переход'},{text:'Денежный эффект',num:true},
   {text:'Обнаруженные изменения'},{text:'Основная причина'}],rows.map(t=>{
    const reasons=(t.reasons||[]).map(x=>`${esc(x.label)}: ${esc(x.before||'—')} → ${esc(x.after||'—')}`).join('; ');
    const options=['<option value="">Не выбрана</option>',...(t.reasons||[]).map(x=>`<option value="${esc(x.label)}" ${t.primary_cause===x.label?'selected':''}>${esc(x.label)}</option>`),
      `<option value="Другое / уточнить" ${t.primary_cause==='Другое / уточнить'?'selected':''}>Другое / уточнить</option>`].join('');
    return `<tr>${cell(esc(t.client)+'<div class="footer-note">'+esc(t.crm)+'</div>')}${cell(esc(t.from+' → '+t.to)+(t.synthetic?' · условный':'') )}${cell(miniDelta(t.expenses),true)}${cell('<div class="factor-reasons">'+(reasons||'Изменившихся признаков не обнаружено')+'</div>')}${cell(`<select class="stage-cause-select" data-crm="${esc(t.crm)}">${options}</select>`)}</tr>`;
   }),'Нет переходов стадий для выбранного набора клиентов');
 $('factorTransitions').insertAdjacentHTML('beforeend',`<div class="pagination"><button ${stagePage===1?'disabled':''} onclick="moveStagePage(-1)">←</button><span>Страница ${stagePage} · переходов: ${data.total??data.rows.length}</span><button ${(stagePage*30>=(data.total??data.rows.length))?'disabled':''} onclick="moveStagePage(1)">→</button></div>`);
 for(const select of $('factorTransitions').querySelectorAll('.stage-cause-select'))select.addEventListener('change',async()=>{
   try{await api('/api/stage-cause',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({report_id:report.id,crm:select.dataset.crm,primary_cause:select.value})});alertBox('Основная причина сохранена');}catch(e){alertBox(e.message,true);}
 });
}
function moveStagePage(step){stagePage=Math.max(1,stagePage+step);renderFactors();}
window.moveStagePage=moveStagePage;
function renderDetail(){let seg=$('factorSegment').value,container=$('factorsDetail');detailSegment=seg==='Все'?'ЮЛ и ИП':seg;
 let tabs=`<div class="detail-tabs">${['ЮЛ и ИП','Физические лица','Банки'].map(s=>`<button class="filter-tab ${detailSegment===s?'active':''}" onclick="detailSegment='${s}';renderDetailTab()">${esc(s)}</button>`).join('')}</div>`;
 container.innerHTML=`<div class="detail-head">${tabs}<div class="searchrow"><input id="positionSearch" placeholder="Поиск по клиенту, договору, CRM ID"><button class="quiet" onclick="loadPositions(1)">Найти</button></div></div><div id="detailBody"></div>`;
 renderDetailTab();}
window.renderDetailTab=function(){document.querySelectorAll('#factorsDetail .filter-tab').forEach(x=>x.classList.toggle('active',x.textContent===detailSegment));if(detailSegment==='ЮЛ и ИП')loadPositions(1);else if(detailSegment==='Физические лица'){
 $('detailBody').innerHTML=table([{text:'Субпортфель'},{text:'EL начало, BYN',num:true},{text:'EL факт, BYN',num:true},{text:'Расходы, BYN',num:true}],report.fl_subportfolios.filter(x=>!factorSubportfolio||x.subportfolio===factorSubportfolio).map(x=>`<tr>${cell(esc(x.subportfolio))}${cell(fmt(x.el0),true)}${cell(fmt(x.el1),true)}${cell(miniDelta(x.expenses),true)}</tr>`));
}else{loadBanks(1);}}
async function loadBanks(page=1){let qp=new URLSearchParams({id:report.id,page,limit:50});for(const crm of factorClients.keys())qp.append('crm',crm);let data=await api('/api/banks?'+qp);$('detailBody').innerHTML=table([{text:'CRM'},{text:'Банк'},{text:'EL начало, BYN',num:true},{text:'EL факт, BYN',num:true},{text:'Расходы, BYN',num:true}],data.rows.map(x=>`<tr>${cell(esc(x.crm))}${cell(esc(x.client))}${cell(fmt(x.el0),true)}${cell(fmt(x.el1),true)}${cell(miniDelta(x.expenses),true)}</tr>`))+`<div class="pagination"><button ${page===1?'disabled':''} onclick="loadBanks(${page-1})">←</button><span>Страница ${page}, банков: ${data.total}</span><button ${page*50>=data.total?'disabled':''} onclick="loadBanks(${page+1})">→</button></div>`;}
window.loadBanks=loadBanks;
async function loadPositions(next=1){try{
 positionPage=next;let input=$('positionSearch');if(input)searchText=input.value.trim();
 let params=new URLSearchParams({id:report.id,segment:'ЮЛ и ИП',search:searchText,page:positionPage,limit:30});
 for(const crm of factorClients.keys())params.append('crm',crm);
 let data=await api('/api/positions?'+params);
 let rows=data.rows.map(x=>`<tr>${cell(esc(x.crm))}${cell(esc(x.client))}${cell(esc(x.contract))}${cell(esc(x.tranche||'—'))}${cell(esc(x.currency))}${cell(fmt(x.el0),true)}${cell(fmt(x.el1),true)}${cell(miniDelta(x.expenses),true)}${cell(esc(x.events.slice(0,2).join('; ')||'—'))}</tr>`);
 let root=$('detailBody');root.innerHTML=table([{text:'CRM'},{text:'Клиент'},{text:'Договор'},{text:'Транш'},{text:'Валюта'},{text:'EL начало',num:true},{text:'EL факт',num:true},{text:'Расходы BYN',num:true},{text:'События'}],rows,'Нет подходящих траншей')+`<div class="pagination"><button ${positionPage===1?'disabled':''} onclick="loadPositions(${positionPage-1})">←</button><span>Страница ${positionPage} · всего ${data.total}</span><button ${positionPage*data.limit>=data.total?'disabled':''} onclick="loadPositions(${positionPage+1})">→</button></div>`;
 let clientParams=new URLSearchParams({id:report.id,search:searchText,page:positionPage,limit:30});
 for(const crm of factorClients.keys())clientParams.append('crm',crm);
 let clientData=await api('/api/significant?'+clientParams);
 root.insertAdjacentHTML('beforeend',`<h3 style="margin-top:24px">Комментарии по существенным клиентам</h3><p class="footer-note">Список загружается постранично. Комментарии можно редактировать и сохранять.</p>`+table([{text:'Клиент'},{text:'Расходы'},{text:'Комментарий'}],clientData.rows.map(x=>`<tr>${cell(esc(x.client))}${cell(miniDelta(x.expenses),true)}${cell(`<textarea id="comment-${esc(x.crm)}" class="comment-input">${esc(x.comment||'')}</textarea><button class="quiet" onclick="saveComment('${esc(x.crm)}')">Сохранить</button>`)}</tr>`),'Нет существенных клиентов')+`<p class="footer-note">Существенных клиентов: ${clientData.total}. Показано до 30 на текущей странице.</p>`);
}catch(e){alertBox(e.message,true);}}
window.loadPositions=loadPositions;
async function saveComment(crm){let input=document.getElementById('comment-'+crm);if(!input)return;try{await api('/api/comment',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({report_id:report.id,crm,comment:input.value})});let item=report.significant.find(x=>x.crm===crm);if(item)item.comment=input.value;alertBox('Комментарий сохранён');}catch(e){alertBox(e.message,true);}}
window.saveComment=saveComment;
function renderHistory(){if(!historyCache)return;$('historyTable').innerHTML=table([{text:'Версия'},{text:'Дата факта'},{text:'База'},{text:'Время расчёта'},{text:'Действия'}],historyCache.reports.map(x=>`<tr>${cell('#'+x.id)}${cell(esc(x.current_date))}${cell(esc(x.base_date))}${cell(esc(x.created_at))}${cell(`<button class="quiet" onclick="openHistory(${x.id})">Открыть</button> <button class="quiet" onclick="openExport(${x.id})">↓ PDF / Excel</button>`)}</tr>`),'Пока нет сохранённых расчётов');$('baseVersions').innerHTML=table([{text:'Версия'},{text:'Дата базы'},{text:'Имя файла'},{text:'Сохранена'}],historyCache.bases.map(x=>`<tr>${cell('#'+x.id)}${cell(esc(x.date))}${cell(esc(x.filename))}${cell(esc(x.created_at))}</tr>`),'База не загружена');}
async function openHistory(id){try{await loadReport(id);switchPage('overview');}catch(e){alertBox(e.message,true);}}
window.openHistory=openHistory;
function openExport(id){if(id){lastRun=id;}else if(report){lastRun=report.id;}else{return alertBox('Сначала сформируйте отчёт',true);} $('exportModal').hidden=false;}
function closeExport(){$('exportModal').hidden=true;}
async function downloadReport(ext){
 if(!lastRun)return;
 const pr=new URLSearchParams({id:lastRun});if(page==='factors'){pr.set('segment',$('factorSegment').value);for(const crm of factorClients.keys())pr.append('crm',crm);if(factorSubportfolio)pr.set('subportfolio',factorSubportfolio);}
 const url='/api/export/report.'+ext+'?'+pr;
 try{
   const response=await fetch(url);
   if(!response.ok){const d=await response.json();throw Error(d.error||'Ошибка экспорта');}
   const data=await response.blob();const link=document.createElement('a');
   const href=URL.createObjectURL(data);link.href=href;
   link.download=`IFRS_expenses_${report?.current_date||'report'}_v${lastRun}.${ext}`;
   document.body.appendChild(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(href),1000);
   closeExport();
 }catch(e){alertBox(e.message+(ext==='pdf'?' Используйте кнопку «Версия для печати».':''),true);}
}
function printReport(){closeExport();if(!report)return;switchPage('overview');setTimeout(()=>window.print(),200);}
window.openExport=openExport;window.closeExport=closeExport;window.downloadReport=downloadReport;window.printReport=printReport;
init();
