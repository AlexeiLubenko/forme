"""Actual HTTP tests for scoped bridges and persisted main-cause selections."""
import json
import tempfile
import threading
import unittest
from pathlib import Path
from urllib.parse import urlencode
from urllib.request import Request, urlopen
from http.server import ThreadingHTTPServer
import server

EXAMPLES=Path(__file__).parent/'examples'

class FactorApiV2(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp=tempfile.TemporaryDirectory(prefix='ifrs_api_v2_')
        cls.old=(server.DB,server.STORAGE,server.BASE_PATH)
        server.STORAGE=Path(cls.temp.name)
        server.DB=server.STORAGE/'db.sqlite3'
        server.BASE_PATH=server.STORAGE/'base_snapshot.xlsx'
        server.save_base(EXAMPLES/'01_fact_base_2026-10-30.xlsx','base_demo.xlsx')
        server.save_run(EXAMPLES/'02_fact_current_2026-11-05.xlsx','current_demo.xlsx')
        cls.http=ThreadingHTTPServer(('127.0.0.1',0),server.Handler)
        cls.worker=threading.Thread(target=cls.http.serve_forever,daemon=True)
        cls.worker.start()
        cls.url=f'http://127.0.0.1:{cls.http.server_address[1]}'
        cls.rid=server.read_report()['id']

    @classmethod
    def tearDownClass(cls):
        cls.http.shutdown();cls.http.server_close()
        server.DB,server.STORAGE,server.BASE_PATH=cls.old
        cls.temp.cleanup()

    def api(self,path,params=None):
        url=self.url+path
        if params:url+='?'+urlencode(params)
        with urlopen(url,timeout=30) as response:return json.load(response)

    def test_scoped_clients_and_search_cyrillic(self):
        found=self.api('/api/client-search',{'id':self.rid,'segment':'ЮЛ и ИП','search':'АЛЬФА'})
        self.assertEqual(found['clients'][0]['crm'],'1001')
        one=self.api('/api/factor-scope',{'id':self.rid,'segment':'ЮЛ и ИП','crm':'1001'})
        self.assertAlmostEqual(one['totals']['expenses'],-551550,places=2)
        self.assertAlmostEqual(one['reconciliation'],0,places=4)
        self.assertAlmostEqual(one['movement_reconciliation'],0,places=4)
        many=self.api('/api/factor-scope',{'id':self.rid,'segment':'ЮЛ и ИП','crm':'1001,1003'})
        self.assertAlmostEqual(many['totals']['expenses'],one['totals']['expenses']+30000,places=2)

    def test_fl_subportfolio_and_banks(self):
        fl=self.api('/api/factor-scope',{'id':self.rid,'segment':'Физические лица','subportfolio':'Ипотека'})
        self.assertAlmostEqual(fl['reconciliation'],0,places=4)
        bank=self.api('/api/factor-scope',{'id':self.rid,'segment':'Банки','crm':'3001'})
        self.assertAlmostEqual(bank['totals']['expenses'],220,places=2)
        self.assertAlmostEqual(bank['reconciliation'],0,places=4)

    def test_stage_cause_save_and_page(self):
        transitions=self.api('/api/transitions',{'id':self.rid,'segment':'ЮЛ и ИП','crm':'1001'})
        self.assertEqual(transitions['total'],1)
        self.assertTrue(transitions['rows'][0]['reasons'])
        choice=transitions['rows'][0]['reasons'][0]['label']
        payload=json.dumps({'report_id':self.rid,'crm':'1001','primary_cause':choice},ensure_ascii=False).encode()
        req=Request(self.url+'/api/stage-cause',payload,{'Content-Type':'application/json'},method='POST')
        with urlopen(req,timeout=30) as response:result=json.load(response)
        self.assertTrue(result['saved'])
        saved=self.api('/api/transitions',{'id':self.rid,'segment':'ЮЛ и ИП','crm':'1001'})
        self.assertEqual(saved['rows'][0]['primary_cause'],choice)

    def test_filtered_excel_download(self):
        from openpyxl import load_workbook
        from io import BytesIO
        url=self.url+'/api/export/report.xlsx?'+urlencode({'id':self.rid,'segment':'ЮЛ и ИП','crm':'1001'})
        with urlopen(url,timeout=60) as response:blob=response.read()
        self.assertTrue(blob.startswith(b'PK'))
        wb=load_workbook(BytesIO(blob),read_only=True,data_only=True)
        rows=list(wb['ЮЛ_ИП_Транши'].values)
        self.assertGreater(len(rows),1)
        self.assertTrue(all(row[0]=='1001' for row in rows[1:]))
        self.assertIn('Переходы_стадий',wb.sheetnames)
        self.assertIn('Подфакторы движения КП',wb.sheetnames)
        wb.close()

if __name__=='__main__':unittest.main()
