"""Version 2: reconciled, order-independent stock ECL attribution.

Every pair is valued with midpoint EAD/rate (two-factor Shapley identity).
Stage impact uses average portfolio stage rates; the remaining rate impact belongs
in portfolio movement.  Classification of *events* is not proof of causality.
"""
from __future__ import annotations
from collections import defaultdict
from datetime import date
from math import isfinite

FACTORS=(
    'Движение КП', 'Новые выдачи', 'Переход 1 → 2',
    'Выход в дефолт', 'Переход 2 → 1', 'Переход 3 → 2',
    'Переход 3 → 1', 'Переоценка', 'Индивидуальная оценка', 'Прочие',
)
SUBFACTORS=(
    'Погашение / уменьшение лимита', 'Изменение срока до погашения',
    'Выборка: УО → актив', 'Гашение: актив → УО', 'Увеличение лимита',
)
TRANSITIONS={(1,2):'Переход 1 → 2',(2,3):'Выход в дефолт',
             (1,3):'Выход в дефолт',(2,1):'Переход 2 → 1',
             (3,2):'Переход 3 → 2',(3,1):'Переход 3 → 1'}
RISK_LABELS={'14':'Рейтинг','16':'Просрочка: риск-сигнал','17':'Красная зона: риск-сигнал',
 '18':'Санкции','19':'Господдержка','20':'Риск-сигнал изменения рейтинга',
 '21':'Проблемные отрасли','22':'Проектный риск','23':'Дата дефолта',
 '32':'Дни просрочки ОД','33':'Дни просрочки процентов',
 '34':'Максимальная просрочка договора','35':'Просрочка клиента',
 '36':'Просрочка субпортфеля','37':'Бакет просрочки',
 '40':'Дата погашения','66':'Красная зона проблемности',
 '67':'Красная зона на выдачу','105':'Проектный риск-профиль'}


def segment(row):
    return 'ЮЛ и ИП' if row['status'] in ('ю','ип') else ('Физические лица' if row['status']=='ф' else 'Банки')


def individual(row):
    return str(row.get('individual','')).strip().lower() in ('да','1','true','yes')


def empty_factors():return {name:0.0 for name in FACTORS}
def empty_sub():return {name:0.0 for name in SUBFACTORS}


def stage_stats(rows):
    """For one snapshot, aggregate EL/EAD for each (segment,stage), exclude individual."""
    result=defaultdict(lambda:[0.,0.])
    excluded={r['crm'] for r in rows if individual(r)}
    for r in rows:
        if r['crm'] not in excluded and r['ead']>0:
            z=result[(segment(r),int(r['stage']))]
            z[0]+=float(r['el']);z[1]+=float(r['ead'])
    return {f'{k[0]}|{k[1]}':{'el':v[0],'ead':v[1]} for k,v in result.items()}


def rate(stats,seg,stage):
    x=stats.get(f'{seg}|{stage}',{})
    ead=x.get('ead',0.)
    return x.get('el',0.)/ead if ead>0 else None


def mix_rate(base_stats,current_stats,seg,stage):
    a=rate(base_stats,seg,stage)
    return a if a is not None else (rate(current_stats,seg,stage) or 0.0)


def safe_rate(el,ead):return el/ead if ead>1e-12 else 0.0


def factor_reasons(a,b):
    if not a or not b:return []
    res=[]
    ra=a.get('risk_fields',{});rb=b.get('risk_fields',{})
    for k,label in RISK_LABELS.items():
        before=ra.get(k,'');after=rb.get(k,'')
        if before!=after:
            res.append({'field':k,'label':label,'before':before,'after':after})
    return res


def client_risk(rows):
    """Union values across a client's positions, so no risk-signal changes are hidden."""
    fields={}
    for k in RISK_LABELS:
        values=sorted({str(p.get('risk_fields',{}).get(k,'')).strip() for p in rows if str(p.get('risk_fields',{}).get(k,'')).strip()})
        fields[k]='; '.join(values)
    return {'risk_fields':fields}


def calculate(base, current, *, base_stage_rates=None,current_stage_rates=None):
    """Pair up positions in one or many clients. Fully reconciled result in BYN."""
    from core import RESERVE_NUMS, KEY_FIELDS, aggregate_snapshot
    if base['date']>=current['date']:
        raise ValueError('Дата текущего факта должна быть позже базы')
    bmap,bwarn=aggregate_snapshot(base['rows']);cmap,cwarn=aggregate_snapshot(current['rows'])
    base_stage_rates=base_stage_rates or stage_stats(base['rows'])
    current_stage_rates=current_stage_rates or stage_stats(current['rows'])
    g0=defaultdict(list);g1=defaultdict(list)
    for p in bmap.values():g0[p['crm']].append(p)
    for p in cmap.values():g1[p['crm']].append(p)
    all_crm=sorted(set(g0)|set(g1))
    result=[];client_out=[];ratings=[];transitions=[]
    segs={s:{'el0':0.,'el1':0.,'ead0':0.,'ead1':0.,'expenses':0.,'count':0} for s in ('ЮЛ и ИП','Физические лица','Банки')}
    fl_sub=defaultdict(lambda:{'el0':0.,'el1':0.,'ead0':0.,'ead1':0.,'expenses':0.,'factors':empty_factors(),'subfactors':empty_sub()})
    fl_migrations=[]
    for crm in all_crm:
        olds=g0.get(crm,[]);news=g1.get(crm,[])
        primary0=olds[0] if olds else None;primary1=news[0] if news else None
        main=primary1 or primary0
        s=segment(main)
        # Stage is a client attribute. Conflicting values in a client are surfaced, not averaged.
        stages0={x['stage'] for x in olds};stages1={x['stage'] for x in news}
        st0=primary0['stage'] if primary0 else None
        st1=primary1['stage'] if primary1 else None
        changed=st0 is not None and st1 is not None and st0!=st1
        transition=TRANSITIONS.get((st0,st1)) if changed else None
        flagged=any(individual(x) for x in olds+news)
        old_contracts={x['contract'] for x in olds}
        if len(stages0)>1 or len(stages1)>1:
            bwarn.append({'level':'warning','crm':crm,'message':'Разные стадии внутри одного CRM ID; используется стадия первой строки'})
        oldmap={tuple(x[k] for k in KEY_FIELDS):x for x in olds}
        newmap={tuple(x[k] for k in KEY_FIELDS):x for x in news}
        cpositions=[]
        for key in sorted(set(oldmap)|set(newmap)):
            a=oldmap.get(key);b=newmap.get(key);p=b or a
            e0=a['el'] if a else 0.;e1=b['el'] if b else 0.
            x0=a['ead'] if a else 0.;x1=b['ead'] if b else 0.
            exp=e0-e1
            factors=empty_factors();sub=empty_sub()
            fx_effect=0.;amount_effect=0.;stage_effect=0.
            new_deal=a is None and b is not None and p['contract'] not in old_contracts
            # Individual assessment is mutually exclusive with all other cash factors.
            if flagged:
                factors['Индивидуальная оценка']=exp
            elif new_deal:
                if st0 is None and st1 in (2,3):
                    # New client with no observed historical stage: synthetic 1->2/3.
                    k1=rate(current_stage_rates,s,1)
                    if k1 is None:k1=0.
                    baseline=x1*k1
                    factors['Новые выдачи']=-baseline
                    f='Переход 1 → 2' if st1==2 else 'Выход в дефолт'
                    factors[f]=exp+baseline
                elif changed and transition:
                    # A new contract belonging to an already observed migrating client.
                    old_k=mix_rate(base_stage_rates,current_stage_rates,s,st0)
                    baseline=x1*old_k
                    factors['Новые выдачи']=-baseline
                    factors[transition]=exp+baseline
                else:
                    factors['Новые выдачи']=exp
            else:
                k0=safe_rate(e0,x0);k1=safe_rate(e1,x1)
                km=.5*(k0+k1)
                if changed and transition:
                    old_stage_rate=mix_rate(base_stage_rates,current_stage_rates,s,st0)
                    new_stage_rate=mix_rate(base_stage_rates,current_stage_rates,s,st1)
                    # Counterfactual two-factor midpoint/Shapley stage contribution.
                    stage_effect=-.5*(x0+x1)*(new_stage_rate-old_stage_rate)
                    factors[transition]+=stage_effect
                # Forex revaluation of the *old* currency exposure, priced at midpoint reserve rate.
                fx0=a.get('fx',1.) if a else 1.
                fx1=b.get('fx',fx0) if b else fx0
                if a and b and p['currency']!='BYN' and fx0>0 and fx1>0:
                    fx_ead=x0/fx0*(fx1-fx0)
                    fx_effect=-fx_ead*km
                    factors['Переоценка']=fx_effect
                else:fx_ead=0.
                amount_effect=-(x1-x0-fx_ead)*km
                # Everything not isolated as stage/FX is part of movement of the loan portfolio.
                movement=exp-stage_effect-fx_effect
                factors['Движение КП']=movement
                # Midpoint split: changing the balance versus changing the reserve rate.
                rate_effect=movement-amount_effect
                if amount_effect>=0:sub['Погашение / уменьшение лимита']+=amount_effect
                else:sub['Увеличение лимита']+=amount_effect
                # Residual rate movement, including maturity and changes of reserve intensity.
                sub['Изменение срока до погашения']+=rate_effect
            # Protect exact cash reconciliation against floating point and impossible features.
            gap=exp-sum(factors.values())
            if abs(gap)>1e-8:factors['Прочие']+=gap
            events=[]
            if st0!=st1 and st0 is not None and st1 is not None:events.append(f'Стадия {st0} → {st1}')
            if st0 is None and st1 in (2,3):events.append(f'Условная стадия 1 → {st1}: клиент появился впервые')
            if primary0 and primary1 and primary0['rating']!=primary1['rating']:
                events.append(f'Рейтинг {primary0["rating"]:g} → {primary1["rating"]:g}')
            if b and not a:events.append('Новая позиция')
            if a and not b:events.append('Выбывшая позиция')
            if flagged:events.append('Индивидуальная оценка')
            for detail in factor_reasons(a,b):
                if detail['field'] not in ('14','40'):
                    events.append(f'{detail["label"]}: {detail["before"] or "—"} → {detail["after"] or "—"}')
            position={'key':'|'.join(key),'crm':crm,'unp':p['unp'],'client':p['client'],'segment':s,
                'status':p['status'],'subportfolio0':a['subportfolio'] if a else '',
                'subportfolio1':b['subportfolio'] if b else '',
                'contract':p['contract'],'tranche':p['tranche'],'currency':p['currency'],
                'stage0':st0,'stage1':st1,'rating0':primary0['rating'] if primary0 else None,
                'rating1':primary1['rating'] if primary1 else None,
                'el0':e0,'el1':e1,'ead0':x0,'ead1':x1,'expenses':exp,'factors':factors,
                'subfactors':sub,'events':events,
                'active0':a['active'] if a else 0.,'active1':b['active'] if b else 0.,
                'uo0':a['uo'] if a else 0.,'uo1':b['uo'] if b else 0.,
                'fx0':a['fx'] if a else None,'fx1':b['fx'] if b else None,
                'risk_fields0':a.get('risk_fields',{}) if a else {},
                'risk_fields1':b.get('risk_fields',{}) if b else {},
                'individual':flagged,'synthetic_stage':st0 is None and st1 in (2,3),
                'new_contract':new_deal,
                'reserve_changes':{str(k):(a['reserves'][str(k)] if a else 0)-(b['reserves'][str(k)] if b else 0) for k in RESERVE_NUMS},
                'reserve_parts0':a['reserves'] if a else {str(k):0. for k in RESERVE_NUMS},
                'reserve_parts1':b['reserves'] if b else {str(k):0. for k in RESERVE_NUMS}}
            cpositions.append(position)
        # Drawdowns between UO and active are offset-neutral movements on the contract+currency.
        if not flagged:
            contracts=defaultdict(list)
            for p in cpositions:contracts[(p['contract'],p['currency'])].append(p)
            for items in contracts.values():
                a0=sum(p['active0'] for p in items);a1=sum(p['active1'] for p in items)
                u0=sum(p['uo0'] for p in items);u1=sum(p['uo1'] for p in items)
                da=a1-a0;du=u1-u0
                if not ((da>1e-9 and du< -1e-9) or (da< -1e-9 and du>1e-9)):
                    continue
                moved=min(abs(da),abs(du));row=next((p for p in items if p['factors']['Движение КП']),items[0])
                # Reserve components: old/new average rates per active/UO, fall back to effective EAD rate.
                def component_rate(which):
                    pairs=[]
                    for is_current in (False,True):
                        vol=sum(p[which+'1' if is_current else which+'0'] for p in items)
                        if which=='uo':
                            reserve=sum(p['reserve_parts1' if is_current else 'reserve_parts0']['87'] for p in items)
                        else:
                            reserve=sum(sum(v for k,v in p['reserve_parts1' if is_current else 'reserve_parts0'].items() if k not in ('87','89')) for p in items)
                        if vol>0:pairs.append(reserve/vol)
                    return sum(pairs)/len(pairs) if pairs else 0.
                ka=component_rate('active');ku=component_rate('uo')
                if da>0:
                    # UO -> active: shift positive UO decrease and negative active increase into drawdown.
                    val=moved*(ku-ka)
                    row['subfactors']['Увеличение лимита']+=moved*ka
                    row['subfactors']['Погашение / уменьшение лимита']-=moved*ku
                    row['subfactors']['Выборка: УО → актив']+=val
                else:
                    val=moved*(ka-ku)
                    row['subfactors']['Погашение / уменьшение лимита']-=moved*ka
                    row['subfactors']['Увеличение лимита']+=moved*ku
                    row['subfactors']['Гашение: актив → УО']+=val
                # Group cash attribution remains unchanged; align the 5 subfactors exactly.
        for p in cpositions:
            # For a new contract, stage & issuance do not belong in portfolio movement.
            movement=p['factors']['Движение КП']
            missing=movement-sum(p['subfactors'].values())
            if abs(missing)>1e-8:p['subfactors']['Изменение срока до погашения']+=missing
        el0=sum(p['el0'] for p in cpositions);el1=sum(p['el1'] for p in cpositions)
        ead0=sum(p['ead0'] for p in cpositions);ead1=sum(p['ead1'] for p in cpositions)
        total=el0-el1
        factors={f:sum(p['factors'][f] for p in cpositions) for f in FACTORS}
        subs={f:sum(p['subfactors'][f] for p in cpositions) for f in SUBFACTORS}
        client={'crm':crm,'client':main['client'],'segment':s,'el0':el0,'el1':el1,
            'ead0':ead0,'ead1':ead1,'expenses':total,'factors':factors,'subfactors':subs,
            'stage0':st0,'stage1':st1,'rating0':primary0['rating'] if primary0 else None,
            'rating1':primary1['rating'] if primary1 else None,'individual':flagged}
        client_out.append(client)
        if primary0 and primary1 and primary0['rating']!=primary1['rating']:
            ratings.append({'crm':crm,'client':main['client'],'before':primary0['rating'],
                'after':primary1['rating'],'movement':'Ухудшение' if primary1['rating']>primary0['rating'] else 'Улучшение',
                'expenses':total})
        if changed or (st0 is None and st1 in (2,3)):
            reasons=factor_reasons(client_risk(olds) if olds else None,client_risk(news) if news else None)
            transitions.append({'crm':crm,'client':main['client'],'segment':s,
                'from':st0 if st0 is not None else 1,'to':st1,
                'synthetic':st0 is None,'expenses':factors.get(TRANSITIONS.get((st0,st1)) or ('Переход 1 → 2' if st1==2 else 'Выход в дефолт'),0.),
                'total_expenses':total,'ead0':ead0,'ead1':ead1,'el0':el0,'el1':el1,
                'reasons':reasons,'primary_cause':None})
        for p in cpositions:
            if s=='Физические лица':
                oldsub=p['subportfolio0'];newsub=p['subportfolio1']
                if oldsub and oldsub==newsub:
                    t=fl_sub[oldsub];t['el0']+=p['el0'];t['el1']+=p['el1'];t['ead0']+=p['ead0'];t['ead1']+=p['ead1'];t['expenses']+=p['expenses']
                    for f,v in p['factors'].items():t['factors'][f]+=v
                    for f,v in p['subfactors'].items():t['subfactors'][f]+=v
                elif oldsub and newsub and oldsub!=newsub:
                    a=fl_sub[oldsub];b=fl_sub[newsub]
                    a['el0']+=p['el0'];a['ead0']+=p['ead0'];a['expenses']+=p['el0'];a['factors']['Движение КП']+=p['el0']
                    a['subfactors']['Погашение / уменьшение лимита']+=p['el0']
                    b['el1']+=p['el1'];b['ead1']+=p['ead1'];b['expenses']-=p['el1'];b['factors']['Движение КП']-=p['el1']
                    b['subfactors']['Увеличение лимита']-=p['el1']
                    fl_migrations.append({'old':oldsub,'new':newsub,'el0':p['el0'],'el1':p['el1']})
                else:
                    t=fl_sub[oldsub or newsub];t['el0']+=p['el0'];t['el1']+=p['el1'];t['ead0']+=p['ead0'];t['ead1']+=p['ead1'];t['expenses']+=p['expenses']
                    for f,v in p['factors'].items():t['factors'][f]+=v
                    for f,v in p['subfactors'].items():t['subfactors'][f]+=v
            stats=segs[s]
            for name in ('el0','el1','ead0','ead1','expenses'):stats[name]+=p[name]
            stats['count']+=1
        result.extend(cpositions)
    totals={k:sum(v[k] for v in segs.values()) for k in ('el0','el1','ead0','ead1','expenses')}
    fact={f:sum(p['factors'][f] for p in result) for f in FACTORS}
    subfact={f:sum(p['subfactors'][f] for p in result) for f in SUBFACTORS}
    sf={s:{f:sum(p['factors'][f] for p in result if p['segment']==s) for f in FACTORS} for s in segs}
    ssf={s:{f:sum(p['subfactors'][f] for p in result if p['segment']==s) for f in SUBFACTORS} for s in segs}
    significant=[]
    for c in client_out:
        if c['segment']=='ЮЛ и ИП' and abs(c['expenses'])>=100000:
            labels=[k for k,v in c['factors'].items() if abs(v)>.005 and k!='Прочие']
            c['comment']=f"Расходы {c['expenses']:,.2f} BYN. Факторы: "+(', '.join(labels) if labels else 'прочие')+'.'
            significant.append(c)
    significant.sort(key=lambda c:-abs(c['expenses']))
    banks=[c for c in client_out if c['segment']=='Банки']
    banks.sort(key=lambda c:-abs(c['expenses']))
    return {'base_date':base['date'],'current_date':current['date'],
       'totals':totals,'segments':segs,'factors':fact,'subfactors':subfact,
       'segment_factors':sf,'segment_subfactors':ssf,'positions':result,
       'clients':[c for c in client_out if c['segment']=='ЮЛ и ИП'],
       'significant':significant,'ratings':ratings,'transitions':transitions,
       'fl_subportfolios':[{'subportfolio':name,**vals} for name,vals in sorted(fl_sub.items())],
       'fl_migrations':fl_migrations,'banks':banks,
       'controls':{'reconciliation':totals['expenses']-sum(fact.values()),
           'movement_reconciliation':fact['Движение КП']-sum(subfact.values()),
           'segment_reconciliation':totals['expenses']-sum(v['expenses'] for v in segs.values()),
           'positions':len(result),'base_rows':base['count'],'current_rows':current['count'],
           'warnings':base['warnings']+current['warnings']+bwarn+cwarn},
       'method_note':('Метод v2: EAD и ставка — симметричное разложение; стадия — оценка по средним '
           'ставкам стадий, новые клиенты — ставка стадии 1 на текущую дату. Остаток ставки '
           'включён в движение КП, условная атрибуция срока. Причины стадий — наблюдаемые события.'),
       'method_version':'2.0'}
