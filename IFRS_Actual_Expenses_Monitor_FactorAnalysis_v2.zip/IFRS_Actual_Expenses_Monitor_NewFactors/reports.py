"""Excel + PDF reports built from saved analytical results; no raw daily Excel retained."""
from io import BytesIO
from pathlib import Path
from collections import defaultdict
from datetime import datetime

MONEY='#,##0.00;[Red](#,##0.00);–'
NAVY='142A55';BLUE='225DDF';LIGHT='E8EEF9';GREEN='087F63';RED='B3273A'

def excel_report(r):
    from openpyxl import Workbook
    from openpyxl.styles import Font,PatternFill,Alignment
    from openpyxl.utils import get_column_letter
    from openpyxl.formatting.rule import CellIsRule
    wb=Workbook();wb.remove(wb.active)
    def sheet(name,headers,rows,money=()):
        ws=wb.create_sheet(name);ws.append(headers)
        for row in rows:ws.append([v if isinstance(v,(str,int,float,type(None))) else str(v) for v in row])
        for cell in ws[1]:cell.fill=PatternFill('solid',fgColor=NAVY);cell.font=Font(bold=True,color='FFFFFF');cell.alignment=Alignment(wrap_text=True,vertical='center')
        ws.row_dimensions[1].height=34;ws.freeze_panes='A2';ws.auto_filter.ref=ws.dimensions
        for i,h in enumerate(headers,1):
            width=min(43,max(13,len(str(h))*0.9+3));ws.column_dimensions[get_column_letter(i)].width=width
        for col in money:
            for row in ws.iter_rows(min_row=2,min_col=col,max_col=col):row[0].number_format=MONEY
        return ws
    sums=r['totals'];lines=[('Начало месяца',r['base_date']),('Текущий факт',r['current_date']),('Версия расчёта',r['id']),('Источник',r['source_filename']),('Формула расходов','EL на начало − EL текущий'),('EL на начало, BYN',sums['el0']),('EL текущий, BYN',sums['el1']),('Расходы на резервы, BYN',sums['expenses']),('Сверка факторов, BYN',r['controls']['reconciliation']),('Позиции',r['controls']['positions']),('Примечание',r['method_note'])]
    sheet('Сводка',['Показатель','Значение'],lines,(2,))
    sheet('Типы клиентов',['Группа','EL начало BYN','EL факт BYN','Расходы BYN','EAD начало BYN','EAD факт BYN'],
          [[name,d['el0'],d['el1'],d['expenses'],d['ead0'],d['ead1']] for name,d in r['segments'].items()],(2,3,4,5,6))
    sheet('Денежные факторы',['Фактор','Расходы BYN'],[[k,v] for k,v in r['factors'].items()],(2,))
    sheet('Подфакторы движения КП',['Подфактор','Расходы BYN'],[[k,v] for k,v in r.get('subfactors',{}).items()],(2,))
    sheet('ЮЛ_ИП_Транши',['CRM ID','Клиент','УНП','Договор','Транш','Валюта','Стадия начало','Стадия факт','Рейтинг начало','Рейтинг факт','EAD начало BYN','EAD факт BYN','EL начало BYN','EL факт BYN','Расходы BYN','События'],
          [[x['crm'],x['client'],x['unp'],x['contract'],x['tranche'],x['currency'],x['stage0'],x['stage1'],x['rating0'],x['rating1'],x['ead0'],x['ead1'],x['el0'],x['el1'],x['expenses'],'; '.join(x['events'])] for x in r['positions'] if x['segment']=='ЮЛ и ИП'],(11,12,13,14,15))
    sheet('ФЛ_Субпортфели',['Субпортфель','EL начало BYN','EL факт BYN','Расходы BYN'],
          [[x['subportfolio'],x['el0'],x['el1'],x['expenses']] for x in r['fl_subportfolios']],(2,3,4))
    sheet('Банки_Клиенты',['CRM ID','Банк','EL начало BYN','EL факт BYN','Расходы BYN'],
          [[x['crm'],x['client'],x['el0'],x['el1'],x['expenses']] for x in r['banks']],(3,4,5))
    sheet('Факторы_ЮЛ_ИП',['CRM ID','Договор','Транш','Валюта','Расходы BYN']+list(r['factors']),
          [[x['crm'],x['contract'],x['tranche'],x['currency'],x['expenses']]+[x['factors'][key] for key in r['factors']] for x in r['positions'] if x['segment']=='ЮЛ и ИП'],tuple(range(5,6+len(r['factors']))))
    # Physical persons: exact sum of 16 reserve-component deltas per subportfolio;
    # independently allocates start and current balances so migrations reconcile.
    fl_components={}
    for x in r['positions']:
        if x['segment']!='Физические лица':continue
        oldsub=x['subportfolio0'];newsub=x['subportfolio1']
        if 'reserve_parts0' not in x or 'reserve_parts1' not in x:
            sub=newsub or oldsub
            entry=fl_components.setdefault(sub,{k:0. for k in x['reserve_changes']})
            for k,v in x['reserve_changes'].items():entry[k]+=v
            continue
        if oldsub:
            entry=fl_components.setdefault(oldsub,{k:0. for k in x['reserve_changes']})
            for k,v in x['reserve_parts0'].items():entry[k]+=v
        if newsub:
            entry=fl_components.setdefault(newsub,{k:0. for k in x['reserve_changes']})
            for k,v in x['reserve_parts1'].items():entry[k]-=v
    component_keys=sorted({k for m in fl_components.values() for k in m},key=int)
    sheet('Факторы_ФЛ',['Субпортфель','Расходы BYN']+[f'Резерв №{k}: изменение BYN' for k in component_keys],
          [[sub['subportfolio'],sub['expenses']]+[fl_components.get(sub['subportfolio'],{}).get(k,0.) for k in component_keys] for sub in r['fl_subportfolios']],
          tuple(range(2,3+len(component_keys))))
    sheet('Факторы_Банки',['CRM ID','Банк','Расходы BYN']+list(r['factors']),
          [[b['crm'],b['client'],b['expenses']]+[sum(x['factors'][k] for x in r['positions'] if x['segment']=='Банки' and x['crm']==b['crm']) for k in r['factors']] for b in r['banks']],tuple(range(3,4+len(r['factors']))))
    sheet('Переходы_стадий',['CRM ID','Клиент','Переход','Условный','Денежный эффект','Основная причина','Причины'],
          [[t['crm'],t['client'],f"{t['from']} → {t['to']}",t['synthetic'],t['expenses'],t.get('primary_cause') or '',
            '; '.join(d['label'] for d in t['reasons'])] for t in r.get('transitions',[])],(5,))
    sheet('Рейтинги',['CRM ID','Клиент','Рейтинг до','Рейтинг после','Направление','Расходы клиента BYN'],
          [[e['crm'],e['client'],e['before'],e['after'],e['movement'],e['expenses']] for e in r['ratings']],(6,))
    sheet('Существенные_ЮЛ_ИП',['CRM ID','Клиент','EL начало BYN','EL факт BYN','Расходы BYN','Комментарий'],
          [[x['crm'],x['client'],x['el0'],x['el1'],x['expenses'],x['comment']] for x in r['significant']],(3,4,5))
    sheet('Миграции_ФЛ',['Субпортфель до','Субпортфель после','EL до BYN','EL после BYN'],
          [[x['old'],x['new'],x['el0'],x['el1']] for x in r['fl_migrations']],(3,4))
    sheet('Компоненты_резервов',['CRM ID','Договор','Транш','Валюта','Компонент №','Расход BYN'],
          [[x['crm'],x['contract'],x['tranche'],x['currency'],k,v] for x in r['positions'] if x['segment']=='ЮЛ и ИП' for k,v in x['reserve_changes'].items()],(6,))
    sheet('Контроль',['Уровень','Строка Excel','CRM ID','Сообщение'],
          [[w.get('level',''),w.get('row',''),w.get('crm',''),w.get('message','')] for w in r['controls']['warnings']])
    out=BytesIO();wb.save(out);return out.getvalue()


def pdf_report(r):
    """Optional ReportLab: otherwise web UI offers browser Print→PDF, without a new dependency."""
    try:
        from reportlab.platypus import SimpleDocTemplate,Paragraph,Table,TableStyle,Spacer,KeepTogether
        from reportlab.lib import colors
        from reportlab.lib.styles import getSampleStyleSheet,ParagraphStyle
        from reportlab.lib.enums import TA_CENTER
        from reportlab.lib.pagesizes import A4
        from reportlab.pdfbase import pdfmetrics
        from reportlab.pdfbase.ttfonts import TTFont
    except ImportError as e:raise ValueError('Для серверной выгрузки PDF нужен reportlab; без него откройте «Версия для печати» и выберите «Сохранить как PDF» в браузере.') from e
    import os
    font='Helvetica'
    candidates=[str(Path(__file__).parent/'fonts'/'DejaVuSans.ttf'),'/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',
      'C:/Windows/Fonts/arial.ttf','C:/Windows/Fonts/seguisym.ttf','C:/Windows/Fonts/segoeui.ttf']
    for path in candidates:
        if os.path.exists(path):
            try:pdfmetrics.registerFont(TTFont('LocalCyrillic',path));font='LocalCyrillic';break
            except Exception:pass
    if font=='Helvetica':raise ValueError('Для русского PDF необходим системный шрифт с кириллицей; используйте печать через браузер.')
    buf=BytesIO();doc=SimpleDocTemplate(buf,pagesize=A4,rightMargin=32,leftMargin=32,topMargin=30,bottomMargin=30)
    styles=getSampleStyleSheet();styles.add(ParagraphStyle(name='RuTitle',fontName=font,fontSize=16,leading=20,textColor=colors.HexColor('#102A50'),spaceAfter=14))
    styles.add(ParagraphStyle(name='RuNormal',fontName=font,fontSize=9,leading=13,spaceAfter=7))
    styles.add(ParagraphStyle(name='RuHeading',fontName=font,fontSize=11,leading=15,spaceBefore=10,spaceAfter=8,textColor=colors.HexColor('#173F8E')))
    story=[Paragraph('Мониторинг расходов на резервы МСФО',styles['RuTitle']),
       Paragraph('База: '+r['base_date']+' | Текущий факт: '+r['current_date']+' | Версия № '+str(r['id']),styles['RuNormal']),
       Paragraph('Расходы = EL на начало месяца − EL текущего отчёта. Все суммы в BYN.',styles['RuNormal'])]
    def m(x):return f'{x:,.2f}'.replace(',',' ')
    def section(title,headers,rows,widths=None):
        story.append(Paragraph(title,styles['RuHeading']))
        data=[[Paragraph(str(c),styles['RuNormal']) for c in headers]]
        for row in rows:data.append([Paragraph(str(c),styles['RuNormal']) for c in row])
        tab=Table(data,repeatRows=1,hAlign='LEFT',colWidths=widths)
        tab.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#DCE7FA')),
             ('GRID',(0,0),(-1,-1),.3,colors.HexColor('#DFE6F2')),
             ('VALIGN',(0,0),(-1,-1),'TOP'),('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,colors.HexColor('#F7F9FC')]),('BOTTOMPADDING',(0,0),(-1,-1),5)]))
        story.append(tab)
    section('Сводка',('Показатель','Значение BYN'),[(k,m(r['totals'][v])) for k,v in (('EL на начало','el0'),('EL текущий','el1'),('Расходы','expenses'))],[250,255])
    section('Типы клиентов',('Группа','EL начало','EL факт','Расходы'),[(k,m(v['el0']),m(v['el1']),m(v['expenses'])) for k,v in r['segments'].items()],[140,120,120,125])
    if r.get('scope_label'):story.append(Paragraph('Выбранный срез: '+r['scope_label'],styles['RuNormal']))
    section('Факторный анализ (выбранный срез)',('Фактор','Расходы BYN'),[(k,m(v)) for k,v in r['factors'].items()],[315,190])
    section('Подфакторы движения КП',('Подфактор','Расходы BYN'),[(k,m(v)) for k,v in r.get('subfactors',{}).items()],[315,190])
    if r.get('transitions'):
        section('Переходы стадий и причины',('Клиент','Переход / эффект','Основная причина'),
          [(x['client'],f"{x['from']} → {x['to']} / {m(x['expenses'])}",x.get('primary_cause') or 'Не выбрана') for x in r['transitions'][:30]],[170,160,175])
    section('Миграция рейтингов — ЮЛ и ИП',('Клиент','Рейтинг','Расходы'),[(x['client'],str(x['before'])+' → '+str(x['after']),m(x['expenses'])) for x in r['ratings'][:20]],[230,100,175])
    section('Существенные клиенты ЮЛ и ИП',('Клиент','Расходы','Комментарий'),[(x['client'],m(x['expenses']),x['comment']) for x in r['significant'][:30]],[120,100,285])
    section('Физические лица — субпортфели',('Субпортфель','Расходы'),[(x['subportfolio'],m(x['expenses'])) for x in r['fl_subportfolios']],[305,200])
    section('Банки — клиенты',('Банк','Расходы'),[(x['client'],m(x['expenses'])) for x in r['banks'][:40]],[305,200])
    story.append(Spacer(1,16));story.append(Paragraph('Контрольная сверка факторов: '+m(r['controls']['reconciliation'])+' BYN. Метод v2: симметричная декомпозиция EAD и ставки, оценочный эффект стадии по ставкам портфеля. Остаточная ставка относится в движение КП. Рейтинг и риск-сигналы — возможные причины, а не доказанная причинность.',styles['RuNormal']))
    doc.build(story);return buf.getvalue()
