"""IFRS expense monitoring: two actual snapshots; no forecasting or BP."""
from __future__ import annotations
from collections import defaultdict
from datetime import datetime, date
from decimal import Decimal
from io import BytesIO
import json, math, re

RESERVE_NUMS=(71,73,75,77,79,81,83,85,87,89,91,93,95,97,99,101)
SIGNALS=(16,17,18,19,20,21,22,66)
KEY_FIELDS=("crm","contract","tranche","currency")
from factor_engine import FACTORS, SUBFACTORS
RISK_INPUTS=(14,16,17,18,19,20,21,22,23,32,33,34,35,36,37,40,66,67,105)



def number(x, default=0.0):
    if x is None or str(x).strip()=="": return default
    if isinstance(x,str): x=x.strip().replace('\u00a0','').replace(' ','').replace(',','.')
    v=float(x)
    if not math.isfinite(v):raise ValueError('Бесконечное / некорректное число')
    return v


def ident(x):
    if x is None:return ''
    s=str(x).strip()
    return s[:-2] if s.endswith('.0') and s[:-2].isdigit() else s


def datum(x):
    if isinstance(x, datetime):return x.date().isoformat()
    if isinstance(x, date):return x.isoformat()
    s=ident(x)
    for f in ('%Y-%m-%d','%d.%m.%Y','%Y-%m-%d %H:%M:%S'):
        try:return datetime.strptime(s,f).date().isoformat()
        except ValueError:pass
    raise ValueError('Не удалось определить отчетную дату: '+s)


def parse_excel(payload: bytes, filename: str):
    """Only in-memory read_only Excel ingestion, no source files written to disk."""
    from openpyxl import load_workbook
    wb=load_workbook(BytesIO(payload),read_only=True,data_only=True)
    ws=wb.active
    iterator=ws.iter_rows(values_only=True)
    headers=next(iterator,None)
    if not headers:raise ValueError('Пустой Excel')
    indexed={}
    for i,h in enumerate(headers):
        m=re.match(r'^\s*(\d+)\s*\.',str(h or ''))
        if m:indexed[int(m.group(1))]=i
    required=(1,2,3,4,5,9,14,24,26,27,30,31,45,48,49,51,55,70,86,87,88,89)
    missing=[str(n) for n in required if n not in indexed]
    if missing:raise ValueError('Отсутствуют обязательные столбцы по номерам: '+', '.join(missing))
    if len(indexed)<75:raise ValueError('Ожидается Excel МСФО с пронумерованной шапкой из 105 столбцов')
    rows=[]; dates=set(); warnings=[]
    for excel_row,raw in enumerate(iterator,2):
        if all(v is None for v in raw):continue
        def g(n):
            idx=indexed.get(n)
            return raw[idx] if idx is not None and idx<len(raw) else None
        try:
            d=datum(g(1)); status=ident(g(2)).lower(); crm=ident(g(3))
            if status not in ('ю','ип','ф','б'):raise ValueError('Неизвестный статус клиента: '+repr(status))
            if not crm:raise ValueError('Нет CRM ID клиента')
            stage=int(number(g(24))); ccy=ident(g(30)).upper() or 'BYN'
            if stage not in (1,2,3):raise ValueError('Стадия должна быть 1, 2 или 3')
            reserve={str(n):number(g(n)) for n in RESERVE_NUMS}
            row={'date':d,'status':status,'crm':crm,'unp':ident(g(4)),'client':ident(g(5)) or crm,
                'subportfolio':ident(g(9)) or 'Не указан','rating':number(g(14),-1),'stage':stage,
                'contract':ident(g(26)) or 'БЕЗ ДОГОВОРА','tranche':ident(g(27)), 'currency':ccy,
                'fx':number(g(31),1),'ead':number(g(45)), 'el':number(g(48)), 'rate':number(g(49)),
                'pd':number(g(51)),'lgd':number(g(55)),'individual':ident(g(59)),'maturity':ident(g(40)),
                'risk_fields':{str(k):ident(g(k)) for k in RISK_INPUTS},'active':sum(number(g(x)) for x in (70,72,74,76)),
                'uo':number(g(86)),'off':number(g(88)),'uo_reserve':number(g(87)),'off_reserve':number(g(89)),
                'reserves':reserve,'signals':{str(k):ident(g(k)) for k in SIGNALS},'line':excel_row}
            dates.add(d)
            if abs(row['el']-sum(reserve.values()))>0.0100001:
                warnings.append({'level':'error','row':excel_row,'crm':crm,'message':'EL отличается от суммы 16 компонентов более чем на 0,01 BYN'})
            if abs(row['el']-row['ead']*row['rate'])>0.0100001:
                warnings.append({'level':'warning','row':excel_row,'crm':crm,'message':'EL ≠ EAD × коэффициент резервирования (свыше 0,01 BYN)'})
            if row['ead']>0 and abs(row['el'])<0.00001:
                warnings.append({'level':'warning','row':excel_row,'crm':crm,'message':'EAD положителен, EL равен нулю'})
            if row['ead']<0 or row['el']<0 or any(v<0 for v in reserve.values()):
                warnings.append({'level':'error','row':excel_row,'crm':crm,'message':'Отрицательный EAD или резерв'})
            if row['ead']==0 and row['el']>0.01:
                warnings.append({'level':'error','row':excel_row,'crm':crm,'message':'EL положителен при EAD=0'})
            if not 0<=row['rate']<=1:
                warnings.append({'level':'error','row':excel_row,'crm':crm,'message':'Коэффициент резервирования вне 0..1'})
            if row['fx']<=0:
                warnings.append({'level':'error','row':excel_row,'crm':crm,'message':'Курс должен быть положительным'})
            rows.append(row)
        except (TypeError,ValueError,OverflowError) as e:
            warnings.append({'level':'error','row':excel_row,'crm':ident(g(3)),'message':'Некорректная строка: '+str(e)})
    if not rows:raise ValueError('Нет валидных строк факта')
    if len(dates)!=1:raise ValueError('В одном файле должна быть одна отчётная дата; найдено: '+', '.join(sorted(dates)))
    return {'date':next(iter(dates)),'rows':rows,'warnings':warnings,'source_name':filename,'count':len(rows)}


def aggregate_snapshot(raw):
    """Aggregates duplicate tranche/ccy positions, including all empty-tranche rows."""
    grouped={}; conflicts=[]
    for r in raw:
        key=tuple(r[k] for k in KEY_FIELDS)
        if key not in grouped:
            q={k:v for k,v in r.items() if k!='line'};q['rows_count']=0
            q['reserves']={p:0.0 for p in r['reserves']};q['lines']=[]
            grouped[key]=q
            for field in ('ead','el','active','uo','off','uo_reserve','off_reserve'):q[field]=0.0
        q=grouped[key]
        for name in ('ead','el','active','uo','off','uo_reserve','off_reserve'):q[name]+=r[name]
        for k,v in r['reserves'].items():q['reserves'][k]+=v
        q['rows_count']+=1;q['lines'].append(r['line'])
        for name in ('stage','rating','pd','lgd','fx','rate'):
            if name!='rate' and r[name]!=q[name]:
                conflicts.append({'level':'warning','crm':r['crm'],'row':r['line'],'message':f'Различаются {name} для одной позиции {key}'})
    return grouped,conflicts


def group_segment(row):
    return 'ЮЛ и ИП' if row['status'] in ('ю','ип') else ('Физические лица' if row['status']=='ф' else 'Банки')


def summarize_pair(base, current, *, base_stage_rates=None, current_stage_rates=None):
    """V2: independent, reconciled factor attribution; see factor_engine.py."""
    from factor_engine import calculate
    return calculate(base,current,base_stage_rates=base_stage_rates,current_stage_rates=current_stage_rates)
