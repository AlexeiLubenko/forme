"""Local-only HTTP service; bounded-memory Excel import, reporting via SQLite."""
from __future__ import annotations
import argparse, io, json, mimetypes, os, shutil, sqlite3, tempfile, threading, zlib
from contextlib import contextmanager
from datetime import datetime
from email.parser import BytesParser
from email.policy import default as email_default
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse, parse_qs, unquote

from core import FACTORS
from factor_engine import SUBFACTORS,stage_stats
from scalable import parse_xlsx_to_sqlite, setup_schema, calculate_stream, decode_position, encode_position
from reports import pdf_report
from large_export import export_to_path

ROOT=Path(__file__).resolve().parent
STATIC=ROOT/'static'
STORAGE=ROOT/'storage'
STORAGE.mkdir(parents=True,exist_ok=True)
DB=STORAGE/'reports.sqlite3'
BASE_PATH=STORAGE/'base_snapshot.xlsx'
MAX_UPLOAD=768*1024*1024
LOCK=threading.RLock()
PROGRESS={'stage':'Готово','rows':0,'active':False}

@contextmanager
def db():
    c=sqlite3.connect(DB,timeout=120)
    c.execute('PRAGMA journal_mode=WAL')
    c.execute('PRAGMA busy_timeout=120000')
    c.execute('PRAGMA synchronous=NORMAL')
    c.execute('''CREATE TABLE IF NOT EXISTS base_versions (id INTEGER PRIMARY KEY AUTOINCREMENT, date TEXT NOT NULL, filename TEXT, created_at TEXT, data BLOB NOT NULL)''')
    c.execute('''CREATE TABLE IF NOT EXISTS reports (id INTEGER PRIMARY KEY AUTOINCREMENT, base_id INTEGER, base_date TEXT, current_date TEXT, created_at TEXT, source_filename TEXT, data BLOB NOT NULL)''')
    c.execute('''CREATE TABLE IF NOT EXISTS comments (report_id INTEGER, crm TEXT, value TEXT, updated_at TEXT, PRIMARY KEY(report_id,crm))''')
    setup_schema(c)
    c.execute('''CREATE TABLE IF NOT EXISTS stage_causes(
      report_id INTEGER NOT NULL, crm TEXT NOT NULL, main_cause TEXT NOT NULL,
      updated_at TEXT, PRIMARY KEY(report_id,crm))''')
    # Existing demo/production databases created before v2 have no status column.
    if 'status' not in {row[1] for row in c.execute('PRAGMA table_info(reports)')}:
        c.execute("ALTER TABLE reports ADD COLUMN status TEXT NOT NULL DEFAULT 'complete'")
    try:
        yield c
        c.commit()
    except Exception:
        c.rollback()
        raise
    finally:c.close()

def pack(value):return zlib.compress(json.dumps(value,ensure_ascii=False,separators=(',',':')).encode('utf8'),5)
def unpack(value):return json.loads(zlib.decompress(value))
def now():return datetime.now().strftime('%Y-%m-%d %H:%M:%S')
def update_progress(stage,rows=0,active=True):PROGRESS.update(stage=stage,rows=rows,active=active)

def source_path(payload):
    """Accept a Path or legacy bytes, without forcing multi-GB byte copies."""
    if isinstance(payload,(str,Path)):return Path(payload),False
    if isinstance(payload,(bytes,bytearray)):
        import tempfile
        t=tempfile.NamedTemporaryFile(suffix='.xlsx',delete=False)
        try:t.write(payload);t.close()
        except Exception:t.close();Path(t.name).unlink(missing_ok=True);raise
        return Path(t.name),True
    raise TypeError('Ожидается путь к файлу или данные XLSX')

def save_base(blob,name):
    path,dispose=source_path(blob)
    try:
        with LOCK,db() as conn:
            update_progress('Чтение и проверка начального факта',0)
            # Temp table is removed after the successful import. Only the validated base
            # is kept permanently. Historical base positions are retained by version.
            table='import_base'
            conn.execute(f'DROP TABLE IF EXISTS {table}')
            meta=parse_xlsx_to_sqlite(path,conn,table,name,create_index=False,
                   progress=lambda count:update_progress('Чтение начального факта',count))
            update_progress('Сохранение начальной базы',meta['count'])
            cur=conn.execute('INSERT INTO base_versions(date,filename,created_at,data) VALUES(?,?,?,?)',
                     (meta['date'],name,now(),pack(meta)))
            bid=cur.lastrowid
            conn.execute(f'INSERT INTO base_rows(base_id,crm,data) SELECT ?,crm,data FROM {table}',(bid,))
            conn.execute(f'DROP TABLE {table}')
            # Original base file is intentionally retained as a single current copy.
            tmp=BASE_PATH.with_suffix('.xlsx.new')
            shutil.copyfile(path,tmp)
            tmp.replace(BASE_PATH)
        return {'base_id':bid,'date':meta['date'],'rows':meta['count'],'warnings':meta['warning_count']}
    finally:
        update_progress('Готово',0,False)
        if dispose:path.unlink(missing_ok=True)

def latest_base():
    with db() as conn:
        row=conn.execute('SELECT id,date,filename,created_at,data FROM base_versions ORDER BY id DESC LIMIT 1').fetchone()
    return row

def ensure_legacy_base(conn, row):
    """One-time non-destructive migration of older JSON-blob base snapshots."""
    bid=row[0]
    if conn.execute('SELECT 1 FROM base_rows WHERE base_id=? LIMIT 1',(bid,)).fetchone():
        meta=unpack(row[4])
        if 'stage_stats' not in meta:
            from scalable import decode_position
            from collections import defaultdict
            acc=defaultdict(lambda:[0.,0.])
            for (blob,) in conn.execute('SELECT data FROM base_rows WHERE base_id=?',(bid,)):
                r=decode_position(blob)
                if str(r.get('individual','')).strip().lower() in ('да','1','true','yes') or r['ead']<=0:continue
                seg='ЮЛ и ИП' if r['status'] in ('ю','ип') else ('Физические лица' if r['status']=='ф' else 'Банки')
                entry=acc[f"{seg}|{r['stage']}"];entry[0]+=r['el'];entry[1]+=r['ead']
            meta['stage_stats']={k:{'el':x[0],'ead':x[1]} for k,x in acc.items()}
            conn.execute('UPDATE base_versions SET data=? WHERE id=?',(pack(meta),bid))
            conn.commit()
        return meta
    data=unpack(row[4])
    if not data.get('rows'):raise ValueError('База не содержит нормализованных записей; загрузите факт на начало повторно')
    conn.executemany('INSERT INTO base_rows(base_id,crm,data) VALUES(?,?,?)',
       ((bid,r['crm'],encode_position(r)) for r in data['rows']))
    meta={k:v for k,v in data.items() if k!='rows'}
    meta['stage_stats']=stage_stats(data['rows'])
    meta['warning_count']=len(meta.get('warnings',[]))
    conn.execute('UPDATE base_versions SET data=? WHERE id=?',(pack(meta),bid))
    conn.commit()
    return meta

def cleanup_incomplete(conn):
    """Remove abandoned provisional calculations after a crash/cancel."""
    pending=[r[0] for r in conn.execute("SELECT id FROM reports WHERE status!='complete'")]
    for rid in pending:
        conn.execute('DELETE FROM report_positions WHERE report_id=?',(rid,))
        conn.execute('DELETE FROM report_clients WHERE report_id=?',(rid,))
        conn.execute('DELETE FROM report_ratings WHERE report_id=?',(rid,))
        conn.execute('DELETE FROM report_transitions WHERE report_id=?',(rid,))
        conn.execute('DELETE FROM stage_causes WHERE report_id=?',(rid,))
        conn.execute('DELETE FROM comments WHERE report_id=?',(rid,))
        conn.execute('DELETE FROM reports WHERE id=?',(rid,))
    return len(pending)

def save_run(blob,name):
    path,dispose=source_path(blob)
    try:
        with LOCK, tempfile.TemporaryDirectory(prefix='ifrs_daily_') as scratch:
            update_progress('Чтение текущего факта',0)
            scratchdb=sqlite3.connect(str(Path(scratch)/'current.sqlite3'))
            try:
                scratchdb.execute('PRAGMA synchronous=OFF')
                meta=parse_xlsx_to_sqlite(path,scratchdb,'current_rows',name,
                     progress=lambda count:update_progress('Чтение текущего факта',count))
                with db() as conn:
                    cleanup_incomplete(conn)
                    base=conn.execute('SELECT id,date,filename,created_at,data FROM base_versions ORDER BY id DESC LIMIT 1').fetchone()
                    if not base:raise ValueError('Сначала загрузите факт на начало месяца')
                    bdate=base[1]
                    by,bm=map(int,bdate[:7].split('-'))
                    cy,cm=map(int,meta['date'][:7].split('-'))
                    if cy*12+cm-(by*12+bm)!=1:
                        raise ValueError('База должна относиться к предыдущему календарному месяцу')
                    bmeta=ensure_legacy_base(conn,base)
                    created=now()
                    cur=conn.execute('INSERT INTO reports(base_id,base_date,current_date,created_at,source_filename,data,status) VALUES(?,?,?,?,?,?,?)',
                        (base[0],bdate,meta['date'],created,name,pack({'processing':True}),'processing'))
                    rid=cur.lastrowid
                    update_progress('Сопоставление и факторный анализ',0)
                    result=calculate_stream(conn,scratchdb,base[0],bmeta,meta,rid,progress=lambda count:update_progress('Факторный анализ',count))
                    result.update(base_id=base[0],source_filename=name,created_at=created)
                    conn.execute("UPDATE reports SET data=?,status='complete' WHERE id=?",(pack(result),rid))
                return {'report_id':rid,'date':meta['date'],'expenses':result['totals']['expenses'],
                        'warnings':result['controls']['warning_count'],'positions':result['controls']['positions']}
            finally:scratchdb.close()
    finally:
        update_progress('Готово',0,False)
        if dispose:path.unlink(missing_ok=True)

def read_report(report_id=None):
    with db() as conn:
        sql="SELECT id,data FROM reports WHERE status='complete' "+('ORDER BY id DESC LIMIT 1' if report_id is None else 'AND id=?')
        row=conn.execute(sql,() if report_id is None else (report_id,)).fetchone()
        if not row:raise ValueError('Отчёт не найден')
        r=unpack(row[1]);r['id']=row[0]
        comments=dict(conn.execute('SELECT crm,value FROM comments WHERE report_id=?',(row[0],)))
        for client in r.get('significant',[]):
            if client['crm'] in comments:client['comment']=comments[client['crm']]
    return r

def short_report(r):return {k:v for k,v in r.items() if k not in ('positions',)}

def archive():
    with db() as conn:
        bases=[dict(zip(('id','date','filename','created_at'),a)) for a in conn.execute('SELECT id,date,filename,created_at FROM base_versions ORDER BY id DESC')]
        reports=[dict(zip(('id','base_date','current_date','created_at','source_filename'),a)) for a in conn.execute("SELECT id,base_date,current_date,created_at,source_filename FROM reports WHERE status='complete' ORDER BY id DESC")]
    return {'bases':bases,'reports':reports}


def factor_scope(r,segment='Все',clients=None,subportfolio=None):
    """Small server-side aggregation over stored per-client factor summaries.

    Does not scan individual report positions or load the 400k-row dataset.
    """
    if segment not in ('Все','ЮЛ и ИП','Физические лица','Банки'):
        raise ValueError('Неизвестный сегмент')
    chosen=sorted(set(str(c).strip() for c in (clients or []) if str(c).strip()))
    if len(chosen)>100:raise ValueError('Для одного запроса доступно до 100 клиентов')
    if segment=='Физические лица' and subportfolio:
        subs=[x for x in r.get('fl_subportfolios',[]) if x['subportfolio']==subportfolio]
        if not subs:raise ValueError('Субпортфель не найден в выбранном отчёте')
        totals={'el0':sum(x['el0'] for x in subs),'el1':sum(x['el1'] for x in subs),
                'expenses':sum(x['expenses'] for x in subs),
                'ead0':sum(x.get('ead0',0.) for x in subs),'ead1':sum(x.get('ead1',0.) for x in subs)}
        factors={f:sum(x.get('factors',{}).get(f,0.) for x in subs) for f in FACTORS}
        sub={f:sum(x.get('subfactors',{}).get(f,0.) for x in subs) for f in SUBFACTORS}
        scope=f'Субпортфель: {subportfolio}'
    elif chosen:
        if segment not in ('ЮЛ и ИП','Банки'):
            raise ValueError('Выбор клиентов доступен только для ЮЛ/ИП и банков')
        with db() as conn:
            marks=','.join('?' for _ in chosen)
            rows=[json.loads(v[0]) for v in conn.execute(
                f'SELECT data FROM report_clients WHERE report_id=? AND segment=? AND crm IN ({marks})',
                [r['id'],segment]+chosen)]
        if len(rows)!=len(chosen):raise ValueError('Некоторые CRM ID отсутствуют в данном сегменте')
        totals={'el0':sum(x['el0'] for x in rows),'el1':sum(x['el1'] for x in rows),
                'expenses':sum(x['expenses'] for x in rows),
                'ead0':sum(x.get('ead0',0.) for x in rows),'ead1':sum(x.get('ead1',0.) for x in rows)}
        factors={f:sum(x.get('factors',{}).get(f,0.) for x in rows) for f in FACTORS}
        sub={f:sum(x.get('subfactors',{}).get(f,0.) for x in rows) for f in SUBFACTORS}
        scope='Клиенты: '+', '.join(x['client'] for x in rows[:8])+('…' if len(rows)>8 else '')
    else:
        base=r['totals'] if segment=='Все' else r['segments'][segment]
        totals={k:base.get(k,0.) for k in ('el0','el1','expenses','ead0','ead1')}
        factors=r['factors'] if segment=='Все' else r['segment_factors'][segment]
        sub=r.get('subfactors',{}) if segment=='Все' else r.get('segment_subfactors',{}).get(segment,{})
        scope='Все сегменты' if segment=='Все' else segment
    return {'scope':scope,'segment':segment,'selected_clients':chosen,'subportfolio':subportfolio,
            'totals':totals,'factors':factors,'subfactors':sub,
            'reconciliation':totals['expenses']-sum(factors.values()),
            'movement_reconciliation':factors.get('Движение КП',0.)-sum(sub.values()),
            'method_version':r.get('method_version','legacy')}



def scoped_report(r,segment='Все',clients=None,subportfolio=None):
    """A small report view for PDF and streaming Excel. Original result is never changed."""
    scope=factor_scope(r,segment,clients,subportfolio)
    if segment=='Все' and not clients and not subportfolio:return r,scope
    v=dict(r);v['totals']=scope['totals'];v['factors']=scope['factors'];v['subfactors']=scope['subfactors']
    v['segments']={segment:scope['totals']}
    v['scope_label']=scope['scope']
    v['controls']=dict(r['controls'])
    v['controls']['reconciliation']=scope['reconciliation']
    v['controls']['movement_reconciliation']=scope['movement_reconciliation']
    chosen=set(scope['selected_clients'])
    if clients:v['controls']['warnings']=[w for w in r['controls'].get('warnings',[]) if w.get('crm') in chosen]
    elif segment=='Физические лица':v['controls']['warnings']=[]
    v['fl_migrations']=[x for x in r.get('fl_migrations',[]) if segment in ('Все','Физические лица') and
        (not subportfolio or x['old']==subportfolio or x['new']==subportfolio)]
    if clients:
        with db() as conn:
            marks=','.join('?' for _ in chosen)
            select=[json.loads(x[0]) for x in conn.execute(
                f'SELECT data FROM report_clients WHERE report_id=? AND crm IN ({marks})',
                [r['id']]+list(chosen))]
            comments=dict(conn.execute('SELECT crm,value FROM comments WHERE report_id=?',(r['id'],)))
        for c in select:
            if c['crm'] in comments:c['comment']=comments[c['crm']]
        v['significant']=[x for x in select if x['segment']=='ЮЛ и ИП' and abs(x['expenses'])>=100000]
        v['banks']=[x for x in select if x['segment']=='Банки']
        v['ratings']=[x for x in r.get('ratings',[]) if x['crm'] in chosen]
    else:
        v['significant']=[] if segment!='ЮЛ и ИП' else r['significant']
        v['banks']=[] if segment!='Банки' else r['banks']
        v['ratings']=r.get('ratings',[]) if segment in ('Все','ЮЛ и ИП') else []
    v['fl_subportfolios']=[x for x in r.get('fl_subportfolios',[])
                           if segment in ('Все','Физические лица') and (not subportfolio or x['subportfolio']==subportfolio)]
    v['transitions']=stage_transitions(r,segment,clients)
    return v,scope

def search_clients(r,segment,search='',limit=50):
    if segment not in ('ЮЛ и ИП','Банки'):return []
    q=search.strip().lower()
    with db() as conn:
        sql='SELECT data FROM report_clients WHERE report_id=? AND segment=?'
        args=[r['id'],segment]
        if q:
            sql+=' AND search_text LIKE ?'
            args.append('%'+q+'%')
        sql+=' ORDER BY expense_abs DESC LIMIT ?';args.append(min(100,limit))
        return [{'crm':x['crm'],'client':x['client'],'expenses':x['expenses']}
                for (blob,) in conn.execute(sql,args) for x in (json.loads(blob),)]


def stage_transitions(r,segment='Все',clients=None,limit=300):
    chosen=sorted(set(clients or []))
    with db() as conn:
        where='WHERE a.report_id=?';args=[r['id']]
        if segment in ('ЮЛ и ИП','Банки'):
            where+=' AND a.segment=?';args.append(segment)
        if chosen:
            marks=','.join('?' for _ in chosen)
            where+=f' AND a.crm IN ({marks})';args.extend(chosen)
        rows=[]
        sql=('SELECT a.data, b.main_cause FROM report_transitions a LEFT JOIN stage_causes b '
             'ON a.report_id=b.report_id AND a.crm=b.crm '+where+' ORDER BY a.crm LIMIT ?')
        for data,cause in conn.execute(sql,args+[limit]):
            x=json.loads(data);x['primary_cause']=cause;rows.append(x)
    return rows

def paged_stage_transitions(r,segment='Все',clients=None,page=1,limit=30):
    """Read a page of saved stage changes; FL are intentionally aggregate-only."""
    if segment=='Физические лица':return {'rows':[],'total':0,'page':page,'limit':limit}
    chosen=sorted(set(clients or []))
    where='WHERE a.report_id=?';args=[r['id']]
    if segment in ('ЮЛ и ИП','Банки'):
        where+=' AND a.segment=?';args.append(segment)
    if chosen:
        where+=' AND a.crm IN ('+','.join('?' for _ in chosen)+')';args+=chosen
    with db() as conn:
        total=conn.execute('SELECT COUNT(*) FROM report_transitions a '+where,args).fetchone()[0]
        sql=('SELECT a.data,b.main_cause FROM report_transitions a LEFT JOIN stage_causes b '
             'ON b.report_id=a.report_id AND b.crm=a.crm '+where+' ORDER BY a.crm LIMIT ? OFFSET ?')
        rows=[]
        for blob,cause in conn.execute(sql,args+[limit,(page-1)*limit]):
            t=json.loads(blob);t['primary_cause']=cause;rows.append(t)
    return {'rows':rows,'total':total,'page':page,'limit':limit}


def get_positions(r,seg,search,page,limit,clients=None):
    if not r.get('scalable'):
        arr=[x for x in r['positions'] if x['segment']==seg and (not clients or x['crm'] in clients) and (not search or any(search in str(x.get(col,'')).lower() for col in ('client','crm','unp','contract','tranche','currency')))]
        arr.sort(key=lambda x:-abs(x['expenses']))
        return {'total':len(arr),'page':page,'limit':limit,'rows':arr[(page-1)*limit:page*limit]}
    where='WHERE report_id=? AND segment=?'
    params=[r['id'],seg]
    if clients:
        where+=' AND crm IN ('+','.join('?' for _ in clients)+')';params.extend(clients)
    if search:
        where+=' AND search_text LIKE ?'
        params.append('%'+search.lower()+'%')
    with db() as conn:
        n=conn.execute('SELECT COUNT(*) FROM report_positions '+where,params).fetchone()[0]
        rows=[decode_position(x[0]) for x in conn.execute('SELECT data FROM report_positions '+where+' ORDER BY expense_abs DESC LIMIT ? OFFSET ?',params+[limit,(page-1)*limit])]
    return {'total':n,'page':page,'limit':limit,'rows':rows}

def get_significant(r,page,limit,search='',clients=None):
    if not r.get('scalable'):
        rows=[x for x in r['significant'] if abs(x['expenses'])>=100000 and (not clients or x['crm'] in clients) and (not search or search.lower() in (x['crm']+x['client']).lower())]
        return {'total':len(rows),'rows':rows[(page-1)*limit:page*limit],'page':page,'limit':limit}
    where="WHERE report_id=? AND segment='ЮЛ и ИП' AND expense_abs>=100000"
    params=[r['id']]
    if clients:where+=' AND crm IN ('+','.join('?' for _ in clients)+')';params.extend(clients)
    if search:where+=' AND search_text LIKE ?';params.append('%'+search.lower()+'%')
    with db() as conn:
        n=conn.execute('SELECT COUNT(*) FROM report_clients '+where,params).fetchone()[0]
        arr=[json.loads(row[0]) for row in conn.execute('SELECT data FROM report_clients '+where+' ORDER BY expense_abs DESC LIMIT ? OFFSET ?',params+[limit,(page-1)*limit])]
        comments=dict(conn.execute('SELECT crm,value FROM comments WHERE report_id=?',(r['id'],)))
        for item in arr:
            if item['crm'] in comments:item['comment']=comments[item['crm']]
    return {'total':n,'rows':arr,'page':page,'limit':limit}

def get_banks(r,page,limit,search='',clients=None):
    if not r.get('scalable'):
        rows=[x for x in r['banks'] if (not clients or x['crm'] in clients) and (not search or search.lower() in (x['crm']+x['client']).lower())]
        return {'total':len(rows),'rows':rows[(page-1)*limit:page*limit],'page':page,'limit':limit}
    where="WHERE report_id=? AND segment='Банки'"
    params=[r['id']]
    if clients:where+=' AND crm IN ('+','.join('?' for _ in clients)+')';params.extend(clients)
    if search:where+=' AND search_text LIKE ?';params.append('%'+search.lower()+'%')
    with db() as conn:
        total=conn.execute('SELECT COUNT(*) FROM report_clients '+where,params).fetchone()[0]
        rows=[json.loads(p[0]) for p in conn.execute('SELECT data FROM report_clients '+where+' ORDER BY expense_abs DESC LIMIT ? OFFSET ?',params+[limit,(page-1)*limit])]
    return {'total':total,'rows':rows,'page':page,'limit':limit}

def parse_multipart(body,ctype):
    message=BytesParser(policy=email_default).parsebytes((f'MIME-Version: 1.0\r\nContent-Type: {ctype}\r\n\r\n').encode()+body)
    if not message.is_multipart():raise ValueError('Ожидается multipart/form-data')
    for item in message.iter_parts():
        name=item.get_filename()
        if name:return item.get_payload(decode=True),Path(name).name
    raise ValueError('Файл не передан')

class Handler(BaseHTTPRequestHandler):
    server_version='IFRSExpenses/2.0'
    def log_message(self,*args):pass
    def respond(self,data,status=200,ctype='application/json',filename=None):
        if isinstance(data,(dict,list)):data=json.dumps(data,ensure_ascii=False,allow_nan=False).encode('utf8')
        elif isinstance(data,str):data=data.encode('utf8')
        self.send_response(status)
        self.send_header('Content-Type',ctype)
        self.send_header('Content-Length',str(len(data)))
        self.send_header('Cache-Control','no-store')
        self.send_header('X-Content-Type-Options','nosniff')
        if filename:self.send_header('Content-Disposition',f'attachment; filename="{filename}"')
        self.end_headers();self.wfile.write(data)
    def respond_file(self,path,ctype,filename):
        self.send_response(200)
        self.send_header('Content-Type',ctype)
        self.send_header('Content-Length',str(Path(path).stat().st_size))
        self.send_header('Cache-Control','no-store')
        self.send_header('Content-Disposition',f'attachment; filename="{filename}"')
        self.end_headers()
        with open(path,'rb') as fd:shutil.copyfileobj(fd,self.wfile,1024*1024)
    def failure(self,e):self.respond({'error':str(e)},400)
    def do_GET(self):
        try:
            p=urlparse(self.path);q=parse_qs(p.query)
            if p.path=='/api/progress':self.respond(dict(PROGRESS));return
            if p.path=='/api/state':
                a=archive();self.respond({'archive':a,'has_base':bool(a['bases']),'has_reports':bool(a['reports'])});return
            if p.path=='/api/report':
                rid=int(q['id'][0]) if q.get('id') else None
                self.respond(short_report(read_report(rid)));return
            if p.path=='/api/factor-scope':
                r=read_report(int(q['id'][0]) if q.get('id') else None)
                ids=[x.strip() for item in q.get('crm',[]) for x in item.split(',') if x.strip()]
                self.respond(factor_scope(r,q.get('segment',['Все'])[0],ids,
                    q.get('subportfolio',[''])[0] or None));return
            if p.path=='/api/client-search':
                r=read_report(int(q['id'][0]) if q.get('id') else None)
                self.respond({'clients':search_clients(r,q.get('segment',['ЮЛ и ИП'])[0],q.get('search',[''])[0])});return
            if p.path=='/api/transitions':
                r=read_report(int(q['id'][0]) if q.get('id') else None)
                ids=[x.strip() for item in q.get('crm',[]) for x in item.split(',') if x.strip()]
                segment=q.get('segment',['Все'])[0]
                sub=q.get('subportfolio',[''])[0]
                pg=max(1,int(q.get('page',['1'])[0]));lim=min(100,max(10,int(q.get('limit',['30'])[0])))
                tpage=paged_stage_transitions(r,segment,ids,pg,lim)
                trows=tpage['rows']
                if segment=='Физические лица':
                    summary=(r.get('transition_by_fl_subportfolio',{}).get(sub,{}) if sub
                              else r.get('transition_by_segment',{}).get('Физические лица',{}))
                elif ids:
                    summary={}
                    for t in stage_transitions(r,segment,ids,max(300,len(ids))):
                        name=f"{t['from']} → {t['to']}"
                        item=summary.setdefault(name,{'clients':0,'expenses':0.,'ead0':0.,'ead1':0.})
                        item['clients']+=1;item['expenses']+=t['expenses'];item['ead0']+=t['ead0'];item['ead1']+=t['ead1']
                else:
                    summary=(r.get('transition_by_segment',{}).get(segment,{}) if segment!='Все'
                             else r.get('transition_summary',{}))
                self.respond({'rows':trows,'summary':summary,'total':tpage['total'],'page':pg,'limit':lim});return
            if p.path=='/api/positions':
                r=read_report(int(q['id'][0]) if q.get('id') else None)
                seg=q.get('segment',['ЮЛ и ИП'])[0];search=q.get('search',[''])[0].strip()
                page=max(1,int(q.get('page',[1])[0]));limit=min(200,max(10,int(q.get('limit',[50])[0])))
                self.respond(get_positions(r,seg,search,page,limit,[x for item in q.get('crm',[]) for x in item.split(',') if x]));return
            if p.path=='/api/banks':
                r=read_report(int(q['id'][0]) if q.get('id') else None)
                page=max(1,int(q.get('page',[1])[0]));limit=min(200,max(10,int(q.get('limit',[50])[0])))
                self.respond(get_banks(r,page,limit,q.get('search',[''])[0],[x for item in q.get('crm',[]) for x in item.split(',') if x]));return
            if p.path=='/api/significant':
                r=read_report(int(q['id'][0]) if q.get('id') else None)
                page=max(1,int(q.get('page',[1])[0]));limit=min(100,max(10,int(q.get('limit',[30])[0])))
                self.respond(get_significant(r,page,limit,q.get('search',[''])[0],[x for item in q.get('crm',[]) for x in item.split(',') if x]));return
            if p.path.startswith('/api/export/'):
                original=read_report(int(q['id'][0]) if q.get('id') else None)
                segment=q.get('segment',['Все'])[0]
                selected=[x.strip() for item in q.get('crm',[]) for x in item.split(',') if x.strip()]
                sub=q.get('subportfolio',[''])[0] or None
                r,_=scoped_report(original,segment,selected,sub)
                filt={'segment':segment,'clients':selected,'subportfolio':sub}
                if p.path.endswith('.xlsx'):
                    with tempfile.TemporaryDirectory(prefix='ifrs_export_') as tmp:
                        dest=Path(tmp)/'export.xlsx'
                        export_to_path(r,DB,dest,filter_spec=filt)
                        self.respond_file(dest,'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',f'IFRS_expenses_{r["current_date"]}_v{r["id"]}.xlsx')
                    return
                if p.path.endswith('.pdf'):
                    self.respond(pdf_report(r),ctype='application/pdf',filename=f'IFRS_expenses_{r["current_date"]}_v{r["id"]}.pdf');return
            rel='index.html' if p.path=='/' else p.path.lstrip('/')
            target=(STATIC/rel).resolve()
            if not target.is_relative_to(STATIC.resolve()) or not target.is_file():self.respond({'error':'Not found'},404);return
            content=target.read_bytes();mime=mimetypes.guess_type(str(target))[0] or 'application/octet-stream'
            if target.suffix=='.js':mime='text/javascript'
            self.respond(content,ctype=mime+'; charset=utf-8' if mime.startswith(('text/','application/javascript')) else mime)
        except (BrokenPipeError,ConnectionResetError):pass
        except Exception as e:self.failure(e)
    def do_POST(self):
        try:
            p=urlparse(self.path).path
            size=int(self.headers.get('Content-Length','0'))
            if size<=0 or size>MAX_UPLOAD:raise ValueError('Размер загрузки превышает 768 МБ или тело пустое')
            if p in ('/api/base','/api/run'):
                ctype=self.headers.get('Content-Type','')
                if ctype.startswith('application/octet-stream') or ctype.startswith('application/vnd.openxmlformats'):
                    filename=Path(unquote(self.headers.get('X-Filename','fact.xlsx'))).name
                    if not filename.lower().endswith('.xlsx'):raise ValueError('Ожидается Excel .xlsx')
                    with tempfile.TemporaryDirectory(prefix='ifrs_upload_') as tmp:
                        path=Path(tmp)/'uploaded.xlsx'
                        remaining=size
                        with path.open('wb') as out:
                            while remaining:
                                chunk=self.rfile.read(min(1024*1024,remaining))
                                if not chunk:raise ValueError('Загрузка прервана')
                                out.write(chunk);remaining-=len(chunk)
                        result=save_base(path,filename) if p=='/api/base' else save_run(path,filename)
                        self.respond(result)
                    return
                # Backward compatibility for older small multipart upload clients.
                if size>16*1024*1024:raise ValueError('Для больших Excel используйте новую форму загрузки в интерфейсе')
                blob,name=parse_multipart(self.rfile.read(size),ctype)
                if not name.lower().endswith('.xlsx'):raise ValueError('Ожидается Excel .xlsx')
                self.respond(save_base(blob,name) if p=='/api/base' else save_run(blob,name));return
            if size>100000:raise ValueError('Слишком большой JSON запрос')
            data=json.loads(self.rfile.read(size))
            if p=='/api/stage-cause':
                rid=int(data['report_id']);crm=str(data['crm']).strip()
                choice=str(data.get('primary_cause','')).strip()[:500]
                r=read_report(rid)
                options=stage_transitions(r,'Все',[crm],2)
                if not options:raise ValueError('Переход клиента не найден')
                allowed=[x['label'] for x in options[0]['reasons']]
                if choice and choice not in allowed and choice!='Другое / уточнить':
                    raise ValueError('Причина должна быть выбрана из выявленных изменений')
                with db() as conn:conn.execute('INSERT OR REPLACE INTO stage_causes(report_id,crm,main_cause,updated_at) VALUES(?,?,?,?)',
                    (rid,crm,choice,now()))
                self.respond({'saved':True});return
            if p=='/api/comment':
                rid=int(data['report_id']);crm=str(data['crm']);comment=str(data.get('comment','')).strip()[:4000]
                _=read_report(rid)
                with db() as conn:conn.execute('INSERT OR REPLACE INTO comments(report_id,crm,value,updated_at) VALUES(?,?,?,?)',(rid,crm,comment,now()))
                self.respond({'saved':True});return
            self.respond({'error':'Unknown endpoint'},404)
        except (BrokenPipeError,ConnectionResetError):pass
        except Exception as e:self.failure(e)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--port',type=int,default=8501);ap.add_argument('--host',default='127.0.0.1');args=ap.parse_args()
    with db() as conn:cleanup_incomplete(conn)
    server=ThreadingHTTPServer((args.host,args.port),Handler)
    print(f'Откройте в браузере http://{args.host}:{args.port}/')
    server.serve_forever()
if __name__=='__main__':main()
