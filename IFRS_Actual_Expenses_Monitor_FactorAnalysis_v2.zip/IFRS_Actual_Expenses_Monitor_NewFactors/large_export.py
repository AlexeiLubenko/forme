"""Memory-bounded XLSX generation directly from persisted SQLite report positions."""
from __future__ import annotations
from collections import defaultdict
import json, sqlite3
from pathlib import Path

from core import RESERVE_NUMS, FACTORS, SUBFACTORS
from scalable import decode_position

NAVY='142A55'
NUM='#,##0.00;[Red](#,##0.00);–'

def export_to_path(report,db_path,target,filter_spec=None):
    """Write Excel incrementally. Does not accumulate 400k positions or 6.4m reserve rows."""
    target=Path(target)
    filter_spec=filter_spec or {}
    crms=filter_spec.get('clients') or []
    seg=filter_spec.get('segment') or 'Все'
    subportfolio=filter_spec.get('subportfolio') or ''
    if not report.get('scalable'):
        from reports import excel_report
        target.write_bytes(excel_report(report))
        return target
    from openpyxl import Workbook
    from openpyxl.cell import WriteOnlyCell
    from openpyxl.styles import Font,PatternFill,Alignment
    from openpyxl.utils import get_column_letter
    wb=Workbook(write_only=True)
    conn=sqlite3.connect(db_path)
    try:
        rid=report['id']
        def sheet(name,headers,rows,money=()):
            ws=wb.create_sheet(name)
            ws.freeze_panes='A2'
            for i,h in enumerate(headers,1):
                ws.column_dimensions[get_column_letter(i)].width=min(37,max(13,len(str(h))*.92+3))
            head=[]
            for h in headers:
                c=WriteOnlyCell(ws,value=h)
                c.font=Font(color='FFFFFF',bold=True,size=10)
                c.fill=PatternFill('solid',fgColor=NAVY)
                c.alignment=Alignment(wrap_text=True,vertical='center')
                head.append(c)
            ws.append(head)
            for row in rows:
                values=[]
                for i,v in enumerate(row,1):
                    if v is not None and not isinstance(v,(str,int,float)):
                        v=str(v)
                    if isinstance(v,(float,int)) and i in money:
                        c=WriteOnlyCell(ws,value=v);c.number_format=NUM;values.append(c)
                    else:values.append(v)
                ws.append(values)
            return ws
        def position_rows(segment=None):
            if seg!='Все' and segment and seg!=segment:return
            sql='SELECT data FROM report_positions WHERE report_id=?'
            params=[rid]
            if segment:sql+=' AND segment=?';params.append(segment)
            elif seg!='Все':sql+=' AND segment=?';params.append(seg)
            if crms:
                sql+=' AND crm IN ('+','.join('?' for _ in crms)+')';params+=crms
            sql+=' ORDER BY crm'
            for (data,) in conn.execute(sql,params):yield decode_position(data)
        t=report['totals']
        sheet('Сводка',['Показатель','Значение'],[
            ('База',report['base_date']),('Текущий факт',report['current_date']),
            ('Версия',report['id']),('Исходный файл',report['source_filename']),
            ('Формула','EL на начало − EL текущий'),('EL начало, BYN',t['el0']),
            ('EL факт, BYN',t['el1']),('Расходы, BYN',t['expenses']),
            ('Сверка факторов, BYN',report['controls']['reconciliation']),
            ('Всего позиций',report['controls']['positions']),
            ('Всего замечаний',report['controls']['warning_count']),
            ('Методика',report['method_note'])],(2,))
        sheet('Типы клиентов',['Сегмент','EL начало','EL факт','Расходы','EAD начало','EAD факт'],
            ((name,s['el0'],s['el1'],s['expenses'],s.get('ead0'),s.get('ead1')) for name,s in report['segments'].items()),(2,3,4,5,6))
        sheet('Денежные факторы',['Фактор','Расходы BYN'],report['factors'].items(),(2,))
        sheet('Подфакторы движения КП',['Подфактор','Расходы BYN'],report.get('subfactors',{}).items(),(2,))
        sheet('ЮЛ_ИП_Транши', ['CRM ID','Клиент','УНП','Договор','Транш','Валюта','Стадия начало','Стадия факт','Рейтинг начало','Рейтинг факт','EAD начало BYN','EAD факт BYN','EL начало BYN','EL факт BYN','Расходы BYN','События'],
            ((p['crm'],p['client'],p['unp'],p['contract'],p['tranche'],p['currency'],p['stage0'],p['stage1'],p['rating0'],p['rating1'],p['ead0'],p['ead1'],p['el0'],p['el1'],p['expenses'],'; '.join(p['events'])) for p in position_rows('ЮЛ и ИП')),(11,12,13,14,15))
        sheet('ФЛ_Субпортфели',['Субпортфель','EL начало BYN','EL факт BYN','Расходы BYN'],
            ((p['subportfolio'],p['el0'],p['el1'],p['expenses']) for p in report['fl_subportfolios'] if not subportfolio or p['subportfolio']==subportfolio),(2,3,4))
        # Full bank list, not the top-1000 preview in the browser.
        bank_totals=defaultdict(lambda:{'name':'','el0':0.,'el1':0.,'expenses':0.,'factors':defaultdict(float),'subfactors':defaultdict(float)})
        for p in position_rows('Банки'):
            a=bank_totals[p['crm']]
            a['name']=p['client']
            for f in ('el0','el1','expenses'):a[f]+=p[f]
            for f,v in p['factors'].items():a['factors'][f]+=v
            for f,v in p.get('subfactors',{}).items():a['subfactors'][f]+=v
        sheet('Банки_Клиенты',['CRM ID','Банк','EL начало','EL факт','Расходы'],
            ((crm,a['name'],a['el0'],a['el1'],a['expenses']) for crm,a in bank_totals.items()),(3,4,5))
        sheet('Факторы_ЮЛ_ИП',['CRM ID','Договор','Транш','Валюта','Расходы BYN']+list(FACTORS)+list(SUBFACTORS),
            ((p['crm'],p['contract'],p['tranche'],p['currency'],p['expenses'],*(p['factors'].get(f,0.) for f in FACTORS),*(p.get('subfactors',{}).get(f,0.) for f in SUBFACTORS)) for p in position_rows('ЮЛ и ИП')),
            tuple(range(5,6+len(FACTORS)+len(SUBFACTORS))))
        # FL components are aggregated while scanning data, never exported as individual clients.
        fl_parts=report.get('fl_components')
        if fl_parts is None: # Legacy results stored FL rows in the positions table.
            fl_parts=defaultdict(lambda:defaultdict(float))
            for p in position_rows('Физические лица'):
                for f in RESERVE_NUMS:
                    k=str(f)
                    if p['subportfolio0']:fl_parts[p['subportfolio0']][k]+=p['reserve_parts0'][k]
                    if p['subportfolio1']:fl_parts[p['subportfolio1']][k]-=p['reserve_parts1'][k]
        sheet('Факторы_ФЛ',['Субпортфель','Расходы BYN']+[f'Резерв №{f}' for f in RESERVE_NUMS],
            ((a['subportfolio'],a['expenses'],*(fl_parts.get(a['subportfolio'],{}).get(str(f),0.) for f in RESERVE_NUMS)) for a in report['fl_subportfolios'] if not subportfolio or a['subportfolio']==subportfolio),
            tuple(range(2,3+len(RESERVE_NUMS))))
        sheet('Факторы_Банки',['CRM ID','Банк','Расходы BYN']+list(FACTORS)+list(SUBFACTORS),
            ((crm,a['name'],a['expenses'],*(a['factors'][f] for f in FACTORS),*(a['subfactors'][f] for f in SUBFACTORS)) for crm,a in bank_totals.items()),
            tuple(range(3,4+len(FACTORS)+len(SUBFACTORS))))
        sheet('Рейтинги',['CRM ID','Клиент','Рейтинг до','Рейтинг после','Изменение','Расходы BYN'],
            ((p['crm'],p['client'],p['before'],p['after'],p['movement'],p['expenses']) for (data,) in conn.execute('SELECT data FROM report_ratings WHERE report_id=? ORDER BY expense_abs DESC',(rid,)) for p in (json.loads(data),) if seg in ('Все','ЮЛ и ИП') and (not crms or p['crm'] in crms)),(6,))
        sql='''SELECT c.data, v.value FROM report_clients c LEFT JOIN comments v ON v.report_id=c.report_id AND v.crm=c.crm
            WHERE c.report_id=? AND c.segment='ЮЛ и ИП' AND c.expense_abs>=100000 ORDER BY c.expense_abs DESC'''
        sheet('Существенные_ЮЛ_ИП',['CRM ID','Клиент','EL начало','EL факт','Расходы','Комментарий'],
            ((p['crm'],p['client'],p['el0'],p['el1'],p['expenses'],comment if comment is not None else p.get('comment',''))
             for data,comment in conn.execute(sql,(rid,)) for p in (json.loads(data),) if seg in ('Все','ЮЛ и ИП') and (not crms or p['crm'] in crms)),(3,4,5))
        transition_sql='''SELECT t.data, c.main_cause FROM report_transitions t
          LEFT JOIN stage_causes c ON c.report_id=t.report_id AND c.crm=t.crm WHERE t.report_id=?'''
        sheet('Переходы_стадий',['CRM ID','Клиент','Переход','Условный','Денежный эффект','Основная причина','Изменившиеся признаки'],
            ((t['crm'],t['client'],f"{t['from']} → {t['to']}",'Да' if t['synthetic'] else 'Нет',
               t['expenses'],choice or '', '; '.join(x['label']+': '+str(x['before'])+' → '+str(x['after']) for x in t['reasons']))
             for data,choice in conn.execute(transition_sql,(rid,)) for t in (json.loads(data),)
             if (not crms or t['crm'] in crms) and (seg=='Все' or seg==t['segment'])),(5,))
        sheet('Миграции_ФЛ',['Субпортфель до','Субпортфель после','EL до','EL после','Позиций'],
            ((x['old'],x['new'],x['el0'],x['el1'],x['count']) for x in report['fl_migrations']),(3,4))
        # Wide representation avoids >1,048,576 rows for 400k positions x 16 components.
        sheet('Компоненты_резервов',['CRM ID','Договор','Транш','Валюта']+[f'Резерв №{f}' for f in RESERVE_NUMS],
            ((p['crm'],p['contract'],p['tranche'],p['currency'],*(p['reserve_changes'][str(f)] for f in RESERVE_NUMS)) for p in position_rows('ЮЛ и ИП')),
            tuple(range(5,5+len(RESERVE_NUMS))))
        sheet('Контроль',['Уровень','Строка Excel','CRM ID','Сообщение'],
            ((x.get('level',''),x.get('row',''),x.get('crm',''),x.get('message','')) for x in report['controls']['warnings']))
        wb.save(target)
        return target
    finally:conn.close()
