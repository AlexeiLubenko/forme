#!/bin/bash
set -Eeuo pipefail
cd "$(dirname "$0")"

on_error() {
  echo ""
  echo "Не удалось запустить проект (строка $1)."
  echo "Проверьте установленный Python 3.13 и доступ к PyPI или внутреннему зеркалу."
  echo "Папка portfolio_storage не изменялась."
  read -r -p "Нажмите Enter для закрытия окна..." _ || true
}
trap 'on_error "$LINENO"' ERR

PYTHON_BIN="${PORTFOLIO_PYTHON:-}"
if [[ -z "$PYTHON_BIN" ]]; then
  for candidate in python3.13 python3 python; do
    if command -v "$candidate" >/dev/null 2>&1 &&       "$candidate" -c 'import sys; sys.exit(0 if sys.version_info[:2] == (3,13) else 1)' >/dev/null 2>&1; then
      PYTHON_BIN="$candidate"
      break
    fi
  done
fi

if [[ -z "$PYTHON_BIN" ]]; then
  echo "Python 3.13 не найден. Проверьте команду python3.13 --version"
  exit 1
fi

"$PYTHON_BIN" -c 'import sys; assert sys.version_info[:2] == (3,13), "Нужен Python 3.13"'
echo "Используется $($PYTHON_BIN --version)"
"$PYTHON_BIN" setup_environment.py
exec ".venv_py313/bin/python" -m streamlit run portfolio_app.py --server.address=127.0.0.1
