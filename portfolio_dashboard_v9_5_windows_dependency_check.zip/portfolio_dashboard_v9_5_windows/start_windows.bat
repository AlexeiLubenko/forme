@echo off
setlocal
chcp 65001 >nul
set "PYTHONIOENCODING=utf-8"
cd /d "%~dp0"

rem Prefer Windows Python Launcher; fall back to python from PATH.
py -3.13 -c "import sys; sys.exit(sys.version_info[:2] != (3,13))" >nul 2>&1
if not errorlevel 1 (
    py -3.13 windows_launcher.py
    goto finish
)
python -c "import sys; sys.exit(sys.version_info[:2] != (3,13))" >nul 2>&1
if not errorlevel 1 (
    python windows_launcher.py
    goto finish
)
echo Python 3.13 not found. Check: py -3.13 --version
:finish
echo.
pause
