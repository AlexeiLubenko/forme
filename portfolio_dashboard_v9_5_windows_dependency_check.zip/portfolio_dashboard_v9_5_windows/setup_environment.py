"""Install dashboard dependencies into a dedicated Python 3.13 environment.

Run using `python3.13 setup_environment.py` or from the Jupyter notebook.
No system pip executable or global package installation is required.
Nothing in `portfolio_storage` is modified.
"""

from __future__ import annotations

import os
from pathlib import Path
import subprocess
import sys

PROJECT = Path(__file__).resolve().parent
ENV_DIR = PROJECT / ".venv_py313"
REQUIREMENTS = PROJECT / "requirements.txt"


def environment_python(env_dir: Path = None) -> Path:
    env_dir = env_dir or ENV_DIR
    if os.name == "nt":
        return env_dir / "Scripts" / "python.exe"
    return env_dir / "bin" / "python"


def run(*args: str) -> None:
    subprocess.run(list(args), check=True)


def install() -> Path:
    version = sys.version_info[:2]
    if version != (3, 13):
        raise RuntimeError(
            "Этот установщик рассчитан на Python 3.13. "
            "Запустите `python3.13 setup_environment.py` либо проверьте ядро Jupyter."
        )
    if not REQUIREMENTS.is_file():
        raise FileNotFoundError("Не найден requirements.txt: {}".format(REQUIREMENTS))

    python_path = environment_python()
    if not python_path.is_file():
        print("[1/3] Создаю .venv_py313 для Python 3.13 ...", flush=True)
        run(sys.executable, "-m", "venv", str(ENV_DIR))
        if not python_path.is_file():
            raise RuntimeError("Не удалось создать окружение .venv_py313")
    else:
        result = subprocess.run(
            [str(python_path), "-c", "import sys; print(sys.version_info[0], sys.version_info[1])"],
            capture_output=True, text=True, check=False,
        )
        if result.returncode != 0 or result.stdout.strip() != "3 13":
            raise RuntimeError(
                "Существующая .venv_py313 создана для другой версии Python. "
                "Переименуйте папку .venv_py313 и повторите установку. "
                "Папку portfolio_storage не трогайте."
            )
        print("[1/3] .venv_py313 уже существует", flush=True)

    print("[2/3] Проверяю pip в изолированном окружении ...", flush=True)
    status = subprocess.run(
        [str(python_path), "-m", "pip", "--version"],
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=False,
    )
    if status.returncode:
        run(str(python_path), "-m", "ensurepip", "--upgrade")

    print("[3/3] Устанавливаю совместимые библиотеки ...", flush=True)
    try:
        run(
            str(python_path), "-m", "pip", "install",
            "--disable-pip-version-check", "-r", str(REQUIREMENTS),
        )
    except subprocess.CalledProcessError as exc:
        raise RuntimeError(
            "Не удалось скачать пакеты. Нужен интернет или разрешённое "
            "внутреннее зеркало PyPI. Возможно, установка пакетов ограничена "
            "политиками рабочего компьютера. Хранилище портфелей не затронуто."
        ) from exc

    run(
        str(python_path), "-c",
        "import sys, streamlit, pandas, numpy, openpyxl, xlrd, plotly; "
        "assert sys.version_info[:2] == (3,13); "
        "print('Все библиотеки готовы. Python', sys.version.split()[0])",
    )
    print("Python приложения: {}".format(python_path), flush=True)
    return python_path


if __name__ == "__main__":
    try:
        install()
    except Exception as exc:
        print("\nОшибка: {}".format(exc), file=sys.stderr)
        raise SystemExit(1)
