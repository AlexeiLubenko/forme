"""Pure data-processing helpers for the portfolio dashboard.

This module has no Streamlit dependency and can be unit-tested separately.
"""
from __future__ import annotations

from io import BytesIO
import csv
from typing import Any

import numpy as np
import pandas as pd

EMPTY_LABEL = "(пусто)"


def normalize_headers(df: pd.DataFrame) -> pd.DataFrame:
    """Make all Excel headers human-readable and unique without modifying values."""
    result = df.copy()
    output: list[str] = []
    used: set[str] = set()
    for i, header in enumerate(df.columns, start=1):
        original = str(header).strip() if pd.notna(header) else ""
        if not original or original.lower().startswith("unnamed:"):
            original = f"Столбец {i}"
        candidate = original
        counter = 2
        while candidate in used:
            candidate = f"{original} ({counter})"
            counter += 1
        used.add(candidate)
        output.append(candidate)
    result.columns = output
    return result


def read_portfolio(
    raw: bytes, filename: str, sheet: str | int | None = None, header_row: int = 1,
    preserve_identifiers: bool = False
) -> pd.DataFrame:
    """Read one XLS/XLSX or CSV sheet; blank rows are removed."""
    filelike = BytesIO(raw)
    name = filename.lower()
    if name.endswith((".xlsx", ".xlsm", ".xls")):
        df = pd.read_excel(filelike, sheet_name=0 if sheet is None else sheet,
                           header=header_row - 1, dtype=str if preserve_identifiers else None)
    elif name.endswith(".csv"):
        # Never use sep=None for this template: many column names contain
        # commas (e.g. "Задолженность, тыс BYN"), which can confuse sniffing.
        try:
            sample = raw[:24_000].decode("utf-8-sig")
            encoding = "utf-8-sig"
        except UnicodeDecodeError:
            sample = raw[:24_000].decode("cp1251")
            encoding = "cp1251"
        try:
            sep = csv.Sniffer().sniff(sample, delimiters=";,\t|").delimiter
        except csv.Error:
            # CSV exported from RU Excel is usually semicolon-delimited.
            sep = ";" if sample.splitlines()[0].count(";") > sample.splitlines()[0].count(",") else ","
        df = pd.read_csv(filelike, sep=sep, engine="python", header=header_row - 1,
                         encoding=encoding, dtype=str if preserve_identifiers else None)
    else:
        raise ValueError("Поддерживаются Excel (.xlsx/.xls/.xlsm) и CSV.")
    df = normalize_headers(df)
    df = df.dropna(axis=0, how="all").reset_index(drop=True)
    return df


def sheet_names(raw: bytes, filename: str) -> list[str]:
    if filename.lower().endswith((".xlsx", ".xlsm", ".xls")):
        with pd.ExcelFile(BytesIO(raw)) as excel:
            return excel.sheet_names
    return ["CSV"]


def numeric_columns(df: pd.DataFrame) -> list[str]:
    return [col for col in df if pd.api.types.is_numeric_dtype(df[col]) and not pd.api.types.is_bool_dtype(df[col])]


def date_columns(df: pd.DataFrame) -> list[str]:
    return [col for col in df if pd.api.types.is_datetime64_any_dtype(df[col])]


def dimension_columns(df: pd.DataFrame) -> list[str]:
    nums = set(numeric_columns(df))
    dates = set(date_columns(df))
    return [col for col in df if col not in nums and col not in dates]


def guess_amount_column(df: pd.DataFrame) -> str | None:
    candidates = numeric_columns(df)
    if not candidates:
        return None
    keywords = ["остаток", "задолж", "сумма", "баланс", "портфел", "резерв", "amount", "balance", "exposure", "ead", "principal"]
    for word in keywords:
        for col in candidates:
            if word in col.casefold():
                return col
    not_ids = [col for col in candidates if not any(k in col.casefold() for k in ("id", "идентиф", "номер", "код", "№"))]
    return (not_ids or candidates)[0]


def smart_dimensions(df: pd.DataFrame) -> list[str]:
    """Prefer categorical columns with a useful number of groups."""
    dims = dimension_columns(df)
    return sorted(dims, key=lambda c: (not 2 <= df[c].nunique(dropna=True) <= 30, df[c].nunique(dropna=True)))


def to_numeric_flexible(series: pd.Series) -> pd.Series:
    """Manual conversion for European-formatted numbers; no automatic coercion of ID columns."""
    if pd.api.types.is_numeric_dtype(series):
        return pd.to_numeric(series, errors="coerce")
    text = series.astype("string").str.replace("\u00a0", "", regex=False).str.replace("\u202f", "", regex=False).str.strip()
    text = text.str.replace(" ", "", regex=False)
    # 1.234,50 => 1234.50; 1,234.50 => 1234.50
    comma_decimal = text.str.contains(r",\d{1,3}$", regex=True, na=False)
    text = text.where(~comma_decimal, text.str.replace(".", "", regex=False).str.replace(",", ".", regex=False))
    text = text.where(comma_decimal, text.str.replace(",", "", regex=False))
    return pd.to_numeric(text, errors="coerce")


def category_values(series: pd.Series) -> pd.Series:
    """Stable string labels, keeping missing rows as a visible group."""
    return series.astype("string").fillna(EMPTY_LABEL)


def apply_filter_definitions(df: pd.DataFrame, definitions: list[dict[str, Any]]) -> pd.DataFrame:
    """Apply typed filters, used by Streamlit and independent tests."""
    mask = pd.Series(True, index=df.index)
    for item in definitions:
        column = item["column"]
        if column not in df:
            continue
        series = df[column]
        mode = item["mode"]
        if mode == "category":
            selected = item.get("values", [])
            if selected:
                mask &= category_values(series).isin(selected)
        elif mode == "contains":
            query = str(item.get("query", "")).strip()
            if query:
                mask &= series.astype("string").str.contains(query, case=False, regex=False, na=False)
        elif mode == "number":
            low, high = item["min"], item["max"]
            mask &= pd.to_numeric(series, errors="coerce").between(low, high)
        elif mode == "date":
            start, end = pd.Timestamp(item["start"]), pd.Timestamp(item["end"])
            mask &= pd.to_datetime(series, errors="coerce").between(start, end + pd.Timedelta(days=1) - pd.Timedelta(nanoseconds=1))
    return df.loc[mask].copy()


def group_summary(df: pd.DataFrame, dimension: str, metric: str | None, agg: str = "Сумма", limit: int = 15) -> pd.DataFrame:
    """Aggregate a metric or row counts by a category."""
    if df.empty:
        return pd.DataFrame(columns=["Группа", "Значение"])
    group = category_values(df[dimension])
    if agg == "Количество" or metric is None:
        result = df.groupby(group, dropna=False).size().rename("Значение")
    else:
        func = {"Сумма": "sum", "Среднее": "mean", "Медиана": "median", "Минимум": "min", "Максимум": "max"}[agg]
        result = df.groupby(group, dropna=False)[metric].agg(func).rename("Значение")
    result = result.sort_values(ascending=False).head(limit)
    return result.rename_axis("Группа").reset_index()


def make_pivot(
    df: pd.DataFrame,
    row: str,
    col: str | None,
    metric: str | None,
    agg: str,
    limit: int = 30,
) -> pd.DataFrame:
    """Build a bounded pivot to avoid creating massive matrices from IDs."""
    if df.empty:
        return pd.DataFrame()
    temp = df.copy()
    temp[row] = category_values(temp[row])
    if col and col != row:
        temp[col] = category_values(temp[col])
    top_rows = temp[row].value_counts().head(limit).index
    temp = temp[temp[row].isin(top_rows)]
    if col and col != row:
        top_cols = temp[col].value_counts().head(limit).index
        temp = temp[temp[col].isin(top_cols)]
    target_agg = {"Сумма": "sum", "Среднее": "mean", "Медиана": "median", "Количество": "size", "Минимум": "min", "Максимум": "max"}[agg]
    groups = [row] + ([col] if col and col != row else [])
    if target_agg == "size" or metric is None:
        summary = temp.groupby(groups, dropna=False).size()
    else:
        summary = temp.groupby(groups, dropna=False)[metric].agg(target_agg)
    if col and col != row:
        summary = summary.unstack(level=1)
    return summary.sort_index()


def quality_summary(df: pd.DataFrame) -> pd.DataFrame:
    count = len(df)
    return pd.DataFrame({
        "Столбец": df.columns,
        "Тип": [str(dt) for dt in df.dtypes],
        "Непустых": [int(df[c].notna().sum()) for c in df],
        "Пустых": [int(df[c].isna().sum()) for c in df],
        "Заполненность, %": [round(df[c].notna().sum() / count * 100, 1) if count else 0.0 for c in df],
        "Уникальных": [int(df[c].nunique(dropna=True)) for c in df],
    })


def numeric_profile(df: pd.DataFrame) -> pd.DataFrame:
    nums = numeric_columns(df)
    if not nums:
        return pd.DataFrame()
    stats = df[nums].describe().T
    stats = stats.rename(columns={"count": "Количество", "mean": "Среднее", "std": "Ст. откл.", "min": "Минимум", "25%": "Q1", "50%": "Медиана", "75%": "Q3", "max": "Максимум"})
    return stats.round(2)


def validate_fixed_schema(df: pd.DataFrame) -> None:
    """Raise an actionable error for any unexpected or missing header."""
    from portfolio_schema import EXPECTED_COLUMNS

    got = list(df.columns)
    expected = list(EXPECTED_COLUMNS)
    missing = [c for c in expected if c not in got]
    extra = [c for c in got if c not in expected]
    if missing or extra or len(got) != len(expected):
        parts = [f"Ожидается {len(expected)} фиксированных столбцов; найдено {len(got)}."]
        if missing:
            parts.append("Отсутствуют: " + "; ".join(missing))
        if extra:
            parts.append("Лишние/переименованные: " + "; ".join(extra))
        raise ValueError(" ".join(parts))


def load_fixed_portfolio(raw: bytes, filename: str, sheet: str | int | None = None,
                         header_row: int = 1) -> pd.DataFrame:
    """Validate strict header set and explicitly type the known portfolio fields."""
    from portfolio_schema import EXPECTED_COLUMNS, DATE_COLUMNS, NUMERIC_COLUMNS

    if int(header_row) < 1:
        raise ValueError("Строка заголовка должна быть положительной.")
    df = read_portfolio(raw, filename, sheet, header_row, preserve_identifiers=True)
    validate_fixed_schema(df)
    df = df[list(EXPECTED_COLUMNS)].copy()
    for col in NUMERIC_COLUMNS:
        if not pd.api.types.is_numeric_dtype(df[col]):
            df[col] = to_numeric_flexible(df[col])
        else:
            df[col] = pd.to_numeric(df[col], errors="coerce")
    for col in DATE_COLUMNS:
        # pandas 1.5 (Python 3.8/3.9) does not support format="mixed".
        # Keep mixed-format parsing only when running on pandas 2.x.
        date_options = {"errors": "coerce", "dayfirst": True}
        if int(pd.__version__.split(".", 1)[0]) >= 2:
            date_options["format"] = "mixed"
        df[col] = pd.to_datetime(df[col], **date_options)
    for col in df.columns:
        if col not in NUMERIC_COLUMNS and col not in DATE_COLUMNS:
            df[col] = df[col].astype("string").str.strip()
    return df


def compare_versions(a: pd.DataFrame, b: pd.DataFrame, metrics: list[str] | None = None) -> pd.DataFrame:
    """Aggregate differences: b - a. No assumption about unique loan identifiers."""
    from portfolio_schema import PORTFOLIO_KPIS

    metrics = metrics or list(PORTFOLIO_KPIS)
    rows = [{"Показатель": "Количество строк", "Было": float(len(a)),
             "Стало": float(len(b)), "Изменение": float(len(b)-len(a))}]
    for column in metrics:
        if column in a and column in b:
            x = float(pd.to_numeric(a[column], errors="coerce").sum())
            y = float(pd.to_numeric(b[column], errors="coerce").sum())
            rows.append({"Показатель": column, "Было": x, "Стало": y, "Изменение": y-x})
    return pd.DataFrame(rows)


def compare_group_versions(a: pd.DataFrame, b: pd.DataFrame,
                           dimension: str, metric: str) -> pd.DataFrame:
    """Full outer join of segment-level sums for version comparison."""
    def grouped(df: pd.DataFrame) -> pd.Series:
        return pd.to_numeric(df[metric], errors="coerce").groupby(category_values(df[dimension])).sum()
    result = pd.concat([grouped(a).rename("Было"), grouped(b).rename("Стало")], axis=1).fillna(0)
    result["Изменение"] = result["Стало"] - result["Было"]
    return result.reset_index(names="Группа").sort_values("Изменение", key=abs, ascending=False)
