"""Offline Python 3.13 installer regression tests (no downloads)."""

from pathlib import Path
import subprocess
from tempfile import TemporaryDirectory
import unittest
from unittest.mock import patch

import setup_environment


class InstallerTests(unittest.TestCase):
    def test_bootstrap_and_install_dependencies(self):
        with TemporaryDirectory() as td:
            p = Path(td)
            requirements = p / "requirements.txt"
            requirements.write_text("streamlit==1.51.0\npandas==2.3.3\n", encoding="utf-8")
            env_dir = p / ".venv_py313"
            py = setup_environment.environment_python(env_dir)
            called = []

            def fake_run(*args):
                called.append(args)
                if args[1:3] == ("-m", "venv"):
                    py.parent.mkdir(parents=True, exist_ok=True)
                    py.write_text("fake executable", encoding="utf-8")

            with patch.object(setup_environment, "ENV_DIR", env_dir), \
                 patch.object(setup_environment, "REQUIREMENTS", requirements), \
                 patch.object(setup_environment.sys, "version_info", (3, 13, 5, "final", 0)), \
                 patch.object(setup_environment, "run", side_effect=fake_run), \
                 patch.object(setup_environment.subprocess, "run", return_value=subprocess.CompletedProcess([], 0)):
                actual = setup_environment.install()

            self.assertEqual(py, actual)
            self.assertTrue(any(args[1:3] == ("-m", "venv") for args in called))
            self.assertTrue(any(args[1:4] == ("-m", "pip", "install") for args in called))
            self.assertTrue(any(args[0] == str(py) and args[1] == "-c" for args in called))

    def test_missing_requirements_does_not_create_environment(self):
        with TemporaryDirectory() as td:
            with patch.object(setup_environment, "REQUIREMENTS", Path(td) / "missing.txt"), \
                 patch.object(setup_environment.sys, "version_info", (3, 13, 5, "final", 0)), \
                 patch.object(setup_environment, "run") as mock_run:
                with self.assertRaises(FileNotFoundError):
                    setup_environment.install()
                mock_run.assert_not_called()

    def test_rejects_old_python(self):
        with patch.object(setup_environment.sys, "version_info", (3, 9, 25, "final", 0)):
            with self.assertRaisesRegex(RuntimeError, "Python 3.13"):
                setup_environment.install()

    def test_rejects_different_env_python(self):
        with TemporaryDirectory() as td:
            p = Path(td)
            req = p / "requirements.txt"
            req.write_text("streamlit==1.51.0\n", encoding="utf-8")
            env = p / ".venv_py313"
            py = setup_environment.environment_python(env)
            py.parent.mkdir(parents=True)
            py.write_text("old", encoding="utf-8")
            with patch.object(setup_environment.sys, "version_info", (3, 13, 5, "final", 0)), \
                 patch.object(setup_environment, "REQUIREMENTS", req), \
                 patch.object(setup_environment, "ENV_DIR", env), \
                 patch.object(setup_environment.subprocess, "run", return_value=subprocess.CompletedProcess([], 0, "3 9", "")):
                with self.assertRaisesRegex(RuntimeError, "другой версии"):
                    setup_environment.install()

    def test_dependencies_target_313(self):
        req = (Path(setup_environment.__file__).resolve().parent / "requirements.txt").read_text("utf-8")
        for package in ("streamlit==1.51.0", "pandas==2.3.3", "numpy==2.2.6"):
            self.assertIn(package, req)
        self.assertNotIn("pandas==1.5", req)


if __name__ == "__main__":
    unittest.main()
