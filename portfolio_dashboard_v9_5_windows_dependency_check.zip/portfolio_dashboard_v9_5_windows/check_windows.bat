@echo off
setlocal
chcp 65001 >nul
set "PYTHONIOENCODING=utf-8"
cd /d "%~dp0"

rem Only inspection: no pip calls and no package installations.
py -3.13 -c "import sys; sys.exit(sys.version_info[:2] != (3,13))" >nul 2>&1
if not errorlevel 1 (
    py -3.13 check_dependencies.py --imports
    goto finish
)
python -c "import sys; sys.exit(sys.version_info[:2] != (3,13))" >nul 2>&1
if not errorlevel 1 (
    python check_dependencies.py --imports
    goto finish
)
echo Python 3.13 not found. Check: py -3.13 --version
:finish
echo.
pause
