"""Windows entrypoint: inspect current Python, then optionally use an isolated env."""

from __future__ import annotations

from pathlib import Path
import subprocess
import sys

import check_dependencies
from setup_environment import ENV_DIR, environment_python, install

PROJECT = Path(__file__).resolve().parent


def is_ready(python: Path) -> bool:
    if not python.is_file():
        return False
    result = subprocess.run(
        [str(python), str(PROJECT / "check_dependencies.py"), "--no-report", "--imports"],
        cwd=str(PROJECT), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
        check=False,
    )
    return result.returncode == 0


def launch(python: str) -> int:
    print("\nЗапуск приложения через:", python, flush=True)
    print("Адрес: http://127.0.0.1:8501\n", flush=True)
    return subprocess.call(
        [python, "-m", "streamlit", "run", "portfolio_app.py", "--server.address=127.0.0.1"],
        cwd=str(PROJECT),
    )


def main() -> int:
    if sys.version_info[:2] != (3, 13):
        print("Нужен Python 3.13; выбран:", sys.version, file=sys.stderr)
        return 2

    print("Проверяю ТЕКУЩИЙ Python-окружение (пока ничего не устанавливаю)...\n", flush=True)
    result = check_dependencies.audit(verify_imports=True)
    report = check_dependencies.render(result)
    print(report, flush=True)
    try:
        check_dependencies.REPORT.write_text(report + "\n", encoding="utf-8")
        print("\nФайл для администратора:", check_dependencies.REPORT, flush=True)
    except OSError as error:
        print("Не удалось записать отчёт:", error)

    if result.ok:
        return launch(sys.executable)

    isolated = environment_python(ENV_DIR)
    if is_ready(isolated):
        print("\nТекущее окружение неполное, но отдельное .venv_py313 уже готово.", flush=True)
        return launch(str(isolated))

    print("\nТекущий Python не изменён. Можно передать dependencies_report.txt администратору.")
    try:
        choice = input("Создать отдельную .venv_py313 и установить библиотеки? [y/N]: ").strip().lower()
    except (EOFError, KeyboardInterrupt):
        return 1
    if choice not in ("y", "yes", "д", "да"):
        print("Установка отменена. Для проверки без запуска: check_windows.bat")
        return 1
    try:
        python_path = install()
    except Exception as error:
        print("Ошибка установки:", error, file=sys.stderr)
        return 1
    if not is_ready(python_path):
        print("Библиотеки установлены, но проверка выявила проблемы в .venv_py313.", file=sys.stderr)
        subprocess.call([str(python_path), str(PROJECT / "check_dependencies.py")])
        return 1
    return launch(str(python_path))


if __name__ == "__main__":
    raise SystemExit(main())
