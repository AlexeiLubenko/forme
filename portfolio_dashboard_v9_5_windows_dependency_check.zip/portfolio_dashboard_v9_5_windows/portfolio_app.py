"""Полноэкранный мониторинг датированных, неизменяемых банковских портфелей.

Run: python -m streamlit run portfolio_app.py
"""
from __future__ import annotations

from datetime import date
from io import BytesIO
from pathlib import Path
import os

import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

from portfolio_core import (
    group_summary,
    make_pivot, quality_summary, sheet_names,
)
from portfolio_schema import (
    CATEGORY_COLUMNS, DEFAULT_GROUP, EXPECTED_COLUMNS,
)
from portfolio_store import PortfolioStore
from reserve_analysis import DEBT, RESERVE, OVERDUE, UNP, CLIENT, GROUP
from material_changes import build_material_client_report, MATERIAL_THRESHOLD_THOUSAND_BYN
from reserve_operational_analysis import (
    compare_operational, FACTOR_ORDER, CORE_FACTORS, CONTRACT,
    F_NEW, F_REPAY, F_NI, F_PFN, F_NVV, F_RESTR, F_COVER, F_OVERDUE,
    F_GROW, F_GONE, F_MULTI, F_OTHER, F_NO_CONTRACT, F_NO_UNP,
)

ROOT = Path(__file__).resolve().parent
# Can point to existing v3 storage from outside the package:
STORE_DIR = Path(os.environ.get('PORTFOLIO_STORAGE', str(ROOT / 'portfolio_storage')))
NAVY = '#172b4d'
BLUE = '#346cf2'
TEAL = '#008b82'
CORAL = '#d95c55'
GRAY = '#64748b'

st.set_page_config(page_title='Портфель и резервы', page_icon='🏦', layout='wide',
                   initial_sidebar_state='expanded')
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700;800&display=swap');
html,body,[class*="css"],.stMarkdown,.stMetric {font-family:Manrope,system-ui,sans-serif;}
.stApp {background:#f7f9fd;}
.block-container {max-width:1540px;padding-top:1.4rem;padding-bottom:4rem;}
[data-testid="stSidebar"] {background:#fff;border-right:1px solid #e5eaf3;}
[data-testid="stSidebar"] [data-testid="stRadio"] label {line-height:1.55;}
[data-testid="stMetric"] {background:#fff;border:1px solid #e4eaf4;border-radius:16px;
 padding:17px;box-shadow:0 3px 12px rgba(17,39,75,.035);}
[data-testid="stMetricLabel"] p {font-weight:650;color:#65768e;font-size:.86rem;}
[data-testid="stMetricValue"] {font-size:1.62rem;font-weight:800;color:#172d50;}
[data-testid="stExpander"] {border:1px solid #e3eaf4;border-radius:12px;background:white;}
[data-testid="stDataFrame"] {border:1px solid #e5eaf4;border-radius:12px;overflow:hidden;}
.stTabs [data-baseweb="tab-list"] {padding:6px;background:#fff;border:1px solid #e5eaf4;
 border-radius:12px;gap:4px;overflow-x:auto;}
.stTabs [data-baseweb="tab"] {border-radius:8px;font-weight:700;padding:.7rem .9rem;}
.stTabs [aria-selected="true"] {background:#e8f0ff;color:#2459bb;}
h1,h2,h3,h4 {color:#172c4d;letter-spacing:-.02em;}
.hero {background:linear-gradient(116deg,#112a4b,#204c84);color:#fff;border-radius:19px;
 padding:24px 27px;margin-bottom:18px;}
.hero small {display:block;color:#b6d2f5;letter-spacing:.12em;font-size:.70rem;
 text-transform:uppercase;font-weight:800;margin-bottom:9px;}
.hero .name {font-size:1.8rem;line-height:1.2;font-weight:800;letter-spacing:-.035em;}
.hero .desc {margin-top:9px;color:#e1edfa;font-size:.93rem;max-width:900px;}
.section-lead {color:#697990;font-size:.92rem;margin:-5px 0 14px;}
.mini-note {background:#f0f5ff;border-left:3px solid #4578e7;color:#314d79;
 border-radius:8px;padding:12px 15px;font-size:.88rem;margin:12px 0;}
.step-num {font-size:12px;color:#386ccc;font-weight:800;letter-spacing:.06em;}
</style>
""",unsafe_allow_html=True)


def fmt(x: float, decimals: int = 1) -> str:
    return f'{x:,.{decimals}f}'.replace(',', ' ')


def metric_text(n: float, unit: str = '') -> str:
    return f'{fmt(n, 1)}{(" " + unit) if unit else ""}'


def csv_export(frame: pd.DataFrame, filename: str, label='Скачать CSV'):
    st.download_button(label, frame.to_csv(index=False, sep=';', decimal=',').encode('utf-8-sig'),
                       file_name=filename, mime='text/csv', use_container_width=True)


def snapshot_label(v: dict) -> str:
    return f"{v['report_date'] or 'Без даты'}  ·  {v['title']}  (#{v['id']})"


@st.cache_data(show_spinner='Загружаю портфель с диска...', max_entries=3)
def load_snapshot(version_id: int, sha: str) -> pd.DataFrame:
    return PortfolioStore(STORE_DIR).load(version_id)


@st.cache_data(show_spinner=False, max_entries=3)
def sheet_list(content: bytes, filename: str) -> list[str]:
    return sheet_names(content, filename)


@st.cache_data(show_spinner='Сопоставляю клиентов и рассчитываю факторы...', max_entries=2)
def analyze_by_dates(old_id: int, old_sha: str, new_id: int, new_sha: str):
    old = load_snapshot(old_id, old_sha)
    new = load_snapshot(new_id, new_sha)
    return compare_operational(old, new)


@st.cache_data(show_spinner='Проверяю заполненность...', max_entries=2)
def profile_cached(vid: int, sha: str) -> pd.DataFrame:
    return quality_summary(load_snapshot(vid, sha))


store = PortfolioStore(STORE_DIR)
versions = store.list_versions()
by_id = {int(v['id']): v for v in versions}
ids = list(by_id)
active = store.active_id()

NAV_ITEMS = [
    '🏠 Главная',
    '🗂️ Портфели по датам',
    '🧮 Расходы на резервы',
    '📋 Таблица портфеля',
    '🧩 Срезы',
    '🔎 Качество данных',
    '❓ Инструкция',
]


def go_to(destination: str):
    st.session_state['main_section'] = destination


with st.sidebar:
    st.markdown('## 🏦 Портфель и резервы')
    st.caption('Локальный мониторинг портфеля МСФО')
    if 'main_section' not in st.session_state:
        st.session_state['main_section'] = '🏠 Главная' if ids else '🗂️ Портфели по датам'
    page = st.radio('Разделы', NAV_ITEMS, key='main_section', label_visibility='collapsed')
    st.divider()
    st.markdown('**Текущий портфель**')
    if ids:
        if st.session_state.get('snapshot_id') not in by_id:
            st.session_state['snapshot_id'] = active if active in by_id else ids[0]
        selected_id = st.selectbox('Отчётная дата', ids,
                                   format_func=lambda i: snapshot_label(by_id[i]), key='snapshot_id')
        selected = by_id[selected_id]
        st.caption(f"{fmt(selected['rows_count'], 0)} строк · 55 столбцов")
        if selected['report_date'] is None:
            st.warning('Этому снимку ещё не назначена отчётная дата.')
    else:
        selected_id = None
        selected = None
        st.info('Сначала загрузите портфель. После этого откроются аналитические разделы.')
    st.divider()
    with st.expander('Что означают суммы?'):
        st.markdown('Все показатели задолженности и резерва в **тыс. BYN**. '
                    'Положительное Δ — резерв вырос, отрицательное — уменьшился. '
                    'Существенные клиенты: **Δ ≤ −100 или Δ ≥ +100** тыс. BYN.')
    st.caption('Исходные портфели сохраняются неизменными на этом компьютере.')

st.markdown("""<div class="hero"><small>АНАЛИТИКА КРЕДИТНОГО ПОРТФЕЛЯ</small>
<div class="name">Мониторинг портфеля и резервов</div>
<div class="desc">Портфели по датам · Поклиентное сравнение · Объяснения изменений · Факторный анализ</div>
</div>""",unsafe_allow_html=True)

data = None
if selected_id is not None:
    try:
        data = load_snapshot(selected_id, selected['content_sha256'])
    except Exception as exc:
        st.error(f'Невозможно прочитать снимок: {exc}')

if page == '🏠 Главная':
    st.subheader('Как работать с приложением')
    steps = st.columns(3)
    with steps[0]:
        with st.container(border=True):
            st.caption('ШАГ 1')
            st.markdown('**Загрузите портфели**')
            st.write('Добавьте Excel за нужные отчётные даты. Каждый снимок сохранится отдельно.')
            st.button('Перейти к загрузке', key='home_load', on_click=go_to,
                      args=('🗂️ Портфели по датам',), use_container_width=True)
    with steps[1]:
        with st.container(border=True):
            st.caption('ШАГ 2')
            st.markdown('**Сравните две даты**')
            st.write('Получите изменения резервов и клиентов с |Δ| от 100 тыс. BYN.')
            st.button('Открыть сравнение', key='home_compare', on_click=go_to,
                      args=('🧮 Расходы на резервы',), use_container_width=True)
    with steps[2]:
        with st.container(border=True):
            st.caption('ШАГ 3')
            st.markdown('**Изучите причины и выгрузите**')
            st.write('Откройте комментарий и договоры клиента, скачайте отчёт в CSV.')
            st.button('Читать инструкцию', key='home_help', on_click=go_to,
                      args=('❓ Инструкция',), use_container_width=True)
    if len([v for v in versions if v['report_date']]) < 2:
        st.info('Для анализа расходов загрузите **как минимум два снимка с разными датами**. '
                'Можете начать с демонстрационных CSV из папки проекта.')
    st.divider()

if page == '🏠 Главная':
    if data is None:
        st.info('Загрузите портфель в разделе «Портфели по датам»;, чтобы увидеть панель показателей.')
    else:
        st.subheader('Портфель на выбранную дату')
        st.caption(f'{selected["report_date"] or "Дата не указана"} · {selected["title"]} · показатели исходного портфеля')
        debt_total = float(data[DEBT].sum())
        reserve_total = float(data[RESERVE].sum())
        overdue = float(data[OVERDUE].sum())
        c = st.columns(4)
        c[0].metric('Задолженность · тыс. BYN', metric_text(debt_total))
        c[1].metric('Резерв факт · тыс. BYN', metric_text(reserve_total))
        c[2].metric('Просрочка · тыс. BYN', metric_text(overdue))
        c[3].metric('Договоров / строк', fmt(len(data), 0))
        st.markdown('')
        c1, c2 = st.columns([1.35, 1])
        with c1:
            st.markdown('#### Структура задолженности')
            dimension = st.selectbox('Группировка', ['Сегмент', 'ГР', 'Зона проблемности', 'Субпортфель'],
                                     key='overview_dimension')
            groups = group_summary(data, dimension, DEBT, 'Сумма', 16)
            if not groups.empty:
                groups = groups.sort_values('Значение')
                fig = px.bar(groups, x='Значение', y='Группа', orientation='h',
                             color_discrete_sequence=[BLUE], height=405)
                fig.update_layout(template='plotly_white', xaxis_title='тыс. BYN',
                                  yaxis_title=None, margin=dict(l=6,r=12,t=5,b=5),
                                  paper_bgcolor='rgba(0,0,0,0)', plot_bgcolor='rgba(0,0,0,0)')
                st.plotly_chart(fig, use_container_width=True)
        with c2:
            st.markdown('#### Риски в портфеле')
            for col in ['NPL (договор)', 'Дефолт', 'Зона проблемности']:
                with st.expander(f'Распределение · {col}', expanded=(col == 'Зона проблемности')):
                    summary = group_summary(data, col, DEBT, 'Сумма', 20)
                    st.dataframe(summary, use_container_width=True, hide_index=True, height=220)
            st.caption('Здесь не интерпретируются значения флагов NPL/дефолта — показаны исходные категории.')
        history = [v for v in versions if v['report_date'] and v['reserve_total'] is not None]
        if len(history) >= 2:
            st.markdown('#### Динамика между отчётными датами')
            timeline = pd.DataFrame(history).sort_values('report_date')
            fig = go.Figure()
            fig.add_trace(go.Scatter(x=timeline['report_date'], y=timeline['reserve_total'],
                                     name='Резерв факт', mode='lines+markers', line=dict(color=BLUE, width=3)))
            fig.update_layout(template='plotly_white', height=290, yaxis_title='тыс. BYN',
                              xaxis_title='Отчётная дата', margin=dict(l=10,r=10,t=10,b=10))
            st.plotly_chart(fig, use_container_width=True)
            if len(history) != len([v for v in versions if v['report_date']]):
                st.caption('В динамику пока не включены старые снимки без пересчитанных сумм. Запустите обновление KPI в разделе «Портфели по датам».')

if page == '📋 Таблица портфеля':
    if data is None:
        st.info('Загрузите первый снимок портфеля.')
    else:
        st.subheader('Просмотр и поиск в портфеле')
        st.info('Выберите дату в левом меню. Фильтры влияют только на просмотр и выгрузку, **сам портфель не меняется**.')
        st.markdown('<div class="section-lead">Нажмите на название столбца для сортировки. Можно выбрать только интересующие колонки.</div>', unsafe_allow_html=True)
        a,b,c,d = st.columns(4)
        search = a.text_input('Клиент / УНП / договор / счёт', placeholder='Введите текст...')
        segment = b.multiselect('Сегмент', sorted(data['Сегмент'].dropna().astype(str).unique()))
        risk = c.multiselect('Зона проблемности', sorted(data['Зона проблемности'].dropna().astype(str).unique()))
        currency = d.multiselect('Код валюты', sorted(data['Код валюты'].dropna().astype(str).unique()))
        df_view = data
        for name, vals in (('Сегмент', segment), ('Зона проблемности', risk), ('Код валюты', currency)):
            if vals:
                df_view = df_view[df_view[name].isin(vals)]
        if search.strip():
            mask = pd.Series(False, index=df_view.index)
            for name in (CLIENT, UNP, 'Номер договора', 'Счет'):
                mask |= df_view[name].str.contains(search.strip(), case=False, regex=False, na=False)
            df_view = df_view.loc[mask]
        st.caption(f'Найдено {len(df_view):,} из {len(data):,} строк'.replace(',', ' '))
        defaults = [UNP, CLIENT, 'Номер договора', 'Сегмент', 'ГР', 'Зона проблемности', DEBT, RESERVE, OVERDUE]
        cols = st.multiselect('Отображаемые столбцы', EXPECTED_COLUMNS, default=defaults)
        rows_limit = st.select_slider('Показывать строк в таблице', options=[100,500,1000,3000,10000], value=1000)
        if cols:
            st.dataframe(df_view.loc[:, cols].head(rows_limit), use_container_width=True, hide_index=True, height=520)
        st.caption('Для производительности в браузере видна только первая часть, но CSV содержит все отфильтрованные строки.')
        csv_export(df_view, f'portfolio_{selected["report_date"] or selected_id}.csv', '⬇️ Выгрузить отфильтрованный портфель')

if page == '🧮 Расходы на резервы':
    st.subheader('Расходы на резервы: сравнение двух дат')
    st.caption('Выберите начальную и конечную даты. Изменение = резерв на конец − резерв на начало. Все суммы — тыс. BYN.')
    dated = sorted([v for v in versions if v['report_date']], key=lambda v: v['report_date'])
    if len(dated) < 2:
        st.info('Пока нельзя сравнить: нужны **два портфеля с разными отчётными датами**.')
        st.button('Перейти к загрузке портфелей', key='exp_upload',on_click=go_to,
                  args=('🗂️ Портфели по датам',))
    else:
        indexed = {v['id']: v for v in dated}
        choices = list(indexed)
        st.markdown('#### 1. Выберите период для сравнения')
        left, right = st.columns(2)
        old_id = left.selectbox('Отчётная дата начала', choices, index=len(choices)-2,
                                 format_func=lambda k: snapshot_label(indexed[k]), key='f_old')
        new_id = right.selectbox('Отчётная дата окончания', choices, index=len(choices)-1,
                                  format_func=lambda k: snapshot_label(indexed[k]), key='f_new')
        st.caption('Совет: в первом поле выбирайте более раннюю дату, во втором — более позднюю.')
        if indexed[old_id]['report_date'] >= indexed[new_id]['report_date']:
            st.warning('Дата начала должна быть раньше даты окончания. Поменяйте даты местами.')
        else:
            try:
                result = analyze_by_dates(old_id, indexed[old_id]['content_sha256'],
                                          new_id, indexed[new_id]['content_sha256'])
            except Exception as exc:
                st.error(f'Не получилось сравнить портфели: {exc}')
            else:
                date_suffix = f"{indexed[old_id]['report_date']}_{indexed[new_id]['report_date']}"
                st.markdown('#### 2. Сводный результат')
                k = st.columns(4)
                k[0].metric('Резерв на начало', metric_text(result.total_before,'тыс. BYN'))
                k[1].metric('Резерв на конец', metric_text(result.total_after,'тыс. BYN'))
                k[2].metric('Δ резерва', metric_text(result.delta,'тыс. BYN'),
                            delta=metric_text(result.delta,'тыс. BYN'),delta_color='inverse')
                k[3].metric('Продолжающихся договоров', fmt(result.continuing_contracts,0))
                st.markdown('''<div class="mini-note"><b>Как читать расчёт:</b> рост резерва = положительное изменение;
                снижение = отрицательное. Погашение рассчитывается как оценка от снижения задолженности.
                События НИ / ПФН / НВВ / реструктуризации / обеспеченности / просрочки определяются из двух снимков;
                без проводок и событийного журнала это не доказанные причины бухгалтерского расхода.</div>''',
                            unsafe_allow_html=True)
                defects = (result.unmatched_unp_before + result.unmatched_unp_after +
                           result.unmatched_contract_before + result.unmatched_contract_after)
                invalid = (result.invalid_debt_before + result.invalid_debt_after +
                           result.invalid_reserve_before + result.invalid_reserve_after)
                if defects:
                    st.warning(f'Строки без УНП: {result.unmatched_unp_before} / {result.unmatched_unp_after}; '
                               f'без номера договора: {result.unmatched_contract_before} / '
                               f'{result.unmatched_contract_after}. Их изменение выделено отдельно.')
                if invalid:
                    st.warning(f'Пустые или некорректные суммы долга/резерва: {invalid}. '
                               'Они при расчёте сумм считаются нулём, выводы требуют проверки источника.')
                if abs(result.balance_error) > 1e-7 * max(1,abs(result.delta)):
                    st.error(f'Не сошёлся факторный мост: {fmt(result.balance_error,5)} тыс. BYN')
                else:
                    st.success('Факторный мост сходится с полным изменением резерва.')

                st.markdown('#### 3. Выберите, что хотите изучить')
                st.caption('Сначала откройте «Существенные клиенты» — это основной отчёт для анализа. '
                           'Подробности по всем клиентам, договорам и формулам доступны справа.')
                material_tab, bridge, clients_tab, contracts_tab, methodology = st.tabs([
                    '🎯 Существенные клиенты', '📊 Причины и факторы', '👥 Все клиенты',
                    '📑 По договорам', '📖 Как считается'
                ])
                with material_tab:
                    report = build_material_client_report(result)
                    st.markdown('#### Клиенты с изменением от 0,1 млн BYN')
                    st.caption(f'Включены клиенты с Δ ≤ −{fmt(MATERIAL_THRESHOLD_THOUSAND_BYN, 0)} или Δ ≥ +{fmt(MATERIAL_THRESHOLD_THOUSAND_BYN, 0)} тыс. BYN (включая равенство). '
                               'Учитываются все договоры клиента, включая новые и выбывшие. '
                               'Суммы по-прежнему показаны в тыс. BYN.')
                    x1, x2, x3, x4 = st.columns(4)
                    x1.metric('Существенных клиентов', fmt(len(report.material), 0))
                    x2.metric('Их суммарное Δ резерва', metric_text(report.material_delta, 'тыс. BYN'))
                    x3.metric('Остальных клиентов', fmt(report.other_clients_count, 0))
                    x4.metric('Δ по остальным', metric_text(report.other_clients_delta, 'тыс. BYN'))
                    if abs(report.unmatched_delta) > 1e-7:
                        st.warning('Отдельная корректировка без сопоставимого ключа УНП/договора: '
                                   f'{metric_text(report.unmatched_delta, "тыс. BYN")}. '
                                   'Она включена в общий итог, но не приписана ни одному клиенту.')
                    st.markdown('''<div class="mini-note"><b>Как читать комментарии:</b>
                    описаны события, видимые между двумя отчётными датами: появление/выбытие договора,
                    изменение задолженности, НИ, ПФН, НВВ, реструктуризация, обеспеченность и просрочка.
                    Это объяснения <i>наблюдаемых изменений</i>, а не подтверждённые причины бухгалтерских проводок.</div>''',
                                unsafe_allow_html=True)
                    material = report.material.copy()
                    if material.empty:
                        st.info('Клиентов с изменением резерва по модулю от 0,1 млн BYN включительно нет.')
                    else:
                        column_list = [UNP, 'Клиент', 'Сегмент', 'Резерв — было',
                                       'Резерв — стало', 'Δ резерва', 'Договоров — было',
                                       'Договоров — стало', 'Основные факторы', 'Комментарий']
                        sel_search, sel_dir = st.columns([2, 1])
                        quick_find = sel_search.text_input('Поиск в существенных клиентах',
                            placeholder='УНП или название клиента', key='material_search')
                        quick_dir = sel_dir.selectbox('Направление изменения',
                            ['Все', 'Рост резерва', 'Снижение резерва'],key='material_dir')
                        shown = material
                        if quick_find.strip():
                            term = quick_find.strip()
                            shown = shown.loc[
                                shown[UNP].astype('string').str.contains(term,case=False,regex=False,na=False)
                                | shown['Клиент'].astype('string').str.contains(term,case=False,regex=False,na=False)]
                        if quick_dir == 'Рост резерва':
                            shown = shown.loc[shown['Δ резерва'] > 0]
                        elif quick_dir == 'Снижение резерва':
                            shown = shown.loc[shown['Δ резерва'] < 0]
                        st.caption(f'Найдено {len(shown)} из {len(material)} существенных клиентов. '
                                   'Итоговая сверка ниже всегда относится ко всем клиентам.')
                        st.dataframe(
                            shown[column_list].head(1000), use_container_width=True,
                            hide_index=True, height=min(570, 80 + 44 * min(len(material), 11)),
                            column_config={
                                'Комментарий': st.column_config.TextColumn('Что произошло', width='large'),
                                'Основные факторы': st.column_config.TextColumn(width='large'),
                                'Δ резерва': st.column_config.NumberColumn('Δ резерва, тыс. BYN', format='%.2f'),
                                'Резерв — было': st.column_config.NumberColumn(format='%.2f'),
                                'Резерв — стало': st.column_config.NumberColumn(format='%.2f'),
                            },
                        )
                        st.caption('Таблица отсортирована по модулю Δ резерва. '
                                   'Полные комментарии доступны в ячейке и в CSV. Фильтры выше не меняют общие итоги.')
                        csv_export(shown, f'material_clients_{date_suffix}.csv',
                                   '⬇️ Скачать видимые после фильтра клиенты (CSV)')
                        csv_export(material, f'material_clients_all_{date_suffix}.csv',
                                   '⬇️ Скачать полный список существенных клиентов (CSV)')
                        with st.expander('🔍 Посмотреть причины по договорам конкретного клиента', expanded=False):
                            unps = material[UNP].astype(str).tolist()
                            chosen_unp = st.selectbox('УНП клиента', unps,
                                format_func=lambda u: f'{u} · {material.loc[material[UNP].astype(str)==u,"Клиент"].iloc[0]}',
                                key='material_unp')
                            chosen = result.contracts.loc[result.contracts[UNP].astype(str)==chosen_unp]
                            detail_cols = [UNP, CONTRACT, 'Статус', 'Задолженность — было',
                                           'Задолженность — стало', 'Резерв — было',
                                           'Резерв — стало', 'Δ резерва', 'Сигналы']
                            st.dataframe(chosen[detail_cols], hide_index=True,
                                         use_container_width=True, height=250)
                        top = material.head(15).sort_values('Δ резерва')
                        fig = px.bar(top, x='Δ резерва', y='Клиент', orientation='h',
                                     color=top['Δ резерва'].gt(0).map({True:'Рост',False:'Снижение'}),
                                     color_discrete_map={'Рост':CORAL,'Снижение':TEAL},
                                     height=max(270, min(600, 40*len(top)+100)),
                                     labels={'Δ резерва':'тыс. BYN', 'Клиент':'Клиент', 'color':'Направление'})
                        fig.update_layout(template='plotly_white',margin=dict(l=10,r=10,t=20,b=5),
                                          legend_title_text=None)
                        st.plotly_chart(fig,use_container_width=True)
                    st.markdown('##### Сверка с полным изменением резерва')
                    st.caption('Существенные клиенты + остальные клиенты + позиции без однозначного ключа '
                               '= Δ резерва всего.')
                    recon = pd.DataFrame({
                        'Группа':['Существенные клиенты', 'Остальные клиенты',
                                 'Без сопоставимого УНП / договора', 'ИТОГО'],
                        'Клиентов':[len(material), report.other_clients_count,
                                   None, report.all_clients_count],
                        'Δ резерва, тыс. BYN':[report.material_delta, report.other_clients_delta,
                                               report.unmatched_delta, result.delta],
                    })
                    st.dataframe(recon,hide_index=True,use_container_width=True)
                    if abs(report.balance_error)>1e-6:
                        st.error(f'Ошибка сверки: {fmt(report.balance_error, 6)} тыс. BYN')
                with bridge:
                    f = result.factors
                    headline = f[f['Фактор'].isin(CORE_FACTORS)]
                    a,b = st.columns([1.6,1.0])
                    with a:
                        fig = go.Figure(go.Waterfall(
                            orientation='v', measure=['relative']*len(f)+['total'],
                            x=f['Фактор'].tolist()+['ИТОГО'],
                            y=f['Изменение'].tolist()+[0],
                            increasing=dict(marker_color=CORAL), decreasing=dict(marker_color=TEAL),
                            totals=dict(marker_color=BLUE),
                            connector=dict(line=dict(color='#d1dbeb',width=1)),
                        ))
                        fig.update_layout(template='plotly_white',height=510,showlegend=False,
                                          yaxis_title='тыс. BYN',xaxis_tickangle=-35,
                                          margin=dict(l=5,r=5,t=10,b=140),font=dict(size=10))
                        st.plotly_chart(fig,use_container_width=True)
                    with b:
                        st.markdown('##### Основные факторы')
                        st.dataframe(headline[['Фактор','Изменение']],hide_index=True,
                                     use_container_width=True,height=295,
                                     column_config={'Изменение':st.column_config.NumberColumn(format='%.2f')})
                        st.metric('Изменение по всем факторам',metric_text(f['Изменение'].sum(),'тыс. BYN'))
                        csv_export(f,f'operational_bridge_{date_suffix}.csv','⬇️ Скачать полный мост')
                    st.caption('Показаны также технические категории: выбывшие договоры, рост задолженности, '
                               'совместные сигналы, прочие случаи и строки без ключей. '
                               'Они нужны, чтобы не приписывать изменения неустановленным причинам.')
                    st.markdown('#### Полная расшифровка')
                    st.dataframe(f[['Фактор','Изменение']],hide_index=True,use_container_width=True,
                                 column_config={'Изменение':st.column_config.NumberColumn(format='%.2f')})
                    st.caption(f'Договоров с несколькими одновременными сигналами: {result.simultaneous_contracts}')
                with clients_tab:
                    table = result.clients.copy()
                    q1,q2,q3 = st.columns([1.3,1,1])
                    q = q1.text_input('Найти УНП или клиента',key='oper_client_search')
                    direction = q2.selectbox('Δ резерва',['Все','Рост','Снижение'],key='oper_dir')
                    factor = q3.selectbox('Фактор',['Любой']+FACTOR_ORDER,key='oper_factor')
                    if q.strip():
                        table=table.loc[
                            table[UNP].astype('string').str.contains(q,regex=False,case=False,na=False) |
                            table['Клиент'].astype('string').str.contains(q,regex=False,case=False,na=False)]
                    if direction=='Рост':table=table[table['Δ резерва']>0]
                    elif direction=='Снижение':table=table[table['Δ резерва']<0]
                    if factor!='Любой':table=table[table[factor].abs()>1e-10]
                    st.caption(f'Клиентов: {len(table)}. Приведены первые 3000; в выгрузке — все.')
                    show=[UNP,'Клиент','Сегмент','Договоров — было','Договоров — стало',
                          'Резерв — было','Резерв — стало','Δ резерва',*CORE_FACTORS,
                          F_MULTI,F_OTHER,'Сигналы']
                    st.dataframe(table[show].head(3000),hide_index=True,use_container_width=True,height=470)
                    csv_export(table,f'clients_operational_{date_suffix}.csv','⬇️ Выгрузить всех клиентов')
                    if not result.segments.empty:
                        with st.expander('Изменение резервов по сегментам'):
                            st.dataframe(result.segments,use_container_width=True,hide_index=True)
                with contracts_tab:
                    c = result.contracts.copy()
                    q1,q2,q3=st.columns([1.4,1,1])
                    qq=q1.text_input('УНП / договор / клиент',key='oper_contract_search')
                    status=q2.multiselect('Статусы', ['Новый договор','Действующий','Выбывший договор'],
                                          key='oper_contract_status')
                    event=q3.selectbox('Событие',['Любое']+CORE_FACTORS+[F_MULTI,F_OTHER],key='oper_event')
                    if qq.strip():
                        match = (c[UNP].astype('string').str.contains(qq,case=False,regex=False,na=False) |
                                 c[CONTRACT].astype('string').str.contains(qq,case=False,regex=False,na=False) |
                                 c['Клиент'].astype('string').str.contains(qq,case=False,regex=False,na=False))
                        c=c.loc[match]
                    if status:c=c[c['Статус'].isin(status)]
                    if event!='Любое':c=c[c[event].abs()>1e-10]
                    fields=[UNP,CONTRACT,'Клиент','Статус','Задолженность — было',
                            'Задолженность — стало','Резерв — было','Резерв — стало','Δ резерва',
                            *CORE_FACTORS,F_MULTI,F_OTHER,'Сигналы',
                            'НИ (было)','НИ (стало)','ПФН (было)','ПФН (стало)',
                            'НВВ (было)','НВВ (стало)',
                            'Рестра (было)','Рестра (стало)',
                            'Рестра — статус (было)','Рестра — статус (стало)',
                            'Обеспеченность (было)','Обеспеченность (стало)']
                    st.dataframe(c[fields].head(3000),hide_index=True,use_container_width=True,height=520)
                    st.caption(f'Показано {min(len(c),3000)} из {len(c)} договоров. '
                               'Наличие сигнала не означает доказанную причинность изменения резерва.')
                    csv_export(c,f'contracts_operational_{date_suffix}.csv','⬇️ Выгрузить договоры и все поля')
                with methodology:
                    st.markdown('''
**Показатель.** `ΔR = Σ Резерв факт (конец) − Σ Резерв факт (начало)`, тыс. BYN.

**Ключ договора.** `(УНП, Номер договора)`. Сначала сворачиваются строки одного договора
(например, несколько счетов), затем факторы суммируются по УНП.
Договоры без УНП или номера договора исключаются из сопоставления, но их резервы
попадают в специальные сверочные категории.

**Новые договоры.** Договор появился в портфеле на конечную дату — в фактор включается весь его новый резерв `+R1`.

**Выбывшие договоры.** Договор исчез из портфеля — в фактор включается `−R0`.
По двум снимкам нельзя доказать, что выбытие произошло именно из-за полного погашения,
а не списания, переноса или иной операции.

**Погашение действующего договора — оценка.** Для сопоставленного договора с `D0 > 0`, `D1 ≥ 0`
объёмный эффект `ΔD × (R0 / D0)`. Если `ΔD < 0`, эффект относим к погашению;
если `ΔD > 0`, к росту задолженности. Снижение задолженности может также быть списанием
или валютной переоценкой. Поэтому это оценка, не бухгалтерский факт.

**Остаточное изменение резерва.** `ΔR − объёмный эффект`:

- НИ, ПФН, НВВ: значения `1` — признак есть, `0` или пусто — признака нет.
  Относим к признанию только переход `0/пусто → 1`.
- Реструктуризация: признаётся при тексте с `рестр` (например, `рестр. 4ГР 30%`);
  отсутствие текста, `0`, `Нет` — признака нет. Изменение одного текста
  реструктуризации на другой без снятия признака не считается признанием заново.
  Неизвестные непустые форматы не приравниваются автоматически к отсутствию признака.
- Обеспеченность: поле заполнено на обе даты, значения различаются.
- Просрочка: отличается сумма просрочки или `Day OD`, причём оба сравниваемых значения известны.
- Если изменился **один** из этих признаков — остаточное изменение относится к нему.
- Если одновременно изменилось **несколько признаков** — их общая сумма показывается как
  **«Совместное влияние факторов»**, а полный перечень доступен у договора.
- Если изменений признаков нет — **«Прочие изменения»**.

Такой мост сходится математически, но распределение остатка между причинами является
**правилом классификации по наблюдаемым событиям**, а не доказанным контрфактическим
расчётом влияния каждого фактора. Для причинной атрибуции нужны журнал событий,
движения по договорам и методика расчёта резерва.

**Данные качества:** пропуски сумм считаются нулём с предупреждением; отрицательная/нулевая
исходная задолженность выделяется в отдельную группу. Оценки — не замена бухгалтерскому учёту.
''')

if page == '🧩 Срезы':
    if data is None:
        st.info('Сводные таблицы появятся после загрузки портфеля.')
    else:
        st.subheader('Сводные срезы')
        st.markdown('<div class="section-lead">Самостоятельный анализ текущего снимка по двум измерениям и выбранному показателю.</div>', unsafe_allow_html=True)
        a,b,c,d = st.columns(4)
        dimensions = [x for x in CATEGORY_COLUMNS if x not in [UNP, CLIENT, 'Номер договора','Счет']]
        r = a.selectbox('Строки', dimensions, index=dimensions.index(DEFAULT_GROUP))
        c = b.selectbox('Колонки', ['—']+[v for v in dimensions if v != r])
        metric = d.selectbox('Показатель', [DEBT, OVERDUE, RESERVE,'Резерв рассчит','EL, тыс BYN'])
        aggregation = st.radio('Агрегация', ['Сумма','Количество','Среднее','Медиана'], horizontal=True)
        result = make_pivot(data, r, None if c=='—' else c, metric, aggregation, limit=25)
        st.dataframe(result, use_container_width=True, height=520)
        st.download_button('⬇️ Выгрузить сводную CSV', result.to_csv(sep=';',decimal=',').encode('utf-8-sig'),
                           file_name='pivot.csv')

if page == '🗂️ Портфели по датам':
    st.subheader('Портфели по отчётным датам')
    st.info('**Один файл = одна отчётная дата.** Загрузите Excel, укажите дату портфеля и нажмите «Сохранить». '
            'Исходный файл нельзя изменить или перезаписать. Вернуться к любой дате можно через меню слева.')
    st.markdown('<div class="section-lead">Если файл создан в Numbers, сначала экспортируйте его в Excel (.xlsx).</div>', unsafe_allow_html=True)
    with st.container(border=True):
        st.markdown('#### Шаг 1. Загрузите Excel или CSV')
        source = st.file_uploader('Файл Excel / CSV', type=['xlsx','xlsm','xls','csv'],
                                  help='Apple Numbers: Файл → Экспортировать в → Excel.')
        sheet = 'CSV'
        if source is not None:
            try:
                sheet = st.selectbox('Лист с портфелем', sheet_list(source.getvalue(), source.name))
            except Exception as error:
                st.error(f'Не удалось прочитать листы: {error}')
        with st.form('upload_snapshot', clear_on_submit=False):
            c1,c2 = st.columns(2)
            report_date = c1.date_input('Дата, на которую составлен портфель', value=date.today(),
                                        help='Дата состояния портфеля, а не дата загрузки файла.')
            title = c2.text_input('Название портфеля', value='Портфель МСФО')
            col1,col2 = st.columns([1,2])
            header = col1.number_input('Строка заголовка', 1, 30, 1)
            comment = col2.text_input('Комментарий (необязательно)', placeholder='Например, отчётный день, сверено с источником')
            submitted = st.form_submit_button('Сохранить портфель на выбранную дату', type='primary', use_container_width=True)
        if submitted:
            if source is None:
                st.warning('Выберите Excel или CSV.')
            else:
                try:
                    vid = store.save(source.getvalue(), source.name, sheet, int(header),
                                     title, comment, report_date=report_date)
                except Exception as err:
                    st.error(f'Не удалось сохранить: {err}')
                else:
                    st.session_state['snapshot_id'] = vid
                    st.success('Портфель сохранён. Исходный файл доступен в библиотеке.')
                    st.rerun()

    if versions:
        st.markdown('#### Шаг 2. Проверьте сохранённые портфели')
        catalog = pd.DataFrame([{'ID':v['id'], 'Дата портфеля':v['report_date'] or 'Не указана',
                                 'Название':v['title'], 'Строк':v['rows_count'],
                                 'Задолженность, тыс. BYN':v['debt_total'],
                                 'Резерв факт, тыс. BYN':v['reserve_total'],
                                 'Файл':v['filename']} for v in versions])
        st.dataframe(catalog, use_container_width=True, hide_index=True, height=320)
        st.markdown('#### Шаг 3. Просмотрите или скачайте портфель')
        pick = st.selectbox('Выберите снимок', ids, format_func=lambda i: snapshot_label(by_id[i]), key='catalog_pick')
        v = by_id[pick]
        c1,c2 = st.columns(2)
        with c1:
            st.download_button('⬇️ Скачать оригинальный файл', data=store.raw_bytes(pick),
                               file_name=v['filename'], use_container_width=True)
        with c2:
            if st.button('Выбрать этот портфель для просмотра', use_container_width=True):
                store.restore(pick)
                st.session_state['snapshot_id'] = pick
                st.rerun()
        with st.expander('Назначить / исправить дату старого снимка'):
            st.caption('Меняется только дата в каталоге, не загруженный файл. Нужно для сравнения старых версий v2/v3.')
            if v['report_date']:
                current = date.fromisoformat(v['report_date'])
            else:
                current = date.today()
            corrected = st.date_input('Отчётная дата для выбранного снимка', current, key=f'date_meta_{pick}')
            if st.button('Записать отчётную дату', key=f'assign_{pick}'):
                try:
                    store.set_report_date(pick, corrected)
                except Exception as err:
                    st.error(str(err))
                else:
                    st.success('Дата в каталоге обновлена.')
                    st.rerun()
        without_summary = [v['id'] for v in versions if v['reserve_total'] is None]
        if without_summary:
            st.caption(f'{len(without_summary)} старых снимков без KPI (загружены в v2/v3).')
            if st.button('Рассчитать KPI старых снимков'):
                try:
                    with st.spinner('Читаю исходные файлы и заполняю агрегаты...'):
                        for legacy_id in without_summary:
                            store.update_summary(legacy_id)
                except Exception as err:
                    st.error(str(err))
                else:
                    st.rerun()
        with st.expander('История действий'):
            events = pd.DataFrame(store.audit_log())
            if not events.empty:
                st.dataframe(events, use_container_width=True, hide_index=True)
    st.caption(f'Хранилище: {STORE_DIR}. Для резервного копирования сохраняйте эту папку целиком.')

if page == '🔎 Качество данных':
    if data is None:
        st.info('Загрузите портфель, чтобы проверить качество данных.')
    else:
        st.subheader('Проверки качества данных')
        st.markdown('<div class="section-lead">Структура файла проверяется при загрузке. Ниже — предупреждения для аналитических расчётов.</div>', unsafe_allow_html=True)
        c = st.columns(4)
        c[0].metric('Колонок', len(data.columns))
        c[1].metric('Строк', len(data))
        c[2].metric('Без УНП', int(data[UNP].isna().sum() + data[UNP].eq('').fillna(False).sum()))
        c[3].metric('Пустой резерв факт', int(data[RESERVE].isna().sum()))
        if st.button('Рассчитать профиль заполненности по 55 столбцам'):
            st.session_state['profile_id'] = selected_id
        if st.session_state.get('profile_id') == selected_id:
            p = profile_cached(selected_id, selected['content_sha256'])
            st.dataframe(p, use_container_width=True, hide_index=True, height=540)
        st.caption('Числа, которые не удалось преобразовать при импорте, помечаются как пропущенные. Перед интерпретацией расхода проверьте исходный файл.')

if page == '❓ Инструкция':
    st.subheader('Инструкция: от Excel до отчёта')
    st.caption('Эти шаги можно выполнить без знания Python. Достаточно один раз запустить приложение.')
    with st.container(border=True):
        st.markdown('### Быстрый сценарий — 5 шагов')
        st.markdown('''
1. Откройте **«Портфели по датам»** и загрузите Excel на первую дату.
2. Введите именно **отчётную дату**, а не день загрузки; сохраните портфель.
3. Загрузите второй портфель на другую дату.
4. Откройте **«Расходы на резервы»**, выберите обе даты и откройте
   **«Существенные клиенты»**.
5. Прочитайте колонку **«Что произошло»**, при необходимости раскройте договоры
   и нажмите **«Скачать полный список существенных клиентов (CSV)»**.
''')
    a,b=st.columns(2)
    with a:
        with st.expander('Как загрузить портфель?',expanded=True):
            st.write('Понадобится Excel (.xlsx/.xls/.xlsm) или CSV со всеми 55 обязательными столбцами. '
                     'Если заголовки находятся не в первой строке, укажите номер строки. '
                     'На одну дату можно сохранить только один снимок.')
        with st.expander('Как выбрать даты и как читается знак изменения?', expanded=True):
            st.write('Начало — более ранняя дата, конец — более поздняя. '
                     'Δ резерва = резерв на конец − резерв на начало. '
                     'Положительное значение означает рост резерва, отрицательное — снижение.')
        with st.expander('Что такое существенный клиент?'):
            st.write('Все договоры одного УНП суммируются. Если изменение ≤ −100 либо ≥ +100 тыс. BYN, '
                     'клиент попадает в подробный отчёт. При −99,99 и +99,99 — в агрегат «Остальные».')
    with b:
        with st.expander('Откуда берутся комментарии?', expanded=True):
            st.write('Сравниваются новый или выбывший договор, задолженность, НИ, ПФН, НВВ, '
                     '«Рестра», обеспеченность и просрочка. Комментарий перечисляет видимые изменения. '
                     'Он не является доказательством бухгалтерской причины.')
        with st.expander('Что такое факторный мост?'):
            st.write('Изменение резерва раскладывается на непересекающиеся аналитические категории. '
                     '«Совместное влияние» возникает при нескольких изменениях одновременно. '
                     '«Прочие» — когда явные признаки не позволяют объяснить остаток. '
                     'Сумма всех факторов равна общему изменению резерва.')
        with st.expander('Где хранятся файлы и как сделать резервную копию?'):
            st.write('В папке portfolio_storage рядом с приложением: база SQLite и оригинальные файлы. '
                     'Закройте приложение и скопируйте папку целиком на разрешённый защищённый носитель. '
                     'Не удаляйте её при обновлениях.')
    st.warning('Портфель содержит банковскую информацию. Приложение не имеет авторизации. '
               'Используйте только локально или во внутреннем защищённом контуре.')
    st.button('Перейти к загрузке',on_click=go_to,args=('🗂️ Портфели по датам',))

st.markdown('---')
st.caption('Portfolio Monitor v9 · данные хранятся локально · аналитический отчёт, не бухгалтерский регистр')
