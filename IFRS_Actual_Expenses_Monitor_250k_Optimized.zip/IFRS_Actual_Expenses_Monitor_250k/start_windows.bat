@echo off
chcp 65001 >nul
pushd "%~dp0"
python -c "import openpyxl" >nul 2>&1
if errorlevel 1 (
 echo ОШИБКА: требуется openpyxl. Обратитесь к ИТ для установки.
 pause
 exit /b 1
)
echo Мониторинг расходов на резервы МСФО
python server.py --host 127.0.0.1 --port 8501
pause
