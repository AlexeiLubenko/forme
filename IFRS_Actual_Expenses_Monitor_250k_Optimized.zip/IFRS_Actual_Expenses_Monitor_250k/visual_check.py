"""Deprecated compatibility wrapper: run smoke_browser.py instead."""
from pathlib import Path
import runpy
runpy.run_path(str(Path(__file__).with_name('smoke_browser.py')),run_name='__main__')
