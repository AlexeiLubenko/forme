"""Optional visual smoke test. Uses local mock API to work in restricted browsers."""
from pathlib import Path
import json
from playwright.sync_api import sync_playwright
from server import archive,read_report,get_positions,get_banks,get_significant
root=Path(__file__).parent
state=archive()
assert state['reports'],'Сначала запустите python load_demo.py'
r=read_report(state['reports'][0]['id'])
mock={
 '/api/state':{'archive':state,'has_base':True,'has_reports':True},
 '/api/report':{key:value for key,value in r.items() if key!='positions'},
 '/api/positions':get_positions(r,'ЮЛ и ИП','',1,30),
 '/api/significant':get_significant(r,1,30),
 '/api/banks':get_banks(r,1,50),
}
html=(root/'static/index.html').read_text(encoding='utf8').replace('<link rel="stylesheet" href="/style.css">','<style>'+(root/'static/style.css').read_text(encoding='utf8')+'</style>').replace('<script src="/app.js"></script>','<script>'+(root/'static/app.js').read_text(encoding='utf8')+'</script>')
with sync_playwright() as pw:
  browser=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
  page=browser.new_page(viewport={'width':1440,'height':1000})
  errors=[];page.on('pageerror',lambda error:errors.append(str(error)))
  page.goto('about:blank')
  page.evaluate('''m => {window.__MOCK=m;window.fetch=async function(uri){let u=String(uri).split('?')[0];let v=window.__MOCK[u]||{};return {ok:true,headers:{get:()=>"application/json"},json:async()=>v,text:async()=>JSON.stringify(v)};}}''',mock)
  page.set_content(html,wait_until='load')
  page.wait_for_timeout(700)
  assert page.locator('#mainKpis .kpi').count()>=3
  page.screenshot(path=str(root/'preview_optimized_overview.png'),full_page=True)
  for tab in ('factors','uploads','history'):
    page.locator(f'.nav[data-page="{tab}"]').click()
    page.wait_for_timeout(400)
    page.screenshot(path=str(root/f'preview_optimized_{tab}.png'),full_page=True)
  assert not errors,errors
  print('Browser smoke test passed: обзор, факторный анализ, загрузка, история')
  browser.close()
