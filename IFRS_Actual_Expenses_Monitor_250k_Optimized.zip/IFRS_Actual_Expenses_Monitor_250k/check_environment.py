import sys
print('Python:',sys.version.split()[0])
try:
 import openpyxl
 print('openpyxl:',openpyxl.__version__,'— обязателен')
except ImportError:print('openpyxl: НЕ УСТАНОВЛЕН (обязателен)')
try:
 import reportlab
 print('reportlab:',reportlab.Version,'— PDF с сервера доступен')
except ImportError:print('reportlab: отсутствует; PDF можно сохранить через «Печать» в браузере')
