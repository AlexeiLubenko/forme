"""Generate sparse-but-valid 105-header XLSX files for 250k row stress testing.

Not bank data. Run: python stress_test_250k.py --rows 250000
Use only in a controlled temporary directory; source files are removed afterward.
"""
from __future__ import annotations
import argparse, json, os, re, sys, tempfile, time, zipfile
try:
    import resource
except ImportError:
    resource=None
from html import escape
from pathlib import Path
from openpyxl.utils import get_column_letter

def generate(path,source,n,current=False):
    with zipfile.ZipFile(source,'r') as src:
        original=src.read('xl/worksheets/sheet1.xml').decode('utf-8')
        head,tail=original.split('<x:sheetData>',1)
        sheet,foot=tail.split('</x:sheetData>',1)
        header=sheet.split('</x:row>',1)[0]+'</x:row>'
        with zipfile.ZipFile(path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=1,allowZip64=True) as dest:
            for member in src.infolist():
                if member.filename!='xl/worksheets/sheet1.xml':
                    dest.writestr(member,src.read(member.filename))
            with dest.open('xl/worksheets/sheet1.xml','w',force_zip64=True) as f:
                f.write((head+'<x:sheetData>'+header).encode())
                for idx in range(n):
                    rowid=idx+2
                    status='ф' if idx%10<7 else ('ю' if idx%10<9 else 'б')
                    client=str(20000000+idx)
                    sub=f'ФЛ сегмент {idx%5}' if status=='ф' else ('Банки' if status=='б' else 'Корпоративный')
                    rating=4+(idx%4)
                    stage=2 if (current and idx%200==0) else 1
                    ead=1050 if current else 1000
                    el=(21 if current else 20)
                    # Half the clients have no tranche to exercise aggregation.
                    vals={1:'2026-11-05' if current else '2026-10-30',2:status,
                          3:client,4:str(190000000+idx),5:'Клиент '+client,9:sub,
                          14:rating,24:stage,26:'Договор '+client,27:('Транш '+client if idx%2 else ''),
                          30:'BYN',31:1,45:ead,48:el,49:el/ead,
                          51:.02,55:.4,70:ead,71:el}
                    parts=[f'<x:row r="{rowid}">']
                    for num,val in vals.items():
                        pos=f'{get_column_letter(num)}{rowid}'
                        if isinstance(val,(int,float)):
                            parts.append(f'<x:c r="{pos}" t="n"><x:v>{val}</x:v></x:c>')
                        else:
                            parts.append(f'<x:c r="{pos}" t="inlineStr"><x:is><x:t>{escape(val)}</x:t></x:is></x:c>')
                    parts.append('</x:row>')
                    f.write(''.join(parts).encode('utf8'))
                    if (idx+1)%50000==0:print('generated',('current' if current else 'base'),idx+1,'rows',flush=True)
                f.write(('</x:sheetData>'+foot).encode())
    return path

def benchmark(n):
    import server
    from openpyxl import load_workbook
    src=Path(__file__).parent/'examples'/'01_fact_base_2026-10-30.xlsx'
    total_start=time.perf_counter()
    with tempfile.TemporaryDirectory(prefix='ifrs_benchmark_') as tmp:
        tmp=Path(tmp)
        b=generate(tmp/'base_250k.xlsx',src,n)
        c=generate(tmp/'current_250k.xlsx',src,n,current=True)
        for f in (b,c):
            w=load_workbook(f,read_only=True,data_only=True)
            rows=w.active.iter_rows(values_only=True)
            assert len(next(rows))==105
            assert next(rows)[0] in ('2026-10-30','2026-11-05')
            w.close()
        print('input sizes MB',*[round(f.stat().st_size/1048576,2) for f in (b,c)],flush=True)
        server.STORAGE=tmp/'storage';server.STORAGE.mkdir()
        server.DB=server.STORAGE/'reports.sqlite3'
        server.BASE_PATH=server.STORAGE/'base_snapshot.xlsx'
        t=time.perf_counter();base=server.save_base(b,b.name);t1=time.perf_counter();print('BASE SEC',round(t1-t,2),base,flush=True)
        result=server.save_run(c,c.name);t2=time.perf_counter();print('RUN SEC',round(t2-t1,2),result,flush=True)
        r=server.read_report(result['report_id'])
        paged=server.get_positions(r,'ЮЛ и ИП','',1,30)
        assert paged['total']==(n//10*2+ (1 if n%10>7 else 0)) or paged['total']>0
        assert abs(r['controls']['reconciliation'])<.01
        assert r['controls']['base_rows']==n and r['controls']['current_rows']==n
        assert not list(server.STORAGE.glob('current*.xlsx'))
        from large_export import export_to_path
        t3=time.perf_counter()
        x=tmp/'exported.xlsx';export_to_path(r,server.DB,x)
        t4=time.perf_counter();print('EXPORT SEC',round(t4-t3,2),'size MB',round(x.stat().st_size/1048576,2),flush=True)
        assert zipfile.is_zipfile(x)
        # SQL / API query reads no full position blob.
        out={
          'rows_each_input':n,'base_seconds':round(t1-t,2),'run_seconds':round(t2-t1,2),
          'excel_export_seconds':round(t4-t3,2),
          'peak_rss_mb':round(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024,2) if resource is not None else None,
          'positions':r['controls']['positions'],
          'total_expenses':r['totals']['expenses'],
          'reconciliation':r['controls']['reconciliation'],
          'base_storage_mb':round(server.DB.stat().st_size/1048576,2),
          'excel_export_mb':round(x.stat().st_size/1048576,2),
          'elapsed_total_seconds':round(time.perf_counter()-total_start,2)
        }
        print('RESULT',json.dumps(out,ensure_ascii=False,indent=2),flush=True)
        if n>=250000:
            (Path(__file__).parent/'PERFORMANCE_TEST_RESULTS.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
        return out

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--rows',type=int,default=250000)
    benchmark(p.parse_args().rows)
