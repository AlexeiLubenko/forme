"""Bounded-memory IFRS actual ingestion and calculation for 250k+ source rows.

Sources are streamed from XLSX, one CRM at a time is fed to the *existing* factor
engine, and report positions are kept in SQLite rather than one JSON blob.
"""
from __future__ import annotations

from collections import defaultdict
from datetime import datetime
from io import BytesIO
from pathlib import Path
import heapq, json, math, re, sqlite3, zlib

from core import FACTORS, RESERVE_NUMS, SIGNALS, datum, ident, number, summarize_pair, group_segment

REQUIRED=(1,2,3,4,5,9,14,24,26,27,30,31,45,48,49,51,55,70,86,87,88,89)
SEGMENTS=('ЮЛ и ИП','Физические лица','Банки')
WARN_SAMPLE=600

def encode_position(value):
    # Per-position compression reduces persistent SQLite footprint substantially.
    return zlib.compress(json.dumps(value,ensure_ascii=False,separators=(',',':')).encode('utf8'),1)

def decode_position(value):
    if isinstance(value,bytes):
        try:return json.loads(zlib.decompress(value))
        except zlib.error:return json.loads(value)
    return json.loads(value)



def parse_xlsx_to_sqlite(path, conn, table, source_name=None, batch=2000, create_index=True, progress=None):
    """Read-only workbook -> SQLite. Memory O(batch), not O(Excel rows)."""
    from openpyxl import load_workbook
    # Do not materialize all rows or the unpacked file.
    wb=load_workbook(path,read_only=True,data_only=True,keep_links=False)
    try:
        it=wb.active.iter_rows(values_only=True)
        headers=next(it,None)
        if not headers:raise ValueError('Пустой Excel')
        indexed={}
        for i,h in enumerate(headers):
            m=re.match(r'^\s*(\d+)\s*\.',str(h or ''))
            if m:indexed[int(m.group(1))]=i
        missing=[str(n) for n in REQUIRED if n not in indexed]
        if missing:raise ValueError('Отсутствуют обязательные столбцы: '+', '.join(missing))
        if len(indexed)<75:raise ValueError('Ожидается Excel с пронумерованной шапкой из 105 столбцов')
        conn.execute(f'CREATE TABLE {table}(crm TEXT NOT NULL, data TEXT NOT NULL)')
        warnings=[];warning_count=0;rows=0;report_date=None;batch_rows=[]
        def warn(level, line, crm, message):
            nonlocal warning_count
            warning_count+=1
            if len(warnings)<WARN_SAMPLE:warnings.append({'level':level,'row':line,'crm':crm,'message':message})
        for line,raw in enumerate(it,2):
            if all(x is None for x in raw):continue
            def g(n):
                pos=indexed.get(n)
                return raw[pos] if pos is not None and pos<len(raw) else None
            crm=ident(g(3))
            try:
                d=datum(g(1));status=ident(g(2)).lower()
                if status not in ('ю','ип','ф','б'):raise ValueError('Неизвестный статус: '+repr(status))
                if not crm:raise ValueError('Нет CRM ID')
                if report_date is None:report_date=d
                elif report_date!=d:raise ValueError('В файле обнаружено несколько отчётных дат: '+report_date+' и '+d)
                stage=int(number(g(24)));ccy=ident(g(30)).upper() or 'BYN'
                if stage not in (1,2,3):raise ValueError('Стадия должна быть 1,2 или 3')
                reserve={str(n):number(g(n)) for n in RESERVE_NUMS}
                r={'date':d,'status':status,'crm':crm,'unp':ident(g(4)),
                   'client':ident(g(5)) or crm,'subportfolio':ident(g(9)) or 'Не указан',
                   'rating':number(g(14),-1),'stage':stage,
                   'contract':ident(g(26)) or 'БЕЗ ДОГОВОРА','tranche':ident(g(27)),
                   'currency':ccy,'fx':number(g(31),1),'ead':number(g(45)),
                   'el':number(g(48)),'rate':number(g(49)),'pd':number(g(51)),
                   'lgd':number(g(55)),
                   'active':sum(number(g(x)) for x in (70,72,74,76)),
                   'uo':number(g(86)),'off':number(g(88)),
                   'uo_reserve':number(g(87)),'off_reserve':number(g(89)),
                   'reserves':reserve,'signals':{str(k):ident(g(k)) for k in SIGNALS},
                   'line':line}
                if abs(r['el']-sum(reserve.values()))>0.0100001:
                    warn('error',line,crm,'EL отличается от суммы 16 компонентов более чем на 0,01 BYN')
                if abs(r['el']-r['ead']*r['rate'])>0.0100001:
                    warn('warning',line,crm,'EL ≠ EAD × коэффициент резервирования (свыше 0,01 BYN)')
                if r['ead']>0 and abs(r['el'])<0.00001:
                    warn('warning',line,crm,'EAD положителен, EL равен нулю')
                if r['ead']<0 or r['el']<0 or any(v<0 for v in reserve.values()):
                    warn('error',line,crm,'Отрицательный EAD или резерв')
                if r['ead']==0 and r['el']>0.01:warn('error',line,crm,'EL положителен при EAD=0')
                if not 0<=r['rate']<=1:warn('error',line,crm,'Коэффициент вне 0..1')
                if r['fx']<=0:warn('error',line,crm,'Курс должен быть положительным')
                batch_rows.append((crm,encode_position(r)))
                rows+=1
                if len(batch_rows)>=batch:
                    if progress:progress(rows)
                    conn.executemany(f'INSERT INTO {table}(crm,data) VALUES(?,?)',batch_rows)
                    batch_rows.clear()
            except (TypeError,ValueError,OverflowError) as e:
                # Mixed report dates are fatal; all other broken rows remain visible in controls.
                if 'несколько отчётных дат' in str(e):raise
                warn('error',line,crm,'Некорректная строка: '+str(e))
        if batch_rows:conn.executemany(f'INSERT INTO {table}(crm,data) VALUES(?,?)',batch_rows)
        if not rows:raise ValueError('Нет валидных строк в отчёте')
        if create_index:conn.execute(f'CREATE INDEX idx_{table}_crm ON {table}(crm)')
        conn.commit()
        return {'date':report_date,'count':rows,'warnings':warnings,'warning_count':warning_count,'source_name':source_name or Path(path).name}
    finally:wb.close()


def iter_groups(conn, table, condition='', parameters=()):
    sql=f'SELECT crm,data FROM {table} '+condition+' ORDER BY crm'
    cursor=conn.execute(sql,parameters)
    key=None;acc=[]
    for crm,blob in cursor:
        if key is not None and crm!=key:
            yield key,acc
            acc=[]
        key=crm
        acc.append(decode_position(blob))
    if key is not None:yield key,acc


def merge_groups(left,right):
    """Merge two CRM-ordered iterators, never loading full snapshots."""
    a=next(left,None);b=next(right,None)
    while a is not None or b is not None:
        if b is None or (a is not None and a[0]<b[0]):
            yield a[0],a[1],[];a=next(left,None)
        elif a is None or b[0]<a[0]:
            yield b[0],[],b[1];b=next(right,None)
        else:
            yield a[0],a[1],b[1]
            a=next(left,None);b=next(right,None)


def setup_schema(conn):
    conn.executescript('''
    CREATE TABLE IF NOT EXISTS base_rows(
      base_id INTEGER NOT NULL, crm TEXT NOT NULL, data TEXT NOT NULL);
    CREATE INDEX IF NOT EXISTS idx_base_rows ON base_rows(base_id,crm);
    CREATE TABLE IF NOT EXISTS report_positions(
      report_id INTEGER NOT NULL, segment TEXT NOT NULL, crm TEXT NOT NULL,
      search_text TEXT NOT NULL, expense_abs REAL NOT NULL, data TEXT NOT NULL);
    CREATE INDEX IF NOT EXISTS idx_report_positions_page ON report_positions(report_id,segment,expense_abs DESC);
    CREATE INDEX IF NOT EXISTS idx_report_positions_crm ON report_positions(report_id,crm);
    CREATE TABLE IF NOT EXISTS report_clients(
      report_id INTEGER NOT NULL, crm TEXT NOT NULL, segment TEXT NOT NULL,
      expense_abs REAL NOT NULL, data TEXT NOT NULL,
      PRIMARY KEY(report_id,crm));
    CREATE INDEX IF NOT EXISTS idx_report_clients_page ON report_clients(report_id,segment,expense_abs DESC);
    CREATE TABLE IF NOT EXISTS report_ratings(
      report_id INTEGER NOT NULL, crm TEXT NOT NULL, expense_abs REAL NOT NULL, data TEXT NOT NULL);
    CREATE INDEX IF NOT EXISTS idx_report_ratings_page ON report_ratings(report_id,expense_abs DESC);
    ''')


def read_base_groups(conn,base_id):
    for crm,rows in iter_groups(conn,'base_rows','WHERE base_id=?',(base_id,)):
        yield crm,rows


def keep_top(heap,item,max_count,expense):
    a=abs(expense);candidate=(a,str(item.get('crm','')),item)
    if len(heap)<max_count:heapq.heappush(heap,candidate)
    elif a>heap[0][0]:heapq.heapreplace(heap,candidate)


def calculate_stream(base_conn, current_conn, base_id, base_meta, current_meta, new_report_id, insert_batch=1000, progress=None):
    """Use existing summarize_pair on CRM-sized blocks; persist each position immediately.

    Peak memory is controlled by the largest single client + at most 1000 positions,
    not the 500k rows in the two source workbooks.
    """
    bdate=base_meta['date'];cdate=current_meta['date']
    if bdate>=cdate:raise ValueError('Дата текущего факта должна быть позже даты базы')
    left=read_base_groups(base_conn,base_id)
    right=iter_groups(current_conn,'current_rows')
    segs={s:{'el0':0.,'el1':0.,'ead0':0.,'ead1':0.,'expenses':0.,'count':0} for s in SEGMENTS}
    seg_comp={s:defaultdict(float) for s in SEGMENTS}
    factors={f:0. for f in FACTORS}
    factor_comp=defaultdict(float)
    seg_factors={s:{f:0. for f in FACTORS} for s in SEGMENTS}
    seg_factor_comp={s:defaultdict(float) for s in SEGMENTS}
    def stable_add(mapping,comp,key,value):
        if key=='count':mapping[key]+=value;return
        v=value-comp[key];n=mapping[key]+v;comp[key]=(n-mapping[key])-v;mapping[key]=n
    fl_sub=defaultdict(lambda:{'el0':0.,'el1':0.,'expenses':0.})
    fl_parts=defaultdict(lambda:defaultdict(float))
    fl_mig=defaultdict(lambda:{'el0':0.,'el1':0.,'count':0})
    bank_top=[];rating_top=[];sig_top=[]
    rating_counts={'Ухудшение':0,'Улучшение':0}
    sig_count=0; rating_count=0; npos=0
    warnings=list(base_meta.get('warnings',[]))+list(current_meta.get('warnings',[]))
    warn_count=base_meta.get('warning_count',len(base_meta.get('warnings',[])))+current_meta.get('warning_count',len(current_meta.get('warnings',[])))
    base_total=base_meta['count'];current_total=current_meta['count']
    batch=[]
    def flush():
        if batch:
            base_conn.executemany('INSERT INTO report_positions(report_id,segment,crm,search_text,expense_abs,data) VALUES(?,?,?,?,?,?)',batch)
            batch.clear()
    for crm,old,new in merge_groups(iter(left),iter(right)):
        block=summarize_pair({'date':bdate,'rows':old,'warnings':[],'count':len(old)},
                             {'date':cdate,'rows':new,'warnings':[],'count':len(new)})
        for seg,stats in block['segments'].items():
            dest=segs[seg]
            for metric in dest:stable_add(dest,seg_comp[seg],metric,stats[metric])
        for f,val in block['factors'].items():stable_add(factors,factor_comp,f,val)
        for seg,m in block['segment_factors'].items():
            for f,val in m.items():stable_add(seg_factors[seg],seg_factor_comp[seg],f,val)
        if block['controls']['warnings']:
            warn_count+=len(block['controls']['warnings'])
            for w in block['controls']['warnings']:
                if len(warnings)<WARN_SAMPLE:warnings.append(w)
        for sub in block['fl_subportfolios']:
            target=fl_sub[sub['subportfolio']]
            for k in target:target[k]+=sub[k]
        for m in block['fl_migrations']:
            agg=fl_mig[(m['old'],m['new'])]
            agg['el0']+=m['el0'];agg['el1']+=m['el1'];agg['count']+=1
        for p in block['positions']:
            npos+=1
            if p['segment']=='Физические лица':
                # FL are reported ONLY at subportfolio granularity. Retaining
                # hundreds of thousands of individual FL rows is unnecessary.
                oldsub=p['subportfolio0'];newsub=p['subportfolio1']
                for key in RESERVE_NUMS:
                    k=str(key)
                    if oldsub:fl_parts[oldsub][k]+=p['reserve_parts0'][k]
                    if newsub:fl_parts[newsub][k]-=p['reserve_parts1'][k]
                continue
            batch.append((new_report_id,p['segment'],p['crm'],
               ' '.join(str(p.get(key,'')) for key in ('client','crm','unp','contract','tranche','currency')).lower(),
               abs(p['expenses']),encode_position(p)))
            if len(batch)>=insert_batch:flush()
        for c in block['clients']:
            base_conn.execute('INSERT INTO report_clients(report_id,crm,segment,expense_abs,data) VALUES(?,?,?,?,?)',
                (new_report_id,crm,c['segment'],abs(c['expenses']),json.dumps(c,ensure_ascii=False)))
        for bank in block['banks']:
            keep_top(bank_top,bank,1000,bank['expenses'])
            base_conn.execute('INSERT INTO report_clients(report_id,crm,segment,expense_abs,data) VALUES(?,?,?,?,?)',
                (new_report_id,crm,'Банки',abs(bank['expenses']),json.dumps(bank,ensure_ascii=False)))
        for c in block['significant']:
            sig_count+=1
            keep_top(sig_top,c,200,c['expenses'])
            # Persist auto-comment with the client summary so it survives pagination.
            base_conn.execute('UPDATE report_clients SET data=? WHERE report_id=? AND crm=?',
                (json.dumps(c,ensure_ascii=False),new_report_id,crm))
        for e in block['ratings']:
            rating_count+=1
            rating_counts[e['movement']]+=1
            keep_top(rating_top,e,500, e['expenses'])
            base_conn.execute('INSERT INTO report_ratings(report_id,crm,expense_abs,data) VALUES(?,?,?,?)',
                (new_report_id,crm,abs(e['expenses']),json.dumps(e,ensure_ascii=False)))
        if progress and npos%10000<max(len(block['positions']),1):progress(npos)
        # Bounded transaction lifetime: avoid one huge pending SQLite write transaction.
        if npos and npos%2000<max(len(block['positions']),1):
            flush();base_conn.commit()
    flush();base_conn.commit()
    totals={k:sum(v[k] for v in segs.values()) for k in ('el0','el1','ead0','ead1','expenses')}
    factor_recon=totals['expenses']-sum(factors.values())
    seg_recon=totals['expenses']-sum(v['expenses'] for v in segs.values())
    # The underlying factor engine uses double precision. Keep sub-cent reconciliation visible,
    # never hide or independently round per tranche before aggregation.
    return {
      'base_date':bdate,'current_date':cdate,'totals':totals,'segments':segs,
      'factors':factors,'segment_factors':seg_factors,
      'positions':None,'clients':[],
      'significant':[x[2] for x in sorted(sig_top,reverse=True)],
      'significant_count':sig_count,
      'ratings':[x[2] for x in sorted(rating_top,reverse=True)],
      'rating_counts':rating_counts,'rating_count':rating_count,
      'fl_subportfolios':[{'subportfolio':k,**v} for k,v in sorted(fl_sub.items())],
      'fl_components':{sub:dict(parts) for sub,parts in fl_parts.items()},
      'fl_migrations':[{'old':a,'new':b,**v} for (a,b),v in fl_mig.items()],
      'banks':[x[2] for x in sorted(bank_top,reverse=True)],
      'controls':{'reconciliation':factor_recon,'segment_reconciliation':seg_recon,
        'positions':npos,'base_rows':base_total,'current_rows':current_total,
        'warnings':warnings,'warning_count':warn_count,'warning_samples_limited':warn_count>len(warnings)},
      'method_note':'Фактор стадии — вся ΔEL клиента; PD/LGD — модельные оценки, остаток в «Прочие». Рейтинг — аналитическое событие, не дополнительный денежный фактор.',
      'scalable':True
    }
