"""IFRS expense monitoring: two actual snapshots; no forecasting or BP."""
from __future__ import annotations
from collections import defaultdict
from datetime import datetime, date
from decimal import Decimal
from io import BytesIO
import json, math, re

RESERVE_NUMS=(71,73,75,77,79,81,83,85,87,89,91,93,95,97,99,101)
SIGNALS=(16,17,18,19,20,21,22,66)
KEY_FIELDS=("crm","contract","tranche","currency")
FACTORS=("Изменение стадии","Новые договоры и транши","Погашение / выбытие","Выборка (УО ↔ актив)","Валютный эффект","Изменение EAD","Изменение PD PIT","Изменение LGD","Прочие")


def number(x, default=0.0):
    if x is None or str(x).strip()=="": return default
    if isinstance(x,str): x=x.strip().replace('\u00a0','').replace(' ','').replace(',','.')
    v=float(x)
    if not math.isfinite(v):raise ValueError('Бесконечное / некорректное число')
    return v


def ident(x):
    if x is None:return ''
    s=str(x).strip()
    return s[:-2] if s.endswith('.0') and s[:-2].isdigit() else s


def datum(x):
    if isinstance(x, datetime):return x.date().isoformat()
    if isinstance(x, date):return x.isoformat()
    s=ident(x)
    for f in ('%Y-%m-%d','%d.%m.%Y','%Y-%m-%d %H:%M:%S'):
        try:return datetime.strptime(s,f).date().isoformat()
        except ValueError:pass
    raise ValueError('Не удалось определить отчетную дату: '+s)


def parse_excel(payload: bytes, filename: str):
    """Only in-memory read_only Excel ingestion, no source files written to disk."""
    from openpyxl import load_workbook
    wb=load_workbook(BytesIO(payload),read_only=True,data_only=True)
    ws=wb.active
    iterator=ws.iter_rows(values_only=True)
    headers=next(iterator,None)
    if not headers:raise ValueError('Пустой Excel')
    indexed={}
    for i,h in enumerate(headers):
        m=re.match(r'^\s*(\d+)\s*\.',str(h or ''))
        if m:indexed[int(m.group(1))]=i
    required=(1,2,3,4,5,9,14,24,26,27,30,31,45,48,49,51,55,70,86,87,88,89)
    missing=[str(n) for n in required if n not in indexed]
    if missing:raise ValueError('Отсутствуют обязательные столбцы по номерам: '+', '.join(missing))
    if len(indexed)<75:raise ValueError('Ожидается Excel МСФО с пронумерованной шапкой из 105 столбцов')
    rows=[]; dates=set(); warnings=[]
    for excel_row,raw in enumerate(iterator,2):
        if all(v is None for v in raw):continue
        def g(n):
            idx=indexed.get(n)
            return raw[idx] if idx is not None and idx<len(raw) else None
        try:
            d=datum(g(1)); status=ident(g(2)).lower(); crm=ident(g(3))
            if status not in ('ю','ип','ф','б'):raise ValueError('Неизвестный статус клиента: '+repr(status))
            if not crm:raise ValueError('Нет CRM ID клиента')
            stage=int(number(g(24))); ccy=ident(g(30)).upper() or 'BYN'
            if stage not in (1,2,3):raise ValueError('Стадия должна быть 1, 2 или 3')
            reserve={str(n):number(g(n)) for n in RESERVE_NUMS}
            row={'date':d,'status':status,'crm':crm,'unp':ident(g(4)),'client':ident(g(5)) or crm,
                'subportfolio':ident(g(9)) or 'Не указан','rating':number(g(14),-1),'stage':stage,
                'contract':ident(g(26)) or 'БЕЗ ДОГОВОРА','tranche':ident(g(27)), 'currency':ccy,
                'fx':number(g(31),1),'ead':number(g(45)), 'el':number(g(48)), 'rate':number(g(49)),
                'pd':number(g(51)),'lgd':number(g(55)),'active':sum(number(g(x)) for x in (70,72,74,76)),
                'uo':number(g(86)),'off':number(g(88)),'uo_reserve':number(g(87)),'off_reserve':number(g(89)),
                'reserves':reserve,'signals':{str(k):ident(g(k)) for k in SIGNALS},'line':excel_row}
            dates.add(d)
            if abs(row['el']-sum(reserve.values()))>0.0100001:
                warnings.append({'level':'error','row':excel_row,'crm':crm,'message':'EL отличается от суммы 16 компонентов более чем на 0,01 BYN'})
            if abs(row['el']-row['ead']*row['rate'])>0.0100001:
                warnings.append({'level':'warning','row':excel_row,'crm':crm,'message':'EL ≠ EAD × коэффициент резервирования (свыше 0,01 BYN)'})
            if row['ead']>0 and abs(row['el'])<0.00001:
                warnings.append({'level':'warning','row':excel_row,'crm':crm,'message':'EAD положителен, EL равен нулю'})
            if row['ead']<0 or row['el']<0 or any(v<0 for v in reserve.values()):
                warnings.append({'level':'error','row':excel_row,'crm':crm,'message':'Отрицательный EAD или резерв'})
            if row['ead']==0 and row['el']>0.01:
                warnings.append({'level':'error','row':excel_row,'crm':crm,'message':'EL положителен при EAD=0'})
            if not 0<=row['rate']<=1:
                warnings.append({'level':'error','row':excel_row,'crm':crm,'message':'Коэффициент резервирования вне 0..1'})
            if row['fx']<=0:
                warnings.append({'level':'error','row':excel_row,'crm':crm,'message':'Курс должен быть положительным'})
            rows.append(row)
        except (TypeError,ValueError,OverflowError) as e:
            warnings.append({'level':'error','row':excel_row,'crm':ident(g(3)),'message':'Некорректная строка: '+str(e)})
    if not rows:raise ValueError('Нет валидных строк факта')
    if len(dates)!=1:raise ValueError('В одном файле должна быть одна отчётная дата; найдено: '+', '.join(sorted(dates)))
    return {'date':next(iter(dates)),'rows':rows,'warnings':warnings,'source_name':filename,'count':len(rows)}


def aggregate_snapshot(raw):
    """Aggregates duplicate tranche/ccy positions, including all empty-tranche rows."""
    grouped={}; conflicts=[]
    for r in raw:
        key=tuple(r[k] for k in KEY_FIELDS)
        if key not in grouped:
            q={k:v for k,v in r.items() if k!='line'};q['rows_count']=0
            q['reserves']={p:0.0 for p in r['reserves']};q['lines']=[]
            grouped[key]=q
            for field in ('ead','el','active','uo','off','uo_reserve','off_reserve'):q[field]=0.0
        q=grouped[key]
        for name in ('ead','el','active','uo','off','uo_reserve','off_reserve'):q[name]+=r[name]
        for k,v in r['reserves'].items():q['reserves'][k]+=v
        q['rows_count']+=1;q['lines'].append(r['line'])
        for name in ('stage','rating','pd','lgd','fx','rate'):
            if name!='rate' and r[name]!=q[name]:
                conflicts.append({'level':'warning','crm':r['crm'],'row':r['line'],'message':f'Различаются {name} для одной позиции {key}'})
    return grouped,conflicts


def group_segment(row):
    return 'ЮЛ и ИП' if row['status'] in ('ю','ип') else ('Физические лица' if row['status']=='ф' else 'Банки')


def summarize_pair(base, current):
    """Signed expenses = old EL - new EL. Factor order is explicit and residual reconciles exactly."""
    if base['date']>=current['date']:raise ValueError('Дата текущего факта должна быть позже даты базы')
    bmap,bwarn=aggregate_snapshot(base['rows']);cmap,cwarn=aggregate_snapshot(current['rows'])
    stage0={};stage1={}; rating0={};rating1={};client_names={}
    for row in bmap.values():
        if row['status'] in ('ю','ип'):
            stage0[row['crm']]=row['stage'];rating0[row['crm']]=row['rating']
        client_names[row['crm']]=row['client']
    for row in cmap.values():
        if row['status'] in ('ю','ип'):
            stage1[row['crm']]=row['stage'];rating1[row['crm']]=row['rating']
        client_names[row['crm']]=row['client']
    changed_stage={crm for crm in (stage0.keys()&stage1.keys()) if stage0[crm]!=stage1[crm]}
    rating_events=[]
    for crm in sorted(rating0.keys()&rating1.keys()):
        a,z=rating0[crm],rating1[crm]
        if a!=z:
            rating_events.append({'crm':crm,'client':client_names[crm],'before':a,'after':z,
                'movement':'Ухудшение' if z>a else 'Улучшение'})
    # For stage changes, ENTIRE client expense is stage factor, including new/closed contracts.
    client_stage_delta=defaultdict(float)
    for r in bmap.values():
        if r['crm'] in changed_stage:client_stage_delta[r['crm']]+=r['el']
    for r in cmap.values():
        if r['crm'] in changed_stage:client_stage_delta[r['crm']]-=r['el']
    keys=set(bmap)|set(cmap)
    result=[]; client_stats=defaultdict(lambda:{'el0':0.,'el1':0.,'ead0':0.,'ead1':0.,'expenses':0.,'client':'','segment':''})
    for key in sorted(keys):
        old=bmap.get(key);new=cmap.get(key);r=new or old; crm=r['crm'];segment=group_segment(r)
        e0=old['el'] if old else 0.;e1=new['el'] if new else 0.
        x0=old['ead'] if old else 0.;x1=new['ead'] if new else 0.
        expenses=e0-e1
        cs=client_stats[crm];cs['el0']+=e0;cs['el1']+=e1;cs['ead0']+=x0;cs['ead1']+=x1;cs['expenses']+=expenses;cs['client']=r['client'];cs['segment']=segment
        factors={k:0. for k in FACTORS}
        if crm in changed_stage and segment=='ЮЛ и ИП':
            factors['Изменение стадии']=expenses
        elif not old:
            factors['Новые договоры и транши']=-e1
        elif not new:
            factors['Погашение / выбытие']=e0
        else:
            # Initial effective rate, exact decomposed volume+rate; currency revalues old volume.
            k0=(e0/x0) if x0>0 else 0.
            fx0=old['fx'] if old['fx']>0 else 1.;fx1=new['fx'] if new['fx']>0 else 1.
            fx_ead=(x0/fx0)*(fx1-fx0) if r['currency']!='BYN' else 0.
            factors['Валютный эффект']=-fx_ead*k0
            factors['Изменение EAD']=-(x1-x0-fx_ead)*k0
            # Contract-level drawdown is allocated after all positions are processed.
            # UO and active credit may reside in different tranche rows.
            # Estimation only, assigned before residual. Rating is a prominent explanatory event, not extra cash factor.
            if old['pd']>0 and new['pd']>=0:
                pd_shift=(new['pd']-old['pd'])/old['pd']
                factors['Изменение PD PIT']=-x1*k0*pd_shift
            if old['lgd']>0 and new['lgd']>=0:
                lgd_shift=(new['lgd']-old['lgd'])/old['lgd']
                factors['Изменение LGD']=-x1*k0*lgd_shift
            factors['Прочие']=expenses-sum(factors.values())
        tags=[]
        if crm in changed_stage:tags.append(f'Стадия {stage0[crm]} → {stage1[crm]}')
        if crm in rating0 and crm in rating1 and rating0[crm]!=rating1[crm]:tags.append(f'Рейтинг {rating0[crm]:g} → {rating1[crm]:g}')
        if not old:tags.append('Новая позиция')
        if not new:tags.append('Выбывшая позиция')
        for s in SIGNALS:
            a=(old or {}).get('signals',{}).get(str(s),'');b=(new or {}).get('signals',{}).get(str(s),'')
            if a!=b:tags.append(f'Риск-сигнал {s}: {a or "—"} → {b or "—"}')
        result.append({'key':'|'.join(key),'crm':crm,'unp':r['unp'],'client':r['client'],'segment':segment,
            'status':r['status'],'subportfolio0':old['subportfolio'] if old else '', 'subportfolio1':new['subportfolio'] if new else '',
            'contract':r['contract'],'tranche':r['tranche'],'currency':r['currency'],
            'stage0':old['stage'] if old else None,'stage1':new['stage'] if new else None,
            'rating0':old['rating'] if old else None,'rating1':new['rating'] if new else None,
            'el0':e0,'el1':e1,'ead0':x0,'ead1':x1,'expenses':expenses,'factors':factors,'events':tags,
            'active0':old['active'] if old else 0.,'active1':new['active'] if new else 0.,
            'uo0':old['uo'] if old else 0.,'uo1':new['uo'] if new else 0.,
            'fx0':old['fx'] if old else None,'fx1':new['fx'] if new else None,
            'reserve_changes':{k:(old['reserves'][k] if old else 0)-(new['reserves'][k] if new else 0) for k in map(str,RESERVE_NUMS)},
            'reserve_parts0':old['reserves'] if old else {str(n):0. for n in RESERVE_NUMS},
            'reserve_parts1':new['reserves'] if new else {str(n):0. for n in RESERVE_NUMS}})
    # Allocate drawdown between UO and active at CONTRACT+CCY granularity,
    # even if UO has no tranche and the active part has multiple tranches.
    groups=defaultdict(list)
    for position in result:
        if position['segment']=='ЮЛ и ИП' and position['crm'] not in changed_stage:
            groups[(position['crm'],position['contract'],position['currency'])].append(position)
    for items in groups.values():
        active0=sum(x['active0'] for x in items);active1=sum(x['active1'] for x in items)
        uo0=sum(x['uo0'] for x in items);uo1=sum(x['uo1'] for x in items)
        da=active1-active0;du=uo1-uo0
        if not ((da>0 and du<0) or (da<0 and du>0)):continue
        moved=min(abs(da),abs(du))
        if moved<=0:continue
        old_rows=[bmap.get(tuple(x['key'].split('|'))) for x in items]
        old_rows=[x for x in old_rows if x is not None]
        a0=sum(x['active'] for x in old_rows);u0=sum(x['uo'] for x in old_rows)
        a_res=sum(max(0.,x['el']-x['uo_reserve']-x['off_reserve']) for x in old_rows)
        u_res=sum(x['uo_reserve'] for x in old_rows)
        kavg=(sum(x['el'] for x in old_rows)/sum(x['ead'] for x in old_rows)) if sum(x['ead'] for x in old_rows)>0 else 0.
        ka=a_res/a0 if a0>0 else kavg
        ku=u_res/u0 if u0>0 else kavg
        draw_effect=moved*(ku-ka)*(1 if da>0 else -1)
        # A contract may include a newly issued tranche. Treat transfer as its own factor,
        # offsetting it against volume/new issuance to avoid double counting.
        target=next((x for x in items if x['factors']['Изменение EAD']!=0),items[0])
        target['factors']['Выборка (УО ↔ актив)']+=draw_effect
        offset='Изменение EAD' if target['factors']['Изменение EAD']!=0 else (
            'Новые договоры и транши' if target['factors']['Новые договоры и транши']!=0 else 'Прочие')
        target['factors'][offset]-=draw_effect
    # Stage-sum is distributed over individual positions above; exact across client.
    sums={t:{'el0':0.,'el1':0.,'ead0':0.,'ead1':0.,'expenses':0.,'count':0} for t in ('ЮЛ и ИП','Физические лица','Банки')}
    for r in result:
        g=sums[r['segment']];g['el0']+=r['el0'];g['el1']+=r['el1'];g['ead0']+=r['ead0'];g['ead1']+=r['ead1'];g['expenses']+=r['expenses'];g['count']+=1
    overall={k:sum(v[k] for v in sums.values()) for k in ('el0','el1','ead0','ead1','expenses')}
    factor_total={factor:sum(r['factors'][factor] for r in result) for factor in FACTORS}
    segment_factors={segment:{k:sum(r['factors'][k] for r in result if r['segment']==segment) for k in FACTORS} for segment in sums}
    # FL subportfolio migrations recorded as cross-subportfolio old->new shift. No individual FL reported to browser.
    fl_sub=defaultdict(lambda:{'el0':0.,'el1':0.,'expenses':0.})
    bank_clients=defaultdict(lambda:{'el0':0.,'el1':0.,'expenses':0.,'client':'','crm':''})
    migrations=[]
    for r in result:
        if r['segment']=='Физические лица':
            if r['el0']:fl_sub[r['subportfolio0']]['el0']+=r['el0'];fl_sub[r['subportfolio0']]['expenses']+=r['el0']
            if r['el1']:fl_sub[r['subportfolio1']]['el1']+=r['el1'];fl_sub[r['subportfolio1']]['expenses']-=r['el1']
            if r['subportfolio0'] and r['subportfolio1'] and r['subportfolio0']!=r['subportfolio1']:
                migrations.append({'old':r['subportfolio0'],'new':r['subportfolio1'],'el0':r['el0'],'el1':r['el1']})
        elif r['segment']=='Банки':
            k=r['crm'];b=bank_clients[k];b['crm']=k;b['client']=r['client'];b['el0']+=r['el0'];b['el1']+=r['el1'];b['expenses']+=r['expenses']
    significant=sorted([dict(crm=k,**v) for k,v in client_stats.items() if v['segment']=='ЮЛ и ИП' and abs(v['expenses'])>=100000],key=lambda r:-abs(r['expenses']))
    clients=sorted([dict(crm=k,**v) for k,v in client_stats.items() if v['segment']=='ЮЛ и ИП'],key=lambda r:-abs(r['expenses']))
    for obj in significant:
        crm=obj['crm']; events=[]
        if crm in changed_stage:events.append(f'изменение стадии {stage0[crm]}→{stage1[crm]}')
        if crm in rating0 and crm in rating1 and rating0[crm]!=rating1[crm]:events.append(f'рейтинг {rating0[crm]:g}→{rating1[crm]:g}')
        positions=[r for r in result if r['crm']==crm]
        if any(r['factors']['Выборка (УО ↔ актив)'] for r in positions):events.append('выборка УО ↔ актив')
        if any(r['factors']['Новые договоры и транши'] for r in positions):events.append('новые позиции')
        if any(r['factors']['Валютный эффект'] for r in positions):events.append('валютный эффект')
        obj['comment']='Расходы на резервы: '+f"{obj['expenses']:,.2f}"+' BYN. '+('; '.join(events) if events else 'Изменение задолженности / ставки резервирования')+'.'
    rating_expenses={r['crm']:r['expenses'] for r in clients}
    for e in rating_events:e['expenses']=rating_expenses.get(e['crm'],0.)
    controls={'reconciliation':overall['expenses']-sum(factor_total.values()),
       'segment_reconciliation':overall['expenses']-sum(v['expenses'] for v in sums.values()),
       'positions':len(result),'base_rows':base['count'],'current_rows':current['count'],
       'warnings':base['warnings']+current['warnings']+bwarn+cwarn}
    return {'base_date':base['date'],'current_date':current['date'],'totals':overall,'segments':sums,
      'factors':factor_total,'segment_factors':segment_factors,'positions':result,'clients':clients,'significant':significant,
      'ratings':rating_events,'fl_subportfolios':[{'subportfolio':k,**v} for k,v in sorted(fl_sub.items())],
      'fl_migrations':migrations,'banks':sorted(bank_clients.values(),key=lambda x:-abs(x['expenses'])),
      'controls':controls,'method_note':'Фактор стадии — вся ΔEL клиента; PD/LGD — модельные оценки, остаток в «Прочие». Рейтинг — аналитическое событие, не дополнительный денежный фактор.'}
