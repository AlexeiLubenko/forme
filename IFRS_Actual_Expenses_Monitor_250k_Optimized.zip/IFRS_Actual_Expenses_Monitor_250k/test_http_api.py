"""Isolated end-to-end upload tests; writes only to a temporary storage folder."""
import json, tempfile, threading, unittest
from pathlib import Path
from urllib.request import Request,urlopen
from http.server import ThreadingHTTPServer
import server
ROOT=Path(__file__).parent

class ApiTests(unittest.TestCase):
    def test_full_upload_and_versioning(self):
        with tempfile.TemporaryDirectory() as tmp:
            orig=(server.STORAGE,server.DB,server.BASE_PATH)
            server.STORAGE=Path(tmp);server.DB=Path(tmp)/'reports.sqlite3';server.BASE_PATH=Path(tmp)/'base_snapshot.xlsx'
            http=ThreadingHTTPServer(('127.0.0.1',0),server.Handler)
            thread=threading.Thread(target=http.serve_forever,daemon=True);thread.start()
            url=f'http://127.0.0.1:{http.server_address[1]}'
            def upload(path,file):
                boundary='----IFRS_TEST_abc'
                body=(f'--{boundary}\r\nContent-Disposition: form-data; name="file"; filename="{file.name}"\r\nContent-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet\r\n\r\n').encode()+file.read_bytes()+f'\r\n--{boundary}--\r\n'.encode()
                req=Request(url+path,body,{'Content-Type':f'multipart/form-data; boundary={boundary}'},method='POST')
                return json.load(urlopen(req))
            try:
                b=ROOT/'examples/01_fact_base_2026-10-30.xlsx';c=ROOT/'examples/02_fact_current_2026-11-05.xlsx'
                z=upload('/api/base',b);self.assertEqual(z['rows'],10)
                a=upload('/api/run',c);d=upload('/api/run',c)
                self.assertNotEqual(a['report_id'],d['report_id'])
                s=json.load(urlopen(url+'/api/state'))
                self.assertEqual(len(s['archive']['reports']),2)
                self.assertTrue((Path(tmp)/'base_snapshot.xlsx').exists())
                self.assertEqual(len(list(Path(tmp).glob('*.xlsx'))),1,'Daily current Excel must never be saved')
                with urlopen(url+f'/api/export/report.xlsx?id={a["report_id"]}') as f:self.assertTrue(f.read(2)==b'PK')
                try:
                    with urlopen(url+f'/api/export/report.pdf?id={a["report_id"]}') as f:self.assertTrue(f.read(4)==b'%PDF')
                except Exception as error:
                    if '400' not in str(error):raise
            finally:
                http.shutdown();http.server_close();server.STORAGE,server.DB,server.BASE_PATH=orig
if __name__=='__main__':unittest.main()
