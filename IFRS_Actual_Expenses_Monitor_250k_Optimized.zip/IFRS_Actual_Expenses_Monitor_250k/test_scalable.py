"""Validate the bounded-memory path and the actual browser raw-file upload protocol."""
import json, tempfile, threading, unittest
from http.server import ThreadingHTTPServer
from pathlib import Path
from urllib.request import Request,urlopen
import server
from core import parse_excel,summarize_pair
from openpyxl import load_workbook

ROOT=Path(__file__).parent

class ScalableTests(unittest.TestCase):
    def test_streaming_pipeline_matches_original_engine(self):
        a=ROOT/'examples'/'01_fact_base_2026-10-30.xlsx'
        b=ROOT/'examples'/'02_fact_current_2026-11-05.xlsx'
        expected=summarize_pair(parse_excel(a.read_bytes(),a.name),parse_excel(b.read_bytes(),b.name))
        with tempfile.TemporaryDirectory() as tmp:
            prev=server.DB,server.STORAGE,server.BASE_PATH
            server.STORAGE=Path(tmp)
            server.DB=Path(tmp)/'test.sqlite3'
            server.BASE_PATH=Path(tmp)/'base_snapshot.xlsx'
            try:
                base=server.save_base(a,a.name)
                self.assertEqual(base['rows'],10)
                one=server.save_run(b,b.name)
                two=server.save_run(b,b.name)
                self.assertNotEqual(one['report_id'],two['report_id'])
                r=server.read_report(one['report_id'])
                self.assertTrue(r['scalable'])
                self.assertEqual(r['controls']['positions'],len(expected['positions']))
                for f in expected['factors']:
                    self.assertAlmostEqual(r['factors'][f],expected['factors'][f],places=5)
                self.assertAlmostEqual(r['totals']['expenses'],expected['totals']['expenses'],places=5)
                self.assertAlmostEqual(r['controls']['reconciliation'],0.,places=5)
                # The daily work file is not copied to long-lived storage.
                self.assertEqual({f.name for f in Path(tmp).glob('*.xlsx')},{'base_snapshot.xlsx'})
                self.assertEqual(server.get_positions(r,'ЮЛ и ИП','',1,10)['limit'],10)
                self.assertEqual(server.get_significant(r,1,10)['total'],len(expected['significant']))
                export=Path(tmp)/'report.xlsx'
                from large_export import export_to_path
                export_to_path(r,server.DB,export)
                self.assertIn('Компоненты_резервов',load_workbook(export,read_only=True).sheetnames)
            finally:server.DB,server.STORAGE,server.BASE_PATH=prev

    def test_raw_http_file_upload(self):
        with tempfile.TemporaryDirectory() as tmp:
            prev=server.DB,server.STORAGE,server.BASE_PATH
            server.STORAGE=Path(tmp);server.DB=Path(tmp)/'test.sqlite3';server.BASE_PATH=Path(tmp)/'base_snapshot.xlsx'
            http=ThreadingHTTPServer(('127.0.0.1',0),server.Handler)
            thread=threading.Thread(target=http.serve_forever,daemon=True);thread.start()
            url=f'http://127.0.0.1:{http.server_address[1]}'
            def upload(endpoint,filename):
                path=ROOT/'examples'/filename
                req=Request(url+endpoint,path.read_bytes(),headers={'Content-Type':'application/octet-stream','X-Filename':filename},method='POST')
                return json.load(urlopen(req))
            try:
                upload('/api/base','01_fact_base_2026-10-30.xlsx')
                response=upload('/api/run','02_fact_current_2026-11-05.xlsx')
                rid=response['report_id']
                details=json.load(urlopen(url+f'/api/positions?id={rid}&page=1&limit=10'))
                self.assertGreater(details['total'],0)
                banks=json.load(urlopen(url+f'/api/banks?id={rid}&page=1&limit=50'))
                self.assertGreater(banks['total'],0)
                sig=json.load(urlopen(url+f'/api/significant?id={rid}'))
                self.assertGreaterEqual(sig['total'],0)
                with urlopen(url+f'/api/export/report.xlsx?id={rid}') as f:
                    self.assertEqual(f.read(2),b'PK')
                self.assertEqual({f.name for f in Path(tmp).glob('*.xlsx')},{'base_snapshot.xlsx'})
            finally:
                http.shutdown();http.server_close();server.DB,server.STORAGE,server.BASE_PATH=prev

if __name__=='__main__':unittest.main()
