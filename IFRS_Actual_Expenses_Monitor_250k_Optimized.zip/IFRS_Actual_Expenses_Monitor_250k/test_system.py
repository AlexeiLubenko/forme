import unittest
from pathlib import Path
from core import parse_excel,summarize_pair
ROOT=Path(__file__).parent

def fixtures():
    a=parse_excel((ROOT/'examples/01_fact_base_2026-10-30.xlsx').read_bytes(),'base.xlsx')
    b=parse_excel((ROOT/'examples/02_fact_current_2026-11-05.xlsx').read_bytes(),'current.xlsx')
    return a,b

class Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.base,cls.current=fixtures();cls.r=summarize_pair(cls.base,cls.current)
    def test_dates(self):self.assertEqual((self.r['base_date'],self.r['current_date']),('2026-10-30','2026-11-05'))
    def test_el_definition(self):self.assertAlmostEqual(self.r['totals']['expenses'],self.r['totals']['el0']-self.r['totals']['el1'])
    def test_factors_reconcile(self):self.assertAlmostEqual(self.r['controls']['reconciliation'],0,places=6)
    def test_segment_reconcile(self):self.assertAlmostEqual(self.r['controls']['segment_reconciliation'],0,places=6)
    def test_categories(self):self.assertEqual(set(self.r['segments']),{'ЮЛ и ИП','Физические лица','Банки'})
    def test_client_stage_priority(self):
        positions=self.r['positions'];crms={r['crm'] for r in positions if r['factors']['Изменение стадии']!=0}
        for crm in crms:
            for row in positions:
                if row['crm']==crm and row['segment']=='ЮЛ и ИП':
                    self.assertAlmostEqual(row['expenses'],row['factors']['Изменение стадии'])
                    self.assertAlmostEqual(sum(v for k,v in row['factors'].items() if k!='Изменение стадии'),0)
    def test_significant(self):self.assertTrue(all(abs(x['expenses'])>=100000 for x in self.r['significant']))
    def test_positions_no_double_count(self):self.assertAlmostEqual(sum(p['expenses'] for p in self.r['positions']),self.r['totals']['expenses'])
    def test_currency_sign(self):
        for p in self.r['positions']:
            if p['currency']=='BYN':self.assertEqual(p['factors']['Валютный эффект'],0)
    def test_reserve_components(self):
        for p in self.r['positions']:
            self.assertAlmostEqual(sum(p['reserve_changes'].values()),p['expenses'],places=2)
    def test_contract_level_drawdown_across_tranche_rows(self):
        from copy import deepcopy
        from core import summarize_pair
        sample=deepcopy(self.base['rows'][0])
        def row(day,tranche,active,uo,rate):
            x=deepcopy(sample);x.update(date=day,status='ю',crm='9876',client='ООО Тест',
             contract='ДОГ-1',tranche=tranche,currency='BYN',fx=1.0,stage=1,
             active=active,uo=uo,off=0.,ead=active+uo,rate=rate,
             el=active*.05+uo*.02,uo_reserve=uo*.02,off_reserve=0.)
            return x
        old=[row('2026-10-30','ДОГ-1_1',2_000_000,0,.05),row('2026-10-30','',0,8_000_000,.02)]
        new=[row('2026-11-05','ДОГ-1_1',5_000_000,0,.05),row('2026-11-05','',0,5_000_000,.02)]
        a={'rows':old,'date':'2026-10-30','count':2,'warnings':[]}
        b={'rows':new,'date':'2026-11-05','count':2,'warnings':[]}
        out=summarize_pair(a,b)
        self.assertAlmostEqual(out['totals']['expenses'],-90_000)
        self.assertAlmostEqual(out['factors']['Выборка (УО ↔ актив)'],-90_000)
        self.assertAlmostEqual(out['factors']['Изменение EAD'],0)
        self.assertAlmostEqual(out['controls']['reconciliation'],0)
    def test_factors_fl_component_subportfolios_reconcile(self):
        from reports import excel_report
        from io import BytesIO
        from openpyxl import load_workbook
        r=dict(self.r,id=1,source_filename='demo.xlsx')
        w=load_workbook(BytesIO(excel_report(r)),read_only=True,data_only=True)
        rows=list(w['Факторы_ФЛ'].values)
        for row in rows[1:]:
            self.assertAlmostEqual(row[1],sum(v or 0 for v in row[2:]),places=2)
    def test_excel_export(self):
        from reports import excel_report
        r=dict(self.r,id=1,source_filename='demo.xlsx')
        payload=excel_report(r)
        self.assertTrue(payload.startswith(b'PK'))
        from openpyxl import load_workbook
        from io import BytesIO
        wb=load_workbook(BytesIO(payload),read_only=True)
        self.assertIn('Факторы_ЮЛ_ИП',wb.sheetnames)
    def test_pdf_export(self):
        from reports import pdf_report
        r=dict(self.r,id=1,source_filename='demo.xlsx')
        try: payload=pdf_report(r)
        except ValueError as e:
            if 'reportlab' in str(e).lower():self.skipTest('Server-side PDF optional: browser Print→PDF fallback')
            raise
        self.assertTrue(payload.startswith(b'%PDF'))
if __name__=='__main__':unittest.main()
