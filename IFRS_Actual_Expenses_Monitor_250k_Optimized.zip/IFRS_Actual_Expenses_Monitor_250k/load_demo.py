"""Load provided dummy facts. Idempotent for pristine installs."""
from pathlib import Path
from server import archive,save_base,save_run
ROOT=Path(__file__).parent
if archive()['reports']:
    print('Сохранённые расчёты уже существуют. Демо-данные повторно не загружаются.')
else:
    b=ROOT/'examples/01_fact_base_2026-10-30.xlsx'
    c=ROOT/'examples/02_fact_current_2026-11-05.xlsx'
    print('База:',save_base(b.read_bytes(),b.name))
    print('Расчёт:',save_run(c.read_bytes(),c.name))
