"""Desktop launcher for the offline bank-portfolio dashboard (Tkinter, stdlib).

There is no localhost, Streamlit, Flask, network, npm or pip dependency.
"""
from __future__ import annotations

from datetime import date
from pathlib import Path
import sys
import traceback

try:
    import tkinter as tk
    from tkinter import filedialog, messagebox, ttk
except ImportError:
    print('Tkinter в текущем Python недоступен. Используйте Jupyter Notebook или offline_cli.py.')
    sys.exit(2)

from offline_service import OfflinePortfolioService, fmt, open_report
from portfolio_core import sheet_names
from portfolio_schema import CATEGORY_COLUMNS, NUMERIC_COLUMNS

BG = '#f4f7fb'
INK = '#16375a'
SUB = '#5b6d83'


class PortfolioWindow(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title('Портфель и резервы · офлайн')
        self.geometry('1200x770')
        self.minsize(990,650)
        self.service=OfflinePortfolioService()
        self.file=tk.StringVar()
        self.report_date=tk.StringVar(value=date.today().isoformat())
        self.sheet=tk.StringVar(value='')
        self.header_row=tk.StringVar(value='1')
        self.note=tk.StringVar(value='')
        self.date_before=tk.StringVar()
        self.date_after=tk.StringVar()
        self.selected_portfolio=tk.StringVar()
        self.search_text=tk.StringVar()
        self.segment=tk.StringVar()
        self.slice_dimension=tk.StringVar(value='Сегмент')
        self.slice_metric=tk.StringVar(value='Резерв факт')
        self.slice_agg=tk.StringVar(value='Сумма')
        self.status=tk.StringVar(value='Готово. Данные не передаются по сети.')
        self._style()
        self._layout()
        self.refresh()

    def _style(self):
        self.configure(bg=BG)
        s=ttk.Style(self)
        if 'clam' in s.theme_names(): s.theme_use('clam')
        s.configure('TFrame',background=BG)
        s.configure('White.TFrame', background='white')
        s.configure('TLabel',background=BG,foreground=INK,font=('Segoe UI',10))
        s.configure('Muted.TLabel',background=BG,foreground=SUB,font=('Segoe UI',9))
        s.configure('Title.TLabel',background=BG,foreground=INK,font=('Segoe UI',21,'bold'))
        s.configure('TNotebook',background=BG,borderwidth=0)
        s.configure('TNotebook.Tab',padding=(15,12),font=('Segoe UI',10,'bold'))
        s.configure('Accent.TButton',padding=(13,10),font=('Segoe UI',10,'bold'),background=INK,foreground='white')
        s.configure('TButton',padding=(10,8))
        s.configure('Treeview',rowheight=31,font=('Segoe UI',9),background='white',fieldbackground='white')
        s.configure('Treeview.Heading',font=('Segoe UI',9,'bold'))

    def _label(self,parent,text,row,col=0,span=1,pady=4,style='TLabel'):
        v=ttk.Label(parent,text=text,style=style)
        v.grid(row=row,column=col,columnspan=span,sticky='w',padx=7,pady=pady)
        return v

    def _layout(self):
        wrapper=ttk.Frame(self,padding=(22,18))
        wrapper.pack(fill='both',expand=True)
        ttk.Label(wrapper,text='Портфель и резервы',style='Title.TLabel').pack(anchor='w')
        ttk.Label(wrapper,text='Локальная работа · снимки по датам · сравнение резервов · без Streamlit и localhost',style='Muted.TLabel').pack(anchor='w',pady=(0,15))
        tabs=ttk.Notebook(wrapper)
        tabs.pack(fill='both',expand=True)
        self.tabs=tabs
        for title,fn in [('Портфели по датам',self._snapshots_tab),('Расходы на резервы',self._reserve_tab),
                         ('Таблица портфеля',self._portfolio_tab),('Срезы и качество',self._slices_tab),('Инструкция',self._help_tab)]:
            pane=ttk.Frame(tabs,padding=15)
            tabs.add(pane,text=title)
            fn(pane)
        ttk.Label(wrapper,textvariable=self.status,style='Muted.TLabel').pack(fill='x',pady=(12,0))

    def _snapshots_tab(self,p):
        self._label(p,'Загрузка нового портфеля',0,0,span=5)
        ttk.Entry(p,textvariable=self.file,width=84).grid(row=1,column=0,columnspan=4,padx=7,pady=6,sticky='we')
        ttk.Button(p,text='Выбрать Excel / CSV',command=self._browse).grid(row=1,column=4,padx=7)
        self._label(p,'Отчётная дата (ГГГГ-ММ-ДД)',2,0)
        self._label(p,'Лист Excel',2,1)
        self._label(p,'Строка заголовка',2,2)
        ttk.Entry(p,textvariable=self.report_date,width=22).grid(row=3,column=0,padx=7,sticky='we')
        self.sheet_box=ttk.Combobox(p,textvariable=self.sheet,width=27,state='readonly')
        self.sheet_box.grid(row=3,column=1,padx=7,sticky='we')
        ttk.Entry(p,textvariable=self.header_row,width=14).grid(row=3,column=2,padx=7,sticky='we')
        ttk.Button(p,text='Сохранить снимок',style='Accent.TButton',command=self._save).grid(row=3,column=4,padx=7,sticky='we')
        self._label(p,'Комментарий (необязательно)',4,0,span=2)
        ttk.Entry(p,textvariable=self.note).grid(row=5,column=0,columnspan=5,sticky='we',padx=7)
        self._label(p,'Сохранённые даты (файлы не перезаписываются)',6,0,span=5,pady=15)
        cols=('Дата','Название','Строк','Резерв, тыс. BYN','Задолженность, тыс. BYN','ID')
        self.snapshot_tree=ttk.Treeview(p,columns=cols,show='headings',height=11)
        for col,width in zip(cols,[130,270,90,160,180,60]):
            self.snapshot_tree.heading(col,text=col)
            self.snapshot_tree.column(col,width=width,stretch=col in ('Название',))
        self.snapshot_tree.grid(row=7,column=0,columnspan=5,sticky='nsew',padx=7,pady=3)
        sb=ttk.Scrollbar(p,orient='vertical',command=self.snapshot_tree.yview)
        sb.grid(row=7,column=5,sticky='ns')
        self.snapshot_tree.configure(yscrollcommand=sb.set)
        footer=ttk.Frame(p)
        footer.grid(row=8,column=0,columnspan=5,sticky='w',pady=(8,0))
        ttk.Button(footer,text='Просмотреть выбранный',command=self._view_selected).pack(side='left',padx=5)
        ttk.Button(footer,text='Назначить дату старому снимку',command=self._assign_date).pack(side='left',padx=5)
        ttk.Button(footer,text='Обновить список',command=self.refresh).pack(side='left',padx=5)
        p.columnconfigure(0,weight=3);p.columnconfigure(1,weight=2);p.columnconfigure(3,weight=1)
        p.rowconfigure(7,weight=1)

    def _reserve_tab(self,p):
        self._label(p,'Сравнение двух отчётных дат',0,0,span=4)
        self._label(p,'Начальная дата',1,0)
        self._label(p,'Конечная дата',1,1)
        self.before_box=ttk.Combobox(p,textvariable=self.date_before,state='readonly',width=28)
        self.after_box=ttk.Combobox(p,textvariable=self.date_after,state='readonly',width=28)
        self.before_box.grid(row=2,column=0,padx=7,sticky='we')
        self.after_box.grid(row=2,column=1,padx=7,sticky='we')
        ttk.Button(p,text='Рассчитать и открыть отчёт',style='Accent.TButton',command=self._compare).grid(row=2,column=2,padx=9)
        explanation=('Основной показатель — изменение поля «Резерв факт» в тыс. BYN. '
          'Сопоставление по УНП и номеру договора. Существенные клиенты: Δ ≤ −100 или Δ ≥ +100 тыс. BYN. '
          'Для остальных УНП выводится одна сумма. Комментарии описывают обнаруженные события, а не доказанную причину бухгалтерских проводок.')
        ttk.Label(p,text=explanation,wraplength=980,justify='left').grid(row=3,column=0,columnspan=4,sticky='we',padx=7,pady=15)
        self.report_status=tk.StringVar(value='Выбери две даты и нажми «Рассчитать».')
        ttk.Label(p,textvariable=self.report_status,wraplength=980,justify='left',font=('Segoe UI',11,'bold')).grid(row=4,column=0,columnspan=4,sticky='we',padx=7,pady=8)
        helptext=('В браузере откроется сохранённый HTML-файл с:\n'
                '• карточками результатов и факторным мостом;\n'
                '• перечнем существенных клиентов и комментариями;\n'
                '• поконтрактной расшифровкой;\n'
                '• поиском и сортировкой таблиц.\n\n'
                'Полные таблицы сохраняются в папку reports в формате CSV, пригодном для Excel.\n'
                'Браузер может работать без интернета: Plotly включён прямо в HTML.')
        ttk.Label(p,text=helptext,justify='left',font=('Segoe UI',10)).grid(row=5,column=0,columnspan=4,sticky='nw',padx=7,pady=12)
        p.columnconfigure(0,weight=1);p.columnconfigure(1,weight=1)

    def _portfolio_tab(self,p):
        self._label(p,'Просмотр портфеля',0,0,span=4)
        self._label(p,'Отчётная дата',1,0)
        self._label(p,'Поиск по УНП, клиенту, договору',1,1)
        self._label(p,'Сегмент (необязательно)',1,2)
        self.portfolio_box=ttk.Combobox(p,textvariable=self.selected_portfolio,state='readonly',width=21)
        self.portfolio_box.grid(row=2,column=0,padx=7,sticky='we')
        ttk.Entry(p,textvariable=self.search_text,width=35).grid(row=2,column=1,padx=7,sticky='we')
        ttk.Entry(p,textvariable=self.segment,width=24).grid(row=2,column=2,padx=7,sticky='we')
        ttk.Button(p,text='Открыть таблицу',style='Accent.TButton',command=self._portfolio_report).grid(row=2,column=3,padx=7,sticky='we')
        ttk.Label(p,text='В HTML показывается до 2500 строк для быстрого просмотра; полный CSV экспортируется автоматически.',
                  wraplength=900).grid(row=3,column=0,columnspan=4,sticky='w',padx=7,pady=20)
        p.columnconfigure(1,weight=2);p.columnconfigure(2,weight=1)

    def _slices_tab(self,p):
        self._label(p,'Срезы и качество данных',0,0,span=4)
        self._label(p,'Отчётная дата',1,0)
        self._label(p,'Группировка',1,1)
        self._label(p,'Показатель',1,2)
        self._label(p,'Функция',1,3)
        self.slice_portfolio=tk.StringVar()
        self.slice_box=ttk.Combobox(p,textvariable=self.slice_portfolio,state='readonly',width=19)
        self.slice_box.grid(row=2,column=0,padx=7,sticky='we')
        ttk.Combobox(p,textvariable=self.slice_dimension,values=list(CATEGORY_COLUMNS),width=28,state='readonly').grid(row=2,column=1,padx=7,sticky='we')
        ttk.Combobox(p,textvariable=self.slice_metric,values=list(NUMERIC_COLUMNS),width=30,state='readonly').grid(row=2,column=2,padx=7,sticky='we')
        ttk.Combobox(p,textvariable=self.slice_agg,values=['Сумма','Среднее','Медиана','Количество','Минимум','Максимум'],width=18,state='readonly').grid(row=2,column=3,padx=7,sticky='we')
        ttk.Button(p,text='Построить срез',style='Accent.TButton',command=self._slice).grid(row=3,column=0,padx=7,pady=12,sticky='we')
        ttk.Button(p,text='Проверить качество',command=self._quality).grid(row=3,column=1,padx=7,pady=12,sticky='w')
        ttk.Label(p,text='Доступны все категориальные и числовые поля исходной фиксированной структуры. Срез сохраняется в HTML и CSV.',
                  wraplength=970).grid(row=4,column=0,columnspan=4,sticky='w',padx=7,pady=20)
        p.columnconfigure(1,weight=2);p.columnconfigure(2,weight=2)

    def _help_tab(self,p):
        text=(
           '1. Перейди в «Портфели по датам» и выбери .xlsx, .xlsm или .csv. Укажи дату YYYY-MM-DD.\n'
           '2. Сохрани первый и второй снимки. На одну дату можно сохранить только один портфель.\n'
           '3. Открой «Расходы на резервы», выбери начальную и конечную дату, нажми «Рассчитать».\n'
           '4. Откроется локальный HTML-отчёт. В нём работают поиск и сортировка таблиц без сети.\n'
           '5. В папке reports будут CSV с существенными клиентами, остальными, факторами и договорами.\n'
           '6. Во вкладке «Таблица портфеля» можно посмотреть и найти договоры, а в «Срезы» — построить группировки.\n\n'
           'Исходные файлы лежат в portfolio_storage/blobs и не изменяются.\n'
           'Если переносишь данные из v9.7, скопируй её папку portfolio_storage сюда ДО первого запуска.\n\n'
           'Важное ограничение: портфели по датам — неизменяемые снимки. Никаких новых пакетов не нужно.\n'
           'Если в этом Python отсутствует Tkinter, используй offline_cli.py или Jupyter Notebook.\n'
           'Доступ к localhost и открытие портов не требуются.')
        widget=tk.Text(p,wrap='word',font=('Segoe UI',11),background='white',foreground=INK,relief='flat',padx=20,pady=20)
        widget.insert('1.0',text)
        widget.configure(state='disabled')
        widget.pack(fill='both',expand=True)

    def _browse(self):
        file=filedialog.askopenfilename(title='Выбери портфель',filetypes=[('Excel / CSV','*.xlsx *.xlsm *.csv'),('Все файлы','*.*')])
        if file:
            self.file.set(file)
            try:
                sheets=sheet_names(Path(file).read_bytes(),Path(file).name)
                self.sheet_box['values']=sheets
                self.sheet.set(sheets[0])
            except Exception as exc:
                messagebox.showerror('Не удалось открыть файл',str(exc))

    def _save(self):
        def action():
            vid=self.service.add_file(self.file.get(),self.report_date.get(),sheet=self.sheet.get() or None,
                                      header_row=int(self.header_row.get()),note=self.note.get())
            self.refresh()
            return f'Снимок #{vid} на {self.report_date.get()} сохранён.'
        self._handle(action)

    def _get_selected_id(self):
        selected=self.snapshot_tree.selection()
        if not selected:
            raise ValueError('Сначала выдели строку снимка.')
        return int(self.snapshot_tree.item(selected[0],'values')[-1])

    def _view_selected(self):
        def action():
            r=self.service.portfolio_report('#'+str(self._get_selected_id()))
            open_report(r['html'])
            return f'Отчёт: {r["html"]}'
        self._handle(action)

    def _assign_date(self):
        from tkinter.simpledialog import askstring
        try:
            vid=self._get_selected_id()
            chosen=askstring('Отчётная дата','Укажи дату YYYY-MM-DD для выбранного снимка:',parent=self)
            if chosen:
                self.service.store.set_report_date(vid,chosen)
                self.refresh()
        except Exception as exc:
            messagebox.showerror('Ошибка',str(exc))

    def _compare(self):
        def action():
            self.report_status.set('Формирование отчёта...')
            self.update_idletasks()
            result=self.service.compare(self.date_before.get(),self.date_after.get())
            r=result['analysis']; m=result['material']
            self.report_status.set(f'Изменение резерва {fmt(r.delta)} тыс. BYN; существенных клиентов {len(m.material)}; остальных {m.other_clients_count}, сумма {fmt(m.other_clients_delta)} тыс. BYN.')
            open_report(result['html'])
            return f'Отчёт: {result["html"]}. Все выгрузки — в папке reports.'
        self._handle(action)

    def _portfolio_report(self):
        def action():
            result=self.service.portfolio_report(self.selected_portfolio.get(),self.search_text.get(),self.segment.get())
            open_report(result['html'])
            return f'Найдено {result["rows"]} строк. CSV: {result["csv"]}'
        self._handle(action)

    def _slice(self):
        def action():
            r=self.service.slice_report(self.slice_portfolio.get(),self.slice_dimension.get(),self.slice_metric.get(),self.slice_agg.get())
            open_report(r['html'])
            return f'Срез сохранён: {r["html"]}'
        self._handle(action)

    def _quality(self):
        def action():
            r=self.service.quality_report(self.slice_portfolio.get())
            open_report(r['html'])
            return f'Отчёт о качестве: {r["html"]}'
        self._handle(action)

    def _handle(self,callback):
        try:
            self.configure(cursor='watch'); self.update_idletasks()
            self.status.set(callback())
        except Exception as exc:
            self.status.set('Ошибка: '+str(exc))
            messagebox.showerror('Не удалось выполнить действие',str(exc))
        finally:
            self.configure(cursor='')

    def refresh(self):
        records=self.service.snapshot_list()
        self.snapshot_tree.delete(*self.snapshot_tree.get_children())
        for m in records:
            self.snapshot_tree.insert('', 'end', values=(m.get('report_date') or '(без даты)',m['title'],m['rows_count'],
                fmt(m.get('reserve_total')) if m.get('reserve_total') is not None else '—',
                fmt(m.get('debt_total')) if m.get('debt_total') is not None else '—',m['id']))
        dates=sorted([m['report_date'] for m in records if m.get('report_date')])
        for box in [self.before_box,self.after_box,self.portfolio_box,self.slice_box]:box['values']=dates
        if dates:
            if self.date_before.get() not in dates:self.date_before.set(dates[0])
            if self.date_after.get() not in dates:self.date_after.set(dates[-1])
            if self.selected_portfolio.get() not in dates:self.selected_portfolio.set(dates[-1])
            if self.slice_portfolio.get() not in dates:self.slice_portfolio.set(dates[-1])
        self.status.set(f'Загружено снимков: {len(records)}. Сервер не требуется.')


if __name__=='__main__':
    try:
        app=PortfolioWindow()
        app.mainloop()
    except tk.TclError as exc:
        print('Не удалось создать графическое окно Tkinter:',exc)
        print('Для работы из Jupyter используйте portfolio_dashboard.ipynb.')
        sys.exit(2)
