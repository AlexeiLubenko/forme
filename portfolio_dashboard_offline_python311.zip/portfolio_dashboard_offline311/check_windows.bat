@echo off
setlocal
chcp 65001 >nul
pushd "%~dp0" 2>nul
if errorlevel 1 (echo Не удалось открыть папку проекта. & pause & exit /b 1)
python offline_cli.py check
if errorlevel 1 echo Не все необходимые пакеты доступны именно в этом Python.
popd
pause
endlocal
