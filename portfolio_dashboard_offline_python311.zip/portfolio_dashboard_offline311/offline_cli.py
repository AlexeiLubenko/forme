"""Non-GUI fallback. Works without Tkinter/Jupyter and without any server."""
from __future__ import annotations
import argparse
import sys
from offline_service import OfflinePortfolioService, open_report


def main(argv=None):
    p=argparse.ArgumentParser(description='Офлайн-анализ портфелей без Streamlit и localhost')
    sub=p.add_subparsers(dest='cmd',required=True)
    add=sub.add_parser('add',help='Загрузить новый снимок по дате')
    add.add_argument('--file',required=True)
    add.add_argument('--date',required=True)
    add.add_argument('--sheet')
    add.add_argument('--header-row',type=int,default=1)
    sub.add_parser('list',help='Список снимков')
    rep=sub.add_parser('report',help='Сравнить две даты')
    rep.add_argument('--before',required=True)
    rep.add_argument('--after',required=True)
    rep.add_argument('--no-open',action='store_true')
    view=sub.add_parser('view',help='Сформировать таблицу одного снимка')
    view.add_argument('--date',required=True)
    view.add_argument('--search',default='')
    sl=sub.add_parser('slice',help='Срез портфеля')
    sl.add_argument('--date',required=True)
    sl.add_argument('--dimension',default='Сегмент')
    sl.add_argument('--metric',default='Резерв факт')
    sub.add_parser('check',help='Проверить версии библиотек')
    args=p.parse_args(argv)
    svc=OfflinePortfolioService()
    if args.cmd=='check':
        for k,v in svc.verify_environment().items():print(k, v)
    elif args.cmd=='add':
        print('Сохранён снимок №',svc.add_file(args.file,args.date,args.sheet,header_row=args.header_row))
    elif args.cmd=='list':
        for v in svc.snapshot_list():print(f'#{v["id"]} | {v.get("report_date") or "без даты"} | {v["rows_count"]} строк | {v["title"]}')
    elif args.cmd=='report':
        r=svc.compare(args.before,args.after)
        print('Δ резерва, тыс. BYN:',r['analysis'].delta)
        print('Существенных клиентов:',len(r['material'].material),'Остальных:',r['material'].other_clients_count)
        print('Отчёт:',r['html'])
        for k,v in r['exports'].items():print(k,':',v)
        if not args.no_open:open_report(r['html'])
    elif args.cmd=='view':
        r=svc.portfolio_report(args.date,args.search)
        print('Отчёт:',r['html'],'\nCSV:',r['csv'])
    elif args.cmd=='slice':
        r=svc.slice_report(args.date,args.dimension,args.metric)
        print('Отчёт:',r['html'],'\nCSV:',r['csv'])


if __name__=='__main__':
    try:main()
    except Exception as exc:
        print('Ошибка:',exc,file=sys.stderr);sys.exit(1)
