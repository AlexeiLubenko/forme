"""Offline portfolio service: no Streamlit, server, sockets, or package installation.

Uses only Python 3.11 stdlib, pandas/numpy/openpyxl/plotly. All data stays on disk.
"""
from __future__ import annotations

from datetime import date
from html import escape
from pathlib import Path
import webbrowser

import pandas as pd
import plotly.graph_objects as go

from portfolio_core import group_summary, quality_summary, sheet_names
from portfolio_store import PortfolioStore
from reserve_operational_analysis import compare_operational
from material_changes import build_material_client_report

HERE = Path(__file__).resolve().parent
DEFAULT_STORAGE = HERE / 'portfolio_storage'
DEFAULT_REPORTS = HERE / 'reports'
PREVIEW_LIMIT = 2500
TABLE_CSS = r'''<style>
:root{--ink:#15263d;--muted:#67758b;--line:#e6ebf1;--navy:#16375a;--bg:#f4f7fb;--teal:#0f766e}
*{box-sizing:border-box}body{font-family:Arial,'Segoe UI',sans-serif;background:var(--bg);color:var(--ink);margin:0;line-height:1.5}
main{max-width:1400px;margin:0 auto;padding:26px 26px 70px}header{background:#16375a;color:#fff;padding:26px 30px;border-radius:14px;margin-bottom:22px}
header h1{margin:0;font-size:27px}header p{margin:7px 0 0;color:#cad9e8}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:12px;margin-bottom:18px}
.metric{background:#fff;padding:18px;border:1px solid var(--line);border-radius:12px}.metric small{display:block;color:var(--muted);margin-bottom:6px}.metric b{font-size:25px}
section{background:#fff;border:1px solid var(--line);border-radius:12px;padding:21px;margin:18px 0}section h2{font-size:20px;margin:0 0 14px}.note{font-size:13px;color:#52647c}
.negative{color:#ae3240}.positive{color:#176c57}.actions{display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin:12px 0}
input{border:1px solid #c9d3de;border-radius:7px;padding:10px;min-width:250px;font-size:14px}.pill{display:inline-block;background:#eaf2ff;padding:4px 10px;border-radius:100px;font-size:12px;margin:4px 4px 0 0}.download{display:inline-block;background:#16375a;color:white;text-decoration:none;padding:9px 13px;border-radius:7px;font-weight:bold;font-size:13px;margin:5px}.download:hover{background:#285581}
.wrap{overflow:auto;max-height:65vh;border:1px solid var(--line);border-radius:8px}table{border-collapse:collapse;font-size:12.5px;min-width:100%;white-space:nowrap}
thead th{position:sticky;top:0;background:#eaf0f7;z-index:1;text-align:left;cursor:pointer;user-select:none}
th,td{padding:10px 12px;border-bottom:1px solid #e8edf3;vertical-align:top}tbody tr:nth-child(even){background:#fbfcfd}tr[hidden]{display:none!important}tr:hover{background:#eaf5f6}
td.comment{white-space:normal;min-width:400px;max-width:700px}footer{color:var(--muted);font-size:12px;text-align:center;margin-top:20px}
@media(max-width:650px){main{padding:10px}header{border-radius:8px;padding:15px}.metric b{font-size:18px}}
</style>'''
TABLE_JS = r'''<script>
function filterTable(id, inputId){const q=document.getElementById(inputId).value.toLocaleLowerCase('ru');const rows=document.querySelectorAll('#'+id+' tbody tr');let visible=0;rows.forEach(r=>{let ok=r.textContent.toLocaleLowerCase('ru').includes(q);r.hidden=!ok;if(ok)visible++;});const num=document.getElementById(id+'-count');if(num)num.textContent=visible+' строк';}
function sortTable(id,col){const tb=document.querySelector('#'+id+' tbody');const rows=Array.from(tb.querySelectorAll('tr'));const key=id+':'+col;window._sortDir=window._sortDir||{};const dir=window._sortDir[key]===1?-1:1;window._sortDir[key]=dir;
const num=s=>{const t=s.replace(/\s/g,'').replace(',','.');return /^[-+]?\d+(\.\d+)?$/.test(t)?Number(t):null};
rows.sort((a,b)=>{let x=a.children[col].textContent.trim(), y=b.children[col].textContent.trim();let nx=num(x),ny=num(y);let v=nx!==null&&ny!==null?nx-ny:x.localeCompare(y,'ru',{numeric:true});return dir*v;});rows.forEach(r=>tb.appendChild(r));}
</script>'''


def _plain(v):
    if pd.isna(v):
        return ''
    if isinstance(v, pd.Timestamp):
        return v.strftime('%d.%m.%Y')
    if isinstance(v, float):
        return ('%.2f' % v).replace('.', ',')
    return str(v)


def fmt(v, decimals=2):
    try:
        return f'{float(v):,.{decimals}f}'.replace(',', ' ').replace('.', ',')
    except (ValueError, TypeError):
        return str(v)


def _table(df: pd.DataFrame, table_id: str, limit: int = PREVIEW_LIMIT, emphasis=None) -> str:
    if df is None or df.empty:
        return '<p class="note">Нет строк для отображения.</p>'
    visible = df.head(limit)
    heads = ''.join(f'<th onclick="sortTable(\'{table_id}\',{i})">{escape(str(c))} ⇅</th>' for i,c in enumerate(visible.columns))
    rows = []
    for vals in visible.itertuples(index=False, name=None):
        cells=[]
        for i,v in enumerate(vals):
            classes = ' class="comment"' if 'оммент' in str(visible.columns[i]) else ''
            cells.append(f'<td{classes}>{escape(_plain(v))}</td>')
        rows.append('<tr>'+''.join(cells)+'</tr>')
    note = f'Показаны первые {len(visible):,} из {len(df):,} строк; полный результат доступен в CSV.' if len(df)>len(visible) else f'{len(visible):,} строк'
    return (f'<div class="actions"><input id="search-{table_id}" placeholder="Поиск по всем столбцам" oninput="filterTable(\'{table_id}\',\'search-{table_id}\')" />'
            f'<span class="note" id="{table_id}-count">{len(visible)} строк</span></div>'
            f'<div class="wrap"><table id="{table_id}"><thead><tr>{heads}</tr></thead><tbody>{"".join(rows)}</tbody></table></div>'
            f'<p class="note">{note}. Нажми на заголовок столбца для сортировки.</p>')


def _metric(label, value, subtitle=''):
    return f'<div class="metric"><small>{escape(label)}</small><b>{escape(str(value))}</b><div class="note">{escape(subtitle)}</div></div>'


def _write(name: str, title: str, subtitle: str, sections: list[str], reports: Path):
    reports.mkdir(parents=True, exist_ok=True)
    page = ('<!DOCTYPE html><html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">'
            f'<title>{escape(title)}</title>{TABLE_CSS}</head><body><main><header><h1>{escape(title)}</h1><p>{escape(subtitle)}</p></header>'
            + '\n'.join(sections) + '<footer>Локальный отчёт. Без подключения к интернету и без передачи данных наружу.</footer></main>' + TABLE_JS + '</body></html>')
    path = reports / name
    path.write_text(page, encoding='utf-8')
    return path.resolve()


def _csv(df: pd.DataFrame, filename: str, reports: Path) -> Path:
    reports.mkdir(parents=True, exist_ok=True)
    path = reports / filename
    # Protect text cells from Excel formula injection when opening exported CSV.
    safe = df.copy()
    for c in safe.columns:
        if pd.api.types.is_object_dtype(safe[c]) or pd.api.types.is_string_dtype(safe[c]):
            safe[c] = safe[c].map(lambda x: ('\'' + x) if isinstance(x, str) and x.lstrip().startswith(('=', '+', '-', '@')) else x)
    safe.to_csv(path, index=False, encoding='utf-8-sig', sep=';')
    return path.resolve()


def open_report(path: Path):
    return webbrowser.open(Path(path).resolve().as_uri())


class OfflinePortfolioService:
    def __init__(self, storage: Path | str = DEFAULT_STORAGE, reports: Path | str = DEFAULT_REPORTS):
        self.store = PortfolioStore(storage)
        self.reports = Path(reports).resolve()
        self.reports.mkdir(parents=True, exist_ok=True)

    def snapshot_list(self):
        return self.store.list_versions()

    def add_file(self, path, report_date, sheet=None, title=None, header_row=1, note=''):
        file_path = Path(path)
        if file_path.suffix.lower() not in ('.xlsx','.xlsm','.csv'):
            raise ValueError('Допускаются только .xlsx, .xlsm и .csv (xlrd не требуется).')
        date.fromisoformat(str(report_date))
        data = file_path.read_bytes()
        if sheet is None:
            sheet = sheet_names(data,file_path.name)[0]
        return self.store.save(data,file_path.name,sheet,int(header_row),
                               title or f'Портфель на {report_date}',note,report_date)

    def get(self, date_or_id):
        if isinstance(date_or_id,int) or (isinstance(date_or_id,str) and date_or_id.startswith('#')):
            return self.store.get_version(int(str(date_or_id).lstrip('#')))
        choices = [v for v in self.snapshot_list() if v['report_date']==str(date_or_id)]
        if not choices:
            raise ValueError(f'Нет сохранённого портфеля на {date_or_id}.')
        return choices[0]

    def load(self, date_or_id):
        return self.store.load(self.get(date_or_id)['id'])

    def portfolio_report(self, date_or_id, search='', segment='', limit=PREVIEW_LIMIT):
        meta=self.get(date_or_id)
        df=self.load(date_or_id)
        if search:
            text = df['УНП'].fillna('').str.contains(search,case=False,regex=False) | df['Клиент'].fillna('').str.contains(search,case=False,regex=False) | df['Номер договора'].fillna('').str.contains(search,case=False,regex=False)
            df=df.loc[text]
        if segment:
            df=df[df['Сегмент'].astype(str)==segment]
        debt=float(df['Задолженность, тыс BYN'].sum())
        reserve=float(df['Резерв факт'].sum())
        cards = '<div class="grid">'+_metric('Строк в срезе',len(df)) + _metric('Задолженность',fmt(debt),'тыс. BYN')+ _metric('Резерв факт',fmt(reserve),'тыс. BYN')+_metric('УНП',df['УНП'].nunique())+'</div>'
        cols=['УНП','Клиент','Номер договора','Сегмент','Зона проблемности','ГР','Задолженность, тыс BYN','Резерв факт','Day OD','НИ','ПФН','НВВ','Рестра','Обеспеченность']
        sec=['<section><h2>Показатели портфеля</h2>'+cards+'</section>',
             '<section><h2>Таблица портфеля</h2>'+_table(df[cols], 'portfolio',limit)+'</section>']
        suff=f'{meta["id"]}'
        full=_csv(df, f'portfolio_{suff}_full.csv', self.reports)
        sec.insert(1, f'<section><a class="download" href="{escape(full.name)}" download>Скачать все строки · CSV</a></section>')
        html_path=_write(f'portfolio_{suff}.html', 'Портфель на '+str(meta.get('report_date') or '#'+suff),
                         'Поиск и сортировка работают в браузере локально; полные данные сохранены в CSV',sec,self.reports)
        return {'html':html_path,'csv':full,'rows':len(df),'reserve':reserve,'debt':debt}

    def slice_report(self, date_or_id, dimension='Сегмент', metric='Резерв факт', aggregation='Сумма'):
        df=self.load(date_or_id)
        if dimension not in df:
            raise ValueError('Неизвестный столбец среза: '+dimension)
        if aggregation != 'Количество' and metric not in df:
            raise ValueError('Неизвестный числовой столбец: '+metric)
        result=group_summary(df,dimension,metric,aggregation,limit=40)
        output=_csv(result, 'slice_'+str(self.get(date_or_id)['id'])+'.csv',self.reports)
        fig=go.Figure(go.Bar(x=result['Значение'],y=result['Группа'].astype(str),orientation='h',marker_color='#1b7890'))
        fig.update_layout(title=f'{aggregation} — {metric} по полю {dimension}',height=max(360,min(1000,30*len(result)+140)),
                          yaxis={'autorange':'reversed'},plot_bgcolor='white',margin=dict(l=20,r=20,t=70,b=30))
        chart=fig.to_html(include_plotlyjs='inline',full_html=False,config={'displaylogo':False,'responsive':True})
        sec=[f'<section><a class="download" href="{escape(output.name)}" download>Скачать срез · CSV</a></section>', '<section><h2>Срез</h2>'+chart+'</section>', '<section><h2>Данные среза</h2>'+_table(result,'slices')+'</section>']
        path=_write('slice_'+str(self.get(date_or_id)['id'])+'.html','Срез портфеля',str(self.get(date_or_id)['report_date']),sec,self.reports)
        return {'html':path,'csv':output,'data':result}

    def quality_report(self,date_or_id):
        df=self.load(date_or_id)
        summary=quality_summary(df)
        path=_write('quality_'+str(self.get(date_or_id)['id'])+'.html','Качество данных',str(self.get(date_or_id)['report_date']),
                    ['<section><h2>55 столбцов: заполненность и уникальность</h2>'+_table(summary,'quality',100)+'</section>'],self.reports)
        return {'html':path,'csv':_csv(summary,'quality_'+str(self.get(date_or_id)['id'])+'.csv',self.reports)}

    def compare(self, before_date, after_date, threshold=100.0):
        bef=self.get(before_date)
        aft=self.get(after_date)
        if bef['id']==aft['id']:
            raise ValueError('Выбери две разные отчётные даты.')
        if bef.get('report_date') and aft.get('report_date') and bef['report_date']>aft['report_date']:
            raise ValueError('Начальная дата должна быть раньше конечной.')
        old=self.store.load(bef['id'])
        new=self.store.load(aft['id'])
        analysis=compare_operational(old,new)
        mat=build_material_client_report(analysis,float(threshold))
        tag=f'{bef["id"]}_{aft["id"]}'
        paths={}
        for key,df in [('material_clients',mat.material),('all_clients',analysis.clients),('contracts',analysis.contracts),('factors',analysis.factors),('segments',analysis.segments)]:
            paths[key]=_csv(df,f'{key}_{tag}.csv',self.reports)
        # Display a concise, stable column set first. The complete dataset is in CSV.
        keycols=['УНП','Клиент','Резерв — было','Резерв — стало','Δ резерва','Основные факторы','Комментарий']
        exposed=mat.material[[x for x in keycols if x in mat.material]]
        factor_fig=go.Figure(go.Bar(x=analysis.factors['Изменение'], y=analysis.factors['Фактор'].astype(str),
                                    orientation='h',marker_color=['#aa454b' if v<0 else '#087e8b' for v in analysis.factors['Изменение']]))
        factor_fig.update_layout(height=640, yaxis={'autorange':'reversed'}, plot_bgcolor='white',margin=dict(l=30,r=15,t=25,b=20),
                                 xaxis_title='Изменение резерва, тыс. BYN')
        chart=factor_fig.to_html(full_html=False,include_plotlyjs='inline',config={'displaylogo':False,'responsive':True})
        cards='<div class="grid">'+_metric('Резерв на начало',fmt(analysis.total_before),'тыс. BYN')+_metric('Резерв на конец',fmt(analysis.total_after),'тыс. BYN')+_metric('Изменение резерва',fmt(analysis.delta),'тыс. BYN')+_metric('Существенных УНП',len(mat.material),f'|Δ| ≥ {fmt(threshold)} тыс. BYN')+_metric('Остальные УНП',mat.other_clients_count,f'Δ {fmt(mat.other_clients_delta)} тыс. BYN')+_metric('Не сопоставлено',fmt(mat.unmatched_delta),'тыс. BYN')+'</div>'
        check=float(analysis.delta-mat.material_delta-mat.other_clients_delta-mat.unmatched_delta)
        summary=f'''<p class="note"><b>Сверка:</b> существенные {fmt(mat.material_delta)} + остальные {fmt(mat.other_clients_delta)} + не сопоставлено {fmt(mat.unmatched_delta)} = {fmt(analysis.delta)} тыс. BYN. Отклонение: {fmt(check,6)} тыс. BYN.</p>'''
        links = ''.join(f'<a class="download" href="{escape(p.name)}" download>{escape(k.replace("_", " ").title())} · CSV</a>' for k,p in paths.items())
        sections=[
            '<section><h2>Скачать таблицы отчёта</h2>'+links+'</section>',
            '<section><h2>Общая картина</h2>'+cards+summary+'</section>',
            '<section><h2>Существенные клиенты с комментариями</h2><p class="note">Порог включительно: изменение ≤ −100 или ≥ +100 тыс. BYN. Отбор по сумме договоров УНП.</p>'+_table(exposed,'material',2500)+'</section>',
            '<section><h2>Факторный анализ</h2>'+chart+'<p class="note">Факторы — классификация наблюдаемых изменений по договорам, а не доказанная бухгалтерская причина. Совместные эффекты не задваиваются.</p>'+_table(analysis.factors,'factor',100)+'</section>',
            '<section><h2>Сегменты</h2>'+_table(analysis.segments[['Сегмент','Резерв — было','Резерв — стало','Δ резерва']], 'segment',100)+'</section>',
            '<section><h2>Поконтрактная расшифровка</h2>'+_table(analysis.contracts[['УНП','Номер договора','Статус','Резерв — было','Резерв — стало','Δ резерва','НИ (было)','НИ (стало)','ПФН (было)','ПФН (стало)','НВВ (было)','НВВ (стало)','Рестра (стало)']],'contracts',2500)+'</section>',
        ]
        path=_write(f'reserve_comparison_{tag}.html','Расходы на резервы',f'{bef.get("report_date")} → {aft.get("report_date")} · тыс. BYN',sections,self.reports)
        return {'html':path,'exports':paths,'analysis':analysis,'material':mat}

    def verify_environment(self):
        import sys
        import numpy, pandas, openpyxl, plotly
        return {'Python':sys.version.split()[0], 'pandas':pandas.__version__, 'numpy':numpy.__version__,
                'openpyxl':openpyxl.__version__, 'plotly':plotly.__version__}
