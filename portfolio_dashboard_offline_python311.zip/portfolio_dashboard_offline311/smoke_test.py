"""Smoke test without pytest, Streamlit, Tkinter or internet."""
import ast
from pathlib import Path
from tempfile import TemporaryDirectory

import pandas as pd
from types import SimpleNamespace

from offline_service import OfflinePortfolioService
from portfolio_core import load_fixed_portfolio
from portfolio_schema import EXPECTED_COLUMNS
from reserve_operational_analysis import compare_operational
from material_changes import build_material_client_report

HERE=Path(__file__).resolve().parent


def main():
    for name in ['offline_service.py','offline_cli.py','offline_app.py','portfolio_core.py','portfolio_store.py',
                 'reserve_operational_analysis.py','material_changes.py']:
        ast.parse((HERE/name).read_text(encoding='utf-8'),feature_version=(3,11))
    with TemporaryDirectory() as tmp:
        workspace=Path(tmp)
        svc=OfflinePortfolioService(workspace/'storage',workspace/'reports')
        for d in ['2026-09-30','2026-10-29']:
            svc.add_file(HERE/f'demo_{d}.csv',d)
        assert len(svc.snapshot_list())==2
        assert len(EXPECTED_COLUMNS)==55
        r=svc.compare('2026-09-30','2026-10-29')
        a=r['analysis']; mat=r['material']
        assert abs(a.delta-mat.material_delta-mat.other_clients_delta-mat.unmatched_delta)<1e-6
        assert (mat.material['Δ резерва'].abs()>=100).all()
        boundary = SimpleNamespace(clients=pd.DataFrame({'УНП':['a','b','c','d'], 'Клиент':['A','B','C','D'], 'Δ резерва':[100.0,-100.0,99.99,-99.99]}),
                                   contracts=pd.DataFrame({'УНП':pd.Series(dtype='str'), 'Δ резерва':pd.Series(dtype='float64')}), delta=0.0)
        from material_changes import build_material_client_report
        border = build_material_client_report(boundary)
        assert set(border.material['УНП']) == {'a','b'} and border.other_clients_count == 2
        assert r['html'].exists()
        assert all(p.exists() for p in r['exports'].values())
        txt=r['html'].read_text(encoding='utf-8')
        assert 'Расходы на резервы' in txt and 'Plotly.newPlot' in txt
        import re
        assert not re.search(r'<script\s+[^>]*src=[\"\']https?://', txt, flags=re.IGNORECASE)
        view=svc.portfolio_report('2026-09-30')
        assert view['html'].exists() and view['csv'].exists()
        sl=svc.slice_report('2026-09-30')
        assert sl['html'].exists()
        quality=svc.quality_report('2026-09-30')
        assert quality['html'].exists()
        df=svc.load('2026-09-30')
        assert len(df.columns)==55
        print('СНИМКИ:',len(svc.snapshot_list()))
        print('Δ резерва, тыс. BYN:',round(a.delta,2))
        print('Существенных УНП:',len(mat.material),'Остальных:',mat.other_clients_count)
        print('Сверка OK; офлайн-HTML и CSV созданы; синтаксис Python 3.11 OK')
    print('SMOKE TEST PASSED')


if __name__=='__main__':main()
