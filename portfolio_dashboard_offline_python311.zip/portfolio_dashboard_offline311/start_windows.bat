@echo off
setlocal EnableExtensions
chcp 65001 >nul
pushd "%~dp0" 2>nul
if errorlevel 1 (
 echo [ОШИБКА] Не удалось перейти в папку приложения.
 echo Проверьте доступ к сетевой папке и права на чтение/запись.
 pause
 exit /b 1
)
where python >nul 2>nul
if errorlevel 1 (
 echo [ОШИБКА] Не найдена команда python.
 echo Откройте Anaconda Prompt в текущем окружении и запустите: python offline_app.py
 popd
 pause
 exit /b 1
)
echo === Проверка Python и установленных библиотек ===
python offline_cli.py check
if errorlevel 1 (
 echo [ОШИБКА] Не удалось импортировать библиотеки. Запуск отменён.
 popd
 pause
 exit /b 1
)
echo.
echo === Запуск приложения без Streamlit и без сети ===
python offline_app.py
if errorlevel 1 (
 echo.
 echo Если Tkinter недоступен, используйте portfolio_dashboard.ipynb
 echo или команды из инструкции: python offline_cli.py --help
)
popd
pause
endlocal
