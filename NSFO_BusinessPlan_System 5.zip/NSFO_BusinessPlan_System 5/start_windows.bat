@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo ==============================================
echo   АС НСФО — Бизнес-план и Факт vs План
 echo ==============================================
python -c "import openpyxl" >nul 2>&1
if errorlevel 1 (
  echo Не найден модуль openpyxl. Установка в банковском контуре выполняется через ИТ.
  pause
  exit /b 1
)
python -c "import engine,access_control; engine.initialize(); access_control.initialize(); raise SystemExit(0 if access_control.user_count() else 1)" >nul 2>&1
if errorlevel 1 (
  echo Первоначальная настройка: задайте логин и пароль администратора.
  python setup_admin.py
  if errorlevel 1 (
    echo Не удалось создать администратора.
    pause
    exit /b 1
  )
)
echo Локальный адрес: http://127.0.0.1:8502
start "" "http://127.0.0.1:8502"
python server.py
if errorlevel 1 (
  echo Не удалось запустить веб-сервис. Проверьте Python и разрешение на localhost.
  pause
)
