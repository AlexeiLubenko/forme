"""Locked portfolio schema extracted from the supplied Apple Numbers template.

This is the contractual header list. Do not silently rename or add columns.
"""
from __future__ import annotations

EXPECTED_COLUMNS: tuple[str, ...] = (
    "Счет",
    "Наименование ГВК/Клиента(если не в ГВК)",
    "УНП",
    "Клиент",
    "Сегмент",
    "Зона проблемности",
    "Номер договора",
    "Номер договора верхнего уровня",
    "Подразделение",
    "РД",
    "Тип операции",
    "Вид кредита",
    "Код валюты",
    "ГР",
    "% рез",
    "Просроченная задолженность, тыс. BYN",
    "Задолженность, тыс BYN",
    "Резерв факт",
    "Резерв рассчит",
    "Курс",
    "Day OD",
    "Day %%",
    "Max-Day OD",
    "Max-Day %%",
    "НИ",
    "ПФН",
    "Рестра",
    "НВВ",
    "Мультивал",
    "Обеспеченность",
    "Дата начала",
    "Дата окончания",
    "ID CRM",
    "ТГС, %",
    "Рейтинги",
    "PD, %",
    "Номер ПС",
    "LGD (факт), %",
    "Дефолт",
    "EL, %",
    "EL, тыс BYN",
    "PD, тыс BYN",
    "Задолженность CCF, тыс BYN",
    "ТОП20 ГВК",
    "ТОП20 ГВК Списан",
    "Дата отнесения к 6 группе риска",
    "ПОК/СПОК",
    "Код цели выдачи",
    "Субпортфель",
    "NPL (договор)",
    "Код продукта (приор. напр-е)",
    "Признак превышения РВСР",
    "ППВ (проср вознаграждение)",
    "ППА (арест/приостан деят-ти)",
    "Рестра ПАО",
)

# Only fields with clearly numeric semantics are parsed into numbers. Monetary
# "Резерв факт" is in thousands of BYN, confirmed by portfolio owner.
NUMERIC_COLUMNS: tuple[str, ...] = (
    "% рез", "Просроченная задолженность, тыс. BYN",
    "Задолженность, тыс BYN", "Резерв факт", "Резерв рассчит", "Курс",
    "Day OD", "Day %%", "Max-Day OD", "Max-Day %%", "ТГС, %", "PD, %",
    "LGD (факт), %", "EL, %", "EL, тыс BYN", "PD, тыс BYN",
    "Задолженность CCF, тыс BYN",
)
DATE_COLUMNS: tuple[str, ...] = (
    "Дата начала", "Дата окончания", "Дата отнесения к 6 группе риска",
)
CATEGORY_COLUMNS: tuple[str, ...] = tuple(
    col for col in EXPECTED_COLUMNS if col not in NUMERIC_COLUMNS + DATE_COLUMNS
)
DEFAULT_METRIC = "Задолженность, тыс BYN"
DEFAULT_GROUP = "Сегмент"
PORTFOLIO_KPIS: tuple[str, ...] = (
    "Задолженность, тыс BYN",
    "Просроченная задолженность, тыс. BYN",
    "Резерв факт",
    "Резерв рассчит",
)
