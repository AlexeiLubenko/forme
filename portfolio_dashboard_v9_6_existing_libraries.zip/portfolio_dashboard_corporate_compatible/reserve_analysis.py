"""Explain changes in IFRS reserve STOCKS between two immutable dated portfolios.

Input amounts: thousand BYN.  Matching: client UNP only.

Exact reserve bridge (for continuing clients with positive debt):
    volume       = (D1 - D0 - dFX) * R0/D0
    FX           = dFX * R0/D0
    PD proxy     = D1 * (p1-p0) * (l0+l1)/2
    LGD proxy    = D1 * (l1-l0) * (p0+p1)/2
    unexplained  = D1*(R1/D1-R0/D0) - PD proxy - LGD proxy

This is a deliberately transparent allocation, NOT causal identification. PD/LGD
are only used where complete client-level exposure-weighted inputs exist. It does
not assert that observed booked reserve equals PD*LGD*EAD. GR movement is shown
as a NON-additive diagnostic, not an extra counted factor. FX assumes that 'Курс'
is BYN per ONE unit of the row currency and source debt is BYN equivalent.
"""
from __future__ import annotations

from dataclasses import dataclass
import numpy as np
import pandas as pd

DEBT = 'Задолженность, тыс BYN'
RESERVE = 'Резерв факт'
OVERDUE = 'Просроченная задолженность, тыс. BYN'
CLIENT = 'Клиент'
UNP = 'УНП'
GROUP = 'Наименование ГВК/Клиента(если не в ГВК)'
PD = 'PD, %'
LGD = 'LGD (факт), %'
FX = 'Курс'
CURRENCY = 'Код валюты'
RISK_FIELDS = ('ГР', 'Зона проблемности', 'NPL (договор)')
FACTOR_ORDER = (
    'Вход клиентов', 'Выход клиентов', 'Изменение задолженности',
    'Валютный эффект (оценка)', 'PD (модельная оценка)',
    'LGD (модельная оценка)', 'Прочая доля резервирования',
    'Вне модели', 'Без ключа',
)
FACTOR_NAMES = {
    'Вход клиентов': 'Новые клиенты',
    'Выход клиентов': 'Выбывшие клиенты',
    'Изменение задолженности': 'Задолженность (без курса)',
    'Валютный эффект (оценка)': 'Курс валют (оценка)',
    'PD (модельная оценка)': 'PD (модельная оценка)',
    'LGD (модельная оценка)': 'LGD (модельная оценка)',
    'Прочая доля резервирования': 'Прочее изменение покрытия',
    'Вне модели': 'Неположительная задолженность',
    'Без ключа': 'Строки без УНП',
}


@dataclass
class ReserveAnalysis:
    clients: pd.DataFrame
    factors: pd.DataFrame
    segments: pd.DataFrame
    gr_migrations: pd.DataFrame
    total_before: float
    total_after: float
    delta: float
    debt_before: float
    debt_after: float
    unmatched_rows_before: int
    unmatched_rows_after: int
    unmatched_reserve_before: float
    unmatched_reserve_after: float
    invalid_reserve_before: int
    invalid_reserve_after: int
    invalid_debt_before: int
    invalid_debt_after: int
    balance_error: float
    fx_clients_covered: int
    fx_clients_partial: int
    risk_clients_covered: int
    continuing_clients: int


def _clean_key(s: pd.Series) -> pd.Series:
    cleaned = s.astype('string').str.strip().str.replace(r'\s+', '', regex=True)
    cleaned = cleaned.str.replace(r'^(\d+)\.0$', r'\1', regex=True)
    return cleaned.mask(cleaned.str.casefold().isin(['', 'nan', 'none', '<na>', 'null']))


def _numeric(df: pd.DataFrame, col: str) -> pd.Series:
    return pd.to_numeric(df[col], errors='coerce') if col in df else pd.Series(np.nan, index=df.index)


def _agg_snapshot(df: pd.DataFrame, key_col: str, reserve_col: str):
    key = _clean_key(df[key_col])
    valid = key.notna()
    temp = df.loc[valid].copy()
    temp['_key'] = key.loc[valid].to_numpy()
    temp['_debt'] = _numeric(temp, DEBT).fillna(0).astype(float)
    temp['_reserve'] = _numeric(temp, reserve_col).fillna(0).astype(float)
    temp['_overdue'] = _numeric(temp, OVERDUE).fillna(0).astype(float)
    temp['_pd'] = _numeric(temp, PD).astype(float) / 100.0
    temp['_lgd'] = _numeric(temp, LGD).astype(float) / 100.0
    temp['_rate'] = _numeric(temp, FX).astype(float)
    if CURRENCY in temp:
        temp['_currency'] = temp[CURRENCY].astype('string').str.strip().str.upper()
    else:
        temp['_currency'] = pd.Series(pd.NA, index=temp.index, dtype='string')
    temp['_currency'] = temp['_currency'].mask(temp['_currency'].isin(['', 'NAN', '<NA>']))
    grouped = temp.groupby('_key', sort=False)
    totals = grouped[['_debt', '_reserve', '_overdue']].sum()
    totals['rows'] = grouped.size()
    # Strictly require every positive exposure to have valid PD and LGD. A
    # negative position invalidates this model estimate for the entire client.
    pos = temp['_debt'] > 0
    valid_risk = (temp['_pd'].between(0, 1) & temp['_lgd'].between(0, 1) & pos)
    temp['_bad_risk'] = ((pos & ~valid_risk) | (temp['_debt'] < 0)).astype('int8')
    temp['_w_pd'] = (temp['_debt'] * temp['_pd']).where(valid_risk, 0.0)
    temp['_w_lgd'] = (temp['_debt'] * temp['_lgd']).where(valid_risk, 0.0)
    temp['_positive_debt'] = temp['_debt'].clip(lower=0)
    agg_risk = grouped[['_bad_risk', '_w_pd', '_w_lgd', '_positive_debt']].sum()
    ok_risk = agg_risk['_bad_risk'].eq(0) & agg_risk['_positive_debt'].gt(0)
    totals['_pd_w'] = (agg_risk['_w_pd'] / agg_risk['_positive_debt']).where(ok_risk)
    totals['_lgd_w'] = (agg_risk['_w_lgd'] / agg_risk['_positive_debt']).where(ok_risk)
    # Display only unequivocal category values. A client may have >1 GR.
    for col in (CLIENT, 'Сегмент', *RISK_FIELDS):
        if col not in temp:
            totals[col] = pd.Series(pd.NA, index=totals.index, dtype='string')
            continue
        series = temp[col].astype('string').fillna('—').str.strip().replace('', '—')
        g = series.groupby(temp['_key'], sort=False)
        single = g.first()
        single[g.nunique(dropna=False) > 1] = 'Несколько'
        totals[col] = single
    quality = {
        'unmatched_rows': int((~valid).sum()),
        'unmatched_reserve': float(_numeric(df.loc[~valid], reserve_col).sum()),
        'invalid_reserve': int(_numeric(df, reserve_col).isna().sum()),
        'invalid_debt': int(_numeric(df, DEBT).isna().sum()),
    }
    return totals, temp, quality


def _currency_table(temp: pd.DataFrame) -> pd.DataFrame:
    """Currency balances with unique, valid rates (per UNP and currency)."""
    cols = ['_debt', '_rate', '_currency', '_key']
    sub = temp.loc[temp['_currency'].notna(), cols].copy()
    if sub.empty:
        return pd.DataFrame(columns=['_debt', 'rate', 'rate_ok', 'is_byn'], index=pd.MultiIndex.from_tuples([], names=['_key','_currency']))
    sub['is_byn'] = sub['_currency'].isin(['BYN', '933'])
    g = sub.groupby(['_key', '_currency'], sort=False)
    grouped = g.agg(_debt=('_debt','sum'), rate=('_rate','first'),
                    min_rate=('_rate','min'), max_rate=('_rate','max'),
                    total=('_rate','size'), rate_count=('_rate','count'),
                    bad_debt=('_debt', lambda s: (s < 0).any()),
                    is_byn=('is_byn','first'))
    valid = (grouped['rate_count'].eq(grouped['total']) &
             grouped['min_rate'].gt(0) &
             (grouped['max_rate'] - grouped['min_rate']).abs().le(
                 1e-6 * grouped['max_rate'].abs().clip(lower=1)) &
             ~grouped['bad_debt'])
    grouped['rate_ok'] = valid | grouped['is_byn']
    grouped.loc[grouped['is_byn'], 'rate'] = 1.0
    return grouped[['_debt','rate','rate_ok','is_byn']]


def _fx_effect(before_temp: pd.DataFrame, after_temp: pd.DataFrame):
    """Return client-level change in BYN debt due to FX at OLD currency quantity.

    Only matched currency buckets with positive, consistent rates on both dates
    are eligible. All ineligible/missing currency movement stays in volume.
    """
    c0 = _currency_table(before_temp)
    c1 = _currency_table(after_temp)
    both = c0.add_suffix('_0').join(c1.add_suffix('_1'), how='inner')
    if both.empty:
        return pd.Series(dtype=float), pd.Series(dtype=int), pd.Series(dtype=float)
    eligible = (both['rate_ok_0'].fillna(False) & both['rate_ok_1'].fillna(False) &
                both['rate_0'].gt(0) & both['rate_1'].gt(0) & both['_debt_0'].ge(0))
    byn = both['is_byn_0'].fillna(False) | both['is_byn_1'].fillna(False)
    both['fx'] = np.where(eligible & ~byn,
                          both['_debt_0'] / both['rate_0'] * (both['rate_1'] - both['rate_0']), 0.0)
    both['eligible'] = eligible & ~byn
    # Sum comparable foreign currency exposure at base date for coverage.
    both['covered_debt'] = np.where(eligible & ~byn, both['_debt_0'], 0.0)
    keys = both.index.get_level_values('_key')
    return (both['fx'].groupby(keys).sum(),
            both['eligible'].groupby(keys).sum().astype(int),
            both['covered_debt'].groupby(keys).sum())


def compare_reserves(before: pd.DataFrame, after: pd.DataFrame,
                     key_col: str = UNP, reserve_col: str = RESERVE) -> ReserveAnalysis:
    """Compare clients by UNP. The additive bridge ALWAYS reconciles Δ reserve.

    Alternate keys and reserve metrics are intentionally disallowed here to
    prevent accidental inconsistent production reports.
    """
    if key_col != UNP or reserve_col != RESERVE:
        raise ValueError('Методика фиксирована: идентификатор УНП, показатель «Резерв факт».')
    for frame in (before, after):
        for col in (UNP, RESERVE, DEBT, OVERDUE):
            if col not in frame:
                raise ValueError(f'Отсутствует обязательное поле: {col}')
    old, t0, q0 = _agg_snapshot(before, UNP, RESERVE)
    new, t1, q1 = _agg_snapshot(after, UNP, RESERVE)
    merged = old.add_suffix('_0').join(new.add_suffix('_1'), how='outer')
    idx = merged.index
    present0 = merged['rows_0'].notna()
    present1 = merged['rows_1'].notna()
    entered = (~present0) & present1
    exited = present0 & (~present1)
    continuing = present0 & present1
    e0 = merged['_debt_0'].fillna(0).astype(float)
    e1 = merged['_debt_1'].fillna(0).astype(float)
    r0 = merged['_reserve_0'].fillna(0).astype(float)
    r1 = merged['_reserve_1'].fillna(0).astype(float)
    overdue0 = merged['_overdue_0'].fillna(0).astype(float)
    overdue1 = merged['_overdue_1'].fillna(0).astype(float)
    normal = continuing & e0.gt(0) & e1.gt(0)
    atypical = continuing & ~normal

    f_in = pd.Series(np.where(entered, r1, 0.0), index=idx)
    f_out = pd.Series(np.where(exited, -r0, 0.0), index=idx)
    f_debt = pd.Series(0.0, index=idx)
    f_fx = pd.Series(0.0, index=idx)
    f_pd = pd.Series(0.0, index=idx)
    f_lgd = pd.Series(0.0, index=idx)
    f_residual = pd.Series(0.0, index=idx)
    f_other = pd.Series(np.where(atypical, r1-r0, 0.0), index=idx)

    fx_change, fx_count, fx_debt = _fx_effect(t0, t1)
    fx_change = fx_change.reindex(idx, fill_value=0).astype(float)
    fx_count = fx_count.reindex(idx, fill_value=0).astype(int)
    fx_debt = fx_debt.reindex(idx, fill_value=0).astype(float)
    rate0 = (r0 / e0.where(normal)).fillna(0)
    rate1 = (r1 / e1.where(normal)).fillna(0)
    f_fx.loc[normal] = fx_change.loc[normal] * rate0.loc[normal]
    f_debt.loc[normal] = ((e1-e0-fx_change) * rate0).loc[normal]
    rate_movement = (e1 * (rate1-rate0)).where(normal, 0)

    p0 = merged['_pd_w_0'].astype(float)
    p1 = merged['_pd_w_1'].astype(float)
    l0 = merged['_lgd_w_0'].astype(float)
    l1 = merged['_lgd_w_1'].astype(float)
    risk_valid = normal & p0.notna() & p1.notna() & l0.notna() & l1.notna()
    f_pd.loc[risk_valid] = (e1 * (p1-p0) * (l0+l1)/2).loc[risk_valid]
    f_lgd.loc[risk_valid] = (e1 * (l1-l0) * (p0+p1)/2).loc[risk_valid]
    f_residual.loc[normal] = (rate_movement-f_pd-f_lgd).loc[normal]

    out = pd.DataFrame(index=idx)
    out.index.name = 'Идентификатор'
    out['Статус'] = np.select([entered, exited], ['Новый', 'Выбыл'], default='Сопоставлен')
    for col in (CLIENT, 'Сегмент', *RISK_FIELDS):
        out[col + ' (было)'] = merged[col + '_0']
        out[col + ' (стало)'] = merged[col + '_1']
    out['Клиент'] = out[CLIENT+' (стало)'].combine_first(out[CLIENT+' (было)']).fillna('—')
    out['Сегмент'] = out['Сегмент (стало)'].combine_first(out['Сегмент (было)']).fillna('—')
    out['Задолженность — было'] = e0
    out['Задолженность — стало'] = e1
    out['Δ задолженности'] = e1-e0
    out['Резерв — было'] = r0
    out['Резерв — стало'] = r1
    out['Δ резерва'] = r1-r0
    out['Просрочка — было'] = overdue0
    out['Просрочка — стало'] = overdue1
    out['Доля резерва — было, %'] = np.where(e0.gt(0), r0/e0*100, np.nan)
    out['Доля резерва — стало, %'] = np.where(e1.gt(0), r1/e1*100, np.nan)
    out['PD — было, %'] = p0 * 100
    out['PD — стало, %'] = p1 * 100
    out['LGD — было, %'] = l0 * 100
    out['LGD — стало, %'] = l1 * 100
    out['ГР изменилась'] = (continuing & out['ГР (было)'].notna() &
                           out['ГР (стало)'].notna() &
                           (out['ГР (было)'] != out['ГР (стало)']))
    out['Модель PD/LGD доступна'] = risk_valid
    out['FX — валютных групп с корректным курсом'] = fx_count
    out['FX — покрытая задолженность было'] = fx_debt
    out['FX — изменение долга в BYN'] = fx_change.where(normal, 0)
    components = {
        'Вход клиентов': f_in,
        'Выход клиентов': f_out,
        'Изменение задолженности': f_debt,
        'Валютный эффект (оценка)': f_fx,
        'PD (модельная оценка)': f_pd,
        'LGD (модельная оценка)': f_lgd,
        'Прочая доля резервирования': f_residual,
        'Вне модели': f_other,
    }
    for name, s in components.items():
        out[name] = s
    # Backward-compatible composite, not included a second time in factor bridge.
    out['Объём задолженности'] = f_debt + f_fx
    out['Доля резервирования'] = f_pd + f_lgd + f_residual

    reasons = pd.Series('Существенного изменения резерва не выявлено', index=idx, dtype='string')
    reasons[entered] = 'Появление клиента в снимке'
    reasons[exited] = 'Выбытие клиента из снимка'
    reasons[atypical] = 'Неположительная задолженность; разложение недоступно'
    reasons[normal & out['Δ резерва'].gt(1e-8)] = 'Увеличение резерва'
    reasons[normal & out['Δ резерва'].lt(-1e-8)] = 'Уменьшение резерва'
    for name, positive, negative in [
        ('Изменение задолженности', 'рост задолженности', 'снижение задолженности'),
        ('Валютный эффект (оценка)', 'положительная курсовая оценка', 'отрицательная курсовая оценка'),
        ('PD (модельная оценка)', 'рост PD (оценка)', 'снижение PD (оценка)'),
        ('LGD (модельная оценка)', 'рост LGD (оценка)', 'снижение LGD (оценка)'),
    ]:
        reasons[normal & out[name].gt(1e-8)] += '; ' + positive
        reasons[normal & out[name].lt(-1e-8)] += '; ' + negative
    reasons[out['ГР изменилась'].fillna(False)] += '; изменение ГР (сигнал)'
    overdue_growth = continuing & overdue1.gt(overdue0+1e-8)
    reasons[overdue_growth] += '; рост просроченной задолженности (сигнал)'
    reasons[normal & ~risk_valid] += '; PD/LGD недоступны или некорректны'
    out['Возможные причины / сигналы'] = reasons

    totals = {
        **{x:float(components[x].sum()) for x in components},
        'Без ключа': q1['unmatched_reserve']-q0['unmatched_reserve'],
    }
    factors = pd.DataFrame([{'Фактор': FACTOR_NAMES[x], 'Изменение': totals[x], 'Код':x}
                            for x in FACTOR_ORDER])
    out = out.reset_index().sort_values('Δ резерва', key=lambda s:s.abs(), ascending=False)
    money_cols = ['Резерв — было','Резерв — стало','Δ резерва',*components]
    segments = (out.groupby('Сегмент', dropna=False, as_index=False)[money_cols].sum()
                .sort_values('Δ резерва', key=lambda s:s.abs(), ascending=False))
    gr_change = out.loc[out['ГР изменилась'].fillna(False)].copy()
    if not gr_change.empty:
        gr_migrations = (gr_change.groupby(['ГР (было)','ГР (стало)'], dropna=False)
                         .agg(Клиентов=('Идентификатор','size'),
                              Изменение_резерва=('Δ резерва','sum'))
                         .reset_index()
                         .rename(columns={'Изменение_резерва':'Δ резерва, тыс. BYN'})
                         .sort_values('Клиентов', ascending=False))
    else:
        gr_migrations = pd.DataFrame(columns=['ГР (было)','ГР (стало)','Клиентов','Δ резерва, тыс. BYN'])
    total_before = float(_numeric(before, RESERVE).sum())
    total_after = float(_numeric(after, RESERVE).sum())
    delta = total_after-total_before
    err = delta-float(factors['Изменение'].sum())
    return ReserveAnalysis(
        clients=out, factors=factors, segments=segments, gr_migrations=gr_migrations,
        total_before=total_before,total_after=total_after,delta=delta,
        debt_before=float(_numeric(before,DEBT).sum()), debt_after=float(_numeric(after,DEBT).sum()),
        unmatched_rows_before=q0['unmatched_rows'], unmatched_rows_after=q1['unmatched_rows'],
        unmatched_reserve_before=q0['unmatched_reserve'], unmatched_reserve_after=q1['unmatched_reserve'],
        invalid_reserve_before=q0['invalid_reserve'],invalid_reserve_after=q1['invalid_reserve'],
        invalid_debt_before=q0['invalid_debt'],invalid_debt_after=q1['invalid_debt'],
        balance_error=err,
        fx_clients_covered=int((normal & fx_count.gt(0)).sum()),
        fx_clients_partial=int((normal & fx_count.eq(0)).sum()),
        risk_clients_covered=int(risk_valid.sum()), continuing_clients=int(continuing.sum()),
    )
