"""Tests for accounting identity, data gaps, metadata migration, dates."""
from __future__ import annotations
import sys
from pathlib import Path
import tempfile
import unittest
import pandas as pd
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from reserve_analysis import compare_reserves, DEBT, RESERVE, OVERDUE
from portfolio_store import PortfolioStore


def sample(rows):
    return pd.DataFrame(rows, columns=['УНП', 'Клиент', 'Сегмент', 'ГР',
                                      'Зона проблемности','NPL (договор)', DEBT,RESERVE,OVERDUE])


class ReservesTests(unittest.TestCase):
    def setUp(self):
        self.old = sample([
            ['001','Альфа','К','1','Норма','Нет',100,10,0],
            ['001','Альфа','К','1','Норма','Нет',50,5,0],
            ['002','Бета','К','1','Норма','Нет',80,16,0],
            ['003','Ушел','К','2','Норма','Нет',30,7,0],
            ['004','Нулевой долг','К','2','Норма','Нет',0,3,0],
            [None, 'Без ИД до','К','1','Норма','Нет',10,2,0],
        ])
        self.new = sample([
            ['001','Альфа','К','2','Норма','Да',200,60,15],
            ['002','Бета','К','1','Норма','Нет',40,2,0],
            ['004','Нулевой долг','К','2','Норма','Нет',0,1,0],
            ['005','Новый','К','2','Норма','Нет',60,20,0],
            ['', 'Без ИД после','К','1','Норма','Нет',50,4,0],
        ])

    def test_reconciled_factor_bridge(self):
        result = compare_reserves(self.old, self.new)
        self.assertAlmostEqual(result.total_before, 43)
        self.assertAlmostEqual(result.total_after, 87)
        self.assertAlmostEqual(result.delta, 44)
        self.assertAlmostEqual(result.factors['Изменение'].sum(), result.delta)
        self.assertAlmostEqual(result.balance_error, 0)
        self.assertAlmostEqual(result.clients['Δ резерва'].sum(), 42)
        c = result.clients.set_index('Идентификатор')
        self.assertEqual(c.loc['001','Статус'], 'Сопоставлен')
        self.assertEqual(c.loc['005','Статус'], 'Новый')
        self.assertEqual(c.loc['003','Статус'], 'Выбыл')
        self.assertAlmostEqual(c.loc['001','Объём задолженности'], 5)
        self.assertAlmostEqual(c.loc['001','Доля резервирования'], 40)
        self.assertAlmostEqual(c.loc['004','Вне модели'], -2)
        self.assertIn('изменение ГР', c.loc['001','Возможные причины / сигналы'])
        self.assertIn('рост просроченной', c.loc['001','Возможные причины / сигналы'])
        self.assertEqual(result.unmatched_rows_before, 1)
        self.assertEqual(result.unmatched_rows_after, 1)
        self.assertAlmostEqual(result.segments['Δ резерва'].sum(), 42)

    def test_unchanged(self):
        r = compare_reserves(self.old, self.old)
        self.assertEqual(r.delta, 0)
        self.assertAlmostEqual(r.factors['Изменение'].sum(), 0)
        self.assertTrue((r.clients['Δ резерва'] == 0).all())

    def test_empty_sides_or_all_missing_keys(self):
        r = compare_reserves(self.old.iloc[:0], self.new)
        self.assertAlmostEqual(r.factors['Изменение'].sum(),r.delta)
        r2 = compare_reserves(self.old[self.old['УНП'].isna()],
                              self.new[self.new['УНП'].isna()])
        self.assertAlmostEqual(r2.factors['Изменение'].sum(),r2.delta)

    def test_realistic_two_demo_csv_files(self):
        from portfolio_core import load_fixed_portfolio
        root = Path(__file__).resolve().parents[1]
        old_path = root / 'demo_2026-09-30.csv'
        new_path = root / 'demo_2026-10-29.csv'
        old = load_fixed_portfolio(old_path.read_bytes(), old_path.name)
        new = load_fixed_portfolio(new_path.read_bytes(), new_path.name)
        self.assertEqual(old.shape[1], 55)
        self.assertEqual(new.shape[1], 55)
        result = compare_reserves(old, new)
        self.assertGreater(result.delta, 0)
        self.assertAlmostEqual(result.delta, result.factors['Изменение'].sum(), places=7)
        self.assertEqual(result.clients['Статус'].eq('Новый').sum(), 3)
        self.assertEqual(result.clients['Статус'].eq('Выбыл').sum(), 3)

    def test_dated_immutable_storage_and_legacy_migration(self):
        root = Path(__file__).resolve().parents[1]
        raw = (root/'demo_portfolio.xlsx').read_bytes()
        with tempfile.TemporaryDirectory() as tmp:
            # Previous v3 default save lacked reporting dates.
            store = PortfolioStore(tmp)
            old_id = store.save(raw, 'demo_portfolio.xlsx', 'Портфель', 1, 'Предыдущая версия')
            store.set_report_date(old_id, '2026-09-30')
            new_id = store.save(raw, 'demo_portfolio.xlsx', 'Портфель', 1,
                                'Октябрь', report_date='2026-10-29')
            self.assertEqual(len(store.list_versions()), 2)
            self.assertEqual(store.get_version(old_id)['report_date'], '2026-09-30')
            before_bytes = store.raw_bytes(old_id)
            with self.assertRaisesRegex(ValueError, 'уже есть портфель'):
                store.save(raw, 'demo_portfolio.xlsx', 'Портфель', 1,
                           'Повтор', report_date='2026-10-29')
            with self.assertRaisesRegex(ValueError, 'уже сохранён'):
                store.set_report_date(old_id, '2026-10-29')
            store.restore(old_id)
            self.assertEqual(store.raw_bytes(old_id), before_bytes)
            self.assertEqual(store.active_id(), old_id)
            self.assertEqual(len(list((Path(tmp)/'blobs').glob('*.xlsx'))), 1)
            self.assertEqual(PortfolioStore(tmp).get_version(new_id)['report_date'], '2026-10-29')


if __name__ == '__main__':
    unittest.main()
