"""Regression checks for strict portfolio schema, filtering, comparison, and versions."""
from __future__ import annotations

from pathlib import Path
import sys
import tempfile
import unittest

import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from portfolio_core import (
    apply_filter_definitions, compare_group_versions, compare_versions,
    group_summary, load_fixed_portfolio, make_pivot, quality_summary,
    read_portfolio, sheet_names, to_numeric_flexible,
    validate_fixed_schema,
)
from portfolio_schema import CATEGORY_COLUMNS, EXPECTED_COLUMNS, NUMERIC_COLUMNS
from portfolio_store import PortfolioStore

ROOT = Path(__file__).resolve().parents[1]


class PortfolioTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.raw = (ROOT / "demo_portfolio.xlsx").read_bytes()
        cls.df = load_fixed_portfolio(cls.raw, "demo_portfolio.xlsx", "Портфель", 1)

    def test_exact_structure(self):
        self.assertEqual(len(EXPECTED_COLUMNS), 55)
        self.assertEqual(self.df.columns.tolist(), list(EXPECTED_COLUMNS))
        self.assertEqual(self.df.shape, (240, 55))
        self.assertEqual(sheet_names(self.raw, "demo_portfolio.xlsx"), ["Портфель", "Описание"])
        self.assertTrue(pd.api.types.is_numeric_dtype(self.df["Задолженность, тыс BYN"]))
        self.assertTrue(pd.api.types.is_datetime64_any_dtype(self.df["Дата начала"]))

    def test_reject_modified_headers(self):
        invalid = self.df.rename(columns={"Счет": "Номер счета"})
        with self.assertRaisesRegex(ValueError, "Отсутствуют"):
            validate_fixed_schema(invalid)
        with self.assertRaisesRegex(ValueError, "Лишние"):
            validate_fixed_schema(self.df.assign(unexpected=1))

    def test_filter_and_pivot(self):
        filtered = apply_filter_definitions(self.df, [
            {"column": "Сегмент", "mode": "category", "values": ["Розница"]},
            {"column": "Задолженность, тыс BYN", "mode": "number", "min": 100, "max": 8000},
        ])
        self.assertFalse(filtered.empty)
        self.assertTrue(filtered["Сегмент"].eq("Розница").all())
        pivot = make_pivot(self.df, "Сегмент", "Код валюты", "Задолженность, тыс BYN", "Сумма", 50)
        self.assertAlmostEqual(float(pivot.sum().sum()), float(self.df["Задолженность, тыс BYN"].sum()))

    def test_comparisons(self):
        newer = self.df.iloc[:-10].copy()
        c = compare_versions(self.df, newer)
        self.assertEqual(c.iloc[0]["Изменение"], -10)
        self.assertAlmostEqual(c.loc[c["Показатель"] == "Задолженность, тыс BYN", "Изменение"].iloc[0],
                               -self.df.iloc[-10:]["Задолженность, тыс BYN"].sum())
        groups = compare_group_versions(self.df, newer, "Сегмент", "Задолженность, тыс BYN")
        self.assertAlmostEqual(groups["Изменение"].sum(), -self.df.iloc[-10:]["Задолженность, тыс BYN"].sum())

    def test_numeric_converter(self):
        text = pd.Series(["1 250,20", "2.300,21", "1,234.56", None])
        v = to_numeric_flexible(text)
        self.assertEqual(v.iloc[:3].tolist(), [1250.2, 2300.21, 1234.56])
        self.assertTrue(pd.isna(v.iloc[3]))

    def test_quality_and_group(self):
        self.assertEqual(len(quality_summary(self.df)), 55)
        grouped = group_summary(self.df, "Сегмент", "Задолженность, тыс BYN", "Сумма")
        self.assertAlmostEqual(grouped["Значение"].sum(), self.df["Задолженность, тыс BYN"].sum())

    def test_persistent_upload_and_restore_audit(self):
        with tempfile.TemporaryDirectory() as tmp:
            store = PortfolioStore(tmp)
            a = store.save(self.raw, "demo_portfolio.xlsx", "Портфель", 1, "Первая")
            # Same raw bytes are deduplicated on disk, but each upload is a version.
            b = store.save(self.raw, "demo_portfolio.xlsx", "Портфель", 1, "Вторая", "Комментарий")
            self.assertEqual([a,b], [1,2])
            self.assertEqual(len(list((Path(tmp)/"blobs").iterdir())), 1)
            self.assertEqual(store.active_id(), 2)
            # Separate process / Streamlit restart: same files and SQLite history.
            reopened = PortfolioStore(tmp)
            self.assertEqual(len(reopened.list_versions()), 2)
            self.assertEqual(len(reopened.load(1)), 240)
            reopened.restore(a)
            self.assertEqual(PortfolioStore(tmp).active_id(), 1)
            self.assertEqual(len(reopened.list_versions()), 2)
            self.assertEqual([x["action"] for x in reopened.audit_log()], ["select_snapshot", "snapshot_upload", "snapshot_upload"])
            reopened.restore(2)
            self.assertEqual(reopened.active_id(), 2)
            self.assertEqual(len(reopened.audit_log()), 4)
            with self.assertRaises(KeyError):
                reopened.restore(999)

    def test_validation_does_not_save_failed_upload(self):
        with tempfile.TemporaryDirectory() as tmp:
            store = PortfolioStore(tmp)
            with self.assertRaises(ValueError):
                store.save(b"invalid", "fake.xlsx", "Портфель", 1, "Плохой")
            self.assertIsNone(store.active_id())
            self.assertEqual(store.list_versions(), [])

    def test_checksum_detects_corruption(self):
        with tempfile.TemporaryDirectory() as tmp:
            store = PortfolioStore(tmp)
            vid = store.save(self.raw, "demo_portfolio.xlsx", "Портфель", 1, "Версия")
            path = Path(tmp) / "blobs" / store.get_version(vid)["blob_name"]
            path.write_bytes(b"changed")
            with self.assertRaisesRegex(IOError, "Контрольная сумма"):
                store.raw_bytes(vid)


if __name__ == "__main__":
    unittest.main()
