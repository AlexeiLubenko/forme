"""Regression tests for client-level materiality and bank-style comments."""
import sys
from pathlib import Path
import unittest
import pandas as pd
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from reserve_operational_analysis import (
    compare_operational,UNP,CONTRACT,CLIENT,SEGMENT,DEBT,RESERVE,OVERDUE,DAY,COVER,
)
from material_changes import build_material_client_report


def row(unp='001',contract='A',debt=1000,reserve=10,**kwargs):
    result={UNP:unp,CONTRACT:contract,CLIENT:f'Клиент {unp}',SEGMENT:'Корп',
            DEBT:debt,RESERVE:reserve,OVERDUE:0,DAY:0,'НИ':0,'ПФН':0,
            'НВВ':0,'Рестра':'',COVER:'80%'}
    result.update(kwargs)
    return result


def report(old,new):
    res=compare_operational(pd.DataFrame(old),pd.DataFrame(new))
    rep=build_material_client_report(res)
    assert abs(rep.balance_error)<1e-6
    return res,rep


class MaterialChangesTest(unittest.TestCase):
    def test_inclusive_boundary_positive_and_negative_100(self):
        old = [row('pos', reserve=10), row('neg', contract='B', reserve=110),
               row('below', contract='C', reserve=10), row('above', contract='D', reserve=10)]
        new = [row('pos', reserve=110), row('neg', contract='B', reserve=10),
               row('below', contract='C', reserve=109.99), row('above', contract='D', reserve=110.01)]
        _, rep = report(old, new)
        self.assertEqual(rep.all_clients_count, 4)
        self.assertEqual(len(rep.material), 3)
        self.assertEqual(set(rep.material[UNP].astype(str)), {'pos', 'neg', 'above'})
        self.assertAlmostEqual(rep.other_clients_delta, 99.99)
        self.assertAlmostEqual(rep.material_delta, 100.01)

    def test_negative_just_below_boundary_excluded(self):
        old = [row('a', reserve=110), row('b', contract='B', reserve=110)]
        new = [row('a', reserve=10.01), row('b', contract='B', reserve=9.99)]
        _, rep = report(old, new)
        self.assertEqual(len(rep.material), 1)
        self.assertEqual(rep.material.iloc[0][UNP], 'b')
        self.assertAlmostEqual(rep.other_clients_delta, -99.99)
        self.assertAlmostEqual(rep.material_delta, -100.01)

    def test_sum_by_unp_before_apply_threshold(self):
        # 2 individually subthreshold changes for ONE client become material.
        old=[row('A','a'),row('A','b'),row('B','c')]
        new=[row('A','a',reserve=70),row('A','b',reserve=70),row('B','c',reserve=75)]
        _,rep=report(old,new)
        self.assertEqual(len(rep.material),1)
        self.assertEqual(rep.material.iloc[0][UNP],'A')
        self.assertAlmostEqual(rep.material_delta,120)
        self.assertEqual(rep.other_clients_count,1)
        self.assertAlmostEqual(rep.other_clients_delta,65)

    def test_opposite_contract_deltas_can_cancel_below_limit(self):
        old=[row('A','a'),row('A','b')]
        new=[row('A','a',reserve=220),row('A','b',reserve=-100.01)]
        _, rep=report(old,new)
        self.assertEqual(len(rep.material),0)
        self.assertAlmostEqual(rep.other_clients_delta,99.99)

    def test_negative_above_threshold_and_comment_on_new_contract(self):
        old=[row('A','a',reserve=300)]
        new=[row('A','a',reserve=90),row('A','b',reserve=50)]
        _,rep=report(old,new)
        self.assertEqual(len(rep.material),1)
        text=rep.material.iloc[0]['Комментарий']
        self.assertIn('Снижение резерва',text)
        self.assertIn('новый договор b',text)
        self.assertIn('договор a',text)

    def test_observed_flags_restructuring_and_overdue_in_comment(self):
        old=[row(reserve=10)]
        new=[row(reserve=150,**{'НИ':1,'ПФН':1,'НВВ':1,'Рестра':'рестр. 4ГР 30%',
                                   COVER:'20%',OVERDUE:12,DAY:31})]
        _,rep=report(old,new)
        comment=rep.material.iloc[0]['Комментарий']
        for text in ('признан НИ','признан ПФН','признан НВВ',
                     'рестр. 4ГР 30%','обеспеченность 80% → 20%',
                     'просрочка 0.0 → 12.0','дней просрочки 0 → 31'):
            self.assertIn(text,comment)

    def test_unmatched_delta_is_separate_and_balances(self):
        a=[row('A','a'),row(unp=None,contract='orphan',reserve=12),row('B',None,reserve=20)]
        b=[row('A','a',reserve=130),row(unp=None,contract='orphan',reserve=17),row('B',None,reserve=30)]
        result, rep=report(a,b)
        self.assertEqual(len(rep.material),1)
        self.assertAlmostEqual(rep.unmatched_delta,15)
        self.assertAlmostEqual(rep.material_delta,120)
        self.assertAlmostEqual(rep.material_delta+rep.other_clients_delta+rep.unmatched_delta,result.delta)

    def test_no_client_data_and_empty_report(self):
        _, rep=report([row(unp=None,reserve=15)], [row(unp=None,reserve=25)])
        self.assertEqual(len(rep.material),0)
        self.assertEqual(rep.other_clients_count,0)
        self.assertAlmostEqual(rep.unmatched_delta,10)

    def test_invalid_threshold_rejected(self):
        result=compare_operational(pd.DataFrame([row()]),pd.DataFrame([row()]))
        for bad in [-1, float('nan'), float('inf')]:
            with self.assertRaises(ValueError):
                build_material_client_report(result,bad)

    def test_report_does_not_modify_original_clients(self):
        result=compare_operational(pd.DataFrame([row()]),pd.DataFrame([row(reserve=200)]))
        before=result.clients.copy(deep=True)
        build_material_client_report(result)
        pd.testing.assert_frame_equal(before,result.clients)


if __name__=='__main__':
    unittest.main()
