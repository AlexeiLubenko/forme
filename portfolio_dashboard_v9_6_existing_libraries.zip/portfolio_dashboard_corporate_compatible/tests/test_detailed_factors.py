import unittest
from pathlib import Path
import sys

import pandas as pd
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from reserve_analysis import compare_reserves


def snap(rows):
    defaults = {'УНП':None, 'Клиент':'Клиент', 'Сегмент':'КБ', 'ГР':'2',
                'Зона проблемности':'Норма','NPL (договор)':'Нет',
                'Задолженность, тыс BYN':0.0,'Резерв факт':0.0,
                'Просроченная задолженность, тыс. BYN':0.0,
                'PD, %':10.0,'LGD (факт), %':50.0,
                'Курс':3.0,'Код валюты':'USD'}
    return pd.DataFrame([{**defaults,**r} for r in rows])


class DetailedFactorTests(unittest.TestCase):
    def test_fx_pd_lgd_and_residual_exact(self):
        old = snap([{'УНП':'001','ГР':'2','Задолженность, тыс BYN':100,
                     'Резерв факт':10, 'PD, %':10, 'LGD (факт), %':50, 'Курс':2}])
        new = snap([{'УНП':'001','ГР':'3','Задолженность, тыс BYN':120,
                     'Резерв факт':27, 'PD, %':20, 'LGD (факт), %':60, 'Курс':3}])
        out = compare_reserves(old,new)
        c = out.clients.iloc[0]
        self.assertAlmostEqual(c['FX — изменение долга в BYN'],50)
        self.assertAlmostEqual(c['Валютный эффект (оценка)'],5)
        self.assertAlmostEqual(c['Изменение задолженности'],-3)
        self.assertAlmostEqual(c['PD (модельная оценка)'],6.6)
        self.assertAlmostEqual(c['LGD (модельная оценка)'],1.8)
        self.assertAlmostEqual(c['Прочая доля резервирования'],6.6)
        self.assertAlmostEqual(out.delta,17)
        self.assertAlmostEqual(out.balance_error,0,places=10)
        self.assertEqual(out.fx_clients_covered,1)
        self.assertEqual(out.risk_clients_covered,1)
        self.assertTrue(c['ГР изменилась'])
        self.assertEqual(len(out.gr_migrations),1)
        # GR must NOT enter additive factors or it would double-count.
        self.assertFalse(out.factors['Фактор'].str.contains('ГР').any())

    def test_missing_or_ambiguous_fx_rates_do_not_make_up_fx(self):
        old = snap([{'УНП':'2','Курс':None,'Задолженность, тыс BYN':100,'Резерв факт':10},
                    {'УНП':'3','Курс':3,'Задолженность, тыс BYN':100,'Резерв факт':10},
                    {'УНП':'3','Курс':4,'Задолженность, тыс BYN':100,'Резерв факт':10}])
        new = snap([{'УНП':'2','Курс':3.4,'Задолженность, тыс BYN':120,'Резерв факт':12},
                    {'УНП':'3','Курс':4,'Задолженность, тыс BYN':220,'Резерв факт':22}])
        result = compare_reserves(old,new)
        self.assertAlmostEqual(result.factors.loc[result.factors['Код']=='Валютный эффект (оценка)',
                                                     'Изменение'].iloc[0],0)
        self.assertAlmostEqual(result.balance_error,0)
        self.assertEqual(result.fx_clients_covered,0)

    def test_missing_risk_stays_in_other_rate_and_no_client_merge_without_unp(self):
        old=snap([{'УНП':'4','Резерв факт':10,'Задолженность, тыс BYN':100,'PD, %':None},
                  {'УНП':None,'Резерв факт':5}])
        new=snap([{'УНП':'4','Резерв факт':20,'Задолженность, тыс BYN':100,'PD, %':20},
                  {'УНП':'','Резерв факт':8}])
        r=compare_reserves(old,new)
        self.assertEqual(r.risk_clients_covered,0)
        self.assertEqual(r.unmatched_rows_before,1)
        self.assertAlmostEqual(r.factors.set_index('Код').loc['Прочая доля резервирования','Изменение'],10)
        self.assertAlmostEqual(r.factors.set_index('Код').loc['Без ключа','Изменение'],3)
        self.assertAlmostEqual(r.balance_error,0)

    def test_byn_currency_is_not_fx_even_without_rate(self):
        old=snap([{'УНП':'933','Код валюты':'933','Курс':None,'Резерв факт':10,
                   'Задолженность, тыс BYN':100}])
        new=snap([{'УНП':'933','Код валюты':'933','Курс':None,'Резерв факт':15,
                   'Задолженность, тыс BYN':120}])
        r=compare_reserves(old,new)
        self.assertAlmostEqual(r.clients.iloc[0]['Валютный эффект (оценка)'],0)
        self.assertAlmostEqual(r.balance_error,0)

    def test_total_reconciles_with_new_exit_and_negative_debt(self):
        old=snap([{'УНП':'X','Резерв факт':100,'Задолженность, тыс BYN':-10},
                  {'УНП':'Y','Резерв факт':20,'Задолженность, тыс BYN':50}])
        new=snap([{'УНП':'X','Резерв факт':200,'Задолженность, тыс BYN':-5},
                  {'УНП':'Z','Резерв факт':4,'Задолженность, тыс BYN':100}])
        r=compare_reserves(old,new)
        self.assertAlmostEqual(r.delta,84)
        self.assertAlmostEqual(r.factors['Изменение'].sum(),84)
        self.assertAlmostEqual(r.clients.set_index('Идентификатор').loc['X','Вне модели'],100)


if __name__=='__main__':
    unittest.main()

class IdentifierIntegrityTests(unittest.TestCase):
    def test_leading_zero_unp_and_large_account_preserved_in_csv(self):
        from portfolio_core import load_fixed_portfolio
        from portfolio_schema import EXPECTED_COLUMNS
        data = {c:'' for c in EXPECTED_COLUMNS}
        data.update({'УНП':'001234567', 'Счет':'12345678901234567890',
                     'Код валюты':'840','Задолженность, тыс BYN':'123,50',
                     'Резерв факт':'2,5'})
        raw = pd.DataFrame([data]).to_csv(index=False,sep=';').encode('utf-8-sig')
        df = load_fixed_portfolio(raw,'sample.csv')
        self.assertEqual(df.loc[0,'УНП'],'001234567')
        self.assertEqual(df.loc[0,'Счет'],'12345678901234567890')
        self.assertAlmostEqual(df.loc[0,'Задолженность, тыс BYN'],123.50)
