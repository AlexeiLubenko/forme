"""Ensure the corporate package never installs extra dependencies."""
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]

class CorporateEnvironmentTests(unittest.TestCase):
    def test_no_installer_in_project(self):
        self.assertFalse((ROOT / "setup_environment.py").exists())
    def test_windows_launchers_never_install(self):
        for name in ("start_windows.bat", "check_windows.bat"):
            script = (ROOT / name).read_text(encoding="utf-8")
            self.assertIn('pushd "%~dp0"', script)
            self.assertNotIn("pip install", script.lower())
            self.assertNotIn("venv", script.lower())
    def test_launcher_has_no_installer_dependency(self):
        script = (ROOT / "windows_launcher.py").read_text(encoding="utf-8")
        self.assertNotIn("setup_environment", script)
        self.assertNotIn("pip install", script)
        self.assertIn("sys.executable", script)

if __name__ == "__main__":
    unittest.main()
