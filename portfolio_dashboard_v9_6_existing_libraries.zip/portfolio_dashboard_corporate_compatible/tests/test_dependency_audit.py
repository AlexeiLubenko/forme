"""Regression tests for the offline Windows dependency report."""

from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import check_dependencies as dep


class DependencyAuditTests(unittest.TestCase):
    def test_five_existing_packages_have_fixed_versions(self):
        found = dep.load_requirements()
        self.assertEqual([name for name, _ in found],
                         ["streamlit", "pandas", "numpy", "openpyxl", "plotly"])

    def test_missing_wrong_and_matching_are_separate(self):
        with tempfile.TemporaryDirectory() as td:
            requirements = Path(td) / "requirements.txt"
            requirements.write_text("alpha==1.0\nbeta==2.0\ngamma==3.0\n", encoding="utf-8")
            with patch.object(dep, "installed_version", side_effect=lambda n: {
                "alpha": None, "beta": "1.9", "gamma": "3.0"}.get(n)):
                result = dep.audit(path=requirements, check_transitive=False)
            self.assertEqual(result.missing, [("alpha", "1.0")])
            self.assertEqual(result.different, [("beta", "2.0", "1.9")])
            self.assertEqual(result.ready, [("gamma", "3.0")])
            self.assertFalse(result.ok)
            output = dep.render(result, requirements)
            self.assertIn("[НЕТ] alpha==1.0", output)
            self.assertIn("[ДРУГАЯ ВЕРСИЯ] beta", output)
            self.assertIn("[OK] gamma==3.0", output)
            self.assertIn("установка библиотек ОТКЛЮЧЕНА", output)

    def test_all_matching_is_ready_with_python_313(self):
        with tempfile.TemporaryDirectory() as td:
            requirements = Path(td) / "requirements.txt"
            requirements.write_text("alpha==1.0\n", encoding="utf-8")
            with patch.object(dep, "installed_version", return_value="1.0"), \
                 patch.object(dep.sys, "version_info", (3, 13, 0)):
                result = dep.audit(path=requirements, check_transitive=False)
            self.assertTrue(result.ok)

    def test_wrong_python_flagged(self):
        with tempfile.TemporaryDirectory() as td:
            requirements = Path(td) / "requirements.txt"
            requirements.write_text("alpha==1.0\n", encoding="utf-8")
            with patch.object(dep, "installed_version", return_value="1.0"), \
                 patch.object(dep.sys, "version_info", (3, 12, 0)):
                result = dep.audit(path=requirements, check_transitive=False)
            self.assertFalse(result.python_compatible)
            self.assertFalse(result.ok)

    def test_refuse_unrecognized_requirement_to_avoid_silent_omissions(self):
        with tempfile.TemporaryDirectory() as td:
            requirements = Path(td) / "requirements.txt"
            requirements.write_text("streamlit>=1.0\n", encoding="utf-8")
            with self.assertRaises(ValueError):
                dep.load_requirements(requirements)

    def test_readonly_check_does_not_call_pip_install(self):
        cmd = [sys.executable, str(Path(dep.__file__).resolve()), "--no-report"]
        result = subprocess.run(cmd, capture_output=True, text=True, check=False)
        self.assertIn("ПРОВЕРКА БИБЛИОТЕК ПОРТФЕЛЯ", result.stdout)
        self.assertIn("Проверка ничего не устанавливает", result.stdout)
        self.assertIn(result.returncode, [0, 1, 2])


if __name__ == "__main__":
    unittest.main()
