"""Network paths must be supported by Windows launchers."""
import unittest
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
class WindowsLaunchTests(unittest.TestCase):
    def test_launchers_map_unc_and_restore(self):
        for name in ("start_windows.bat", "check_windows.bat"):
            text = (ROOT / name).read_text(encoding="utf-8")
            self.assertIn('pushd "%~dp0"', text)
            self.assertIn("popd", text)
    def test_no_python_wheel_download_in_scripts(self):
        for name in ("start_windows.bat", "check_windows.bat", "windows_launcher.py"):
            text = (ROOT / name).read_text(encoding="utf-8").lower()
            self.assertNotIn("pip install", text)
            self.assertNotIn("subprocess.run([sys.executable, '-m', 'pip'", text)
if __name__ == "__main__": unittest.main()
