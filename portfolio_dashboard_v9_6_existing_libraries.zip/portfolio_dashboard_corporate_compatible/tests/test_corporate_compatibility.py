"""Check the environment package matches user's installed libraries exactly."""
import unittest
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from portfolio_core import read_portfolio, sheet_names
import check_dependencies

class CorporateCompatibilityTests(unittest.TestCase):
    def test_exact_installed_versions(self):
        self.assertEqual(dict(check_dependencies.load_requirements()), {
            "streamlit":"1.45.1", "pandas":"2.2.3", "numpy":"2.1.3",
            "openpyxl":"3.1.5", "plotly":"5.24.1",
        })
    def test_xls_does_not_require_missing_xlrd(self):
        with self.assertRaisesRegex(ValueError, "xlrd"):
            read_portfolio(b"dummy", "test.xls")
        with self.assertRaisesRegex(ValueError, "xlrd"):
            sheet_names(b"dummy", "test.xls")
    def test_xlsx_is_supported(self):
        import io
        import pandas as pd
        b = io.BytesIO()
        pd.DataFrame({"a":[1]}).to_excel(b, index=False)
        self.assertEqual(read_portfolio(b.getvalue(), "test.xlsx")["a"].iloc[0], 1)

if __name__ == "__main__": unittest.main()
