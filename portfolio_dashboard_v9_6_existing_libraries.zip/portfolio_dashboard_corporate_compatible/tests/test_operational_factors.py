"""Tests for operational/event based reserve stock attribution."""
import sys
from pathlib import Path
import unittest
import pandas as pd
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from reserve_operational_analysis import *


def row(unp='001', contract='A', debt=100, reserve=10, **kwargs):
    r={UNP:unp,CONTRACT:contract,CLIENT:'Альфа',SEGMENT:'Корп',DEBT:debt,
       RESERVE:reserve,OVERDUE:0,DAY:0,'НИ':'Нет','ПФН':'Нет',
       'Рестра':'', 'НВВ':0,COVER:'80%', 'ГР':'2'}
    r.update(kwargs)
    return r


class OperationalFactorsTests(unittest.TestCase):
    def check(self, old, new):
        result=compare_operational(pd.DataFrame(old),pd.DataFrame(new))
        self.assertAlmostEqual(result.balance_error,0,places=8)
        self.assertAlmostEqual(result.delta,result.factors['Изменение'].sum(),places=8)
        return result

    def test_new_contract_same_client(self):
        old=[row()]
        new=[row(),row(contract='B',debt=70,reserve=22)]
        r=self.check(old,new)
        self.assertAlmostEqual(r.factors.set_index('Фактор').loc[F_NEW,'Изменение'],22)
        self.assertEqual(len(r.clients),1)
        self.assertEqual(r.clients.iloc[0]['Договоров — стало'],2)

    def test_decrease_in_debt_estimated_repayment(self):
        r=self.check([row()], [row(debt=60,reserve=6)])
        self.assertAlmostEqual(r.factors.set_index('Фактор').loc[F_REPAY,'Изменение'],-4)
        self.assertAlmostEqual(r.factors.set_index('Фактор').loc[F_OTHER,'Изменение'],0)

    def test_single_events(self):
        cases=[('НИ',F_NI,1),('ПФН',F_PFN,1),('НВВ',F_NVV,1),('Рестра',F_RESTR,'рестр. 4ГР 30%'),
               (COVER,F_COVER,'40%'),(OVERDUE,F_OVERDUE,15), (DAY,F_OVERDUE,20)]
        for col,factor,val in cases:
            with self.subTest(field=col):
                r=self.check([row()], [row(reserve=20,**{col:val})])
                self.assertAlmostEqual(r.factors.set_index('Фактор').loc[factor,'Изменение'],10)
                self.assertAlmostEqual(r.factors.set_index('Фактор').loc[F_OTHER,'Изменение'],0)

    def test_multiple_events_not_double_counted(self):
        r=self.check([row()],[row(reserve=37,**{'НИ':1,COVER:'40%'})])
        f=r.factors.set_index('Фактор')['Изменение']
        self.assertEqual(f[F_NI],0)
        self.assertEqual(f[F_COVER],0)
        self.assertEqual(f[F_MULTI],27)
        self.assertEqual(r.simultaneous_contracts,1)
        self.assertIn('Признание НИ',r.contracts.iloc[0]['Сигналы'])

    def test_blank_old_flag_counts_as_false(self):
        for old_value in [None, '', 0, '0']:
            with self.subTest(old_value=old_value):
                r=self.check([row(**{'НИ':old_value})],[row(reserve=30,**{'НИ':1})])
                self.assertEqual(r.factors.set_index('Фактор').loc[F_NI,'Изменение'],20)

    def test_unrecognized_nonempty_old_flag_stays_unknown(self):
        r=self.check([row(**{'НИ':'?'})], [row(reserve=30,**{'НИ':1})])
        self.assertEqual(r.factors.set_index('Фактор').loc[F_NI,'Изменение'],0)
        self.assertEqual(r.factors.set_index('Фактор').loc[F_OTHER,'Изменение'],20)

    def test_disappearing_contract_not_assumed_repayment(self):
        r=self.check([row(),row(contract='B',reserve=15)], [row()])
        self.assertAlmostEqual(r.factors.set_index('Фактор').loc[F_GONE,'Изменение'],-15)
        self.assertAlmostEqual(r.factors.set_index('Фактор').loc[F_REPAY,'Изменение'],0)

    def test_duplicate_contract_lines_aggregate(self):
        old=[row(debt=40,reserve=4),row(debt=60,reserve=6)]
        new=[row(debt=30,reserve=3),row(debt=40,reserve=4)]
        r=self.check(old,new)
        self.assertEqual(len(r.contracts),1)
        self.assertAlmostEqual(r.contracts.iloc[0][F_REPAY],-3)

    def test_missing_keys_kept_in_bridge(self):
        old=[row(unp=None,reserve=5),row(contract=None,reserve=10)]
        new=[row(unp=None,reserve=7),row(contract=None,reserve=12)]
        r=self.check(old,new)
        f=r.factors.set_index('Фактор')['Изменение']
        self.assertEqual(f[F_NO_UNP],2)
        self.assertEqual(f[F_NO_CONTRACT],2)
        self.assertEqual(len(r.contracts),0)

    def test_negative_debt(self):
        r=self.check([row(debt=-3,reserve=8)], [row(debt=-5,reserve=12)])
        self.assertEqual(r.factors.set_index('Фактор').loc[F_ATYPICAL,'Изменение'],4)

    def test_row_level_no_double_count_with_volume_and_event(self):
        r=self.check([row()], [row(debt=80,reserve=18,**{'НИ':1})])
        f=r.factors.set_index('Фактор')['Изменение']
        self.assertAlmostEqual(f[F_REPAY],-2)
        self.assertAlmostEqual(f[F_NI],10)
        self.assertAlmostEqual(f.sum(),8)

    def test_nvv_blank_to_one_and_reversions(self):
        for previous in ['', None, 0, '0']:
            with self.subTest(value=previous):
                r=self.check([row(**{'НВВ':previous})],
                             [row(reserve=25, **{'НВВ':1})])
                self.assertAlmostEqual(r.factors.set_index('Фактор').loc[F_NVV,'Изменение'],15)
        r=self.check([row(**{'НВВ':1})],[row(reserve=5,**{'НВВ':0})])
        self.assertAlmostEqual(r.factors.set_index('Фактор').loc[F_NVV,'Изменение'],0)
        self.assertAlmostEqual(r.factors.set_index('Фактор').loc[F_OTHER,'Изменение'],-5)

    def test_restructuring_text_change_is_not_new_event(self):
        r=self.check([row(**{'Рестра':'Рестр. 4ГР 30%'})],
                     [row(reserve=35,**{'Рестра':'реструктуризация 5ГР 45%'})])
        self.assertEqual(r.factors.set_index('Фактор').loc[F_RESTR,'Изменение'],0)
        self.assertEqual(r.factors.set_index('Фактор').loc[F_OTHER,'Изменение'],25)
        self.assertEqual(r.contracts.iloc[0]['Рестра (было)'],'Рестр. 4ГР 30%')
        self.assertEqual(r.contracts.iloc[0]['Рестра (стало)'],'реструктуризация 5ГР 45%')

    def test_restructuring_blank_to_text_with_capitalization(self):
        for old in ['',None,'0']:
            with self.subTest(old=old):
                r=self.check([row(**{'Рестра':old})],
                             [row(reserve=29,**{'Рестра':'  РеСтР. 4ГР 30% '})])
                self.assertAlmostEqual(r.factors.set_index('Фактор').loc[F_RESTR,'Изменение'],19)

    def test_nvv_and_restructuring_both_detected_without_double_count(self):
        r=self.check([row()],[row(reserve=30,**{'НВВ':1,'Рестра':'рестр. 4ГР 30%'})])
        self.assertEqual(r.factors.set_index('Фактор').loc[F_NVV,'Изменение'],0)
        self.assertEqual(r.factors.set_index('Фактор').loc[F_RESTR,'Изменение'],0)
        self.assertEqual(r.factors.set_index('Фактор').loc[F_MULTI,'Изменение'],20)

    def test_multiline_contract_flags_aggregate(self):
        first=[row(debt=50,reserve=5,**{'НИ':'','Рестра':''}),
               row(debt=50,reserve=5,**{'НИ':0,'Рестра':''})]
        second=[row(debt=50,reserve=10,**{'НИ':1,'Рестра':''}),
                row(debt=50,reserve=10,**{'НИ':'','Рестра':''})]
        r=self.check(first,second)
        self.assertEqual(len(r.contracts),1)
        self.assertAlmostEqual(r.factors.set_index('Фактор').loc[F_NI,'Изменение'],10)

    def test_demo_files(self):
        from portfolio_core import load_fixed_portfolio
        root=Path(__file__).resolve().parents[1]
        files=[root/'demo_2026-09-30.csv',root/'demo_2026-10-29.csv']
        frames=[load_fixed_portfolio(p.read_bytes(),p.name) for p in files]
        r=compare_operational(*frames)
        self.assertAlmostEqual(r.delta,r.factors['Изменение'].sum(),places=6)

if __name__=='__main__':unittest.main()
