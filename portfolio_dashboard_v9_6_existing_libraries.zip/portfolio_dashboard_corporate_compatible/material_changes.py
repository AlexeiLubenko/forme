"""Material client reserve movements and traceable explanatory notes.

Amounts in the source analysis are THOUSANDS of BYN. 100.0 = 0.1m BYN.
Comments describe observed contract-level events, not accounting causation.
"""
from __future__ import annotations
from dataclasses import dataclass
import math
import pandas as pd

from reserve_operational_analysis import (
    OperationalAnalysis, UNP, CONTRACT, F_NEW, F_GONE, F_REPAY, F_GROW,
    F_NI, F_PFN, F_NVV, F_RESTR, F_COVER, F_OVERDUE, F_MULTI, F_OTHER,
    FACTOR_ORDER,
)

MATERIAL_THRESHOLD_THOUSAND_BYN = 100.0
EPS = 1e-8


@dataclass
class MaterialClientReport:
    material: pd.DataFrame
    other_clients_count: int
    other_clients_delta: float
    all_clients_count: int
    material_delta: float
    unmatched_delta: float
    gross_movement: float
    balance_error: float
    threshold_thousand_byn: float


def _value(x) -> str:
    if pd.isna(x):
        return 'не указано'
    return str(x)


def _num(x, decimal: int = 1) -> str:
    if pd.isna(x):
        return 'н/д'
    return f'{float(x):,.{decimal}f}'.replace(',', ' ')


def _signed(x) -> str:
    return f'{"+" if x >= 0 else "−"}{_num(abs(x))}'


def _activated(row: pd.Series, flag: str) -> bool:
    a, b = row.get(f'{flag} (было)'), row.get(f'{flag} (стало)')
    return pd.notna(a) and pd.notna(b) and not bool(a) and bool(b)


def _changes(row: pd.Series) -> list[str]:
    """Summarize only observed changes in a continued contract."""
    events = []
    delta_debt = float(row['Задолженность — стало'] - row['Задолженность — было'])
    if delta_debt < -EPS:
        events.append(f'снижение задолженности на {_num(-delta_debt)} тыс. BYN (возможное погашение)')
    elif delta_debt > EPS:
        events.append(f'рост задолженности на {_num(delta_debt)} тыс. BYN')
    for flag in ('НИ', 'ПФН', 'НВВ'):
        if _activated(row, flag):
            events.append(f'признан {flag}')
    if _activated(row, 'Рестра — статус'):
        events.append('появилась реструктуризация: ' + _value(row.get('Рестра (стало)')))
    c0,c1=row.get('Обеспеченность (было)'),row.get('Обеспеченность (стало)')
    if pd.notna(c0) and pd.notna(c1) and str(c0) != str(c1):
        events.append(f'обеспеченность {_value(c0)} → {_value(c1)}')
    o0,o1=row.get('Просрочка — было'),row.get('Просрочка — стало')
    if pd.notna(o0) and pd.notna(o1) and abs(float(o1)-float(o0))>EPS:
        events.append(f'просрочка {_num(o0)} → {_num(o1)} тыс. BYN')
    day0,day1=row.get('Дней просрочки — было'),row.get('Дней просрочки — стало')
    if pd.notna(day0) and pd.notna(day1) and abs(float(day1)-float(day0))>EPS:
        events.append(f'дней просрочки {_num(day0,0)} → {_num(day1,0)}')
    return events


def _note_for_contract(row: pd.Series) -> str:
    contract=_value(row[CONTRACT])
    change=float(row['Δ резерва'])
    status=row['Статус']
    if status=='Новый договор':
        return f'новый договор {contract}: резерв {_signed(change)} тыс. BYN'
    if status=='Выбывший договор':
        return f'договор {contract} выбыл: резерв {_signed(change)} тыс. BYN (причина выбытия не установлена)'
    events=_changes(row)
    explanation='; '.join(events) if events else 'явных событий по отслеживаемым полям нет'
    return f'договор {contract}: {explanation}; Δ резерва {_signed(change)} тыс. BYN'


def _short_factors(client: pd.Series) -> str:
    contributions = [(name, float(client[name])) for name in FACTOR_ORDER
                     if name in client and pd.notna(client[name]) and abs(float(client[name])) > EPS]
    contributions.sort(key=lambda pair: abs(pair[1]), reverse=True)
    return '; '.join(f'{name} ({_signed(val)})' for name,val in contributions[:4]) or 'Не выявлены'


def _explain(client: pd.Series, contracts: pd.DataFrame, max_contracts: int = 3) -> str:
    total=float(client['Δ резерва'])
    direction = 'Увеличение' if total >= 0 else 'Снижение'
    intro = f'{direction} резерва на {_num(abs(total))} тыс. BYN.'
    # Prioritize largest contract movements; avoid claims of causality from mere correlation.
    c=contracts.sort_values('Δ резерва',key=lambda s:s.abs(),ascending=False)
    relevant=c.loc[c['Δ резерва'].abs() > EPS]
    if relevant.empty:
        return intro+' Изменения договоров взаимно компенсировались; требуется детализация.'
    parts=[_note_for_contract(row) for _,row in relevant.head(max_contracts).iterrows()]
    if len(relevant)>max_contracts:
        parts.append(f'ещё {len(relevant)-max_contracts} договор(ов) с изменениями')
    return intro+' '+'; '.join(parts)+'.'


def build_material_client_report(
    result: OperationalAnalysis, threshold_thousand_byn: float = MATERIAL_THRESHOLD_THOUSAND_BYN,
) -> MaterialClientReport:
    """Partition clients by inclusive |Δ reserve| >= threshold; reconcile to full Δ.

    Clients with unknown UNP or contract number are NOT falsely assigned to a
    named UNP; unmatched balance difference is kept separately.
    """
    if not math.isfinite(threshold_thousand_byn) or threshold_thousand_byn < 0:
        raise ValueError('Порог должен быть конечным неотрицательным числом')
    clients=result.clients.copy()
    # The portfolio can contain hundreds of thousands of clients: only create
    # expensive explanations for material ones, never for the remainder.
    mask = clients['Δ резерва'].abs() >= threshold_thousand_byn
    big = clients.loc[mask].copy().sort_values('Δ резерва', key=lambda s:s.abs(), ascending=False)
    if big.empty:
        big['Комментарий'] = pd.Series(index=big.index,dtype='string')
        big['Основные факторы'] = pd.Series(index=big.index,dtype='string')
    else:
        included = set(big[UNP].astype(str))
        contracts = result.contracts.loc[result.contracts[UNP].astype(str).isin(included)]
        contract_groups = {key: group for key,group in contracts.groupby(UNP,sort=False)}
        big['Комментарий'] = [
            _explain(row,contract_groups.get(row[UNP], contracts.iloc[:0]))
            for _,row in big.iterrows()
        ]
        big['Основные факторы'] = big.apply(_short_factors,axis=1)
    rest = clients.loc[~mask]
    big_sum = float(big['Δ резерва'].sum())
    rest_sum = float(rest['Δ резерва'].sum())
    unmatched = float(result.delta - float(clients['Δ резерва'].sum()))
    gross=float(clients['Δ резерва'].abs().sum())
    error=float(result.delta-big_sum-rest_sum-unmatched)
    return MaterialClientReport(
        material=big, other_clients_count=len(rest), other_clients_delta=rest_sum,
        all_clients_count=len(clients), material_delta=big_sum,
        unmatched_delta=unmatched, gross_movement=gross, balance_error=error,
        threshold_thousand_byn=threshold_thousand_byn,
    )
