#!/bin/sh
set -e
cd "$(dirname "$0")"
python3 -m streamlit run portfolio_app.py --server.address=127.0.0.1
