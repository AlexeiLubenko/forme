"""Local immutable dated portfolio snapshots; SQLite catalogue and audited storage.

Migrates the database used by v2/v3 in place. Raw original files are never rewritten.
Only report-date metadata for historical snapshots may be assigned/updated.
"""
from __future__ import annotations

from contextlib import contextmanager
from datetime import date, datetime, timezone
from hashlib import sha256
from pathlib import Path
import os
import sqlite3
import tempfile

from portfolio_core import load_fixed_portfolio


class PortfolioStore:
    def __init__(self, root: str | Path):
        self.root = Path(root).resolve()
        self.root.mkdir(parents=True, exist_ok=True)
        self.blobs = self.root / "blobs"
        self.blobs.mkdir(parents=True, exist_ok=True)
        self.database = self.root / "portfolio.sqlite3"
        with self._connect() as conn:
            conn.executescript("""
                CREATE TABLE IF NOT EXISTS versions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    created_at TEXT NOT NULL,
                    title TEXT NOT NULL,
                    note TEXT NOT NULL DEFAULT '',
                    filename TEXT NOT NULL,
                    sheet TEXT NOT NULL,
                    header_row INTEGER NOT NULL,
                    content_sha256 TEXT NOT NULL,
                    blob_name TEXT NOT NULL,
                    rows_count INTEGER NOT NULL,
                    columns_count INTEGER NOT NULL,
                    parent_version_id INTEGER REFERENCES versions(id)
                );
                CREATE TABLE IF NOT EXISTS config (
                    id INTEGER PRIMARY KEY CHECK (id = 1),
                    active_version_id INTEGER REFERENCES versions(id)
                );
                INSERT OR IGNORE INTO config(id, active_version_id) VALUES (1, NULL);
                CREATE TABLE IF NOT EXISTS audit (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    created_at TEXT NOT NULL,
                    action TEXT NOT NULL,
                    from_version INTEGER,
                    to_version INTEGER NOT NULL REFERENCES versions(id),
                    details TEXT NOT NULL DEFAULT ''
                );
            """)
            names = {r[1] for r in conn.execute('PRAGMA table_info(versions)')}
            for name, dtype in (
                ('parent_version_id', 'INTEGER'),
                ('report_date', 'TEXT'),
                ('debt_total', 'REAL'),
                ('reserve_total', 'REAL'),
                ('overdue_total', 'REAL'),
            ):
                if name not in names:
                    conn.execute(f'ALTER TABLE versions ADD COLUMN {name} {dtype}')
            # Legacy duplicates may exist without report_date. Enforce one assigned
            # snapshot per reporting date from now on, even across browser sessions.
            conn.execute('''CREATE UNIQUE INDEX IF NOT EXISTS ux_versions_report_date
                            ON versions(report_date) WHERE report_date IS NOT NULL''')

    @contextmanager
    def _connect(self):
        conn = sqlite3.connect(self.database, timeout=30)
        try:
            conn.execute('PRAGMA foreign_keys=ON')
            conn.execute('PRAGMA busy_timeout=30000')
            conn.row_factory = sqlite3.Row
            yield conn
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    @staticmethod
    def _now():
        return datetime.now(timezone.utc).isoformat(timespec='seconds')

    @staticmethod
    def _date(value: date | str | None) -> str | None:
        if value is None or value == '':
            return None
        if isinstance(value, datetime):
            return value.date().isoformat()
        if isinstance(value, date):
            return value.isoformat()
        return date.fromisoformat(str(value)).isoformat()

    def save(self, raw: bytes, filename: str, sheet: str, header_row: int,
             title: str, note: str = '', report_date: date | str | None = None) -> int:
        """Store one validated immutable source file, with a dated catalogue entry."""
        suffix = Path(filename).suffix.lower()
        if suffix not in {'.xlsx', '.xlsm', '.xls', '.csv'}:
            raise ValueError('Поддерживаются XLSX, XLSM, XLS и CSV. Экспортируйте Numbers в XLSX.')
        if not raw or len(raw) > 200 * 1024 * 1024:
            raise ValueError('Пустой файл или превышен лимит 200 МБ.')
        if not title.strip():
            raise ValueError('Введите название портфеля.')
        iso = self._date(report_date)
        frame = load_fixed_portfolio(raw, filename, sheet, header_row)
        if frame.empty:
            raise ValueError('Нельзя загрузить пустой портфель.')
        if iso:
            with self._connect() as conn:
                if conn.execute('SELECT id FROM versions WHERE report_date=?', (iso,)).fetchone():
                    raise ValueError(f'На {iso} уже есть портфель. Снимки по датам не перезаписываются.')
        digest = sha256(raw).hexdigest()
        blob_name = digest + suffix
        dest = self.blobs / blob_name
        if not dest.exists():
            fd, temp_name = tempfile.mkstemp(prefix='snapshot_', suffix='.tmp', dir=self.blobs)
            try:
                with os.fdopen(fd, 'wb') as stream:
                    stream.write(raw)
                    stream.flush()
                    os.fsync(stream.fileno())
                os.chmod(temp_name, 0o600)
                os.replace(temp_name, dest)
            finally:
                if os.path.exists(temp_name):
                    os.unlink(temp_name)
        totals = [float(frame[field].sum()) for field in (
            'Задолженность, тыс BYN', 'Резерв факт',
            'Просроченная задолженность, тыс. BYN')]
        try:
            with self._connect() as conn:
                conn.execute('BEGIN IMMEDIATE')
                old = conn.execute('SELECT active_version_id FROM config WHERE id=1').fetchone()[0]
                cursor = conn.execute('''INSERT INTO versions (
                        created_at, title, note, filename, sheet, header_row,
                        content_sha256, blob_name, rows_count, columns_count,
                        parent_version_id, report_date, debt_total, reserve_total, overdue_total)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NULL, ?, ?, ?, ?)''',
                    (self._now(), title.strip()[:150], note.strip()[:1000],
                     Path(filename).name[:255], str(sheet), int(header_row),
                     digest, blob_name, len(frame), len(frame.columns), iso, *totals))
                vid = int(cursor.lastrowid)
                conn.execute('UPDATE config SET active_version_id=? WHERE id=1', (vid,))
                conn.execute('''INSERT INTO audit(created_at, action, from_version, to_version, details)
                    VALUES (?, 'snapshot_upload', ?, ?, ?)''',
                    (self._now(), old, vid, f'Дата: {iso or "не задана"}'))
        except sqlite3.IntegrityError as error:
            raise ValueError(f'На {iso} уже есть портфель. Выберите другую дату.') from error
        return vid

    def list_versions(self) -> list[dict]:
        with self._connect() as conn:
            result = conn.execute('''SELECT v.*, (v.id = c.active_version_id) AS is_active
                FROM versions v CROSS JOIN config c
                ORDER BY (v.report_date IS NULL), v.report_date DESC, v.id DESC''').fetchall()
        return [dict(r) for r in result]

    def get_version(self, version_id: int) -> dict:
        with self._connect() as conn:
            row = conn.execute('''SELECT v.*, (v.id = c.active_version_id) AS is_active
                FROM versions v CROSS JOIN config c WHERE v.id=?''', (int(version_id),)).fetchone()
        if row is None:
            raise KeyError(f'Снимок #{version_id} не найден')
        return dict(row)

    def active_id(self) -> int | None:
        with self._connect() as conn:
            return conn.execute('SELECT active_version_id FROM config WHERE id=1').fetchone()[0]

    def raw_bytes(self, version_id: int) -> bytes:
        meta = self.get_version(version_id)
        raw = (self.blobs / meta['blob_name']).read_bytes()
        if sha256(raw).hexdigest() != meta['content_sha256']:
            raise IOError('Контрольная сумма исходного портфеля не совпадает.')
        return raw

    def load(self, version_id: int):
        meta = self.get_version(version_id)
        return load_fixed_portfolio(self.raw_bytes(version_id), meta['filename'], meta['sheet'], meta['header_row'])

    def set_report_date(self, version_id: int, report_date: date | str) -> None:
        """Assign/correct *catalogue metadata* only; the source file stays immutable."""
        iso = self._date(report_date)
        if iso is None:
            raise ValueError('Укажите отчётную дату.')
        try:
            with self._connect() as conn:
                conn.execute('BEGIN IMMEDIATE')
                old = conn.execute('SELECT report_date FROM versions WHERE id=?', (version_id,)).fetchone()
                if old is None:
                    raise KeyError(version_id)
                if old[0] == iso:
                    return
                conn.execute('UPDATE versions SET report_date=? WHERE id=?', (iso, version_id))
                conn.execute('''INSERT INTO audit(created_at, action, from_version, to_version, details)
                    VALUES (?, 'date_metadata', ?, ?, ?)''',
                    (self._now(), version_id, version_id, f'{old[0]} → {iso}'))
        except sqlite3.IntegrityError as error:
            raise ValueError('На эту отчётную дату уже сохранён другой портфель.') from error

    def update_summary(self, version_id: int) -> None:
        """Populate missing aggregate metadata for old v2/v3 snapshots."""
        frame = self.load(version_id)
        amounts = [float(frame[c].sum()) for c in (
            'Задолженность, тыс BYN', 'Резерв факт',
            'Просроченная задолженность, тыс. BYN')]
        with self._connect() as conn:
            conn.execute('UPDATE versions SET debt_total=?, reserve_total=?, overdue_total=? WHERE id=?',
                         (*amounts, version_id))

    def restore(self, version_id: int) -> None:
        """Set default displayed snapshot only (never change its content)."""
        self.raw_bytes(version_id)
        with self._connect() as conn:
            conn.execute('BEGIN IMMEDIATE')
            old = conn.execute('SELECT active_version_id FROM config WHERE id=1').fetchone()[0]
            if old == version_id:
                return
            conn.execute('UPDATE config SET active_version_id=? WHERE id=1', (version_id,))
            conn.execute('''INSERT INTO audit(created_at, action, from_version, to_version, details)
                VALUES (?, 'select_snapshot', ?, ?, ?)''', (self._now(), old, version_id,
                    'Изменён снимок по умолчанию'))

    def audit_log(self) -> list[dict]:
        with self._connect() as conn:
            return [dict(r) for r in conn.execute('SELECT * FROM audit ORDER BY id DESC').fetchall()]
