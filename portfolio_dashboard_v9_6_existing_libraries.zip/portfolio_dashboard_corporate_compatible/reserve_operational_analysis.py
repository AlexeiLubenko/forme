"""Contract-level reserve stock bridge for immutable dated bank portfolios.

All money is thousand BYN. Contract identity: (UNP, Contract number).
This is a deterministic *attribution by observed signals*, not a causal estimate
of accounting expense. Multiple simultaneous signals are reported in a separate
bucket instead of double-counted. A residual always reconciles the balance.
"""
from __future__ import annotations
from dataclasses import dataclass
import numpy as np
import pandas as pd

UNP = 'УНП'
CONTRACT = 'Номер договора'
CLIENT = 'Клиент'
SEGMENT = 'Сегмент'
DEBT = 'Задолженность, тыс BYN'
RESERVE = 'Резерв факт'
OVERDUE = 'Просроченная задолженность, тыс. BYN'
DAY = 'Day OD'
COVER = 'Обеспеченность'
FLAGS = {'НИ': 'Признание НИ', 'ПФН': 'Признание ПФН', 'НВВ': 'Признание НВВ', 'Рестра': 'Реструктуризация'}
F_NEW = 'Новые договоры'
F_REPAY = 'Погашение (оценка)'
F_NI = 'Признание НИ'
F_PFN = 'Признание ПФН'
F_NVV = 'Признание НВВ'
F_RESTR = 'Реструктуризация'
F_COVER = 'Изменение обеспеченности'
F_OVERDUE = 'Изменение просрочки'
F_GROW = 'Рост задолженности'
F_GONE = 'Выбывшие договоры'
F_MULTI = 'Совместное влияние факторов'
F_OTHER = 'Прочие изменения'
F_ATYPICAL = 'Нетипичная задолженность'
F_NO_CONTRACT = 'Без номера договора'
F_NO_UNP = 'Без УНП'
FACTOR_ORDER = [F_NEW,F_REPAY,F_NI,F_PFN,F_NVV,F_RESTR,F_COVER,F_OVERDUE,
                F_GROW,F_GONE,F_MULTI,F_OTHER,F_ATYPICAL,F_NO_CONTRACT,F_NO_UNP]
CORE_FACTORS = [F_NEW,F_REPAY,F_NI,F_PFN,F_NVV,F_RESTR,F_COVER,F_OVERDUE]


@dataclass
class OperationalAnalysis:
    contracts: pd.DataFrame
    clients: pd.DataFrame
    factors: pd.DataFrame
    segments: pd.DataFrame
    total_before: float
    total_after: float
    delta: float
    debt_before: float
    debt_after: float
    balance_error: float
    unmatched_unp_before: int
    unmatched_unp_after: int
    unmatched_contract_before: int
    unmatched_contract_after: int
    invalid_reserve_before: int
    invalid_reserve_after: int
    invalid_debt_before: int
    invalid_debt_after: int
    continuing_contracts: int
    simultaneous_contracts: int


def _key(col: pd.Series) -> pd.Series:
    s = col.astype('string').str.strip().str.replace(r'\s+', '', regex=True)
    s = s.str.replace(r'^(\d+)\.0$',r'\1',regex=True)
    return s.mask(s.str.lower().isin(['','nan','null','none','<na>']))


def _number(df: pd.DataFrame, name: str) -> pd.Series:
    if name not in df:
        return pd.Series(np.nan, index=df.index, dtype='float64')
    return pd.to_numeric(df[name],errors='coerce').astype(float)


def _text(df: pd.DataFrame, name: str) -> pd.Series:
    if name not in df:
        return pd.Series(pd.NA, index=df.index, dtype='string')
    s = df[name].astype('string').str.strip()
    return s.mask(s.str.lower().isin(['','nan','null','none','<na>']))


# NI / PFN / NVV: 1 => recognized, 0 or empty => absent.
# Resturcturing (Рестра): free-form annotation, e.g. «рестр. 4ГР 30%».
# Unknown nonempty values stay NA: we do not silently classify them as false.
_TRUE = {'1', '1.0', 'да', 'yes', 'true', 'истина'}
_FALSE = {'0', '0.0', 'нет', 'no', 'false', 'ложь', '-'}
_BLANK = {'', 'nan', 'null', 'none', '<na>'}


def _flag(s: pd.Series, *, restructuring: bool = False) -> pd.Series:
    normalized = (s.astype('string').str.lower().str.strip()
                  .str.replace(r'\s+', ' ', regex=True))
    result = pd.Series(pd.NA, index=s.index, dtype='boolean')
    no = normalized.isna() | normalized.isin(_FALSE | _BLANK)
    yes = normalized.isin(_TRUE)
    if restructuring:
        # Full text is preserved separately for display. The substring must
        # actually denote restructuring (not just any free-form annotation).
        yes = yes | normalized.str.contains(r'рестр', case=False, regex=True, na=False)
    result.loc[no.fillna(False)] = False
    result.loc[yes.fillna(False)] = True
    return result


def _group_flag(t: pd.DataFrame, col: str) -> pd.Series:
    """For multi-line contracts: 1 in any line wins; 0/empty in all lines => 0.

    Mixed 1 + empty is positive (many accounts per contract). If there are
    unrecognised values and no positive flags, state is unknown.
    """
    keys = [t['_unp'], t['_contract']]
    yes = t[col].eq(True).fillna(False).groupby(keys, sort=False).any()
    no = t[col].eq(False).fillna(False).groupby(keys, sort=False).all()
    result = pd.Series(pd.NA, index=yes.index, dtype='boolean')
    result.loc[yes] = True
    result.loc[~yes & no] = False
    result.index.names = [UNP, CONTRACT]
    return result


def _uniform(g: pd.core.groupby.generic.DataFrameGroupBy, source: pd.Series) -> pd.Series:
    """One unambiguous value per contract; missing/mixed values => NA."""
    vals = source.groupby([g.obj['_unp'], g.obj['_contract']], dropna=False, sort=False)
    first = vals.first()
    fully = vals.count().eq(vals.size()) & vals.nunique(dropna=True).eq(1)
    return first.where(fully)


def _snapshot(df: pd.DataFrame):
    if UNP not in df or CONTRACT not in df or DEBT not in df or RESERVE not in df:
        raise ValueError('Нужны колонки УНП, Номер договора, задолженность и Резерв факт')
    t = pd.DataFrame(index=df.index)
    t['_unp'] = _key(df[UNP])
    t['_contract'] = _key(df[CONTRACT])
    t['_debt'] = _number(df, DEBT)
    t['_reserve'] = _number(df, RESERVE)
    t['_overdue'] = _number(df, OVERDUE)
    t['_day'] = _number(df, DAY)
    t[COVER] = _text(df, COVER)
    for f in FLAGS:
        t[f] = _flag(_text(df, f), restructuring=(f == 'Рестра'))
    t['_restra_text'] = _text(df, 'Рестра')
    for f in [CLIENT, SEGMENT, 'ГР']:
        t[f] = _text(df, f)

    missing_unp = t['_unp'].isna()
    missing_contract = ~missing_unp & t['_contract'].isna()
    quality = {
        'missing_unp': int(missing_unp.sum()),
        'missing_contract': int(missing_contract.sum()),
        'missing_unp_reserve': float(t.loc[missing_unp,'_reserve'].sum()),
        'missing_contract_reserve': float(t.loc[missing_contract,'_reserve'].sum()),
        'invalid_reserve': int(t['_reserve'].isna().sum()),
        'invalid_debt': int(t['_debt'].isna().sum()),
    }
    t = t.loc[~missing_unp & ~missing_contract].copy()
    if t.empty:
        empty = pd.DataFrame(index=pd.MultiIndex.from_arrays([[],[]], names=[UNP,CONTRACT]))
        empty = empty.reindex(columns=['D','R','O','Day',COVER,*FLAGS,'_restra_text',CLIENT,SEGMENT,'ГР','rows'])
        return empty,quality
    g = t.groupby(['_unp','_contract'],sort=False,dropna=False)
    base = g.agg(D=('_debt','sum'),R=('_reserve','sum'),O=('_overdue','sum'),
                 Day=('_day','max'),rows=('_debt','size'))
    base.index.names = [UNP,CONTRACT]
    # Require consistent categorical values across lines of the same contract.
    for label in [COVER,CLIENT,SEGMENT,'ГР']:
        base[label] = _uniform(g,t[label]).reindex(base.index)
    for label in FLAGS:
        base[label] = _group_flag(t,label).reindex(base.index)
    # The restructuring description is preserved without treating free-text
    # changes between two active statuses as fresh recognition.
    base['_restra_text'] = t['_restra_text'].groupby(
        [t['_unp'], t['_contract']], sort=False).agg(
        lambda values: '; '.join(dict.fromkeys(values.dropna().astype(str))) or pd.NA
    ).reindex(base.index)
    return base,quality


def compare_operational(before: pd.DataFrame, after: pd.DataFrame) -> OperationalAnalysis:
    """Build exact bridge at contract level, then aggregate to UNP.

    Continued contracts: a change in debt is allocated at old reserve/debt
    ratio (negative = repayment proxy, positive = debt growth).
    Remaining change in booked reserve is assigned to ONE detected event,
    'simultaneous signals' if >1, otherwise 'other changes'.
    """
    a,qa = _snapshot(before)
    b,qb = _snapshot(after)
    m = a.add_suffix('_0').join(b.add_suffix('_1'),how='outer')
    idx = m.index
    p0 = m['rows_0'].notna()
    p1 = m['rows_1'].notna()
    new = ~p0 & p1
    gone = p0 & ~p1
    old_debt = m['D_0'].fillna(0).astype(float)
    new_debt = m['D_1'].fillna(0).astype(float)
    old_res = m['R_0'].fillna(0).astype(float)
    new_res = m['R_1'].fillna(0).astype(float)
    dr = new_res-old_res
    continuing = p0 & p1
    standard = continuing & old_debt.gt(0) & new_debt.ge(0)
    other_debt = continuing & ~standard
    components = pd.DataFrame(0.0, index=idx,columns=FACTOR_ORDER)
    components[F_NEW] = new_res.where(new,0.0)
    components[F_GONE] = -old_res.where(gone,0.0)
    components[F_ATYPICAL] = dr.where(other_debt,0.0)
    rate0 = (old_res / old_debt.where(standard)).replace([np.inf,-np.inf],np.nan).fillna(0)
    delta_debt = new_debt-old_debt
    components[F_REPAY] = (delta_debt.clip(upper=0)*rate0).where(standard,0.0)
    components[F_GROW] = (delta_debt.clip(lower=0)*rate0).where(standard,0.0)
    residual = dr-components[F_REPAY]-components[F_GROW]

    def flag_increased(name: str) -> pd.Series:
        # Recognition is a transition 0/empty -> 1/text. Unknown stays unknown.
        old = m[f'{name}_0'].astype('boolean').fillna(False)
        nxt = m[f'{name}_1'].astype('boolean').fillna(False)
        known0 = m[f'{name}_0'].notna()
        known1 = m[f'{name}_1'].notna()
        return continuing & known0 & known1 & ~old & nxt

    signals = pd.DataFrame(index=idx)
    for source,name in FLAGS.items():
        signals[name] = flag_increased(source).astype(bool)
    cover0 = m[f'{COVER}_0'].astype('string')
    cover1 = m[f'{COVER}_1'].astype('string')
    signals[F_COVER] = (continuing & cover0.notna() & cover1.notna() & cover0.ne(cover1).fillna(False)).astype(bool)
    od0 = m['O_0'].astype(float)
    od1 = m['O_1'].astype(float)
    days0 = m['Day_0'].astype(float)
    days1 = m['Day_1'].astype(float)
    overdue_change = (od0.notna() & od1.notna() & (od0-od1).abs().gt(1e-8))
    days_change = (days0.notna() & days1.notna() & (days0-days1).abs().gt(1e-8))
    signals[F_OVERDUE] = (continuing & (overdue_change | days_change)).astype(bool)
    signals = signals.fillna(False)
    number_of_signals = signals.sum(axis=1)
    for name in signals:
        mask = standard & number_of_signals.eq(1) & signals[name]
        components.loc[mask,name] = residual.loc[mask]
    joint = standard & number_of_signals.gt(1)
    components.loc[joint,F_MULTI] = residual.loc[joint]
    no_signal = standard & number_of_signals.eq(0)
    components.loc[no_signal,F_OTHER] = residual.loc[no_signal]

    out = pd.DataFrame(index=idx)
    out['Статус'] = np.select([new,gone],['Новый договор','Выбывший договор'],default='Действующий')
    out['Задолженность — было'] = old_debt
    out['Задолженность — стало'] = new_debt
    out['Резерв — было'] = old_res
    out['Резерв — стало'] = new_res
    out['Δ резерва'] = dr
    out['Δ задолженности'] = delta_debt
    out['Просрочка — было'] = m['O_0']
    out['Просрочка — стало'] = m['O_1']
    out['Дней просрочки — было'] = m['Day_0']
    out['Дней просрочки — стало'] = m['Day_1']
    for c in [CLIENT,SEGMENT,'ГР',COVER,*FLAGS]:
        source = '_restra_text' if c == 'Рестра' else c
        out[c+' (было)'] = m[source+'_0']
        out[c+' (стало)'] = m[source+'_1']
    out['Рестра — статус (было)'] = m['Рестра_0']
    out['Рестра — статус (стало)'] = m['Рестра_1']
    out['Клиент'] = out[CLIENT+' (стало)'].combine_first(out[CLIENT+' (было)']).fillna('—')
    out['Сегмент'] = out[SEGMENT+' (стало)'].combine_first(out[SEGMENT+' (было)']).fillna('—')
    for name in FACTOR_ORDER:
        out[name] = components[name]
    out['Количество сигналов'] = number_of_signals
    out['Сигналы'] = signals.apply(lambda r:', '.join(r.index[r.to_numpy(dtype=bool)]), axis=1)
    out['Сигналы'] = out['Сигналы'].replace('', 'Нет подтверждённых переходов')
    out.loc[new,'Сигналы'] = 'Появился новый договор'
    out.loc[gone,'Сигналы'] = 'Договор отсутствует в новом снимке; причина выбытия неизвестна'
    out.loc[other_debt,'Сигналы'] = 'Нулевой/отрицательный остаток: детализация недоступна'
    out['Фактор риска'] = np.select([joint,no_signal], [F_MULTI,F_OTHER], default='')
    for name in signals:
        chosen = standard & number_of_signals.eq(1) & signals[name]
        out.loc[chosen,'Фактор риска'] = name
    out = out.reset_index()
    # Contract-level detail to UNP. Multi-contract clients are aggregated AFTER
    # classification; a new contract to an existing UNP is never lost.
    factor_cols = list(FACTOR_ORDER)
    numerics = factor_cols + ['Резерв — было','Резерв — стало','Δ резерва',
                               'Задолженность — было','Задолженность — стало','Δ задолженности']
    if not out.empty:
        clients = out.groupby(UNP,dropna=False,sort=False)[numerics].sum().reset_index()
        clients.insert(1,'Клиент',out.groupby(UNP,sort=False)['Клиент'].first().to_numpy())
        clients.insert(2,'Сегмент',out.groupby(UNP,sort=False)['Сегмент'].first().to_numpy())
        clients['Договоров — было'] = out.loc[out['Статус']!='Новый договор'].groupby(UNP).size().reindex(clients[UNP],fill_value=0).to_numpy()
        clients['Договоров — стало'] = out.loc[out['Статус']!='Выбывший договор'].groupby(UNP).size().reindex(clients[UNP],fill_value=0).to_numpy()
        clients['Сигналы'] = out.groupby(UNP)['Сигналы'].agg(lambda s:'; '.join(sorted(set(s)))).reindex(clients[UNP]).to_numpy()
        clients = clients.sort_values('Δ резерва',key=lambda s:s.abs(),ascending=False)
        segments = clients.groupby('Сегмент',dropna=False)[numerics].sum().reset_index().sort_values('Δ резерва',key=lambda s:s.abs(),ascending=False)
    else:
        clients = pd.DataFrame(columns=[UNP,CLIENT,SEGMENT,*numerics,'Договоров — было','Договоров — стало','Сигналы'])
        segments = pd.DataFrame(columns=[SEGMENT,*numerics])
    total_before = float(_number(before,RESERVE).sum())
    total_after = float(_number(after,RESERVE).sum())
    extra = {
        F_NO_CONTRACT:qb['missing_contract_reserve']-qa['missing_contract_reserve'],
        F_NO_UNP:qb['missing_unp_reserve']-qa['missing_unp_reserve'],
    }
    factors = pd.DataFrame({'Фактор':FACTOR_ORDER,
                            'Изменение':[float(components[f].sum())+extra.get(f,0) for f in FACTOR_ORDER]})
    factors['Доля от абсолютного изменения, %'] = np.where(
        abs(total_after-total_before)>1e-12, factors['Изменение']/(total_after-total_before)*100,np.nan)
    return OperationalAnalysis(
        contracts=out.sort_values('Δ резерва',key=lambda s:s.abs(),ascending=False),
        clients=clients, factors=factors,segments=segments,
        total_before=total_before,total_after=total_after,delta=total_after-total_before,
        debt_before=float(_number(before,DEBT).sum()),debt_after=float(_number(after,DEBT).sum()),
        balance_error=(total_after-total_before)-float(factors['Изменение'].sum()),
        unmatched_unp_before=qa['missing_unp'],unmatched_unp_after=qb['missing_unp'],
        unmatched_contract_before=qa['missing_contract'],unmatched_contract_after=qb['missing_contract'],
        invalid_reserve_before=qa['invalid_reserve'],invalid_reserve_after=qb['invalid_reserve'],
        invalid_debt_before=qa['invalid_debt'],invalid_debt_after=qb['invalid_debt'],
        continuing_contracts=int(continuing.sum()),simultaneous_contracts=int(joint.sum()),
    )
