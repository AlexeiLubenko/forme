@echo off
setlocal EnableExtensions
chcp 65001 >nul
set "PYTHONIOENCODING=utf-8"
rem UNC network paths are mapped to a temporary drive letter using pushd.
pushd "%~dp0" >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Cannot access network project folder: %~dp0
    pause
    exit /b 1
)

rem Use the currently selected corporate Anaconda/Python first.
rem If python is not on PATH, try the Windows Python launcher.
where python >nul 2>&1
if not errorlevel 1 (
    python -c "import sys; sys.exit(sys.version_info[:2] != (3,13))" >nul 2>&1
    if not errorlevel 1 goto run_python
)
py -3.13 -c "import sys; sys.exit(sys.version_info[:2] != (3,13))" >nul 2>&1
if not errorlevel 1 goto run_launcher

echo [ERROR] Python 3.13 was not found from this terminal.
echo Open Anaconda Prompt or activate the environment where the packages are installed.
set "EXIT_CODE=2"
goto finish

:run_python
python check_dependencies.py --imports
set "EXIT_CODE=%errorlevel%"
goto finish

:run_launcher
py -3.13 check_dependencies.py --imports
set "EXIT_CODE=%errorlevel%"
goto finish

:finish
popd
echo.
pause
exit /b %EXIT_CODE%
