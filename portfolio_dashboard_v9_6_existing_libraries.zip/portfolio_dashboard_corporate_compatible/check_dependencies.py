"""Offline dependency audit for the *selected* Python interpreter.

No third-party dependencies, no downloads and no changes to the environment.
Reports the project's direct dependencies, plus discoverable installed-package
transitive dependencies when `packaging` is available.

Run: python check_dependencies.py
     python check_dependencies.py --imports
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass, field
from importlib import metadata
import os
from pathlib import Path
import re
import shlex
import subprocess
import sys
from typing import Dict, List, Optional, Sequence, Tuple

PROJECT = Path(__file__).resolve().parent
REQUIREMENTS = PROJECT / "requirements.txt"
REPORT = PROJECT / "dependencies_report.txt"
REQUIRED_PYTHON = (3, 13)
LINE_RE = re.compile(r"^([A-Za-z0-9][A-Za-z0-9._-]*)\s*==\s*([A-Za-z0-9.!+_-]+)\s*(?:#.*)?$")
IMPORT_NAMES = {"streamlit": "streamlit", "pandas": "pandas", "numpy": "numpy",
                "openpyxl": "openpyxl", "plotly": "plotly"}


def normalize(name: str) -> str:
    return re.sub(r"[-_.]+", "-", name).lower()


def load_requirements(path: Path = REQUIREMENTS) -> List[Tuple[str, str]]:
    """Read the pinned, reviewable requirements file; fail on unsupported syntax."""
    result = []
    seen = set()
    for num, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        found = LINE_RE.fullmatch(line)
        if not found:
            raise ValueError("Неподдерживаемая строка {} в {}: {}".format(num, path.name, line))
        name, version = found.groups()
        key = normalize(name)
        if key in seen:
            raise ValueError("Повтор библиотеки в requirements.txt: {}".format(name))
        seen.add(key)
        result.append((name, version))
    if not result:
        raise ValueError("requirements.txt пуст")
    return result


def installed_version(name: str) -> Optional[str]:
    try:
        return metadata.version(name)
    except metadata.PackageNotFoundError:
        return None


@dataclass
class Audit:
    requirements: List[Tuple[str, str]]
    missing: List[Tuple[str, str]] = field(default_factory=list)
    different: List[Tuple[str, str, str]] = field(default_factory=list)
    ready: List[Tuple[str, str]] = field(default_factory=list)
    transitive_missing: List[Tuple[str, str]] = field(default_factory=list)
    transitive_conflicts: List[Tuple[str, str, str]] = field(default_factory=list)
    import_errors: List[Tuple[str, str]] = field(default_factory=list)
    transitive_note: str = ""
    python_compatible: bool = True

    @property
    def ok(self) -> bool:
        return (self.python_compatible and not self.missing and not self.different
                and not self.transitive_missing and not self.transitive_conflicts
                and not self.import_errors)


def inspect_transitive(roots: Sequence[str], direct: Sequence[str]) -> Tuple[List[Tuple[str, str]], List[Tuple[str, str, str]], str]:
    """Inspect available dist metadata without querying PyPI or resolving absent roots."""
    try:
        from packaging.requirements import Requirement
    except ImportError:
        return [], [], ("Пакет packaging отсутствует: глубокая проверка зависимостей недоступна. "
                        "Установка через pip разрешит зависимости автоматически.")

    visited = set()
    queue = list(roots)
    missing: Dict[str, str] = {}
    conflicts: Dict[str, Tuple[str, str]] = {}
    direct_names = {normalize(item) for item in direct}
    while queue:
        parent = queue.pop(0)
        key = normalize(parent)
        if key in visited:
            continue
        visited.add(key)
        try:
            dist = metadata.distribution(parent)
        except metadata.PackageNotFoundError:
            continue
        for requirement_line in dist.requires or []:
            try:
                req = Requirement(requirement_line)
                # Do not enable optional 'extra' requirements unless explicitly requested.
                if req.marker and not req.marker.evaluate({"extra": ""}):
                    continue
            except (ValueError, TypeError):
                continue
            dep = req.name
            dep_key = normalize(dep)
            if dep_key in direct_names:
                continue  # already handled with the project's pinned version
            current = installed_version(dep)
            expected = str(req.specifier) or "любая версия"
            if current is None:
                missing[dep_key] = expected
            else:
                if req.specifier and current not in req.specifier:
                    conflicts[dep_key] = (expected, current)
                if dep_key not in visited:
                    queue.append(dep)
    return ([(name, ver) for name, ver in sorted(missing.items())],
            [(name, expected, actual) for name, (expected, actual) in sorted(conflicts.items())],
            "Недоступные пакеты не имеют локальных метаданных: их будущие зависимости "
            "можно полностью определить только при установке/разрешении через pip.")


def inspect_imports(names: Sequence[str]) -> List[Tuple[str, str]]:
    failures = []
    for name in names:
        module = IMPORT_NAMES.get(normalize(name), name.replace("-", "_"))
        result = subprocess.run(
            [sys.executable, "-c", "import importlib; importlib.import_module({!r})".format(module)],
            capture_output=True, text=True, errors="replace", check=False,
        )
        if result.returncode:
            message = (result.stderr or result.stdout).strip().splitlines()
            failures.append((name, message[-1][:300] if message else "Ошибка импорта"))
    return failures


def audit(path: Path = REQUIREMENTS, verify_imports: bool = False,
          check_transitive: bool = True) -> Audit:
    requirements = load_requirements(path)
    result = Audit(requirements=requirements, python_compatible=sys.version_info[:2] == REQUIRED_PYTHON)
    for name, required in requirements:
        actual = installed_version(name)
        if actual is None:
            result.missing.append((name, required))
        elif actual != required:
            result.different.append((name, required, actual))
        else:
            result.ready.append((name, required))
    if check_transitive:
        installed_roots = [name for name, _ in result.ready] + [name for name, _, _ in result.different]
        result.transitive_missing, result.transitive_conflicts, result.transitive_note = inspect_transitive(
            installed_roots, [name for name, _ in requirements]
        )
    if verify_imports:
        installed = [name for name, _ in result.ready] + [name for name, _, _ in result.different]
        result.import_errors = inspect_imports(installed)
    return result


def installation_command(requirements: Path = REQUIREMENTS) -> str:
    args = [sys.executable, "-m", "pip", "install", "-r", str(requirements)]
    return subprocess.list2cmdline(args) if os.name == "nt" else " ".join(shlex.quote(part) for part in args)


def render(result: Audit, req_file: Path = REQUIREMENTS) -> str:
    lines = ["ПРОВЕРКА БИБЛИОТЕК ПОРТФЕЛЯ", "=" * 48,
             "Python: {}".format(sys.version.split()[0]),
             "Исполняемый файл: {}".format(sys.executable),
             "Файл зависимостей: {}".format(req_file), ""]
    if not result.python_compatible:
        lines += ["ВНИМАНИЕ: приложению нужен Python 3.13; выбран другой интерпретатор.", ""]
    lines.append("Библиотеки проекта ({}):".format(len(result.requirements)))
    missing_names = {normalize(n) for n, _ in result.missing}
    different_map = {normalize(n): actual for n, _, actual in result.different}
    for name, required in result.requirements:
        key = normalize(name)
        if key in missing_names:
            lines.append("  [НЕТ] {}=={}".format(name, required))
        elif key in different_map:
            lines.append("  [ДРУГАЯ ВЕРСИЯ] {}: установлена {}, требуется {}".format(
                name, different_map[key], required))
        else:
            lines.append("  [OK] {}=={}".format(name, required))

    lines += ["", "Отсутствуют основные библиотеки: {}".format(len(result.missing))]
    lines.extend("  - {}=={}".format(n, v) for n, v in result.missing)
    lines.append("Отличаются от проверенных версий: {}".format(len(result.different)))
    lines.extend("  - {}: установлено {}, нужно {}".format(n, a, v)
                 for n, v, a in result.different)
    if result.transitive_missing:
        lines.append("Отсутствуют зависимости установленных пакетов ({}):".format(len(result.transitive_missing)))
        lines.extend("  - {} ({})".format(n, v) for n, v in result.transitive_missing)
    if result.transitive_conflicts:
        lines.append("Конфликты версий зависимостей ({}):".format(len(result.transitive_conflicts)))
        lines.extend("  - {}: установлено {}, требуется {}".format(n, a, v)
                     for n, v, a in result.transitive_conflicts)
    if result.import_errors:
        lines.append("Ошибки импорта ({}):".format(len(result.import_errors)))
        lines.extend("  - {}: {}".format(n, problem) for n, problem in result.import_errors)
    if result.transitive_note:
        lines += ["", "Примечание: " + result.transitive_note]
    lines += ["", "ИТОГ: " + ("можно запускать без установки" if result.ok else "проверьте выбранное окружение"),
              "", "В этой сборке установка библиотек ОТКЛЮЧЕНА.",
              "Проверка ничего не устанавливает и не изменяет в окружении."]
    return "\n".join(lines)


def main(argv: Optional[Sequence[str]] = None) -> int:
    parser = argparse.ArgumentParser(description="Проверить библиотеки Python 3.13 без установки")
    parser.add_argument("--imports", action="store_true", help="проверить реальные импорты библиотек")
    parser.add_argument("--no-report", action="store_true", help="не записывать текстовый отчёт")
    args = parser.parse_args(argv)
    try:
        result = audit(verify_imports=args.imports)
    except (OSError, ValueError) as error:
        print("Ошибка проверки: {}".format(error), file=sys.stderr)
        return 2
    output = render(result)
    print(output, flush=True)
    if not args.no_report:
        try:
            REPORT.write_text(output + "\n", encoding="utf-8")
            print("\nОтчёт сохранён: {}".format(REPORT), flush=True)
        except OSError as error:
            print("Не удалось сохранить отчёт (результат виден выше): {}".format(error), file=sys.stderr)
    return 0 if result.ok else (2 if not result.python_compatible else 1)


if __name__ == "__main__":
    raise SystemExit(main())
