"""Запуск банковского мониторинга через установленный корпоративный Python.

Ничего не скачивает, не устанавливает и не создаёт виртуальное окружение.
"""
from __future__ import annotations

import subprocess
import sys
from pathlib import Path
import check_dependencies

PROJECT = Path(__file__).resolve().parent


def main() -> int:
    print("Используем существующий Python:", sys.executable, flush=True)
    print("Версия Python:", sys.version.split()[0], flush=True)
    result = check_dependencies.audit(verify_imports=True)
    report = check_dependencies.render(result)
    print(report, flush=True)
    try:
        check_dependencies.REPORT.write_text(report + "\n", encoding="utf-8")
    except OSError as exc:
        print("Не удалось записать отчёт:", exc)
    if not result.ok:
        print("\nЗапуск остановлен. Проверяйте Python/Anaconda-окружение; установка отключена.")
        print("Список версий: dependencies_report.txt")
        return 1

    print("\nСервер: http://localhost:8501", flush=True)
    return subprocess.call([
        sys.executable, "-m", "streamlit", "run", str(PROJECT / "portfolio_app.py"),
        "--server.address=127.0.0.1", "--server.port=8501",
    ], cwd=str(PROJECT))


if __name__ == "__main__":
    raise SystemExit(main())
