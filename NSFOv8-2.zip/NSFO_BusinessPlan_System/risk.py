"""Methodology-approved NSFO risk classification and signed reserve factor analysis.

Amounts: debt in original currency units, OD/reserves/factors in BYN units;
percent rates: 0.5 means 0.5%, never 0.005.
"""
from __future__ import annotations
from dataclasses import dataclass, replace
import re

class MethodologyError(ValueError):
    pass

SECURITY = {
    'высококачественное обеспечение': 'high',
    'высокообеспеченный': 'high',
    'обеспеченный': 'secured',
    'недостаточно обеспеченный': 'insufficient',
    'необеспеченный': 'unsecured',
    'обеспеченный (не указан)': 'micro_unknown',
}
RATE_BY_GR = {1: .5, 2: 5., 3: 20., 4: 30., 5: 50., 6: 100.}
FACTOR_NAMES = {
    # Factor 1: portfolio movement
    'debt_change': 'Изменение задолженности действующих договоров',
    'new_contract_base': 'Новые договоры: базовый резерв 0,5% / 5%',
    # Factor 2: financial state
    'ni_in': 'Возникновение НИ',
    'pfn_in': 'Возникновение ПФН',
    'nvv_in': 'Возникновение НВВ',
    'restruct_in': 'Возникновение реструктуризации',
    'new_contract_risk': 'Новый договор: превышение ставки над 5%',
    'ni_to_pfn': 'Переход НИ → ПФН',
    'ni_out': 'Снятие НИ',
    'pfn_out': 'Снятие ПФН',
    'nvv_out': 'Снятие НВВ',
    'pfn_to_ni': 'Переход ПФН → НИ',
    'reclassification': 'Реклассификация: снятие реструктуризации',
    'override': 'Ручное изменение ставки',
    # Factor 3: collateral
    'security_worsening': 'Ухудшение обеспечения',
    'security_improvement': 'Улучшение обеспечения',
}

FACTOR_GROUPS = [
    {
        'key': 'movement',
        'name': 'Движение кредитного портфеля',
        'items': ['debt_change', 'new_contract_base'],
    },
    {
        'key': 'financial_state',
        'name': 'Изменение финансового состояния',
        'sections': [
            {'name': 'Ухудшение', 'items': [
                'ni_in', 'pfn_in', 'nvv_in', 'restruct_in',
                'new_contract_risk', 'ni_to_pfn',
            ]},
            {'name': 'Улучшение', 'items': [
                'ni_out', 'pfn_out', 'nvv_out', 'pfn_to_ni',
            ]},
            {'name': 'Реклассификация', 'items': ['reclassification']},
            {'name': 'Корректировки', 'items': ['override']},
        ],
    },
    {
        'key': 'security_effect',
        'name': 'Изменение обеспечения',
        'items': ['security_worsening', 'security_improvement'],
    },
    {
        'key': 'revaluation',
        'name': 'Переоценка',
        'items': [],
    },
]

FINANCIAL_FACTOR_KEYS = {
    'ni_in', 'pfn_in', 'nvv_in', 'restruct_in', 'new_contract_risk',
    'ni_to_pfn', 'ni_out', 'pfn_out', 'nvv_out', 'pfn_to_ni',
    'reclassification', 'override',
}
SECURITY_FACTOR_KEYS = {'security_worsening', 'security_improvement'}



def flag(value):
    if value is None or str(value).strip() == '': return 0
    if str(value).strip().lower() in ('нет','false','no','0','0.0'): return 0
    if str(value).strip().lower() in ('да','true','yes','1','1.0'): return 1
    raise MethodologyError(f'Неопределённое значение признака: {value!r}; допустимо 0, 1, пусто')


def rate_percent(value):
    if value is None or str(value).strip() == '': return None
    try: result=float(str(value).replace('%','').replace(',','.').strip())
    except (ValueError, TypeError): raise MethodologyError('Некорректный процент резервирования: '+str(value))
    if 0 < result < .5: result *= 100  # 0.005 => 0.5%; 0.02 => 2%
    if not .5 <= result <= 100: raise MethodologyError(f'Ставка {result:g}% вне допустимого диапазона 0,5–100%')
    return round(result, 8)


def gr_value(v):
    if v is None or str(v).strip()=='': return None
    s=str(v).strip().upper()
    if 'ПОК' in s: return 'ПОК'
    m=re.search(r'\d+',s)
    return int(m.group()) if m else None


def normal_security(value, micro=False):
    t=' '.join(str(value or '').strip().lower().replace('ё','е').split())
    aliases={'высококачественный':'high','высокообеспеченный':'high','высококачественное обеспечение':'high','обеспеченный':'secured','недостаточно обеспеченный':'insufficient','необеспеченный':'unsecured','обеспеченный (не указан)':'micro_unknown'}
    result=aliases.get(t)
    if result == 'micro_unknown' and not micro:
        raise MethodologyError('«Обеспеченный (не указан)» допустим только для микрокредитов')
    if not result and not micro:
        raise MethodologyError(f'Неизвестная обеспеченность: {value!r}')
    return result or 'micro_unknown'


def micro_flag(v):
    t=str(v or '').strip().lower()
    return t in ('да','1','1.0','true','микрокредит','мк') or (bool(t) and 'микро' in t)


def is_black_zone(zone):
    z=str(zone or '').strip().lower().replace('ё','е')
    return 'черн' in z or z in ('black','чз')


def currency(v):
    s=str(v or '').strip().upper()
    return {'933':'BYN','840':'USD','978':'EUR','643':'RUB','974':'BYR','BYR':'BYN'}.get(s,s)


def is_new_contract(contract):
    return 'новый договор' in ' '.join(str(contract or '').casefold().split())


def side_for_operation(operation):
    return 'баланс' if str(operation or '').strip().casefold() in ('кредит','цб для продажи') else 'внебаланс'


def match_key(unp, contract, ccy, side):
    return '|'.join([' '.join(str(unp or '').upper().split()),' '.join(str(contract or '').upper().split()),currency(ccy),side_for_operation(side) if side not in ('баланс','внебаланс') else side])

@dataclass(frozen=True)
class Criteria:
    ni:int=0; pfn:int=0; nvv:int=0
    restra:str=''; security:str=''; operation:str='Кредит'
    currency:str='BYN'; micro:bool=False; poc:bool=False
    poc_rate:float|None=None

    def as_dict(self):
        return {'ni':self.ni,'pfn':self.pfn,'nvv':self.nvv,'restra':self.restra,
          'security':self.security,'operation':self.operation,'currency':self.currency,
          'micro':self.micro,'poc':self.poc,'poc_rate':self.poc_rate}


def classify(c:Criteria):
    """Return (GR, percent, explanation), or raise rather than silently invent a risk group."""
    active = side_for_operation(c.operation)=='баланс'
    ccy=currency(c.currency)
    if c.poc:
        if not active: return 1, .5, 'ПОК: УО/внебаланс → 1 ГР, 0,5%'
        if c.poc_rate is None: raise MethodologyError('ПОК: нет ставки по договору в факте или в других датах БП')
        return 'ПОК', rate_percent(c.poc_rate), 'ПОК: ставка конкретного договора'
    sec=normal_security(c.security,c.micro)
    restra=str(c.restra or '').strip()
    if restra and active:
        m=re.search(r'([456])\s*(?:[- ]?\s*гр|группа)',restra.lower())
        if not m:
            raise MethodologyError(f'Неизвестная реструктуризация: {restra!r}; нужна 4/5/6 ГР')
        gr=int(m.group(1))
        return gr,RATE_BY_GR[gr],'Реструктуризация договора; приоритет над ПФН и НИ'
    # Re-structuring on UO does not participate, even if source has erroneous value
    ni=flag(c.ni);pfn=flag(c.pfn); nvv=flag(c.nvv)
    if c.micro:
        gr=2 if (ni or pfn) else 1
        return gr,RATE_BY_GR[gr],'Микрокредит: обеспечение не влияет; НИ/ПФН'
    if 'цб' in str(c.operation).lower():
        if pfn: return (3,30. if sec=='unsecured' else 20.,'ЦБ: ПФН')
        if ni: return (2,20. if sec=='unsecured' else 5.,'ЦБ: НИ')
        return (1, .5 if sec in ('high','secured') else 2.,'ЦБ: без НИ и ПФН')
    # ordinary active/contingent exposures
    if pfn:
        if sec=='high': return 1,.5,'ПФН, высококачественное обеспечение'
        if sec in ('secured','insufficient'): return 3,20.,'ПФН, обеспечен/недостаточно обеспечен'
        if sec=='unsecured': return (4,30.,'ПФН, необеспеченный актив') if active else (3,20.,'ПФН, необеспеченное УО')
    if ni:
        if sec=='high': return 1,.5,'НИ, высококачественное обеспечение'
        if sec in ('secured','insufficient'): return 2,5.,'НИ, обеспечен/недостаточно обеспечен'
        return 3,20.,'НИ, необеспечен'
    if nvv and active and ccy != 'BYN':
        if sec in ('secured','insufficient'): return 2,5.,'НВВ, валютный актив'
        if sec=='unsecured': return 3,20.,'НВВ, валютный необеспеченный актив'
        # Underlying high-security NВВ combination has no explicit approved rule.
        raise MethodologyError('НВВ + высококачественное обеспечение не описано в матрице')
    if sec in ('high','secured'): return 1,.5,'Без действующих признаков риска, обеспечен'
    return 2,5.,'Без действующих признаков риска, недостаточно обеспечен/необеспечен'


def _safe_rate(criteria: Criteria):
    try:
        return classify(criteria)[1]
    except MethodologyError:
        return None


def _security_direction(before: str, after: str) -> str:
    """Classify collateral movement using the agreed quality ordering."""
    ranks = {
        'high': 0,
        'secured': 1,
        'insufficient': 2,
        'unsecured': 3,
        'micro_unknown': 1,
    }
    try:
        old = normal_security(before, micro=True)
        new = normal_security(after, micro=True)
    except MethodologyError:
        return 'security_worsening'
    if ranks.get(new, 3) < ranks.get(old, 3):
        return 'security_improvement'
    return 'security_worsening'


def quality_breakdown(before: Criteria, after: Criteria, current_od: float,
                      rate0: float, rate1: float):
    """Sequential decomposition of financial-state and collateral effects.

    Agreed order inside the financial-state factor:
      1) recognition of restructuring (strongest contractual criterion),
      2) NI <-> PFN transitions and other client flags in PFN, NI, NVV order,
      3) removal of restructuring as a separate reclassification line.
    Collateral is always applied after financial-state changes.

    Each step uses current OD and the rate difference between the intermediate
    states. Events remain visible even when a stronger criterion shadows them
    and their monetary effect is therefore zero.
    """
    terms = {key: 0.0 for key in FACTOR_NAMES}
    events = []
    current = before

    def apply(fields, key):
        nonlocal current
        nxt = replace(current, **fields)
        events.append(key)
        old_rate = _safe_rate(current)
        new_rate = _safe_rate(nxt)
        if old_rate is not None and new_rate is not None:
            terms[key] += -current_od * (new_rate - old_rate) / 100.0
        current = nxt

    # A newly recognized restructuring has priority over client-level flags.
    if before.restra != after.restra and bool(str(after.restra or '').strip()):
        apply({'restra': after.restra}, 'restruct_in')

    # These two transitions are single events, not two independent effects.
    ni_to_pfn = bool(before.ni) and not bool(before.pfn) and not bool(after.ni) and bool(after.pfn)
    pfn_to_ni = bool(before.pfn) and not bool(before.ni) and not bool(after.pfn) and bool(after.ni)

    if ni_to_pfn:
        apply({'ni': after.ni, 'pfn': after.pfn}, 'ni_to_pfn')
    elif pfn_to_ni:
        apply({'pfn': after.pfn, 'ni': after.ni}, 'pfn_to_ni')
    else:
        # Stronger client-level indicator first: PFN -> NI -> NVV.
        if before.pfn != after.pfn:
            apply({'pfn': after.pfn}, 'pfn_in' if after.pfn else 'pfn_out')
        if before.ni != after.ni:
            apply({'ni': after.ni}, 'ni_in' if after.ni else 'ni_out')

    if before.nvv != after.nvv:
        apply({'nvv': after.nvv}, 'nvv_in' if after.nvv else 'nvv_out')

    # Removing a restructuring is a distinct reclassification subfactor.
    # It is applied after the other financial-state events so that the
    # remaining client criteria determine the post-reclassification rate.
    if before.restra != after.restra and bool(str(before.restra or '').strip()) and not bool(str(after.restra or '').strip()):
        apply({'restra': after.restra}, 'reclassification')

    # Collateral changes are applied after all financial-state changes.
    if before.security != after.security:
        key = _security_direction(before.security, after.security)
        apply({'security': after.security}, key)

    # Manual rate overrides and unsupported intermediate classifications are
    # explicit adjustments, not silently mixed into an ordinary subfactor.
    actual_effect = -current_od * (rate1 - rate0) / 100.0
    calculated = sum(terms.values())
    terms['override'] += actual_effect - calculated

    terms = {key: round(value, 2) for key, value in terms.items()}
    terms['override'] = round(terms['override'] + round(actual_effect - sum(terms.values()), 2), 2)
    return terms, events


def _new_contract_base_rate(current: dict) -> float:
    """Base reserve rate for a newly issued contract: 0.5% for GR1, 5% for GR2+."""
    gr = gr_value(current.get('gr'))
    if gr == 1:
        return 0.5
    if isinstance(gr, int) and gr >= 2:
        return 5.0
    # Non-numeric classifications (e.g. contract-specific ПОК) have no
    # agreed generic 0.5%/5% split; do not invent one.
    return float(current['rate'])


def compute_factors(prior, current, new_contract=False, *, archived_fx_effect=None):
    """Return signed factor decomposition reconciled to prior reserve-current reserve.

    Negative values mean reserve creation (negative expenses); positive values
    mean reserve release. A row is a new issuance only when its contract name
    contains the explicit marker and its debt changes from zero to positive.
    """
    prior_debt = float(prior['debt'] or 0.0)
    current_debt = float(current['debt'] or 0.0)
    is_new_issue = bool(new_contract) and prior_debt <= 0.000001 and current_debt > 0.000001

    # Older forecast exports store the signed FX effect and OD, but omit spot rates.
    fx = archived_fx_effect
    if fx is None:
        fx = -(prior_debt * (current['fx'] - prior['fx']) * prior['rate'] / 100.0)
    sub = {key: 0.0 for key in FACTOR_NAMES}
    events = []

    if is_new_issue:
        base_rate = _new_contract_base_rate(current)
        movement = -(current['od'] - prior['od']) * base_rate / 100.0 - fx
        sub['new_contract_base'] = movement
        gr = gr_value(current.get('gr'))
        if isinstance(gr, int) and gr > 2:
            sub['new_contract_risk'] = -current['od'] * (current['rate'] - 5.0) / 100.0
            events.append('new_contract_risk')
        elif abs(current['rate'] - base_rate) > 0.000001:
            # Covers exceptional non-standard matrices without inventing a
            # new factor definition; visible as a manual/methodology adjustment.
            sub['override'] = -current['od'] * (current['rate'] - base_rate) / 100.0
            events.append('override')
        events.append('new_contract_base')
    else:
        movement = -(current['od'] - prior['od']) * prior['rate'] / 100.0 - fx
        sub, events = quality_breakdown(
            Criteria(**prior['criteria']),
            Criteria(**current['criteria']),
            current['od'], prior['rate'], current['rate'],
        )
        sub['debt_change'] = movement
        events.append('debt_change') if abs(current['od'] - prior['od']) > 0.01 else None

    financial_state = sum(sub[key] for key in FINANCIAL_FACTOR_KEYS)
    security_effect = sum(sub[key] for key in SECURITY_FACTOR_KEYS)
    quality = financial_state + security_effect  # legacy aggregate retained for DB/API compatibility
    expenses = prior['reserve'] - current['reserve']

    fx = round(fx, 2)
    movement = round(movement, 2)
    financial_state = round(financial_state, 2)
    security_effect = round(security_effect, 2)
    quality = round(financial_state + security_effect, 2)
    expenses = round(expenses, 2)

    residual = round(expenses - fx - movement - financial_state - security_effect, 2)
    return {
        'movement': movement,
        'financial_state': financial_state,
        'security_effect': security_effect,
        'quality': quality,
        'fx': fx,
        'expenses': expenses,
        'rounding': residual,
        'factors': {key: round(value, 2) for key, value in sub.items()},
        'events': events,
    }

