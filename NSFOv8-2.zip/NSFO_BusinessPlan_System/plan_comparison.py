"""Read a frozen forecast and compare its period bridges with the live project."""
from contextlib import closing
from datetime import datetime
import json
import math
import re
import sqlite3
from xml.etree.ElementTree import ParseError
from zipfile import BadZipFile

from openpyxl import load_workbook
from openpyxl.utils.exceptions import InvalidFileException
import engine
from risk import (Criteria, FACTOR_GROUPS, FACTOR_NAMES, classify, compute_factors, currency,
                  flag, is_new_contract, side_for_operation)

TEMPLATE = '08_Шаблон_сформированного_БП.xlsx'
SHEET = 'Прогноз НСФО'
IDENTITY = ('Ключ', 'УНП', 'Наименование клиента', 'Номер договора', 'Тип операции', 'Валюта', 'Микрокредит')
FIELDS = ('Задолженность', 'НИ', 'ПФН', 'НВВ', 'Рестра', 'Обеспеченность', 'ГР', '%рез')
OPTIONAL = ('Курс', 'OD', 'Резерв', 'Переоценка')
BRIDGE = ('expenses', 'movement', 'financial_state', 'security_effect', 'revaluation', 'rounding')


def columns(header):
    static, dated = {}, {}
    for i, title in enumerate(header):
        if not isinstance(title, str):
            continue
        base, sep, suffix = title.strip().partition('_')
        if base in IDENTITY + ('Зона проблемности', 'ПОК', 'Ставка ПОК') and not sep:
            dest = static
        elif sep and base in FIELDS + OPTIONAL:
            try:
                day = datetime.strptime(suffix, '%d.%m.%Y').date()
                if day.day != 1:
                    raise ValueError
            except ValueError:
                raise ValueError(f'Столбец «{title}». Нужна дата на первое число месяца в формате ДД.ММ.ГГГГ.')
            dest = dated.setdefault(day.isoformat(), {})
        else:
            continue
        if base in dest:
            raise ValueError(f'Повторяется столбец «{title}».')
        dest[base] = i
    for label, required, mapping in [(SHEET, IDENTITY, static), *((engine.dd(d), FIELDS, m) for d, m in dated.items())]:
        missing = [key for key in required if key not in mapping]
        if missing:
            raise ValueError(f'{label}. Отсутствуют столбцы: {", ".join(missing)}.')
    if len(dated) < 2:
        raise ValueError('Нужны начальный остаток и хотя бы одна прогнозная дата.')
    return static, dict(sorted(dated.items()))


def number(value, field):
    if isinstance(value, bool) or value is None or not str(value).strip():
        raise ValueError(f'Заполните «{field}» числом.')
    try:
        result = engine.val(value)
        if not math.isfinite(result):
            raise ValueError
    except ValueError:
        raise ValueError(f'Некорректное число в поле «{field}»: {value!r}.')
    return result


def cell(row, mapping, field):
    index = mapping.get(field)
    return row[index] if index is not None and index < len(row) else None


def identifier(value, name):
    if value is None or not str(value).strip():
        raise ValueError(f'Заполните «{name}».')
    return str(value).strip()


def archived_position(db, pid, row, static, dated):
    identity = {key: identifier(cell(row, static, key), key) for key in IDENTITY if key != 'Микрокредит'}
    key, client = identity['Ключ'], identity['Наименование клиента']
    operation, contract = identity['Тип операции'], identity['Номер договора']
    ccy = currency(identity['Валюта'])
    side = side_for_operation(operation)
    zone = str(cell(row, static, 'Зона проблемности') or '')
    micro = flag(cell(row, static, 'Микрокредит'))
    poc = (flag(cell(row, static, 'ПОК')) if 'ПОК' in static else
           any(str(cell(row, m, 'ГР')).strip().upper() == 'ПОК' for m in dated.values()))
    poc_rate = cell(row, static, 'Ставка ПОК')
    if poc and side == 'баланс':
        if poc_rate is None:
            poc_rate = cell(row, next(iter(dated.values())), '%рез')
        poc_rate = number(poc_rate, 'Ставка ПОК')
    else:
        poc_rate = None
    try:
        pos = db.execute('''INSERT INTO comparison_positions(project_id,row_key,unp,client,contract,side,zone)
                            VALUES(?,?,?,?,?,?,?)''', (pid, key, identity['УНП'], client, contract, side, zone)).lastrowid
    except sqlite3.IntegrityError as exc:
        raise ValueError(f'Повторяется ключ позиции «{key}».') from exc
    previous = None
    legacy = False
    for date, mapping in dated.items():
        def value(name):
            return cell(row, mapping, name)

        try:
            debt = number(value('Задолженность'), 'Задолженность')
            rate = number(value('%рез'), '%рез')
            if not 0.5 <= rate <= 100:
                raise ValueError('Ставка «%рез» задаётся в процентных пунктах от 0,5 до 100.')
            gr = str(value('ГР')).strip().upper()
            if gr not in ('1', '2', '3', '4', '5', '6', 'ПОК'):
                raise ValueError('Допустимая ГР: 1–6 или ПОК.')
            criteria = Criteria(*(flag(value(k)) for k in ('НИ', 'ПФН', 'НВВ')),
                                str(value('Рестра') or '').strip(), str(value('Обеспеченность') or '').strip(),
                                operation, ccy, bool(micro), bool(poc), poc_rate)
            classify(criteria)  # Validate risk inputs while keeping the agreed rate, including overrides.
            fx_effect = None
            if 'Курс' in mapping or ccy == 'BYN':
                fx = number(value('Курс'), 'Курс') if 'Курс' in mapping else 1.0
                if fx <= 0 or (ccy == 'BYN' and fx != 1):
                    raise ValueError('Курс должен быть положительным. Для BYN укажите 1.')
                od = round(debt * fx, 2)
                if 'OD' in mapping and abs(number(value('OD'), 'OD') - od) > 0.010001:
                    raise ValueError('OD расходится с произведением задолженности и курса.')
            else:
                fx = None
                legacy = True
                od = number(value('OD'), 'OD')
            if previous and (fx is None or previous['fx'] is None):
                fx_effect = number(value('Переоценка'), 'Переоценка')
            reserve = round(od * rate / 100, 2)
            if 'Резерв' in mapping:
                stated = number(value('Резерв'), 'Резерв')
                if abs(stated - reserve) > 0.010001:
                    raise ValueError('Резерв расходится с OD × %рез / 100 более чем на 0,01 BYN.')
                reserve = stated
            current = dict(debt=debt, fx=fx, od=od, rate=rate, reserve=reserve,
                           criteria=criteria.as_dict(), gr=gr)
            if previous:
                f = compute_factors(previous, current, is_new_contract(contract), archived_fx_effect=fx_effect)
                db.execute('''INSERT INTO comparison_periods
                    (project_id,position_id,period,od,reserve,expenses,movement,financial_state,security_effect,
                     quality,revaluation,rounding,factors,events) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)''',
                    (pid, pos, date, od, reserve, f['expenses'], f['movement'], f['financial_state'],
                     f['security_effect'], f['quality'], f['fx'], f['rounding'], engine.js(f['factors']), engine.js(f['events'])))
            previous = current
        except ValueError as exc:
            raise ValueError(f'{engine.dd(date)}, договор «{contract}». {exc}') from exc
    return legacy


def import_plan(pid, path, filename, username):
    try:
        with closing(load_workbook(path, read_only=True, data_only=True, keep_links=False)) as workbook:
            if SHEET not in workbook.sheetnames:
                raise ValueError(f'В книге нужен лист «{SHEET}». Используйте шаблон или детальную выгрузку прогноза.')
            sheet = workbook[SHEET]
            sheet.reset_dimensions()
            rows = sheet.values
            static, dated = columns(next(rows, ()))
            with engine.connect() as db:
                db.execute('BEGIN IMMEDIATE')
                if not db.execute('SELECT 1 FROM projects WHERE id=?', (pid,)).fetchone():
                    raise ValueError('Проект не найден.')
                db.execute('DELETE FROM comparison_plans WHERE project_id=?', (pid,))
                db.execute('''INSERT INTO comparison_plans(project_id,filename,uploaded,username,periods)
                              VALUES(?,?,?,?,?)''', (pid, filename, engine.now(), username, engine.js(list(dated))))
                count = 0
                legacy = False
                for n, row in enumerate(rows, 2):
                    if all(x is None or x == '' for x in row):
                        continue
                    try:
                        used_legacy = archived_position(db, pid, row, static, dated)
                    except ValueError as exc:
                        raise ValueError(f'Лист «{SHEET}», строка {n}. {exc}') from exc
                    legacy |= used_legacy
                    count += 1
                if not count:
                    raise ValueError(f'На листе «{SHEET}» нет позиций.')
                db.execute('UPDATE comparison_plans SET positions=?,legacy_fx=? WHERE project_id=?',
                           (count, int(legacy), pid))
                db.execute('INSERT INTO audit(project_id,at,action,new,reason) VALUES(?,?,?,?,?)',
                           (pid, engine.now(), 'comparison_import', filename, f'{username}, позиций: {count}'))
                return {'positions': count, 'periods': list(dated), 'filename': filename}
    except (BadZipFile, InvalidFileException, ParseError, KeyError, OSError) as exc:
        raise ValueError('Не удалось прочитать книгу Excel. Проверьте формат XLSX.') from exc


def intervals(periods):
    return set(zip(periods, periods[1:]))


def compare(pid, start='', end='', search='', side=''):
    with engine.connect() as db:
        db.execute('BEGIN')  # Read the source metadata and both sets of factors from one snapshot.
        project = db.execute('SELECT name,periods,status FROM projects WHERE id=?', (pid,)).fetchone()
        if not project:
            raise ValueError('Проект не найден.')
        source = db.execute('SELECT * FROM comparison_plans WHERE project_id=?', (pid,)).fetchone()
        saved = intervals(json.loads(source['periods'])) if source else set()
        live = intervals(json.loads(project['periods'])) if project['status'] != 'building' else set()
        all_dates = sorted(live | saved)
        selected = (start, end)
        if selected not in all_dates:
            selected = min(live & saved or all_dates, default=None)
        out = dict(source=dict(source) if source else None, project=project['name'],
                   building=project['status']=='building',
                   intervals=[dict(start=a, end=b, current=(a,b) in live, reference=(a,b) in saved)
                              for a,b in all_dates], selected=selected, current=None, reference=None,
                   delta=None, factor_names=FACTOR_NAMES, factor_groups=FACTOR_GROUPS)
        if not selected:
            return out
        a, b = selected
        for key, dates in [('current', live), ('reference', saved)]:
            if selected in dates:
                out[key] = engine.factor_summary_in(db, pid, b, search, side=side, prior_period=a, reference=(key=='reference'))
        current, reference = out['current'], out['reference']
        if current and reference and not current['incomplete']:
            out['delta'] = {
                part: {k: round(current[part].get(k, 0) - reference[part].get(k, 0), 2) for k in keys}
                for part, keys in [('totals', BRIDGE), ('subfactors', FACTOR_NAMES), ('events', FACTOR_NAMES)]}
        return out
