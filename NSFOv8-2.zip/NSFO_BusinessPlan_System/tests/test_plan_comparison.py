"""Regression checks for imported plan bridges and project-scoped comparisons."""
import json
from io import BytesIO
from pathlib import Path
import shutil
import tempfile
import unittest

from openpyxl import load_workbook
import engine
import exports
import plan_comparison as comparison


class ComparisonTests(unittest.TestCase):
    def setUp(self):
        original = engine.DATA, engine.DB
        self.addCleanup(lambda: (setattr(engine, 'DATA', original[0]), setattr(engine, 'DB', original[1])))
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        engine.DATA = Path(tmp.name)
        engine.DB = engine.DATA / 'nsfo.sqlite3'
        self.examples = engine.ROOT / 'examples'
        shutil.copyfile(self.examples / 'demo_nsfo.sqlite3', engine.DB)
        self.template = self.examples / comparison.TEMPLATE
        engine.initialize()
        self.pid = 1
        engine.recalculate_project(self.pid)

    def upload(self, file, name='БП.xlsx'):
        return comparison.import_plan(self.pid, file, name, 'admin-test')

    def test_native_roundtrip_and_live_edit(self):
        self.upload(exports.build_excel(self.pid))
        for interval in comparison.compare(self.pid)['intervals']:
            a, b = interval['start'], interval['end']
            data = comparison.compare(self.pid, a, b)
            for section in data['delta'].values():
                self.assertTrue(all(value == 0 for value in section.values()))
        before = comparison.compare(self.pid, search='D1', side='баланс')
        with engine.connect() as db:
            position = db.execute("SELECT id FROM positions WHERE project_id=? AND contract='D1' AND side='баланс'",
                                  (self.pid,)).fetchone()[0]
        end = before['selected'][1]
        engine.edit(self.pid, position, end, 'debt', 1400000)
        after = comparison.compare(self.pid, search='D1', side='баланс')
        self.assertEqual(before['reference'], after['reference'])
        self.assertNotEqual(after['delta']['totals']['movement'], 0)
        self.assertEqual(after['delta']['totals']['expenses'], after['delta']['totals']['movement'])
        self.assertEqual(after['current']['totals'], engine.factor_summary(self.pid, end, 'D1', side='баланс')['totals'])

    def test_template_factor_values_and_filters(self):
        self.assertEqual(self.upload(self.template)['positions'], 3)
        usd = comparison.compare(self.pid, search='001001', side='баланс')['reference']
        self.assertEqual(usd['positions'], 1)
        self.assertEqual([usd['totals'][k] for k in comparison.BRIDGE], [-16100,-160,-15840,0,-100,0])
        second = comparison.compare(self.pid, '2026-11-01', '2026-12-01', '001001', 'баланс')['reference']
        self.assertEqual(second['subfactors']['ni_to_pfn'], -48000)
        self.assertEqual(second['totals']['security_effect'], -32000)
        self.assertEqual(second['events']['ni_to_pfn'], 1)
        self.assertEqual(second['totals']['rounding'], 0)
        new = comparison.compare(self.pid, search='договор 02')['reference']
        self.assertEqual(new['subfactors']['new_contract_base'], -10000)
        self.assertEqual(new['subfactors']['new_contract_risk'], -30000)
        self.assertEqual(comparison.compare(self.pid, search='001001', side='внебаланс')['reference']['totals']['expenses'],50)

    def test_legacy_export_and_invalid_replacement(self):
        self.upload(next(self.examples.glob('04_*')), 'Старая выгрузка.xlsx')
        before = comparison.compare(self.pid)
        self.assertTrue(before['source']['legacy_fx'])
        self.assertEqual(before['reference']['totals']['revaluation'], -2700)
        book = load_workbook(self.template)
        sheet = book[comparison.SHEET]
        for title, value, message in [('Ключ','УЧ-01','Повторяется ключ'),
                                      ('Курс_01.11.2026',0,'Курс должен'),
                                      ('Задолженность_01.10.2026',None,'Заполните')]:
            with self.subTest(field=title):
                index = [c.value for c in sheet[1]].index(title) + 1
                target = sheet.cell(3,index)
                original = target.value
                target.value = value
                buf = BytesIO()
                book.save(buf)
                buf.seek(0)
                with self.assertRaisesRegex(ValueError,'строка 3.*'+message):
                    self.upload(buf)
                self.assertEqual(before, comparison.compare(self.pid))
                target.value = original
        book.close()

    def test_only_identical_intervals_compare_and_sources_are_project_scoped(self):
        self.upload(self.template)
        other = engine.create_project('Отдельный проект')
        self.assertIsNone(comparison.compare(other)['source'])
        with engine.connect() as db:
            dates = ['2026-10-01','2026-12-01']
            db.execute('UPDATE projects SET periods=? WHERE id=?', (json.dumps(dates),self.pid))
        for start, end, available in [('2026-10-01','2026-12-01','current'),('2026-11-01','2026-12-01','reference')]:
            result = comparison.compare(self.pid,start,end)
            self.assertTrue(result[available])
            self.assertIsNone(result['delta'])
        with engine.connect() as db:
            db.execute("UPDATE projects SET periods='[]' WHERE id=?", (self.pid,))
        result = comparison.compare(self.pid)
        self.assertTrue(result['reference'])
        self.assertIsNone(result['current'])

    def test_incomplete_current_calculation_suppresses_variance(self):
        self.upload(self.template)
        with engine.connect() as db:
            db.execute("UPDATE position_periods SET reserve=NULL WHERE project_id=? AND period='2026-10-01'",(self.pid,))
        result = comparison.compare(self.pid)
        self.assertGreater(result['current']['incomplete'],0)
        self.assertIsNone(result['delta'])
