"""Editor RBAC regression: legacy database migration, UI and HTTP permissions."""
from __future__ import annotations
import json
import sqlite3
import tempfile
import threading
import unittest
import urllib.error
import urllib.request
from http.server import ThreadingHTTPServer
from pathlib import Path
import access_control as auth
import dashboard_service as dash
import engine
import plan_comparison
import server

class EditorRoleTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.prev_db,self.prev_data=engine.DB,engine.DATA
        engine.DATA=Path(self.tmp.name)
        engine.DB=engine.DATA/'roles.sqlite3'
        engine.initialize()
        # Simulate v1.3.0 with two-role CHECK and a real admin session.
        with engine.connect() as db:
            db.executescript('''
                CREATE TABLE access_users (
                    username TEXT PRIMARY KEY,password_hash TEXT NOT NULL,
                    role TEXT NOT NULL CHECK(role IN ('admin','viewer')),
                    created TEXT NOT NULL,active INTEGER NOT NULL DEFAULT 1);
                CREATE TABLE access_sessions (
                    token_hash TEXT PRIMARY KEY,username TEXT NOT NULL,csrf_hash TEXT NOT NULL,
                    expires_at REAL NOT NULL,created TEXT NOT NULL,
                    FOREIGN KEY(username) REFERENCES access_users(username));''')
            db.execute('INSERT INTO access_users VALUES (?,?,?,?,?)',
                ('oldadmin',auth._hash_password('some_secure_password_123'),'admin',engine.now(),1))
        token='legacy_abcdefghijk'
        with engine.connect() as db:
            db.execute('INSERT INTO access_sessions VALUES (?,?,?,?,?)',
                       (auth._key(token),'oldadmin',auth._key('oldcsrf'),9999999999,engine.now()))
        self.legacy_token=token
        auth.initialize()
        auth.initialize()   # idempotent
        dash.initialize()
        auth.upsert_user('editor-test','test_editor_password_123','editor')
        auth.upsert_user('viewer-test','test_viewer_password_123','viewer')
        self.server=ThreadingHTTPServer(('127.0.0.1',0),server.Handler)
        self.thread=threading.Thread(target=self.server.serve_forever,daemon=True)
        self.thread.start()
        self.url=f'http://127.0.0.1:{self.server.server_address[1]}'

    def tearDown(self):
        self.server.shutdown()
        self.server.server_close()
        self.thread.join(timeout=3)
        engine.DB,engine.DATA=self.prev_db,self.prev_data
        self.tmp.cleanup()

    def fetch(self,path,role,method='GET',body=None,csrf=True):
        if role=='editor':
            who=auth.login('editor-test','test_editor_password_123','127.0.0.1')
        elif role=='viewer':
            who=auth.login('viewer-test','test_viewer_password_123','127.0.0.1')
        elif role=='admin':
            who=auth.login('oldadmin','some_secure_password_123','127.0.0.1')
        else:
            raise AssertionError(role)
        headers={'Cookie':'nsfo_session='+who['token']}
        if method=='POST':
            headers['Content-Type']='application/json'
            if csrf:headers['X-CSRF-Token']=who['csrf']
        req=urllib.request.Request(self.url+path,headers=headers,method=method,
                                   data=json.dumps(body or {}).encode() if method=='POST' else None)
        try:
            with urllib.request.urlopen(req,timeout=5) as response:
                return response.status,response.read()
        except urllib.error.HTTPError as exc:
            return exc.code,exc.read()

    def test_migration_preserves_admin_session(self):
        actor=auth.current('nsfo_session='+self.legacy_token)
        self.assertEqual(actor['username'],'oldadmin')
        self.assertEqual(actor['role'],'admin')
        with engine.connect() as db:
            self.assertEqual(db.execute("SELECT role FROM access_users WHERE username='editor-test'").fetchone()['role'],'editor')
            self.assertFalse(db.execute('PRAGMA foreign_key_check').fetchall())

    def test_editor_can_manage_main_module_but_not_dashboard_management(self):
        self.assertEqual(self.fetch('/api/projects','editor')[0],200)
        self.assertEqual(self.fetch('/api/projects','viewer')[0],403)
        status,content=self.fetch('/api/projects','editor','POST',{'name':'Test project'})
        self.assertEqual(status,200,content)
        pid=json.loads(content)['id']
        self.assertEqual(self.fetch(f'/api/projects/{pid}/state','editor')[0],200)
        self.assertEqual(self.fetch('/api/dashboard','editor')[0],200)
        self.assertEqual(self.fetch('/api/dashboard/factors?year=2027&month=1','editor')[0],200)
        self.assertEqual(self.fetch('/api/dashboard/admin','editor')[0],403)
        self.assertEqual(self.fetch('/api/dashboard/preview','editor')[0],403)
        self.assertEqual(self.fetch('/api/dashboard/factor-errors?run=1','editor')[0],403)
        self.assertEqual(self.fetch('/api/dashboard/template.xlsx','editor')[0],403)
        self.assertEqual(self.fetch('/api/dashboard/portfolio-template.xlsx','editor')[0],403)
        status, content = self.fetch('/api/dashboard/portfolio-template.xlsx','admin')
        self.assertEqual(status,200)
        self.assertTrue(content.startswith(b'PK'))
        self.assertEqual(self.fetch('/api/dashboard/import','editor','POST')[0],403)
        self.assertEqual(self.fetch('/api/dashboard/portfolio','editor','POST')[0],403)
        self.assertEqual(self.fetch('/api/dashboard/publish','editor','POST')[0],403)
        self.assertEqual(self.fetch('/api/dashboard/restore','editor','POST')[0],403)
        self.assertEqual(self.fetch('/api/dashboard/admin','admin')[0],200)
        self.assertEqual(self.fetch('/api/dashboard','viewer')[0],200)
        self.assertEqual(self.fetch('/api/dashboard/factors','viewer')[0],403)
        self.assertEqual(self.fetch('/api/dashboard/publish','admin','POST',{},csrf=False)[0],403)

    def test_comparison_file_roles(self):
        pid=engine.create_project('Сравнение БП')
        prefix=f'/api/projects/{pid}/comparison'
        self.assertEqual(self.fetch(prefix,'editor')[0],200)
        self.assertEqual(self.fetch(prefix,'viewer')[0],403)
        for role in ('editor','viewer'):
            self.assertEqual(self.fetch(prefix+'/upload',role,'POST')[0],403)
        self.assertEqual(self.fetch(prefix+'/upload','admin','POST',csrf=False)[0],403)
        self.assertEqual(self.fetch(prefix+'/template.xlsx','admin')[0],200)

    def test_admin_upload_and_editor_read_over_http(self):
        pid=engine.create_project('Права на сформированный БП')
        route=f'/api/projects/{pid}/comparison'
        who=auth.login('oldadmin','some_secure_password_123','127.0.0.1')
        headers={'Cookie':'nsfo_session='+who['token'], 'X-CSRF-Token':who['csrf'],
                 'Content-Type':'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                 'X-Filename':'previous.xlsx'}
        template=(engine.ROOT/'examples'/plan_comparison.TEMPLATE).read_bytes()
        req=urllib.request.Request(self.url+route+'/upload',data=template,headers=headers,method='POST')
        with urllib.request.urlopen(req,timeout=5) as response:
            self.assertEqual(json.load(response)['positions'],3)
        status,body=self.fetch(route,'editor')
        self.assertEqual(status,200)
        result=json.loads(body)
        self.assertEqual(result['source']['filename'],'previous.xlsx')
        self.assertEqual(result['reference']['totals']['expenses'],-56050)
        self.assertIsNone(result['current'])
        req=urllib.request.Request(self.url+route+'/upload',data=b'not xlsx',headers=headers,method='POST')
        with self.assertRaises(urllib.error.HTTPError) as failed:
            urllib.request.urlopen(req,timeout=5)
        self.assertEqual(failed.exception.code,400)
        self.assertEqual(json.loads(self.fetch(route,'editor')[1]),result)

    def test_login_returns_editor_role(self):
        self.assertEqual(self.fetch('/api/auth/me','editor')[0],200)
        who=auth.login('editor-test','test_editor_password_123','127.0.0.1')
        actor=auth.current('nsfo_session='+who['token'])
        self.assertEqual(actor['role'],'editor')

if __name__=='__main__':unittest.main()
