"""Integration checks for imported client-wide DPD, written-off loans and Excel export."""
import tempfile
import unittest
from pathlib import Path
from openpyxl import Workbook,load_workbook
import engine
import dashboard_service as dash
import access_control as auth

HEADER=[x.value for x in next(load_workbook(Path(__file__).resolve().parents[1]/'examples'/'02_Выверенный_факт_пример.xlsx',read_only=True).active.rows)]
H={name:i for i,name in enumerate(HEADER)}

class ImportedFactors(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.db=engine.DB;self.data=engine.DATA
        engine.DB=Path(self.tmp.name)/'db.sqlite3';engine.DATA=Path(self.tmp.name)
        engine.initialize();dash.initialize();auth.initialize()
    def tearDown(self):
        engine.DB=self.db;engine.DATA=self.data
        self.tmp.cleanup()

    def source(self,name,records):
        wb=Workbook();ws=wb.active;ws.title='Данные';ws.append(HEADER)
        for contract,seg,grp,rate,dpd,kind,debt,reserve,unp in records:
            row=[None]*len(HEADER)
            def put(field,value):row[H[field]]=value
            put('УНП',unp);put('Клиент','Тестовый клиент');put('Сегмент',seg)
            put('Номер договора',contract);put('Тип операции','Кредит');put('Код валюты','933')
            put('ГР',grp);put('% рез',rate);put('Задолженность, тыс BYN',debt)
            put('Резерв факт',reserve);put('Курс',1);put('НИ',0);put('ПФН',0);put('НВВ',0)
            put('Рестра','');put('Обеспеченность','Обеспеченный')
            put('Max-Day OD',dpd);put('Max-Day %%',0)
            put('ПОК/СПОК',kind)
            ws.append(row)
        path=Path(self.tmp.name)/name;wb.save(path);wb.close();return path

    def test_client_wide_dpd_from_mmb_affects_medium(self):
        jan=self.source('jan.xlsx',[
            ('MED','Средний','1',.5,0,'',100,.5,'123'),
            ('MMB','ММБ','1',.5,0,'',50,.25,'123'),
        ])
        feb=self.source('feb.xlsx',[
            ('MED','Средний','4',30,0,'',100,30,'123'),
            ('MMB','ММБ','4',30,40,'',50,15,'123'),
        ])
        dash.import_portfolio(jan,'jan.xlsx','2027-01-01','admin')
        result=dash.import_portfolio(feb,'feb.xlsx','2027-02-01','admin')
        self.assertEqual(result['runs'][0]['errors'],0)
        self.assertEqual(result['runs'][0]['rows'],1)
        self.assertEqual(result['runs'][0]['totals_cents']['financial_state'],-2_950_000)
        dash.publish('admin')
        path=Path(self.tmp.name)/'export.xlsx'
        dash.export_factor_excel(2027,1,path)
        wb=load_workbook(path,read_only=True,data_only=True)
        self.assertEqual(wb.sheetnames,['Свод_клиенты','Договоры_помесячно'])
        rows=list(wb['Договоры_помесячно'].values)
        self.assertEqual(len(rows),2)
        self.assertEqual(rows[1][7],0)
        self.assertEqual(rows[1][8],40)
        self.assertAlmostEqual(rows[1][15],-0.0295,places=8)
        self.assertAlmostEqual(rows[1][17],-0.0295,places=8)
        wb.close()

    def test_writtenoff_blank_ledger_reserve(self):
        src=self.source('writeoff.xlsx',[
            ('W','Средний','Списан',None,0,'',100,None,'123')
        ])
        result=dash.import_portfolio(src,'writeoff.xlsx','2027-01-01','admin')
        with engine.connect() as db:
            rec=db.execute('SELECT reserve_byn,rate,written_off FROM dash_positions WHERE snapshot_id=?',(result['snapshot_id'],)).fetchone()
        self.assertEqual(rec['reserve_byn'],100000)
        self.assertEqual(rec['rate'],100)
        self.assertEqual(rec['written_off'],1)

    def test_missing_reserve_regular_is_rejected(self):
        src=self.source('invalid.xlsx',[('Z','Средний','1',.5,0,'',100,None,'123')])
        with self.assertRaisesRegex(ValueError,'Не заполнен/некорректен резерв факт'):
            dash.import_portfolio(src,'invalid.xlsx','2027-01-01','admin')

    def test_migration_keeps_old_snapshot(self):
        with engine.connect() as db:
            for col in ('dpd','spok','written_off'):
                self.assertIn(col,[r['name'] for r in db.execute('PRAGMA table_info(dash_positions)')])
        dash.initialize()
        with engine.connect() as db:
            self.assertEqual(len([r for r in db.execute('PRAGMA table_info(dash_positions)') if r['name']=='dpd']),1)

    def test_reimport_legacy_neighbor_in_chronological_order(self):
        # Before 1.4.0 the same date already exists without DPD/POK fields.
        with engine.connect() as db:
            db.execute("INSERT INTO dash_portfolios(asof,created,original_name,created_by,row_count,position_count) VALUES('2027-02-01','now','old.xlsx','admin',1,0)")
        jan=self.source('new_jan.xlsx',[('MED','Средний','1',.5,0,'',100,.5,'123')])
        feb=self.source('new_feb.xlsx',[('MED','Средний','1',.5,0,'',110,.55,'123')])
        r=dash.import_portfolio(jan,'new_jan.xlsx','2027-01-01','admin')
        self.assertEqual(r['runs'],[])
        self.assertEqual(len(dash.admin_state()['pending']),1)
        with self.assertRaisesRegex(ValueError,'повторно загрузите'):
            dash.publish('admin')
        r=dash.import_portfolio(feb,'new_feb.xlsx','2027-02-01','admin')
        self.assertEqual(r['runs'][0]['errors'],0)
        self.assertEqual(dash.admin_state()['pending'],[])
        dash.publish('admin')

    def test_cross_side_draw_is_detected(self):
        # Two records, one off-balance shrink and one on-balance increase.
        before=[('x|d|BYN|внебаланс',{'side':'внебаланс','debt_byn':50000,'fx':1},None),
                ('x|d|BYN|баланс',None,{'side':'баланс','debt_byn':20000,'fx':1})]
        found=dash._transfer_by_side(before)
        self.assertEqual(found['баланс'],20000)
        self.assertEqual(dash._pairs_by_contract is not None,True)

if __name__=='__main__':unittest.main()
