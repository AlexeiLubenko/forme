"""No third-party authentication dependency; cookie sessions + PBKDF2 + CSRF.

Network installations MUST put HTTPS reverse proxy before this HTTP service.
Configure the first admin via `python setup_admin.py` (never in source code).
"""
from __future__ import annotations
import base64, datetime as dt, hashlib, hmac, os, secrets, sqlite3, threading, time
from http.cookies import SimpleCookie
import engine

SESSIONS_HOURS=int(os.environ.get('NSFO_SESSION_HOURS','8'))
ITERATIONS=330_000
LOCK=threading.Lock()
FAILED={}


def initialize():
    with engine.connect() as db:
        db.executescript('''
        CREATE TABLE IF NOT EXISTS access_users(
            username TEXT PRIMARY KEY,password_hash TEXT NOT NULL,role TEXT NOT NULL CHECK(role IN ('admin','viewer')),
            created TEXT NOT NULL,active INTEGER NOT NULL DEFAULT 1);
        CREATE TABLE IF NOT EXISTS access_sessions(
            token_hash TEXT PRIMARY KEY,username TEXT NOT NULL,csrf_hash TEXT NOT NULL,
            expires_at REAL NOT NULL,created TEXT NOT NULL,
            FOREIGN KEY(username) REFERENCES access_users(username));
        ''')


def user_count():
    with engine.connect() as db:
        return db.execute('SELECT COUNT(*) n FROM access_users WHERE active=1').fetchone()['n']


def _hash_password(password,salt=None):
    if len(password)<12:raise ValueError('Пароль должен содержать не менее 12 символов')
    salt=salt or secrets.token_bytes(16)
    digest=hashlib.pbkdf2_hmac('sha256',password.encode('utf-8'),salt,ITERATIONS)
    return f'pbkdf2_sha256${ITERATIONS}${salt.hex()}${digest.hex()}'


def upsert_user(username,password,role='admin'):
    username=username.strip().lower()
    if not username or len(username)>64 or not all(c.isascii() and (c.isalnum() or c in '._-') for c in username):
        raise ValueError('Логин: 1–64 символа (латиница, цифры, точки и дефисы)')
    if role not in ('admin','viewer'):raise ValueError('Роль admin или viewer')
    ph=_hash_password(password)
    with engine.connect() as db:
        db.execute('INSERT INTO access_users(username,password_hash,role,created) VALUES(?,?,?,?) ON CONFLICT(username) DO UPDATE SET password_hash=excluded.password_hash,role=excluded.role,active=1',
                   (username,ph,role,engine.now()))
        db.execute('DELETE FROM access_sessions WHERE username=?',(username,))


def _verify(password,stored):
    try:alg,iters,salt,h=stored.split('$')
    except ValueError:return False
    if alg!='pbkdf2_sha256':return False
    try:computed=hashlib.pbkdf2_hmac('sha256',password.encode('utf-8'),bytes.fromhex(salt),int(iters))
    except (ValueError,TypeError):return False
    return hmac.compare_digest(computed,bytes.fromhex(h))


def _key(token):return hashlib.sha256(token.encode('ascii')).hexdigest()


def login(username,password,ip):
    username=str(username or '').strip().lower()
    ip=str(ip)
    key=ip+'|'+username
    with LOCK:
        now=time.monotonic();recent=[x for x in FAILED.get(key,[]) if now-x<300]
        FAILED[key]=recent
        if len(recent)>=6:raise PermissionError('Слишком много попыток входа. Повторите позже.')
    with engine.connect() as db:
        u=db.execute('SELECT * FROM access_users WHERE username=? AND active=1',(username,)).fetchone()
        if not u or not _verify(str(password or ''),u['password_hash']):
            with LOCK:FAILED.setdefault(key,[]).append(time.monotonic())
            raise PermissionError('Неверный логин или пароль')
        token=secrets.token_urlsafe(32);csrf=secrets.token_urlsafe(32)
        db.execute('DELETE FROM access_sessions WHERE expires_at<?',(time.time(),))
        db.execute('INSERT INTO access_sessions VALUES(?,?,?,?,?)',(_key(token),username,_key(csrf),time.time()+SESSIONS_HOURS*3600,engine.now()))
        with LOCK:FAILED.pop(key,None)
        return {'username':username,'role':u['role'],'token':token,'csrf':csrf}


def current(cookie_header):
    try:
        c=SimpleCookie();c.load(cookie_header or '')
        token=c['nsfo_session'].value
    except (KeyError,ValueError):return None
    if len(token)>256:return None
    with engine.connect() as db:
        row=db.execute('''SELECT s.username,s.csrf_hash,s.expires_at,u.role FROM access_sessions s
                          JOIN access_users u ON u.username=s.username WHERE s.token_hash=? AND u.active=1''',(_key(token),)).fetchone()
        if not row or row['expires_at']<=time.time():return None
        return dict(row)


def csrf_ok(actor,csrf):
    return bool(actor and csrf and hmac.compare_digest(actor['csrf_hash'],_key(csrf)))


def logout(cookie_header):
    try:
        c=SimpleCookie();c.load(cookie_header or '');token=c['nsfo_session'].value
    except (ValueError,KeyError):return
    with engine.connect() as db:db.execute('DELETE FROM access_sessions WHERE token_hash=?',(_key(token),))
