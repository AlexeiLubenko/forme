"""Read-only bank dashboard, staged Excel imports and independently versioned facts.

All monetary dashboard values are million BYN. Portfolio source OD / factual reserves
are thousand BYN; normalized fact positions use BYN. No Streamlit/Flask required.
"""
from __future__ import annotations
import datetime as dt
import json
import re
from collections import defaultdict
from decimal import Decimal, ROUND_HALF_UP, InvalidOperation
from pathlib import Path
from openpyxl import load_workbook
import engine
from risk import (Criteria, MethodologyError, classify, flag, currency, rate_percent,
                  gr_value, side_for_operation, match_key, compute_factors)

METRICS = {
    'bank_rnr': ('РнР Банк', 'money'),
    'bank_cor': ('COR Банк', 'percent'),
    'bank_upr': ('УПР Банк', 'percent'),
    'mmb_rnr': ('РнР ММБ', 'money'),
    'banks_other_rnr': ('РнР Банки и прочие', 'money'),
    'fl_rnr': ('РнР ФЛ', 'money'),
    'fl_writeoff': ('Поступления по списанным ФЛ', 'money'),
    'fl_cor': ('COR ФЛ', 'percent'),
    'fl_upr': ('УПР ФЛ', 'percent'),
    'ul_writeoff': ('Поступления по списанным ЮЛ', 'money'),
    'kb_cor': ('COR КБ', 'percent'),
    'kb_upr': ('УПР КБ', 'percent'),
}
MONEY={k for k,(_,typ) in METRICS.items() if typ=='money'}
FACTOR_KEYS=('movement','financial_state','security_effect','revaluation')
FACTOR_LABELS={'movement':'Движение КП','financial_state':'Финансовое состояние','security_effect':'Обеспечение','revaluation':'Переоценка'}
SEGMENTS={'крупнейший','крупный','средний'}
MONTHS=('Январь','Февраль','Март','Апрель','Май','Июнь','Июль','Август','Сентябрь','Октябрь','Ноябрь','Декабрь')


def initialize():
    with engine.connect() as db:
        db.executescript('''
        CREATE TABLE IF NOT EXISTS dash_versions(
            id INTEGER PRIMARY KEY, state TEXT NOT NULL CHECK(state IN ('draft','published','archived')),
            created TEXT NOT NULL, published TEXT, author TEXT NOT NULL, note TEXT DEFAULT '', source_name TEXT DEFAULT '');
        CREATE TABLE IF NOT EXISTS dash_metrics(
            version_id INTEGER NOT NULL,year INTEGER NOT NULL,metric TEXT NOT NULL,
            scenario TEXT NOT NULL CHECK(scenario IN ('plan','fact')),
            month INTEGER NOT NULL CHECK(month BETWEEN 1 AND 12),value REAL NOT NULL,
            PRIMARY KEY(version_id,year,metric,scenario,month));
        CREATE TABLE IF NOT EXISTS dash_portfolios(
            id INTEGER PRIMARY KEY, asof TEXT NOT NULL,created TEXT NOT NULL,original_name TEXT NOT NULL,
            created_by TEXT NOT NULL,row_count INTEGER NOT NULL,position_count INTEGER NOT NULL,
            status TEXT DEFAULT 'active');
        CREATE INDEX IF NOT EXISTS dash_portfolios_date ON dash_portfolios(asof,id);
        CREATE TABLE IF NOT EXISTS dash_positions(
            snapshot_id INTEGER NOT NULL,key TEXT NOT NULL,unp TEXT NOT NULL,client TEXT,
            contract TEXT,ccy TEXT,side TEXT,operation TEXT,segment TEXT,
            debt_byn REAL NOT NULL,reserve_byn REAL NOT NULL,fx REAL NOT NULL,rate REAL NOT NULL,
            gr TEXT,ni INTEGER,pfn INTEGER,nvv INTEGER,restra TEXT,security TEXT,micro INTEGER,poc INTEGER,
            PRIMARY KEY(snapshot_id,key));
        CREATE INDEX IF NOT EXISTS dash_position_unp ON dash_positions(snapshot_id,unp);
        CREATE TABLE IF NOT EXISTS dash_factor_runs(
            id INTEGER PRIMARY KEY,start_id INTEGER NOT NULL,end_id INTEGER NOT NULL,
            month TEXT NOT NULL,created TEXT NOT NULL,rows INTEGER NOT NULL,
            errors INTEGER NOT NULL,amount_cents INTEGER NOT NULL DEFAULT 0,
            totals_json TEXT NOT NULL DEFAULT '{}', UNIQUE(start_id,end_id));
        CREATE TABLE IF NOT EXISTS dash_factor_rows(
            run_id INTEGER NOT NULL,key TEXT NOT NULL,unp TEXT,client TEXT,contract TEXT,
            segment TEXT, movement_cents INTEGER NOT NULL,financial_cents INTEGER NOT NULL,
            security_cents INTEGER NOT NULL,fx_cents INTEGER NOT NULL,expenses_cents INTEGER NOT NULL,
            explanation TEXT,PRIMARY KEY(run_id,key));
        CREATE TABLE IF NOT EXISTS dash_factor_errors(
            run_id INTEGER NOT NULL,key TEXT NOT NULL,description TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS dash_version_runs(
            version_id INTEGER NOT NULL,month TEXT NOT NULL,run_id INTEGER NOT NULL,
            PRIMARY KEY(version_id,month));
        CREATE TABLE IF NOT EXISTS dash_audit(
            id INTEGER PRIMARY KEY,at TEXT NOT NULL,actor TEXT NOT NULL,action TEXT NOT NULL,
            details TEXT NOT NULL DEFAULT '{}');
        ''')


def _audit(db,actor,action,details=None):
    db.execute('INSERT INTO dash_audit(at,actor,action,details) VALUES(?,?,?,?)',
               (engine.now(),actor,action,json.dumps(details or {},ensure_ascii=False)))


def _latest(db,state):
    return db.execute('SELECT * FROM dash_versions WHERE state=? ORDER BY id DESC LIMIT 1',(state,)).fetchone()


def _draft(db,actor):
    current=_latest(db,'draft')
    if current:return current['id']
    cur=db.execute('INSERT INTO dash_versions(state,created,author) VALUES(?,?,?)',('draft',engine.now(),actor))
    v=cur.lastrowid
    pub=_latest(db,'published')
    if pub:
        db.execute('INSERT INTO dash_metrics SELECT ?,year,metric,scenario,month,value FROM dash_metrics WHERE version_id=?',(v,pub['id']))
        db.execute('INSERT INTO dash_version_runs SELECT ?,month,run_id FROM dash_version_runs WHERE version_id=?',(v,pub['id']))
    return v


def _num(value, context):
    if isinstance(value,bool):raise ValueError(f'{context}: ожидается число')
    if value is None or (isinstance(value,str) and not value.strip()):return None
    s=str(value).replace('\xa0','').replace(' ','').replace(',','.').replace('−','-')
    try:n=Decimal(s)
    except InvalidOperation:raise ValueError(f'{context}: некорректное число {value!r}')
    if not n.is_finite():raise ValueError(f'{context}: бесконечное значение')
    return n


def _year(raw):
    try:y=int(raw)
    except (ValueError,TypeError):raise ValueError('Укажите год в ячейке B2 шаблона')
    if y<2020 or y>2100:raise ValueError('Год должен находиться в диапазоне 2020–2100')
    return y


def import_metrics(path,filename,actor):
    book=load_workbook(path,read_only=True,data_only=True)
    try:
        ws=book['Показатели'] if 'Показатели' in book else book.active
        year=_year(ws['B2'].value)
        headers=[engine.normalize_header(ws.cell(5,j).value) for j in range(1,15)]
        if headers[:2]!=['показатель','сценарий'] or [x.casefold() for x in MONTHS]!=headers[2:]:
            raise ValueError('Шапка должна содержать «Показатель», «Сценарий» и месяцы с января по декабрь в строке 5')
        names={engine.normalize_header(label):key for key,(label,_) in METRICS.items()}
        parsed={};rows_seen=set();errors=[]
        for rown,row in enumerate(ws.iter_rows(min_row=6,max_col=14,values_only=True),6):
            title=engine.normalize_header(row[0]);scenario=engine.normalize_header(row[1])
            if not title and not scenario and not any(x is not None for x in row[2:]):continue
            if not title or title not in names:
                errors.append(f'Строка {rown}: неизвестный показатель {row[0]!r}');continue
            if scenario not in ('бп','факт'):
                errors.append(f'Строка {rown}: сценарий должен быть БП или Факт');continue
            key=names[title];sc='plan' if scenario=='бп' else 'fact'
            if (key,sc) in rows_seen:
                errors.append(f'Строка {rown}: дублирование {row[0]} / {row[1]}');continue
            rows_seen.add((key,sc))
            for month,raw in enumerate(row[2:],1):
                if raw is None or (isinstance(raw,str) and not raw.strip()):continue
                try:val=_num(raw,f'Строка {rown}, {MONTHS[month-1]}')
                except ValueError as e:errors.append(str(e));continue
                if key not in MONEY and (val<0 or val>100):
                    errors.append(f'Строка {rown}: COR/УПР указывается числом от 0 до 100, например 2,5');continue
                parsed[(year,key,sc,month)]=float(val)
        if errors:raise ValueError('Ошибки Excel: '+'; '.join(errors[:15]))
        if not parsed:raise ValueError('В файле нет заполненных месячных значений')
    finally:book.close()
    with engine.connect() as db:
        version=_draft(db,actor)
        changes=[]
        for (y,metric,sc,month),val in parsed.items():
            old=db.execute('SELECT value FROM dash_metrics WHERE version_id=? AND year=? AND metric=? AND scenario=? AND month=?',
                           (version,y,metric,sc,month)).fetchone()
            if old is None or abs(old['value']-val)>1e-9:
                changes.append({'metric':METRICS[metric][0],'scenario':sc,'month':month,'old':old['value'] if old else None,'new':val})
            db.execute('INSERT INTO dash_metrics VALUES(?,?,?,?,?,?) ON CONFLICT(version_id,year,metric,scenario,month) DO UPDATE SET value=excluded.value',
                       (version,y,metric,sc,month,val))
        db.execute('UPDATE dash_versions SET source_name=? WHERE id=?',(filename,version))
        _audit(db,actor,'metrics_import',{'year':year,'count':len(parsed),'changed':len(changes),'filename':filename})
    return {'draft_id':version,'year':year,'values':len(parsed),'changed':len(changes),'preview':changes[:60]}


def _asof(date):
    try:d=dt.date.fromisoformat(date)
    except (ValueError,TypeError):raise ValueError('Дата портфеля должна быть в формате ГГГГ-ММ-ДД')
    if d.day!=1:raise ValueError('Фактический портфель должен быть на 1-е число месяца')
    return d.isoformat()


def _seg(s):
    s=engine.normalize_header(s)
    if s.startswith('крупнейш'):return 'Крупнейший'
    if s.startswith('крупн'):return 'Крупный'
    if s.startswith('средн'):return 'Средний'
    return s


def _money_cents(value):
    return int((Decimal(str(value))*100).quantize(Decimal('1'),rounding=ROUND_HALF_UP))


def _decround(value):
    return value.quantize(Decimal('.01'),rounding=ROUND_HALF_UP)


def _criteria(row):
    gr=gr_value(row['gr'])
    return Criteria(ni=row['ni'],pfn=row['pfn'],nvv=row['nvv'],restra=row['restra'] or '',
                    security=row['security'] or '',operation=row['operation'],currency=row['ccy'],
                    micro=bool(row['micro']),poc=bool(row['poc']),poc_rate=row['rate'] if gr=='ПОК' else None)


def _position_pairs(db,start_id,end_id):
    """Merge two sorted SQLite cursors without materializing whole portfolios."""
    left=iter(db.execute('SELECT * FROM dash_positions WHERE snapshot_id=? ORDER BY key',(start_id,)))
    right=iter(db.execute('SELECT * FROM dash_positions WHERE snapshot_id=? ORDER BY key',(end_id,)))
    a=next(left,None);b=next(right,None)
    while a is not None or b is not None:
        if b is None or (a is not None and a['key']<b['key']):
            yield a['key'],dict(a),None
            a=next(left,None)
        elif a is None or b['key']<a['key']:
            yield b['key'],None,dict(b)
            b=next(right,None)
        else:
            yield a['key'],dict(a),dict(b)
            a=next(left,None);b=next(right,None)


def _same_group(pos):
    return pos is not None and pos['segment'] in ('Крупнейший','Крупный','Средний')


def _calculate_factor_row(old,new):
    """Return signed BYN cents for four factors; reject unmatched classification.

    Whole-contract addition/removal is a portfolio movement. For overlapping
    contracts reuse the approved forecasting bridge (without accepting its
    'override' or 'rounding' placeholders as money factors).
    """
    old_in=_same_group(old);new_in=_same_group(new)
    if not(old_in or new_in):return None
    # Crossing the segment perimeter requires an explicit agreed accounting policy.
    if old is not None and new is not None and old_in!=new_in:
        raise ValueError('Переход между Средний+ и другим сегментом: требуется правило классификации')
    if old is None or new is None:
        p=old if old is not None else new
        r=_money_cents(p['reserve_byn'])
        direction=1 if old is not None else -1
        if old is not None:return {'movement':direction*r,'financial_state':0,'security_effect':0,'revaluation':0,'expenses':direction*r,'explanation':'Выбытие договора'}
        base=.5 if gr_value(p['gr'])==1 else 5.0 if isinstance(gr_value(p['gr']),int) and gr_value(p['gr'])>=2 else p['rate']
        basec=_money_cents(Decimal(str(p['debt_byn']))*Decimal(str(base))/100)
        extra=r-basec
        if extra and not (isinstance(gr_value(p['gr']),int) and gr_value(p['gr'])>2):
            raise ValueError('Новый договор со ставкой, не объяснённой базовыми 0,5% / 5%: требуется методика')
        return {'movement':-basec,'financial_state':-extra,'security_effect':0,'revaluation':0,
                'expenses':-r,'explanation':'Новый договор: базовый резерв + эффект ГР выше 2'}
    if old['ccy']!=new['ccy']:
        raise ValueError('Изменена валюта договорного ключа')
    # Prevent the same record from silently being represented by a different business segment.
    if old['segment']!=new['segment']:
        explanation='Внутренний переход сегмента Средний+ (%s → %s)'%(old['segment'],new['segment'])
    else:explanation='Изменение действующего договора'
    p={'debt':old['debt_byn']/old['fx'], 'od':old['debt_byn'], 'fx':old['fx'],
       'rate':old['rate'], 'reserve':old['reserve_byn'],'criteria':_criteria(old).as_dict(),'gr':old['gr']}
    c={'debt':new['debt_byn']/new['fx'], 'od':new['debt_byn'], 'fx':new['fx'],
       'rate':new['rate'], 'reserve':new['reserve_byn'],'criteria':_criteria(new).as_dict(),'gr':new['gr']}
    try:result=compute_factors(p,c,new_contract=False)
    except (MethodologyError,ValueError,TypeError,KeyError) as e:raise ValueError('Невозможно разложить изменения: '+str(e))
    override=float(result['factors'].get('override',0))
    if abs(override)>.009:
        raise ValueError(f'Изменение ставки без объясняющего критерия ({override:+.2f} BYN)')
    values={'movement':_money_cents(result['movement']),'financial_state':_money_cents(result['financial_state']),
            'security_effect':_money_cents(result['security_effect']),'revaluation':_money_cents(result['fx']),
            'expenses':_money_cents(result['expenses']),'explanation':explanation}
    if sum(values[k] for k in FACTOR_KEYS)!=values['expenses']:
        raise ValueError('Четыре фактора не сходятся с фактическими расходами до 0,01 BYN')
    return values


def _build_run(db,start_id,end_id):
    begin=db.execute('SELECT asof FROM dash_portfolios WHERE id=?',(start_id,)).fetchone()['asof']
    end=db.execute('SELECT asof FROM dash_portfolios WHERE id=?',(end_id,)).fetchone()['asof']
    if end!=_next_month(begin):raise ValueError('Для факторного анализа требуются два последовательных портфеля')
    run=db.execute('INSERT INTO dash_factor_runs(start_id,end_id,month,created,rows,errors,totals_json) VALUES(?,?,?,?,0,0,\'{}\')',
                   (start_id,end_id,begin[:7],engine.now())).lastrowid
    totals={k:0 for k in FACTOR_KEYS};total=0;count=0;errors=0
    # Full portfolio perimeters, not only overlapping contract keys.
    for key,old,new in _position_pairs(db,start_id,end_id):
        if not (_same_group(old) or _same_group(new)):continue
        try:r=_calculate_factor_row(old,new)
        except ValueError as e:
            errors+=1
            if errors<=2000:db.execute('INSERT INTO dash_factor_errors VALUES(?,?,?)',(run,key,str(e)))
            continue
        if r is None:continue
        p=new or old;count+=1
        db.execute('INSERT INTO dash_factor_rows VALUES(?,?,?,?,?,?,?,?,?,?,?,?)',
                   (run,key,p['unp'],p['client'],p['contract'],p['segment'],r['movement'],r['financial_state'],
                    r['security_effect'],r['revaluation'],r['expenses'],r['explanation']))
        total+=r['expenses']
        for k in FACTOR_KEYS:totals[k]+=r[k]
    db.execute('UPDATE dash_factor_runs SET rows=?,errors=?,amount_cents=?,totals_json=? WHERE id=?',
               (count,errors,total,json.dumps(totals),run))
    return run,{'rows':count,'errors':errors,'amount_cents':total,'totals_cents':totals,'month':begin[:7]}


def _next_month(asof):
    y,m=map(int,asof[:7].split('-'))
    if m==12:y+=1;m=1
    else:m+=1
    return f'{y:04d}-{m:02d}-01'


def import_portfolio(path,filename,asof,actor):
    """Atomic streaming import for up to hundreds of thousands of XLSX records."""
    asof=_asof(asof)
    book=load_workbook(path,read_only=True,data_only=True)
    try:
        ws,headrow,header=engine.find_sheet_header(book,['УНП','Номер договора','Тип операции','Код валюты','Сегмент','Резерв факт','% рез'])
        h={engine.normalize_header(v):j for j,v in enumerate(header) if v is not None}
        required=['Задолженность, тыс BYN','Курс','ГР','НИ','ПФН','НВВ','Рестра','Обеспеченность']
        for item in required:
            if engine.normalize_header(item) not in h:raise ValueError('Нет столбца фактического портфеля: '+item)
        count=0;medium=0;positions=0
        with engine.connect() as db:
            snap=db.execute('INSERT INTO dash_portfolios(asof,created,original_name,created_by,row_count,position_count) VALUES(?,?,?,?,0,0)',
                            (asof,engine.now(),filename,actor)).lastrowid
            for lineno,row in enumerate(ws.iter_rows(min_row=headrow+1,values_only=True),headrow+1):
                unp=engine.normalize_unp(engine.get(row,h,'УНП'))
                contract=str(engine.get(row,h,'Номер договора') or '').strip()
                if not unp or not contract:continue
                try:
                    ccy=currency(engine.get(row,h,'Код валюты'))
                    operation=str(engine.get(row,h,'Тип операции') or '').strip()
                    side=side_for_operation(operation)
                    key=match_key(unp,contract,ccy,side)
                    seg=_seg(engine.get(row,h,'Сегмент'))
                    if not seg:raise ValueError('Не заполнен сегмент')
                    debt=_num(engine.get(row,h,'Задолженность, тыс BYN'),'задолженность')
                    reserve=_num(engine.get(row,h,'Резерв факт'),'резерв факт')
                    fx=_num(engine.get(row,h,'Курс'),'курс')
                    if fx is None or fx<=0:raise ValueError('Курс должен быть положительным')
                    if debt is None or reserve is None or debt<0 or reserve<0:raise ValueError('Недопустимая задолженность/резерв')
                    rate=rate_percent(engine.get(row,h,'% рез'))
                    if rate is None:raise ValueError('Не заполнен % резервирования')
                    debt_byn=debt*1000;reserve_byn=reserve*1000
                    if abs(reserve_byn-_decround(debt_byn*Decimal(str(rate))/100))>Decimal('.01'):
                        raise ValueError('Резерв факт не совпадает с задолженностью × % резервирования (допуск 0,01 BYN)')
                    gr=str(engine.get(row,h,'ГР') or '').strip()
                    p={'key':key,'unp':unp,'contract':contract,'client':str(engine.get(row,h,'Клиент') or ''),
                       'ccy':ccy,'side':side,'operation':operation,'segment':seg,
                       'debt_byn':float(debt_byn),'reserve_byn':float(reserve_byn),'fx':float(fx),
                       'rate':rate,'gr':gr,'ni':flag(engine.get(row,h,'НИ')),
                       'pfn':flag(engine.get(row,h,'ПФН')),'nvv':flag(engine.get(row,h,'НВВ')),
                       'restra':str(engine.get(row,h,'Рестра') or ''),'security':str(engine.get(row,h,'Обеспеченность') or ''),
                       'micro':int('микро' in str(engine.get(row,h,'Вид кредита') or '').casefold()),
                       'poc':int(gr_value(gr)=='ПОК')}
                    prior=db.execute('SELECT * FROM dash_positions WHERE snapshot_id=? AND key=?',(snap,key)).fetchone()
                    if prior:
                        attrs=('unp','contract','ccy','side','operation','segment','rate','gr','ni','pfn','nvv','restra','security','micro','poc','fx')
                        if any(prior[k]!=p[k] for k in attrs):
                            raise ValueError('Различные критерии или сегменты в строках одного договорного ключа: '+key)
                        db.execute('UPDATE dash_positions SET debt_byn=debt_byn+?,reserve_byn=reserve_byn+? WHERE snapshot_id=? AND key=?',
                                   (p['debt_byn'],p['reserve_byn'],snap,key))
                    else:
                        db.execute('INSERT INTO dash_positions VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
                           (snap,p['key'],p['unp'],p['client'],p['contract'],p['ccy'],p['side'],p['operation'],p['segment'],
                            p['debt_byn'],p['reserve_byn'],p['fx'],p['rate'],p['gr'],p['ni'],p['pfn'],p['nvv'],
                            p['restra'],p['security'],p['micro'],p['poc']))
                        positions+=1
                    count+=1
                    if seg in ('Крупнейший','Крупный','Средний'):medium+=1
                except (ValueError,MethodologyError) as e:
                    raise ValueError(f'Портфель не принят, строка {lineno}: {e}') from e
            if not count:raise ValueError('Не обнаружено договоров в файле')
            if not medium:raise ValueError('Нет ни одной позиции сегментов Крупнейший / Крупный / Средний: проверьте «Сегмент»')
            db.execute('UPDATE dash_portfolios SET row_count=?,position_count=? WHERE id=?',(count,positions,snap))
            draft=_draft(db,actor)
            runs=[]
            for begin in (date_before(asof),asof):
                end=_next_month(begin)
                old=db.execute('SELECT id FROM dash_portfolios WHERE asof=? ORDER BY id DESC LIMIT 1',(begin,)).fetchone()
                nxt=db.execute('SELECT id FROM dash_portfolios WHERE asof=? ORDER BY id DESC LIMIT 1',(end,)).fetchone()
                if not old or not nxt:continue
                exists=db.execute('SELECT id FROM dash_factor_runs WHERE start_id=? AND end_id=?',(old['id'],nxt['id'])).fetchone()
                if exists:
                    runid=exists['id'];rr=db.execute('SELECT * FROM dash_factor_runs WHERE id=?',(runid,)).fetchone()
                    info={'rows':rr['rows'],'errors':rr['errors'],'amount_cents':rr['amount_cents'],'month':begin[:7]}
                else:runid,info=_build_run(db,old['id'],nxt['id'])
                db.execute('INSERT INTO dash_version_runs VALUES(?,?,?) ON CONFLICT(version_id,month) DO UPDATE SET run_id=excluded.run_id',
                           (draft,begin[:7],runid))
                runs.append({'id':runid,**info})
            _audit(db,actor,'portfolio_import',{'asof':asof,'name':filename,'snapshot_id':snap,'runs':runs})
        return {'snapshot_id':snap,'asof':asof,'rows':count,'positions':positions,'medium_rows':medium,'draft_id':draft,'runs':runs}
    finally:book.close()


def date_before(asof):
    y,m=map(int,asof[:7].split('-'))
    if m==1:y-=1;m=12
    else:m-=1
    return f'{y:04d}-{m:02d}-01'


def publish(actor,note=''):
    with engine.connect() as db:
        draft=_latest(db,'draft')
        if not draft:raise ValueError('Нет черновика для публикации')
        runs=list(db.execute('SELECT r.month,r.errors FROM dash_version_runs vr JOIN dash_factor_runs r ON r.id=vr.run_id WHERE vr.version_id=?',(draft['id'],)))
        blocked=[r['month'] for r in runs if r['errors']]
        if blocked:raise ValueError('Факторный анализ не сходится по месяцам: '+', '.join(blocked)+'. Исправьте ошибки до публикации.')
        values=db.execute('SELECT COUNT(*) n FROM dash_metrics WHERE version_id=?',(draft['id'],)).fetchone()['n']
        if not values and not runs:raise ValueError('Черновик не содержит данных')
        db.execute("UPDATE dash_versions SET state='archived' WHERE state='published'")
        db.execute("UPDATE dash_versions SET state='published',published=?,note=? WHERE id=?",
                   (engine.now(),str(note)[:300],draft['id']))
        _audit(db,actor,'publish',{'version':draft['id'],'values':values,'runs':len(runs)})
        return {'version':draft['id'],'values':values,'factor_periods':len(runs),'published_at':engine.now()}


def restore(version_id,actor):
    with engine.connect() as db:
        item=db.execute("SELECT id FROM dash_versions WHERE id=? AND state IN ('published','archived')",(version_id,)).fetchone()
        if not item:raise ValueError('Версия для восстановления не найдена')
        old=_latest(db,'draft')
        if old:
            db.execute('DELETE FROM dash_metrics WHERE version_id=?',(old['id'],))
            db.execute('DELETE FROM dash_version_runs WHERE version_id=?',(old['id'],))
            db.execute('DELETE FROM dash_versions WHERE id=?',(old['id'],))
        new=db.execute('INSERT INTO dash_versions(state,created,author,note) VALUES(?,?,?,?)',
                       ('draft',engine.now(),actor,f'Восстановление версии {version_id}')).lastrowid
        db.execute('INSERT INTO dash_metrics SELECT ?,year,metric,scenario,month,value FROM dash_metrics WHERE version_id=?',(new,version_id))
        db.execute('INSERT INTO dash_version_runs SELECT ?,month,run_id FROM dash_version_runs WHERE version_id=?',(new,version_id))
        _audit(db,actor,'restore_staged',{'source':version_id,'draft':new})
        return {'draft_id':new,'restored_from':version_id}


def _metric_data(db,v,year):
    result={}
    for r in db.execute('SELECT metric,scenario,month,value FROM dash_metrics WHERE version_id=? AND year=?',(v,year)):
        result.setdefault(r['metric'],{}).setdefault(r['scenario'],{})[r['month']]=r['value']
    for r in db.execute('SELECT vr.month,r.totals_json,r.amount_cents FROM dash_version_runs vr JOIN dash_factor_runs r ON r.id=vr.run_id WHERE vr.version_id=? AND substr(vr.month,1,4)=?',(v,str(year))):
        month=int(r['month'][5:7]);result.setdefault('medium_rnr',{}).setdefault('fact',{})[month]=r['amount_cents']/100_000_000
        for key,cents in json.loads(r['totals_json']).items():
            result.setdefault('factor_'+key,{}).setdefault('fact',{})[month]=cents/100_000_000
    return result


def dashboard_data(year,month,admin=False):
    year=_year(year)
    try:month=int(month)
    except (TypeError,ValueError):raise ValueError('Некорректный месяц')
    if not 1<=month<=12:raise ValueError('Месяц должен быть от 1 до 12')
    with engine.connect() as db:
        v=_latest(db,'draft') if admin else _latest(db,'published')
        if not v:return {'version':None,'year':year,'month':month,'metrics':{},'factor_names':FACTOR_LABELS,'is_draft':admin,'status':'empty'}
        src=_metric_data(db,v['id'],year)
        out={}
        for key,series in src.items():
            out[key]={}
            for sc,months in series.items():
                current=[months.get(m) for m in range(1,month+1)]
                if key in MONEY or key=='medium_rnr' or key.startswith('factor_'):
                    out[key][sc]={'series':current,'value':round(sum(current),6) if all(z is not None for z in current) else None,
                                   'monthly':True}
                else:out[key][sc]={'series':current,'value':current[-1] if current else None,'monthly':False}
        return {'version':v['id'],'created':v['created'],'published':v['published'],'year':year,'month':month,
                'is_draft':admin,'status':v['state'],'metrics':out,'factor_names':FACTOR_LABELS}


def admin_state():
    with engine.connect() as db:
        versions=[dict(r) for r in db.execute('SELECT id,state,created,published,author,note,source_name FROM dash_versions ORDER BY id DESC LIMIT 40')]
        ports=[dict(r) for r in db.execute('SELECT id,asof,created,original_name,row_count,position_count FROM dash_portfolios ORDER BY asof DESC,id DESC LIMIT 50')]
        draft=_latest(db,'draft');pub=_latest(db,'published')
        runs=[]
        if draft:
            runs=[dict(r) for r in db.execute('SELECT vr.month,r.id,r.rows,r.errors,r.amount_cents FROM dash_version_runs vr JOIN dash_factor_runs r ON vr.run_id=r.id WHERE vr.version_id=? ORDER BY vr.month',(draft['id'],))]
        return {'versions':versions,'portfolios':ports,'runs':runs,'draft_id':draft['id'] if draft else None,'published_id':pub['id'] if pub else None}


def factor_detail(year,month,search='',page=1,limit=50):
    """Contract-level YTD factor detail for the published snapshot, not just month-end."""
    year=_year(year);month=int(month);page=max(1,int(page));limit=max(1,min(int(limit),100))
    if not 1<=month<=12:raise ValueError('Некорректный месяц')
    ym=f'{year:04d}-{month:02d}'
    with engine.connect() as db:
        published=_latest(db,'published')
        if not published:return {'total':0,'rows':[],'page':page,'limit':limit}
        runs=list(db.execute('SELECT month,run_id FROM dash_version_runs WHERE version_id=? AND month BETWEEN ? AND ? ORDER BY month',
                 (published['id'],f'{year:04d}-01',ym)))
        if len(runs)!=month or any(row['month']!=f'{year:04d}-{i:02d}' for i,row in enumerate(runs,1)):
            return {'total':0,'rows':[],'page':page,'limit':limit,'error':'Накопленный факторный анализ не полон за выбранный период'}
        ids=[row['run_id'] for row in runs]
        placeholders=','.join('?' for _ in ids)
        pattern='%'+search.strip()+'%'
        where=f'WHERE run_id IN ({placeholders}) AND (unp LIKE ? OR client LIKE ? OR contract LIKE ?)'
        args=(*ids,pattern,pattern,pattern)
        count=db.execute('SELECT COUNT(*) n FROM (SELECT key FROM dash_factor_rows '+where+' GROUP BY key)',args).fetchone()['n']
        sql=('SELECT key,MAX(unp) unp,MAX(client) client,MAX(contract) contract,MAX(segment) segment,'
             'SUM(movement_cents) movement_cents,SUM(financial_cents) financial_cents,'
             'SUM(security_cents) security_cents,SUM(fx_cents) fx_cents,'
             'SUM(expenses_cents) expenses_cents FROM dash_factor_rows '+where+
             ' GROUP BY key ORDER BY ABS(SUM(expenses_cents)) DESC LIMIT ? OFFSET ?')
        rows=[dict(r) for r in db.execute(sql,(*args,limit,(page-1)*limit))]
        for row in rows:
            for k in ('movement_cents','financial_cents','security_cents','fx_cents','expenses_cents'):
                row[k.removesuffix('_cents')]=row.pop(k)/100_000_000
        return {'total':count,'rows':rows,'page':page,'limit':limit}


def factor_errors(run_id,limit=100):
    with engine.connect() as db:
        r=db.execute('SELECT month,errors,rows FROM dash_factor_runs WHERE id=?',(run_id,)).fetchone()
        if not r:raise ValueError('Расчёт не найден')
        return {'month':r['month'],'errors':r['errors'],'rows':r['rows'],
                'items':[dict(x) for x in db.execute('SELECT key,description FROM dash_factor_errors WHERE run_id=? LIMIT ?', (run_id,max(1,min(int(limit),200))))]}
