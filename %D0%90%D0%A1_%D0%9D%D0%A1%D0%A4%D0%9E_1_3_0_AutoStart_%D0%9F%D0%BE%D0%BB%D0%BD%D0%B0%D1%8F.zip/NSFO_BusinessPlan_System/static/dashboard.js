/* Fact vs Plan dashboard. Server performs all reserve calculations and version checks. */
const D={year:new Date().getFullYear(),month:new Date().getMonth()+1,admin:false,metrics:null,run:null};
const D_NAMES=['Янв','Фев','Мар','Апр','Май','Июн','Июл','Авг','Сен','Окт','Ноя','Дек'];
const dashGet=(url,params={})=>api(url+'?'+new URLSearchParams(params));
const dashPost=(url,body)=>api(url,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
const mValue=(data,key,scenario)=>data?.metrics?.[key]?.[scenario]?.value??null;
const mSeries=(data,key,scenario)=>data?.metrics?.[key]?.[scenario]?.series||[];
const fmtM=v=>v==null?'Нет данных':money(v,2)+' млн BYN';
const pct=v=>v==null?'—':money(v,2)+'%';

function dashBar(name,plan,fact,{hint='',compact=false,showDelta=true}={}){
 // Same zero axis is preserved for positive/negative values and opposite signs.
 let scale=Math.max(1e-8,Math.abs(plan||0),Math.abs(fact||0));
 let shape=(value,cls)=>{
  if(value==null)return '';
  let pctWidth=Math.min(48,Math.abs(value)/scale*48);
  return `<span class="db-${cls}" style="${value>=0?'left:50%':'right:50%'};width:${pctWidth.toFixed(3)}%"></span>`;
 };
 const delta=plan==null||fact==null?null:fact-plan;
 let tail='';
 if(delta!=null&&Math.sign(fact)===Math.sign(plan)&&Math.abs(fact)>Math.abs(plan)){
  const start=Math.abs(plan)/scale*48,w=(Math.abs(fact)-Math.abs(plan))/scale*48;
  tail=`<span class="db-over" style="${fact>=0?`left:calc(50% + ${start.toFixed(3)}%)`:`right:calc(50% + ${start.toFixed(3)}%)`};width:${w.toFixed(3)}%"></span>`;
 }
 return `<div class="dashbar ${compact?'compact':''}"><div class="db-label"><b>${esc(name)}</b>${hint?`<span>${esc(hint)}</span>`:''}</div>
 <div class="db-track" title="${esc(name)} · БП: ${esc(fmtM(plan))}; факт: ${esc(fmtM(fact))}"><div class="db-zero"></div>${shape(plan,'plan')}${shape(fact,'fact')}${tail}</div>
 <div class="db-values"><span>БП <b>${plan==null?'—':money(plan,2)}</b></span><span>Факт <b>${fact==null?'—':money(fact,2)}</b></span>${showDelta&&delta!=null?`<span class="${delta<0?'red':'green'}">Δ ${delta>0?'+':''}${money(delta,2)}</span>`:''}</div></div>`;
}
function dashChart(name,plan,fact){
 const n=Math.max(plan.length,fact.length,1);const values=[...plan,...fact].filter(x=>x!=null&&Number.isFinite(x));
 if(!values.length)return `<div class="dc-chart"><div class="dc-chart-head"><b>${esc(name)}</b><span>Нет данных</span></div><div class="dc-empty">Загрузите помесячные COR / УПР</div></div>`;
 let lo=Math.min(...values),hi=Math.max(...values),range=hi-lo;if(range<.01){hi+=.3;lo-=.3;range=hi-lo}else {lo-=range*.13;hi+=range*.13;range=hi-lo}
 const X=i=>n===1?198:46+310*i/(n-1),Y=v=>123-102*(v-lo)/range;
 const paths=(a)=>{const chunks=[];let active=[];for(let i=0;i<n;i++){let v=a[i];if(v!=null){active.push(`${active.length?'L':'M'}${X(i).toFixed(1)} ${Y(v).toFixed(1)}`)}else if(active.length){chunks.push(active.join(' '));active=[]}}if(active.length)chunks.push(active.join(' '));return chunks.join(' ')};
 const pts=(a,color)=>a.map((v,i)=>v==null?'':`<circle cx="${X(i)}" cy="${Y(v)}" r="3.7" fill="${color}" stroke="white" stroke-width="1.4"><title>${D_NAMES[i]}: ${money(v,2)}%</title></circle>`).join('');
 return `<div class="dc-chart"><div class="dc-chart-head"><b>${esc(name)}</b><span><i class="dc-dot plan"></i> БП <i class="dc-dot fact"></i> Факт</span></div>
 <svg role="img" aria-label="Динамика ${esc(name)}" class="dc-svg" viewBox="0 0 374 152" preserveAspectRatio="xMidYMid meet">
 ${[0,1,2,3].map(i=>{let v=lo+(hi-lo)*(3-i)/3;let y=21+i*34;return `<line x1="43" x2="362" y1="${y}" y2="${y}" stroke="#e7edf5"/><text x="38" y="${y+4}" text-anchor="end" font-size="10" fill="#8393a9">${money(v,1)}</text>`}).join('')}
 <path d="${paths(plan)}" stroke="#5b83d2" stroke-width="2.8" fill="none" stroke-linecap="round" stroke-linejoin="round"/>
 <path d="${paths(fact)}" stroke="#159b8b" stroke-width="3" fill="none" stroke-linecap="round" stroke-linejoin="round"/>
 ${pts(plan,'#5b83d2')}${pts(fact,'#159b8b')}
 ${Array.from({length:n},(_,i)=>`<text x="${X(i)}" y="144" fill="#8796a9" font-size="10" text-anchor="middle">${D_NAMES[i]}</text>`).join('')}
 </svg><div class="dc-latest">Текущий месяц: БП <b>${pct(plan[n-1])}</b> · Факт <b>${pct(fact[n-1])}</b></div></div>`;
}
const dashWrap=(title,subtitle,body)=>`<div class="dc-card"><div class="dc-card-head"><h2>${esc(title)}</h2>${subtitle?`<div>${esc(subtitle)}</div>`:''}</div>${body}</div>`;
const dashBarOf=(data,key,title,opts)=>dashBar(title,mValue(data,key,'plan'),mValue(data,key,'fact'),opts||{});
const dashChartOf=(data,key,title)=>dashChart(title,mSeries(data,key,'plan'),mSeries(data,key,'fact'));
function dashControls(admin){const years=Array.from({length:14},(_,i)=>2023+i).map(y=>`<option ${D.year===y?'selected':''} value="${y}">${y}</option>`).join('');
 return `<div class="dc-controls"><label>Год <select id="dc-year" class="control">${years}</select></label><label>Период <select id="dc-month" class="control">${D_NAMES.map((x,i)=>`<option ${D.month===i+1?'selected':''} value="${i+1}">${x}</option>`).join('')}</select></label>${admin?`<span class="badge orange">Предпросмотр черновика</span>`:''}</div>`;}
function dashLegend(){return `<div class="dc-legend"><b>Как читать бары</b><span><i class="leg-plan"></i> Бизнес-план — сплошная заливка</span><span><i class="leg-fact"></i> Факт — диагональная штриховка</span><span><i class="leg-over"></i> Продолжение факта за планом</span><span>Денежные значения: млн BYN. Для отрицательных величин используется левая сторона нулевой оси.</span></div>`;}
async function renderDashboard(preview=false){
 D.admin=preview;loading('Получаем показатели дашборда...');
 let data;
 try{data=await dashGet(preview?'/api/dashboard/preview':'/api/dashboard',{year:D.year,month:D.month})}catch(e){error(e);return}
 D.metrics=data;
 const rnrMedium=mValue(data,'medium_rnr','fact');
 const factors=['movement','financial_state','security_effect','revaluation'].map((k)=>dashBar(data.factor_names?.[k]||k,null,mValue(data,'factor_'+k,'fact'),{compact:true,showDelta:false})).join('');
 const top=`<div class="dc-topgrid">${dashWrap('Расходы на резервы · Банк','Накопленным с начала года',dashBarOf(data,'bank_rnr','РнР банка'))}${dashWrap('COR банка','Помесячная динамика',dashChartOf(data,'bank_cor','COR · Банк'))}${dashWrap('УПР банка','Помесячная динамика',dashChartOf(data,'bank_upr','УПР · Банк'))}</div>`;
 const left=`<div class="dc-col">${dashWrap('Физические лица','Денежные показатели — накопленным',dashBarOf(data,'fl_rnr','Расходы на резервы')+dashBarOf(data,'fl_writeoff','Поступления по списанным')+dashChartOf(data,'fl_cor','COR · ФЛ')+dashChartOf(data,'fl_upr','УПР · ФЛ'))}${dashWrap('Банки и прочие','Накопленным с января',dashBarOf(data,'banks_other_rnr','Расходы на резервы'))}</div>`;
 const right=`<div class="dc-col">${dashWrap('Средний+','Крупнейший + Крупный + Средний',dashBar('Расходы на резервы',null,rnrMedium,{hint:'БП пока не определён'})+`<div class="dc-subtitle">Факторы фактических расходов · накопленным</div>`+factors+`<p class="dc-foot">Четыре фактора должны точно сходиться с фактическими расходами. Неопубликованные или невыверенные расчёты не показываются.</p>`+(S.auth?.role==='admin'?'<button class="btn mini" id="dc-detail">Детализация по договорам</button>':''))}${dashWrap('ММБ','Накопленным с января',dashBarOf(data,'mmb_rnr','Расходы на резервы'))}${dashWrap('Все юридические лица','Накопленным с января',dashBarOf(data,'ul_writeoff','Поступления по списанным'))}${dashWrap('Корпоративный бизнес','Готовые помесячные проценты',dashChartOf(data,'kb_cor','COR · КБ')+dashChartOf(data,'kb_upr','УПР · КБ'))}</div>`;
 $('content').innerHTML=`<div class="dc-page"><div class="dc-head"><div><div class="eyebrow">Модуль 2 / Аналитика банка</div><h1>Факт vs План</h1><p class="sub">Показатели с начала года по ${D_NAMES[D.month-1].toLowerCase()} ${D.year} года · ${data.version?'версия '+data.version:'нет публикации'}</p></div>${dashControls(preview)}</div>
 ${data.version?`${top}<div class="dc-columns">${left}${right}</div>`:`<div class="card card-pad"><div class="empty">Нет ${preview?'загруженного черновика':'опубликованных данных'} за выбранный период. Администратор может загрузить готовые показатели из Excel.</div></div>`}
 ${dashLegend()}</div>`;
 $('dc-year').onchange=e=>{D.year=+e.target.value;renderDashboard(preview)};
 $('dc-month').onchange=e=>{D.month=+e.target.value;renderDashboard(preview)};
 const details=$('dc-detail');if(details)details.onclick=()=>openDashDetail();
}
async function openDashDetail(search='',page=1){
 try{const data=await dashGet('/api/dashboard/factors',{year:D.year,month:D.month,search,page});
 const rows=data.rows.map(x=>`<tr><td>${esc(x.client)}<br><small>${esc(x.unp)}</small></td><td>${esc(x.contract)}</td><td class="right">${money(x.expenses)}</td><td class="right">${money(x.movement)}</td><td class="right">${money(x.financial)}</td><td class="right">${money(x.security)}</td><td class="right">${money(x.fx)}</td></tr>`);
 modal('Средний+ · детализация факторов',`<div class="sub">Только опубликованные результаты. ${data.total} договорных позиций</div><div class="toolbar"><input id="df-search" class="input grow" placeholder="УНП, клиент, договор" value="${esc(search)}"><button class="btn mini" id="df-apply">Найти</button></div>${table(['Клиент / УНП','Договор','РнР','КП','ФС','Обеспечение','Переоценка'],rows)}<div class="pagination"><button class="btn mini" id="df-prev" ${page<=1?'disabled':''}>Назад</button><span>Страница ${page}</span><button class="btn mini" id="df-next" ${page*data.limit>=data.total?'disabled':''}>Далее</button></div>`);
 $('df-apply').onclick=()=>openDashDetail($('df-search').value,1);
 $('df-prev').onclick=()=>openDashDetail(search,page-1);
 $('df-next').onclick=()=>openDashDetail(search,page+1);
 }catch(e){error(e)}
}
async function renderDashAdmin(){if(S.auth?.role!=='admin')return nav('dashboard');loading('Проверяем загрузки и версии...');
 let r;try{r=await api('/api/dashboard/admin')}catch(e){error(e);return}
 const report=r.runs.map(x=>`<tr><td>${esc(x.month)}</td><td>${x.rows}</td><td>${x.errors?badge(x.errors+' ошибок','red'):badge('4 фактора сходятся','green')}</td><td>${money(x.amount_cents/100000000)} млн</td><td>${x.errors?`<button class="btn mini" data-run-errors="${x.id}">Проверить</button>`:'—'}</td></tr>`);
 const ports=r.portfolios.map(x=>`<tr><td>${esc(labelDate(x.asof))}</td><td>${esc(x.original_name)}</td><td>${x.row_count}</td><td>${x.position_count}</td><td>${esc(x.created)}</td></tr>`);
 const versions=r.versions.map(x=>`<tr><td>#${x.id}</td><td>${esc(x.created)}</td><td>${x.state==='published'?badge('Опубликована','green'):x.state==='draft'?badge('Черновик','orange'):badge('Архив')}</td><td>${esc(x.author)}</td><td>${x.state==='archived'?`<button data-restore="${x.id}" class="btn mini">Восстановить</button>`:'—'}</td></tr>`);
 $('content').innerHTML=`<div class="dc-page"><div class="dc-head"><div><div class="eyebrow">Администрирование / Только администратор</div><h1>Управление дашбордом</h1><p class="sub">Загрузка исходных данных · Проверка · Черновик · Публикация</p></div><span>${badge('Черновик '+(r.draft_id||'не создан'),'orange')} ${badge('Публикация '+(r.published_id||'не создана'),'green')}</span></div>
 <div class="dc-admin-grid">${dashWrap('1 · Готовые показатели','Единый Excel, денежные значения в млн BYN',`<div class="dc-upload"><div class="upload-pict">⇧</div><b>Excel с БП и фактом</b><p>Банк, ФЛ, ММБ, банки и прочие, COR, УПР, списанные ЮЛ и ФЛ</p><input type="file" id="dc-metrics-file" accept=".xlsx"><a class="btn mini" href="/api/dashboard/template.xlsx">Скачать шаблон Excel</a></div>`)}
 ${dashWrap('2 · Фактические портфели ЮЛ','Формат выверенного факта из первого модуля',`<div class="dc-upload"><label>Дата фактического портфеля (1-е число месяца)</label><input class="input" type="date" id="dc-asof" value="${D.year}-${String(D.month).padStart(2,'0')}-01"><input type="file" id="dc-portfolio-file" accept=".xlsx"><p>Расчёт Средний+ по четырём факторам выполняется автоматически при наличии двух последовательных портфелей.</p></div>`)}</div>
 <div class="dc-admin-actions"><button class="btn" id="dc-preview">Предпросмотр дашборда</button><button class="btn primary" id="dc-publish" ${r.draft_id?'':'disabled'}>Опубликовать проверенные данные</button><span class="sub">Публикация заблокирована при несходимости хотя бы одного договора Средний+.</span></div>
 ${dashWrap('Расчёты Средний+ в черновике','Каждый месяц: предыдущий портфель vs текущий',report.length?table(['Период','Договоров','Сверка','РнР','Контроль'],report):empty('Загрузите фактические портфели за две соседние даты'))}
 ${dashWrap('Загруженные фактические портфели','В базе сохраняются нормализованные снимки',ports.length?table(['На дату','Файл','Строк','Позиций','Загрузка'],ports):empty('Портфели ещё не загружались'))}
 ${dashWrap('Версии публикаций','Черновики и архивы хранятся отдельно',versions.length?table(['Версия','Создана','Статус','Автор','Действие'],versions):empty('Версий ещё нет'))}
 </div>`;
 $('dc-metrics-file').onchange=e=>{if(e.target.files.length)dashUpload(e.target.files[0],'metrics')};
 $('dc-portfolio-file').onchange=e=>{if(e.target.files.length)dashUpload(e.target.files[0],'portfolio')};
 $('dc-preview').onclick=()=>renderDashboard(true);
 $('dc-publish').onclick=async()=>{if(!confirm('Опубликовать проверенный черновик для сотрудников банка?'))return;
  try{const v=await dashPost('/api/dashboard/publish',{note:'Публикация дашборда'});toast(`Версия ${v.version} опубликована`);renderDashAdmin()}catch(e){error(e)}};
 document.querySelectorAll('[data-restore]').forEach(b=>b.onclick=async()=>{if(!confirm('Восстановить архивную версию в черновик? Текущий черновик будет заменён.'))return;
  try{await dashPost('/api/dashboard/restore',{version:+b.dataset.restore});toast('Архивная версия восстановлена в черновик');renderDashAdmin()}catch(e){error(e)}});
 document.querySelectorAll('[data-run-errors]').forEach(b=>b.onclick=async()=>{try{const r=await dashGet('/api/dashboard/factor-errors',{run:b.dataset.runErrors});modal('Ошибки факторного анализа · '+r.month,table(['Договорный ключ','Описание'],r.items.map(x=>`<tr><td>${esc(x.key)}</td><td>${esc(x.description)}</td></tr>`)))}catch(e){error(e)}});
}
async function dashUpload(file,kind){if(!file.name.toLowerCase().endsWith('.xlsx'))return error(Error('Нужен Excel .xlsx'));
 const route=kind==='metrics'?'/api/dashboard/import':'/api/dashboard/portfolio?asof='+encodeURIComponent($('dc-asof').value);
 loading('Принимаем '+file.name+'...');try{
  const result=await api(route,{method:'POST',headers:{'Content-Type':'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet','X-Filename':encodeURIComponent(file.name)},body:file});
  const problems=(result.runs||[]).reduce((a,x)=>a+x.errors,0);
  toast(kind==='metrics'?`Загружено ${result.values} значений; изменено ${result.changed}`:`Принято ${result.positions} договорных позиций; ошибок факторизации: ${problems}`);
  renderDashAdmin();
 }catch(e){error(e);renderDashAdmin()}}
