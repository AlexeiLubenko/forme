"""Create/rotate an admin or viewer account from a trusted machine."""
import argparse
import getpass
import engine
import access_control

p=argparse.ArgumentParser(description='Создать пользователя АС НСФО')
p.add_argument('--username',default='admin')
p.add_argument('--role',choices=('admin','viewer'),default='admin')
a=p.parse_args()
engine.initialize();access_control.initialize()
password=getpass.getpass('Новый пароль (не менее 12 символов): ')
confirmation=getpass.getpass('Повторите пароль: ')
if password!=confirmation:raise SystemExit('Пароли не совпали')
access_control.upsert_user(a.username,password,a.role)
print('Пользователь '+a.username+' настроен. Пароль не сохраняется в открытом виде.')
