/* Fact vs Plan dashboard. Server performs all reserve calculations and version checks. */
const D={year:new Date().getFullYear(),month:new Date().getMonth()+1,admin:false,metrics:null,run:null};
const D_NAMES=['Янв','Фев','Мар','Апр','Май','Июн','Июл','Авг','Сен','Окт','Ноя','Дек'];
const dashGet=(url,params={})=>api(url+'?'+new URLSearchParams(params));
const dashPost=(url,body)=>api(url,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
const mValue=(data,key,scenario)=>data?.metrics?.[key]?.[scenario]?.value??null;
const mSeries=(data,key,scenario)=>data?.metrics?.[key]?.[scenario]?.series||[];
const fmtM=v=>v==null?'Нет данных':money(v,2)+' млн BYN';
const pct=v=>v==null?'—':money(v,2)+'%';

function dashBar(name,plan,fact,{hint='',compact=false,showDelta=true,scaleMax=null}={}){
 // Use the whole track for one-sided amounts; keep a centered zero for opposite signs.
 // Both measures share the same numerical scale (not two independently normalized bars).
 const known=[plan,fact].filter(v=>v!=null&&Number.isFinite(v));
 const scale=Math.max(1e-8,...known.map(v=>Math.abs(v)),scaleMax||0);
 const mixed=known.some(v=>v<0)&&known.some(v=>v>0);
 const onlyNegative=!mixed&&known.some(v=>v<0);
 const zero=mixed?50:(onlyNegative?99:1);
 const available=mixed?48:98;
 const span=value=>Math.min(available,Math.abs(value)/scale*available);
 const shape=(value,cls)=>{
  if(value==null||!Number.isFinite(value))return '';
  const w=span(value),start=value<0?zero-w:zero;
  return `<span class="db-${cls}" style="left:${start.toFixed(3)}%;width:${w.toFixed(3)}%"></span>`;
 };
 const delta=plan==null||fact==null?null:fact-plan;
 let tail='';
 if(plan!=null&&fact!=null&&Number.isFinite(plan)&&Number.isFinite(fact)&&
    Math.sign(fact)===Math.sign(plan)&&Math.abs(fact)>Math.abs(plan)){
  const w=span(fact)-span(plan);
  const start=fact<0?zero-span(fact):zero+span(plan);
  tail=`<span class="db-over" style="left:${start.toFixed(3)}%;width:${w.toFixed(3)}%"></span>`;
 }
 return `<div class="dashbar ${compact?'compact':''}"><div class="db-label"><b>${esc(name)}</b>${hint?`<span>${esc(hint)}</span>`:''}</div>
 <div class="db-track ${mixed?'db-mixed':''}" title="${esc(name)} · БП: ${esc(fmtM(plan))}; факт: ${esc(fmtM(fact))}"><div class="db-zero" style="left:${zero}%"></div>${shape(plan,'plan')}${shape(fact,'fact')}${tail}</div>
 <div class="db-values"><span class="db-value-plan">БП <b>${plan==null?'—':money(plan,2)}</b></span><span class="db-value-fact">Факт <b>${fact==null?'—':money(fact,2)}</b></span>${showDelta&&delta!=null?`<span class="db-delta">Δ ${delta>0?'+':''}${money(delta,2)}</span>`:''}</div></div>`;
}
function dashChart(name,plan,fact,{key="",expanded=false}={}){
 // Show numeric labels for *every* available monthly point, for both plan and fact.
 // Wider data sets scroll horizontally rather than squeezing or hiding labels.
 const n=Math.max(plan.length,fact.length,1);
 const values=[...plan,...fact].filter(x=>x!=null&&Number.isFinite(x));
 if(!values.length)return `<div class="dc-chart"><div class="dc-chart-head"><b>${esc(name)}</b><span>Нет данных</span></div><div class="dc-empty">Загрузите помесячные COR / УПР</div></div>`;
 let lo=Math.min(...values),hi=Math.max(...values),range=hi-lo;
 if(range<0.01){const pad=Math.max(.10,Math.abs(lo)*.05);lo-=pad;hi+=pad}
 else{lo-=range*.18;hi+=range*.18}
 range=hi-lo;
 const W=expanded?Math.max(960,160+(n-1)*112):Math.max(374,128+(n-1)*70);
 const H=expanded?520:236;
 const xLeft=expanded?85:57,xRight=W-(expanded?55:35),top=expanded?90:55,bottom=expanded?H-100:175;
 const X=i=>n===1?(xLeft+xRight)/2:xLeft+(xRight-xLeft)*i/(n-1);
 const Y=v=>bottom-(bottom-top)*(v-lo)/range;
 const paths=a=>{
  const chunks=[];let segment=[];
  for(let i=0;i<n;i++){
   const v=a[i];
   if(v!=null&&Number.isFinite(v))segment.push(`${segment.length?'L':'M'}${X(i).toFixed(1)} ${Y(v).toFixed(1)}`);
   else if(segment.length){chunks.push(segment.join(' '));segment=[]}
  }
  if(segment.length)chunks.push(segment.join(' '));return chunks.join(' ');
 };
 const pointGroup=(a,kind)=>a.map((v,i)=>{
  if(v==null||!Number.isFinite(v))return '';
  const x=X(i),y=Y(v),label=`${money(v,2)}%`;
  const w=Math.max(45,label.length*6.5+14);
  const bx=x-w/2;
  // Keep the two value labels on opposite sides even where the curves cross.
  const other=kind==='plan'?fact:plan;
  const otherVal=other[i];
  const closeToOther=otherVal!=null&&Number.isFinite(otherVal)&&Math.abs(Y(otherVal)-y)<40;
  const swap=closeToOther&&kind==='plan'&&y>Y(otherVal) ||
             closeToOther&&kind==='fact'&&y<Y(otherVal);
  const above=(kind==='plan')?!swap:swap;
  const by=above?Math.max(5,y-29):Math.min(H-38,y+11);
  return `<g class="dc-point dc-point-${kind}">
   <circle cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="4.2"><title>${esc(name)} · ${D_NAMES[i]} · ${kind==='plan'?'БП':'Факт'}: ${label}</title></circle>
   <rect class="dc-point-tag" x="${bx.toFixed(1)}" y="${by.toFixed(1)}" width="${w.toFixed(1)}" height="18" rx="5"></rect>
   <text x="${x.toFixed(1)}" y="${(by+12.5).toFixed(1)}" text-anchor="middle">${label}</text>
  </g>`;
 }).join('');
 const grid=Array.from({length:4},(_,i)=>{
  const y=top+(bottom-top)*i/3,v=hi-(hi-lo)*i/3;
  return `<line x1="${xLeft}" x2="${xRight}" y1="${y}" y2="${y}" class="dc-grid-line"/><text x="${xLeft-9}" y="${y+4}" text-anchor="end" class="dc-axis-value">${money(v,1)}%</text>`;
 }).join('');
 const labels=Array.from({length:n},(_,i)=>`<text x="${X(i).toFixed(1)}" y="${expanded?H-46:218}" class="dc-month-label" text-anchor="middle">${D_NAMES[i]}</text>`).join('');
 const latestPlan=plan[n-1]??null,latestFact=fact[n-1]??null;
 const expandButton=!expanded&&key?`<button class="dc-expand-btn" type="button" data-dc-expand="${esc(key)}" aria-label="Развернуть ${esc(name)} на весь экран" title="Развернуть на весь экран">⛶ <span>На весь экран</span></button>`:'';
 return `<div class="dc-chart ${expanded?'dc-chart-expanded':''}"><div class="dc-chart-head"><b>${esc(name)}</b><div class="dc-chart-tools"><span class="dc-chart-legend"><i class="dc-dot plan"></i> БП <i class="dc-dot fact"></i> Факт</span>${expandButton}</div></div>
 <div class="dc-chart-scroll" tabindex="0" aria-label="${esc(name)}: помесячный график; при необходимости прокрутите горизонтально">
 <svg role="img" aria-label="${esc(name)}: динамика БП и факта, значения в процентах подписаны у точек" class="dc-svg" viewBox="0 0 ${W} ${H}" style="min-width:${W}px" preserveAspectRatio="xMidYMid meet">
 ${grid}
 <path d="${paths(plan)}" class="dc-series-plan"/>
 <path d="${paths(fact)}" class="dc-series-fact"/>
 ${pointGroup(plan,'plan')}${pointGroup(fact,'fact')}
 ${labels}
 </svg></div><div class="dc-latest">${D_NAMES[n-1]}: БП <b>${pct(latestPlan)}</b> · Факт <b>${pct(latestFact)}</b></div></div>`;
}
const dashWrap=(title,subtitle,body)=>`<div class="dc-card"><div class="dc-card-head"><h2>${esc(title)}</h2>${subtitle?`<div>${esc(subtitle)}</div>`:''}</div>${body}</div>`;
const dashBarOf=(data,key,title,opts)=>dashBar(title,mValue(data,key,'plan'),mValue(data,key,'fact'),opts||{});
const dashChartOf=(data,key,title)=>dashChart(title,mSeries(data,key,'plan'),mSeries(data,key,'fact'),{key});
// The chart can be opened fullscreen without changing the dashboard's filters or data.
const DASH_FULLSCREEN_NAMES={
 bank_cor:'COR · Банк',bank_upr:'УПР · Банк',
 fl_cor:'COR · ФЛ',fl_upr:'УПР · ФЛ',
 kb_cor:'COR · КБ',kb_upr:'УПР · КБ'
};
let dashFullscreenTrigger=null;
function closeDashFullscreen(restoreFocus=true){
 const overlay=document.querySelector('.dc-zoom-overlay');
 if(!overlay)return;
 // Exit native fullscreen if active; otherwise the viewport-sized overlay is enough.
 if(document.fullscreenElement===overlay&&document.exitFullscreen){
  try{const result=document.exitFullscreen();if(result?.catch)result.catch(()=>{});}catch(_){}
 }
 overlay.remove();
 document.body.classList.remove('dc-zoom-open');
 if(restoreFocus&&dashFullscreenTrigger?.isConnected)dashFullscreenTrigger.focus();
 dashFullscreenTrigger=null;
}
function openDashFullscreen(key,trigger){
 if(!Object.prototype.hasOwnProperty.call(DASH_FULLSCREEN_NAMES,key)||!D.metrics)return;
 closeDashFullscreen(false);
 dashFullscreenTrigger=trigger;
 const name=DASH_FULLSCREEN_NAMES[key];
 const chart=dashChart(name,mSeries(D.metrics,key,'plan'),mSeries(D.metrics,key,'fact'),{expanded:true});
 const overlay=document.createElement('div');
 overlay.className='dc-zoom-overlay';
 overlay.innerHTML=`<div class="dc-zoom-shell" role="dialog" aria-modal="true" aria-labelledby="dc-zoom-title">
  <div class="dc-zoom-head"><div><div class="dc-zoom-overline">Факт vs План · ${D.year} год</div><h2 id="dc-zoom-title">${esc(name)} — помесячная динамика</h2></div>
  <button type="button" class="dc-zoom-close" aria-label="Закрыть полноэкранный график" title="Закрыть (Esc)">✕ Закрыть</button></div>
  <div class="dc-zoom-body">${chart}</div>
  <div class="dc-zoom-foot">БП и факт показаны в процентах. Для закрытия нажмите Esc. Если месяцев много, используйте горизонтальную прокрутку.</div>
 </div>`;
 document.body.appendChild(overlay);
 document.body.classList.add('dc-zoom-open');
 overlay.querySelector('.dc-zoom-close').addEventListener('click',()=>closeDashFullscreen());
 overlay.addEventListener('click',e=>{if(e.target===overlay)closeDashFullscreen()});
 overlay.querySelector('.dc-zoom-close').focus();
 // Native browser fullscreen (F11-like) where permitted; CSS overlay is the fallback.
 if(overlay.requestFullscreen){
  try{const result=overlay.requestFullscreen();if(result?.then)result.then(()=>{overlay.dataset.nativeFullscreen='1'}).catch(()=>{});}catch(_){}
 }
}
document.addEventListener('click',e=>{
 const trigger=e.target.closest('[data-dc-expand]');
 if(trigger)openDashFullscreen(trigger.dataset.dcExpand,trigger);
});
document.addEventListener('keydown',e=>{
 if(e.key==='Escape'&&document.querySelector('.dc-zoom-overlay')){e.preventDefault();closeDashFullscreen();}
});
document.addEventListener('fullscreenchange',()=>{
 const overlay=document.querySelector('.dc-zoom-overlay');
 if(overlay?.dataset.nativeFullscreen==='1'&&document.fullscreenElement!==overlay){closeDashFullscreen();}
});

function dashControls(admin){const years=Array.from({length:14},(_,i)=>2023+i).map(y=>`<option ${D.year===y?'selected':''} value="${y}">${y}</option>`).join('');
 return `<div class="dc-controls"><label>Год <select id="dc-year" class="control">${years}</select></label><label>Период <select id="dc-month" class="control">${D_NAMES.map((x,i)=>`<option ${D.month===i+1?'selected':''} value="${i+1}">${x}</option>`).join('')}</select></label>${admin?`<span class="badge orange">Предпросмотр черновика</span>`:''}</div>`;}
function dashLegend(){return `<div class="dc-legend"><b>Как читать бары</b><span><i class="leg-plan"></i> Бизнес-план — сплошная заливка</span><span><i class="leg-fact"></i> Факт — диагональная штриховка</span><span><i class="leg-over"></i> Продолжение факта за планом</span><span>Денежные значения: млн BYN. Для отрицательных величин используется левая сторона нулевой оси.</span></div>`;}
async function renderDashboard(preview=false){
 D.admin=preview;loading('Получаем показатели дашборда...');
 let data;
 try{data=await dashGet(preview?'/api/dashboard/preview':'/api/dashboard',{year:D.year,month:D.month})}catch(e){error(e);return}
 D.metrics=data;
 const rnrMedium=mValue(data,'medium_rnr','fact');
 const factorKeys=['movement','financial_state','security_effect','revaluation'];
 const factorScale=Math.max(1e-8,...factorKeys.map(k=>Math.abs(mValue(data,'factor_'+k,'fact')||0)));
 const factors=factorKeys.map(k=>dashBar(data.factor_names?.[k]||k,null,mValue(data,'factor_'+k,'fact'),{compact:true,showDelta:false,scaleMax:factorScale})).join('');
 const top=`<div class="dc-topgrid">${dashWrap('Расходы на резервы · Банк','Накопленным с начала года',dashBarOf(data,'bank_rnr','РнР банка'))}${dashWrap('COR банка','Помесячная динамика',dashChartOf(data,'bank_cor','COR · Банк'))}${dashWrap('УПР банка','Помесячная динамика',dashChartOf(data,'bank_upr','УПР · Банк'))}</div>`;
 const left=`<div class="dc-col">${dashWrap('Физические лица','Денежные показатели — накопленным',dashBarOf(data,'fl_rnr','Расходы на резервы')+dashBarOf(data,'fl_writeoff','Поступления по списанным')+dashChartOf(data,'fl_cor','COR · ФЛ')+dashChartOf(data,'fl_upr','УПР · ФЛ'))}${dashWrap('Банки и прочие','Накопленным с января',dashBarOf(data,'banks_other_rnr','Расходы на резервы'))}</div>`;
 const right=`<div class="dc-col">${dashWrap('Средний+','Крупнейший + Крупный + Средний',dashBar('Расходы на резервы',null,rnrMedium,{hint:'БП пока не определён'})+`<div class="dc-subtitle">Факторы фактических расходов · накопленным</div>`+factors+`<p class="dc-foot">Четыре фактора должны точно сходиться с фактическими расходами. Неопубликованные или невыверенные расчёты не показываются.</p>`+(S.auth?.role!=='viewer'&&rnrMedium!=null?'<div class="dc-factor-actions"><button class="btn mini" id="dc-detail">Детализация по договорам</button> <button class="btn mini" id="dc-export-factors">⇩ Excel: подфакторы</button></div>':''))}${dashWrap('ММБ','Накопленным с января',dashBarOf(data,'mmb_rnr','Расходы на резервы'))}${dashWrap('Все юридические лица','Накопленным с января',dashBarOf(data,'ul_writeoff','Поступления по списанным'))}${dashWrap('Корпоративный бизнес','Готовые помесячные проценты',dashChartOf(data,'kb_cor','COR · КБ')+dashChartOf(data,'kb_upr','УПР · КБ'))}</div>`;
 $('content').innerHTML=`<div class="dc-page"><div class="dc-head"><div><div class="eyebrow">Модуль 2 / Аналитика банка</div><h1>Факт vs План</h1><p class="sub">Показатели с начала года по ${D_NAMES[D.month-1].toLowerCase()} ${D.year} года · ${data.version?'версия '+data.version:'нет публикации'}</p></div>${dashControls(preview)}</div>
 ${data.version?`${top}<div class="dc-columns">${left}${right}</div>`:`<div class="card card-pad"><div class="empty">Нет ${preview?'загруженного черновика':'опубликованных данных'} за выбранный период. Администратор может загрузить готовые показатели из Excel.</div></div>`}
 ${dashLegend()}</div>`;
 // On small cards show the latest months first; users may scroll left for history.
 $('content').querySelectorAll('.dc-chart-scroll').forEach(el=>{el.scrollLeft=el.scrollWidth-el.clientWidth});
 $('dc-year').onchange=e=>{D.year=+e.target.value;renderDashboard(preview)};
 $('dc-month').onchange=e=>{D.month=+e.target.value;renderDashboard(preview)};
 const details=$('dc-detail');if(details)details.onclick=()=>openDashDetail();
 const exportFactors=$('dc-export-factors');if(exportFactors)exportFactors.onclick=()=>{window.location.href='/api/dashboard/factors.xlsx?'+new URLSearchParams({year:D.year,month:D.month,draft:preview?'1':'0'});};
}
async function openDashDetail(search='',page=1){
 try{const data=await dashGet('/api/dashboard/factors',{year:D.year,month:D.month,search,page});
 const rows=data.rows.map(x=>`<tr><td>${esc(x.client)}<br><small>${esc(x.unp)}</small></td><td>${esc(x.contract)}</td><td class="right">${money(x.expenses)}</td><td class="right">${money(x.movement)}</td><td class="right">${money(x.financial)}</td><td class="right">${money(x.security)}</td><td class="right">${money(x.fx)}</td></tr>`);
 modal('Средний+ · детализация факторов',`<div class="sub">Только опубликованные результаты. ${data.total} договорных позиций</div><div class="toolbar"><input id="df-search" class="input grow" placeholder="УНП, клиент, договор" value="${esc(search)}"><button class="btn mini" id="df-apply">Найти</button></div>${table(['Клиент / УНП','Договор','РнР','КП','ФС','Обеспечение','Переоценка'],rows)}<div class="pagination"><button class="btn mini" id="df-prev" ${page<=1?'disabled':''}>Назад</button><span>Страница ${page}</span><button class="btn mini" id="df-next" ${page*data.limit>=data.total?'disabled':''}>Далее</button></div>`);
 $('df-apply').onclick=()=>openDashDetail($('df-search').value,1);
 $('df-prev').onclick=()=>openDashDetail(search,page-1);
 $('df-next').onclick=()=>openDashDetail(search,page+1);
 }catch(e){error(e)}
}
async function renderDashAdmin(){if(S.auth?.role!=='admin')return nav('dashboard');loading('Проверяем загрузки и версии...');
 let r;try{r=await api('/api/dashboard/admin')}catch(e){error(e);return}
 const report=r.runs.map(x=>`<tr><td>${esc(x.month)}${x.methodology_version<3?' · историческая просрочка':x.methodology_version<4?' · прежнее определение микрокредита':x.methodology_version<5?' · до правила выхода ПОК':x.methodology_version<6?' · просрочка из Max-Day OD':''}</td><td>${x.rows}</td><td>${x.errors?badge(x.errors+' ошибок','red'):badge('4 фактора сходятся','green')}</td><td>${money(x.amount_cents/100000000)} млн</td><td>${x.errors?`<button class="btn mini" data-run-errors="${x.id}">Проверить</button>`:'—'}</td></tr>`);
 const ports=r.portfolios.map(x=>`<tr><td>${esc(labelDate(x.asof))}</td><td>${esc(x.original_name)}</td><td>${x.row_count}</td><td>${x.position_count}</td><td>${esc(x.created)}</td></tr>`);
 const versions=r.versions.map(x=>`<tr><td>#${x.id}</td><td>${esc(x.created)}</td><td>${x.state==='published'?badge('Опубликована','green'):x.state==='draft'?badge('Черновик','orange'):badge('Архив')}</td><td>${esc(x.author)}</td><td>${x.state==='archived'?`<button data-restore="${x.id}" class="btn mini">Восстановить</button>`:'—'}</td></tr>`);
 $('content').innerHTML=`<div class="dc-page"><div class="dc-head"><div><div class="eyebrow">Администрирование / Только администратор</div><h1>Управление дашбордом</h1><p class="sub">Загрузка исходных данных · Проверка · Черновик · Публикация</p></div><span>${badge('Черновик '+(r.draft_id||'не создан'),'orange')} ${badge('Публикация '+(r.published_id||'не создана'),'green')}</span></div>
 <div class="dc-admin-grid">${dashWrap('1 · Готовые показатели','Единый Excel, денежные значения в млн BYN',`<div class="dc-upload"><div class="upload-pict">⇧</div><b>Excel с БП и фактом</b><p>Банк, ФЛ, ММБ, банки и прочие, COR, УПР, списанные ЮЛ и ФЛ</p><input type="file" id="dc-metrics-file" accept=".xlsx"><a class="btn mini" href="/api/dashboard/template.xlsx">Скачать шаблон Excel</a></div>`)}
 ${dashWrap('2 · Фактические портфели ЮЛ','Выверенный факт · исходный формат из 55 столбцов',`<div class="dc-upload">
  <div class="dc-portfolio-help"><b>Шаблон фактического портфеля ЮЛ</b><p>Сохраняет все 55 столбцов выверенного факта. Обязательные поля выделены бирюзовым. Можно загружать и исходную выверенную выгрузку без переноса в шаблон.</p>
  <a class="btn mini dc-template-download" href="/api/dashboard/portfolio-template.xlsx" download>⇩ Скачать шаблон портфеля ЮЛ (.xlsx)</a>
  <details class="dc-portfolio-details" open><summary>Какие столбцы использует АС</summary>
    <div class="dc-fields-section"><b>Идентификация и сегмент</b><p>УНП · Номер договора · Тип операции · Код валюты · Сегмент</p></div>
    <div class="dc-fields-section"><b>Резерв и валюта</b><p>Задолженность, тыс BYN · Резерв факт · % рез · Курс</p></div>
    <div class="dc-fields-section"><b>Факторный анализ</b><p>ГР · НИ · ПФН · НВВ · Рестра · Обеспеченность</p></div>
    <div class="dc-fields-section"><b>Просрочка и особые договоры</b><p>Day OD (максимум по клиенту вычисляется из строк) · ПОК/СПОК · ГР «Списан» (резерв принимается равным задолженности). Max-Day %% для расчёта не используется.</p></div>
    <div class="dc-fields-section"><b>Дополнительно</b><p>Клиент · Вид кредита</p></div>
  </details>
  <p class="dc-portfolio-rule">Задолженность и «Резерв факт» — <b>тыс. BYN</b>. Учётный «Резерв факт» берётся из файла. В графе «% рез» указывайте 0,5 для 0,5%, 5 для 5%. Сегмент для Средний+: Крупнейший, Крупный, Средний.</p></div>
  <label for="dc-asof">Дата фактического портфеля (1-е число месяца)</label><input class="input" type="date" id="dc-asof" value="${D.year}-${String(D.month).padStart(2,'0')}-01"><input type="file" id="dc-portfolio-file" accept=".xlsx"><p>Расчёт Средний+ по четырём факторам выполняется автоматически при наличии двух последовательных портфелей.</p></div>`)}</div>
 <div class="dc-admin-actions"><button class="btn" id="dc-recalculate-saved" ${r.portfolios.length<2?'disabled':''}>Пересчитать сохранённые портфели</button><span class="sub" id="dc-saved-status">Файлы загружать не требуется. Для старых снимков сохранён Max-Day OD; исходные Day OD восстановить невозможно. Для точного нового расчёта загрузите исходный Excel.</span></div>
 <div class="dc-admin-actions"><button class="btn" id="dc-preview">Предпросмотр дашборда</button><button class="btn primary" id="dc-publish" ${r.draft_id?'':'disabled'}>Опубликовать проверенные данные</button><span class="sub">Публикация заблокирована при несходимости хотя бы одного договора Средний+.</span></div>
 ${dashWrap('Расчёты Средний+ в черновике','Каждый месяц: предыдущий портфель vs текущий',report.length?table(['Период','Договоров','Сверка','РнР','Контроль'],report):empty('Загрузите фактические портфели за две соседние даты'))}
 ${r.pending?.length?dashWrap('Неполные исторические снимки','В этих снимках нет данных, необходимых для расчёта',table(['Период','Что сделать'],r.pending.map(x=>`<tr><td>${esc(x.month)}</td><td>${esc(x.reason)}</td></tr>`))):''}
 ${dashWrap('Загруженные фактические портфели','В базе сохраняются нормализованные снимки',ports.length?table(['На дату','Файл','Строк','Позиций','Загрузка'],ports):empty('Портфели ещё не загружались'))}
 ${dashWrap('Версии публикаций','Черновики и архивы хранятся отдельно',versions.length?table(['Версия','Создана','Статус','Автор','Действие'],versions):empty('Версий ещё нет'))}
 </div>`;
 $('dc-metrics-file').onchange=e=>{if(e.target.files.length)dashUpload(e.target.files[0],'metrics')};
 $('dc-portfolio-file').onchange=e=>{if(e.target.files.length)dashUpload(e.target.files[0],'portfolio')};
 $('dc-recalculate-saved').onclick=async()=>{
  const button=$('dc-recalculate-saved'),status=$('dc-saved-status');button.disabled=true;
  try{
   await dashPost('/api/dashboard/recalculate-saved',{});
   let job;
   do{
    await new Promise(resolve=>setTimeout(resolve,900));
    job=await dashGet('/api/dashboard/recalculate-saved');
    if(S.page!=='dash_admin')return;
    status.textContent=job.stage||'Пересчёт сохранённых портфелей…';
   }while(job.status==='running');
   if(job.status==='error')throw Error(job.error);
   const result=job.result;
   toast(`Пересчитано: ${result.runs.length}; старая просрочка: ${result.legacy_months.length}; старые правила классификации: ${(result.legacy_micro_months||[]).length}`);
   renderDashAdmin();
  }catch(e){error(e);button.disabled=false;status.textContent=e.message;}
 };
 $('dc-preview').onclick=()=>renderDashboard(true);
 $('dc-publish').onclick=async()=>{const legacy=r.runs.filter(x=>x.methodology_version<3).map(x=>x.month);
  const prompt=legacy.length?`В периодах ${legacy.join(', ')} сохранён старый максимум двух колонок просрочки; точное Max-Day OD восстановить невозможно. Опубликовать проверенный черновик с этим допущением?`:'Опубликовать проверенный черновик для сотрудников банка?';
  if(!confirm(prompt))return;
  try{const v=await dashPost('/api/dashboard/publish',{note:'Публикация дашборда'});toast(`Версия ${v.version} опубликована`);renderDashAdmin()}catch(e){error(e)}};
 document.querySelectorAll('[data-restore]').forEach(b=>b.onclick=async()=>{if(!confirm('Восстановить архивную версию в черновик? Текущий черновик будет заменён.'))return;
  try{await dashPost('/api/dashboard/restore',{version:+b.dataset.restore});toast('Архивная версия восстановлена в черновик');renderDashAdmin()}catch(e){error(e)}});
 document.querySelectorAll('[data-run-errors]').forEach(b=>b.onclick=async()=>{try{const r=await dashGet('/api/dashboard/factor-errors',{run:b.dataset.runErrors});modal('Ошибки факторного анализа · '+r.month,table(['Договорный ключ','Описание'],r.items.map(x=>`<tr><td>${esc(x.key)}</td><td>${esc(x.description)}</td></tr>`)))}catch(e){error(e)}});
}
async function dashUpload(file,kind){if(!file.name.toLowerCase().endsWith('.xlsx'))return error(Error('Нужен Excel .xlsx'));
 const route=kind==='metrics'?'/api/dashboard/import':'/api/dashboard/portfolio?asof='+encodeURIComponent($('dc-asof').value);
 loading('Принимаем '+file.name+'...');try{
  const result=await api(route,{method:'POST',headers:{'Content-Type':'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet','X-Filename':encodeURIComponent(file.name)},body:file});
  const problems=(result.runs||[]).reduce((a,x)=>a+x.errors,0);
  toast(kind==='metrics'?`Загружено ${result.values} значений; изменено ${result.changed}`:`Принято ${result.positions} договорных позиций; ошибок факторизации: ${problems}`);
  renderDashAdmin();
 }catch(e){error(e);renderDashAdmin()}}
