"""Compare an intramonth contract register with the project's opening fact and input plan."""
from collections import defaultdict
from contextlib import closing
from datetime import date
import json
from uuid import uuid4

from openpyxl import load_workbook
import engine
from risk import canonical_security, currency, flag, is_new_contract, match_key, micro_flag, side_for_operation

FLAGS = ('ni', 'pfn', 'nvv')
FIELDS = FLAGS + ('restra', 'security')
HEADERS = ['УНП','Номер договора','Тип операции','Код валюты','НИ','ПФН','НВВ','Рестра','Обеспеченность']


def project_dates(db, pid):
    project = db.execute('SELECT periods,fact_date,status FROM projects WHERE id=?',(pid,)).fetchone()
    if not project or project['status']=='building' or not project['fact_date']:
        raise ValueError('Сначала завершите построение рабочего БП с выверенным фактом.')
    return project['fact_date'], json.loads(project['periods'])


def stage(pid, path, name, asof, actor):
    day = date.fromisoformat(asof)
    with closing(load_workbook(path,read_only=True,data_only=True)) as book, engine.connect() as db:
        db.execute('BEGIN IMMEDIATE')
        baseline, _ = project_dates(db,pid)
        if day.isoformat() <= baseline:
            raise ValueError('Дата текущего портфеля должна быть позже даты выверенного факта.')
        ws, header_row, header = engine.find_sheet_header(book, HEADERS)
        cols = {engine.normalize_header(v):i for i,v in enumerate(header) if v}
        db.execute('DELETE FROM current_portfolios WHERE project_id=?',(pid,))
        db.execute('INSERT INTO current_portfolios VALUES(?,?,?,?,NULL)',(pid,uuid4().hex,asof,name))
        clients, contracts = {}, {}
        for n,row in enumerate(ws.iter_rows(min_row=header_row+1,values_only=True),header_row+1):
            if all(v in ('',None) for v in row):
                continue
            def get(k):
                return engine.get(row,cols,k)
            try:
                unp = engine.normalize_unp(get('УНП'))
                contract = str(get('Номер договора') or '').strip()
                op = str(get('Тип операции') or '').strip()
                ccy = currency(get('Код валюты'))
                if not all((unp,contract,op,ccy)):
                    raise ValueError('Заполните УНП, номер договора, тип операции и валюту.')
                side = side_for_operation(op)
                key = match_key(unp,contract,ccy,side)
                flags = tuple(flag(get(k)) for k in ('НИ','ПФН','НВВ'))
                if clients.setdefault(unp,flags)!=flags:
                    raise ValueError(f'Разные НИ, ПФН или НВВ по УНП {unp}.')
                sec = canonical_security(get('Обеспеченность'),micro_flag(get('Вид кредита')))
                values = (*flags,str(get('Рестра') or '').strip(),sec)
                if key in contracts:
                    if contracts[key]!=values:
                        raise ValueError(f'Разные характеристики строк договора {contract}.')
                    continue
                contracts[key]=values
                db.execute('INSERT INTO current_contracts VALUES(?,?,?,?,?,?,?,?,?,?,?,?,NULL)',
                           (pid,key,unp,str(get('Клиент') or ''),contract,ccy,side,*values))
            except ValueError as exc:
                raise ValueError(f'Строка {n}. {exc}') from exc
        if not contracts:
            raise ValueError('В текущем портфеле нет договоров.')
        db.execute('INSERT INTO audit(project_id,at,action,reason) VALUES(?,?,?,?)',
                   (pid,engine.now(),'current_upload',f'{actor} · {name} · {asof}'))
    return {'count':len(contracts)}


def registers(db,pid):
    old={r['match_key']:dict(r) for r in db.execute('SELECT * FROM fact_contracts WHERE project_id=?',(pid,))}
    current={r['match_key']:dict(r) for r in db.execute('SELECT * FROM current_contracts WHERE project_id=?',(pid,))}
    positions=[dict(r) for r in db.execute('SELECT id,match_key,unp,contract,side,ccy,client,src FROM positions WHERE project_id=? ORDER BY id',(pid,))]
    by_key, candidates = defaultdict(list), defaultdict(list)
    for p in positions:
        by_key[p['match_key']].append(p)
        if p['src']=='bp' and p['match_key'] not in current and is_new_contract(p['contract']):
            candidates[(p['unp'],p['ccy'],p['side'])].append(p)
    return old,current,positions,by_key,candidates


def differences(old,cur):
    changed={}
    if old and cur:
        for k in FIELDS:
            a,b=old[k],cur[k]
            if k=='security':
                try:a=canonical_security(a,micro_flag(old['micro']))
                except ValueError:pass
            if a!=b:
                changed[k]=[a,b]
    return changed


def report(pid, kind='', search='', page=1):
    page=max(1,int(page))
    with engine.connect() as db:
        db.execute('BEGIN')
        meta=db.execute('SELECT * FROM current_portfolios WHERE project_id=?',(pid,)).fetchone()
        if not meta:
            return {'meta':None}
        baseline,periods=project_dates(db,pid)
        old,current,positions,by_key,candidates=registers(db,pid)
        totals=defaultdict(int)
        rows=[]
        count=0
        bp_keys={p['match_key'] for p in positions if p['src']=='bp'}
        for key in sorted(old.keys() | current.keys() | bp_keys):
            a,b=old.get(key),current.get(key)
            p=b or a or by_key[key][0]
            tags=[]
            changes=differences(a,b)
            if b and not a:tags.append('new')
            if a and not b:tags.append('gone')
            if changes:tags.append('changed')
            if b and key not in bp_keys:tags.append('missing')
            if key in bp_keys and not b:tags.append('plan_only')
            for tag in tags:totals[tag]+=1
            if kind and kind not in tags:continue
            if search.casefold() not in ' '.join([p['unp'],p['contract'],p['client'] or '']).casefold():continue
            count+=1
            if not (page-1)*100<count<=page*100:continue
            choices=candidates.get((p['unp'],p['ccy'],p['side']),[]) if 'missing' in tags else []
            rows.append(dict(key=key,unp=p['unp'],client=p['client'],contract=p['contract'],ccy=p['ccy'],side=p['side'],
                             tags=tags,changes=changes,values={k:b[k] for k in FIELDS} if b else None,
                             mapped_id=b['mapped_id'] if b else None,
                             candidates=[{'id':c['id'],'contract':c['contract']} for c in choices]))
        start=engine.add_one_month(baseline)
        return dict(meta=dict(meta),baseline=baseline,start=next((d for d in periods if d>=start),None),
                    rows=rows,count=count,totals=totals,page=page)


def apply(pid,token,links,actor):
    if not isinstance(links,dict):
        raise ValueError('Некорректный список соответствий.')
    with engine.connect() as db:
        db.execute('BEGIN IMMEDIATE')
        meta=db.execute('SELECT * FROM current_portfolios WHERE project_id=?',(pid,)).fetchone()
        if not meta or meta['token']!=token:
            raise ValueError('Портфель изменился. Обновите сверку.')
        if meta['applied']:
            return {'applied':meta['applied'],'already':True}
        baseline,periods=project_dates(db,pid)
        start=engine.add_one_month(baseline)
        if not any(d>=start for d in periods):
            raise ValueError('В БП нет прогнозной даты после месяца факта.')
        _,current,positions,by_key,candidates=registers(db,pid)
        client_flags={r['unp']:tuple(r[k] for k in FLAGS) for r in current.values()}
        contracts={p['id']:current[p['match_key']] for p in positions if p['match_key'] in current}
        used=set()
        for key,value in links.items():
            r=current.get(key)
            target=int(value)
            if not r or any(p['src']=='bp' for p in by_key[key]) or target in used:
                raise ValueError('Недопустимое или повторное соответствие договора.')
            eligible=candidates.get((r['unp'],r['ccy'],r['side']),[])
            if not any(p['id']==target for p in eligible):
                raise ValueError('Строка «Новый договор» не подходит по УНП, валюте или стороне.')
            used.add(target)
            contracts[target]=r
            db.execute('UPDATE current_contracts SET mapped_id=? WHERE project_id=? AND match_key=?',(target,pid,key))
        changed=0
        for p in positions:
            if p['unp'] not in client_flags:continue
            values=dict(zip(FLAGS,client_flags[p['unp']]))
            r=contracts.get(p['id'])
            if r:
                values.update(restra=r['restra'] if p['side']=='баланс' else '',security=r['security'])
            modified=False
            for period in periods:
                if period<start:continue
                row=db.execute('SELECT * FROM position_periods WHERE project_id=? AND position_id=? AND period=?',
                               (pid,p['id'],period)).fetchone()
                if not row:continue
                updates={k:v for k,v in values.items() if row[k]!=v}
                base={'base_'+k:v for k,v in values.items() if k in FLAGS and row['base_'+k]!=v}
                if not updates and not base:continue
                fields={**base,**updates}
                if updates:
                    if row['override_reason']!=engine.RESTORE_REASON:
                        fields['override_reason']=''
                    modified=True
                db.execute('UPDATE position_periods SET '+','.join(f'{k}=?' for k in fields)+
                           ' WHERE project_id=? AND position_id=? AND period=?',(*fields.values(),pid,p['id'],period))
                for k,v in updates.items():
                    db.execute('INSERT INTO audit(project_id,at,action,position_id,period,field,old,new,reason) VALUES(?,?,?,?,?,?,?,?,?)',
                               (pid,engine.now(),'edit',p['id'],period,k,str(row[k]),str(v),f'Текущий портфель {meta["asof"]}, {actor}'))
            if modified:
                engine.calc_one(db,pid,p['id'],baseline,periods,False,from_period=start)
                bad=db.execute('SELECT period FROM position_periods WHERE project_id=? AND position_id=? AND period>=? AND reserve IS NULL',
                               (pid,p['id'],start)).fetchone()
                if bad:raise ValueError(f'Не рассчитан резерв по договору {p["contract"]} на {bad[0]}. Перенос отменён.')
                changed+=1
        at=engine.now()
        db.execute('UPDATE current_portfolios SET applied=? WHERE project_id=?',(at,pid))
        if changed:db.execute("UPDATE projects SET status='draft' WHERE id=?",(pid,))
        db.execute('INSERT INTO audit(project_id,at,action,reason) VALUES(?,?,?,?)',
                   (pid,at,'current_apply',f'{actor}, портфель {meta["asof"]}, позиций изменено: {changed}'))
        return {'applied':at,'changed':changed}
