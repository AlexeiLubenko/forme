"""Compare an intramonth contract register with the project's opening fact and input plan."""
from collections import defaultdict
from contextlib import closing
from datetime import date
import json
from uuid import uuid4

from openpyxl import load_workbook
import engine
from risk import canonical_security, currency, flag, is_new_contract, match_key, micro_flag, side_for_operation

FLAGS = ('ni', 'pfn', 'nvv')
FIELDS = FLAGS + ('restra', 'security')
HEADERS = ['УНП','Номер договора','Тип операции','Код валюты','НИ','ПФН','НВВ','Рестра','Обеспеченность']


def project_dates(db, pid):
    project = db.execute('SELECT periods,fact_date,status FROM projects WHERE id=?',(pid,)).fetchone()
    if not project or project['status']=='building' or not project['fact_date']:
        raise ValueError('Сначала завершите построение рабочего БП с выверенным фактом.')
    return project['fact_date'], json.loads(project['periods'])


def stage(pid, path, name, asof, actor):
    day = date.fromisoformat(asof)
    with closing(load_workbook(path,read_only=True,data_only=True)) as book, engine.connect() as db:
        db.execute('BEGIN IMMEDIATE')
        baseline, _ = project_dates(db,pid)
        if day.isoformat() <= baseline:
            raise ValueError('Дата текущего портфеля должна быть позже даты выверенного факта.')
        ws, header_row, header = engine.find_sheet_header(book, HEADERS)
        cols = {engine.normalize_header(v):i for i,v in enumerate(header) if v}
        db.execute('DELETE FROM current_portfolios WHERE project_id=?',(pid,))
        db.execute('INSERT INTO current_portfolios VALUES(?,?,?,?,NULL)',(pid,uuid4().hex,asof,name))
        clients, contracts = {}, {}
        for n,row in enumerate(ws.iter_rows(min_row=header_row+1,values_only=True),header_row+1):
            if all(v in ('',None) for v in row):
                continue
            def get(k):
                return engine.get(row,cols,k)
            try:
                unp = engine.normalize_unp(get('УНП'))
                contract = str(get('Номер договора') or '').strip()
                op = str(get('Тип операции') or '').strip()
                ccy = currency(get('Код валюты'))
                if not all((unp,contract,op,ccy)):
                    raise ValueError('Заполните УНП, номер договора, тип операции и валюту.')
                side = side_for_operation(op)
                key = match_key(unp,contract,ccy,side)
                flags = tuple(flag(get(k)) for k in ('НИ','ПФН','НВВ'))
                if clients.setdefault(unp,flags)!=flags:
                    raise ValueError(f'Разные НИ, ПФН или НВВ по УНП {unp}.')
                sec = canonical_security(get('Обеспеченность'),micro_flag(get('Вид кредита')))
                values = (*flags,str(get('Рестра') or '').strip(),sec)
                if key in contracts:
                    if contracts[key]!=values:
                        raise ValueError(f'Разные характеристики строк договора {contract}.')
                    continue
                contracts[key]=values
                db.execute('INSERT INTO current_contracts VALUES(?,?,?,?,?,?,?,?,?,?,?,?,NULL)',
                           (pid,key,unp,str(get('Клиент') or ''),contract,ccy,side,*values))
            except ValueError as exc:
                raise ValueError(f'Строка {n}. {exc}') from exc
        if not contracts:
            raise ValueError('В текущем портфеле нет договоров.')
        db.execute('INSERT INTO audit(project_id,at,action,reason) VALUES(?,?,?,?)',
                   (pid,engine.now(),'current_upload',f'{actor} · {name} · {asof}'))
    return {'count':len(contracts)}


def registers(db,pid):
    old={r['match_key']:dict(r) for r in db.execute('SELECT * FROM fact_contracts WHERE project_id=?',(pid,))}
    current={r['match_key']:dict(r) for r in db.execute('SELECT * FROM current_contracts WHERE project_id=?',(pid,))}
    positions=[dict(r) for r in db.execute('SELECT id,match_key,unp,contract,side,ccy,client,src FROM positions WHERE project_id=? ORDER BY id',(pid,))]
    by_key, candidates = defaultdict(list), defaultdict(list)
    for p in positions:
        by_key[p['match_key']].append(p)
        if p['src']=='bp' and p['match_key'] not in current and is_new_contract(p['contract']):
            candidates[(p['unp'],p['ccy'],p['side'])].append(p)
    return old,current,positions,by_key,candidates


def differences(old,cur):
    changed={}
    if old and cur:
        for k in FIELDS:
            a,b=old[k],cur[k]
            if k=='security':
                try:a=canonical_security(a,micro_flag(old['micro']))
                except ValueError:pass
            if a!=b:
                changed[k]=[a,b]
    return changed


def contract_id(row):
    return row['unp'], ' '.join(row['contract'].upper().split())


def source_for(position, current, grouped=None):
    """Prefer an exact position, then the same contract across credit/UO."""
    if position['match_key'] in current:return current[position['match_key']]
    rows=grouped.get(contract_id(position),[]) if grouped is not None else [r for r in current.values() if contract_id(r)==contract_id(position)]
    same_currency=[r for r in rows if r['ccy']==position['ccy']]
    rows=same_currency or rows
    if not rows:return None
    if len({tuple(r[k] for k in FIELDS) for r in rows})>1:
        raise ValueError(f'Договор {position["contract"]}: разные признаки в текущем портфеле; добавьте строку для {position["ccy"]}, {position["side"]}.')
    return rows[0]


def report(pid, kind='', search='', page=1):
    page=max(1,int(page))
    with engine.connect() as db:
        db.execute('BEGIN')
        meta=db.execute('SELECT * FROM current_portfolios WHERE project_id=?',(pid,)).fetchone()
        if not meta:return {'meta':None}
        baseline,periods=project_dates(db,pid)
        start=next((d for d in periods if d>=engine.add_one_month(baseline)),None)
        old,current,positions,by_key,candidates=registers(db,pid)
        groups=defaultdict(lambda:{'old':[],'current':[],'bp':[]})
        for name,values in [('old',old.values()),('current',current.values()),('bp',[p for p in positions if p['src']=='bp'])]:
            for r in values:groups[contract_id(r)][name].append(r)
        next_balances={r['position_id']:r['debt'] for r in db.execute('SELECT position_id,debt FROM position_periods WHERE project_id=? AND period=?',(pid,start))}
        possible=defaultdict(list)
        for pos in positions:
            if pos['src']=='bp' and is_new_contract(pos['contract']) and pos['match_key'] not in current:
                possible[(pos['unp'],pos['ccy'])].append(pos)
        totals=defaultdict(int);rows=[]
        for identity,g in sorted(groups.items()):
            a,b,plans=g['old'],g['current'],g['bp']
            p=(b or a or plans)[0]
            client=next((r['client'] for r in b+plans+a if r['client']), '')
            changes={};details=[]
            for cur in b:
                prev=old.get(cur['match_key'])
                if not prev:
                    alternatives=[r for r in a if r['ccy']==cur['ccy']]
                    if alternatives and len({tuple(r[k] for k in FIELDS) for r in alternatives})==1:prev=alternatives[0]
                delta=differences(prev,cur)
                if delta:details.append(dict(ccy=cur['ccy'],side=cur['side'],changes=delta))
            for field in FIELDS:
                pairs=[d['changes'][field] for d in details if field in d['changes']]
                if pairs:
                    # One contract row, with differing position values explicitly labelled.
                    if all(pair==pairs[0] for pair in pairs):changes[field]=pairs[0]
                    else:
                        changes[field]=['; '.join(f'{d["ccy"]} {d["side"]}: {d["changes"][field][i]}' for d in details if field in d['changes']) for i in (0,1)]
            tags=[]
            if (a or b) and not plans:tags.append('missing')
            if plans and not b and any(abs(next_balances.get(r['id'],0) or 0)>1e-8 for r in plans):tags.append('plan_only')
            if changes:tags.append('changed')
            if not tags:continue
            if b and not a:tags.append('new')
            if a and not b:tags.append('gone')
            for tag in tags:totals[tag]+=1
            if kind and kind not in tags:continue
            if search.casefold() not in ' '.join([p['unp'],p['contract'],client]).casefold():continue
            choices={}
            if 'missing' in tags:
                for r in b:
                    for c in candidates.get((r['unp'],r['ccy'],r['side']),[]):choices.setdefault(contract_id(c),{'id':c['id'],'contract':c['contract']})
                # Index candidates once, including the counterpart on the other side.
                for ccy in {r['ccy'] for r in b}:
                    for c in possible.get((p['unp'],ccy),[]):
                        choices.setdefault(contract_id(c),{'id':c['id'],'contract':c['contract']})
            vals={k:next(iter(v)) if len(v)==1 else '; '.join(sorted(map(str,v))) for k in FIELDS for v in [{r[k] for r in b}]} if b else None
            rows.append(dict(key=p['match_key'],unp=p['unp'],client=client,contract=p['contract'],
                ccy=', '.join(sorted({r['ccy'] for r in a+b+plans})),side=p['side'],tags=tags,changes=changes,details=details,
                values=vals,mapped_id=next((r['mapped_id'] for r in b if r['mapped_id']),None),candidates=list(choices.values())))
        return dict(meta=dict(meta),baseline=baseline,start=start,rows=rows[(page-1)*100:page*100],count=len(rows),totals=totals,page=page)


def apply(pid,token,links,actor):
    if not isinstance(links,dict):
        raise ValueError('Некорректный список соответствий.')
    with engine.connect() as db:
        db.execute('BEGIN IMMEDIATE')
        meta=db.execute('SELECT * FROM current_portfolios WHERE project_id=?',(pid,)).fetchone()
        if not meta or meta['token']!=token:
            raise ValueError('Портфель изменился. Обновите сверку.')
        if meta['applied']:
            return {'applied':meta['applied'],'already':True}
        baseline,periods=project_dates(db,pid)
        start=engine.add_one_month(baseline)
        if not any(d>=start for d in periods):
            raise ValueError('В БП нет прогнозной даты после месяца факта.')
        _,current,positions,by_key,candidates=registers(db,pid)
        client_flags={r['unp']:tuple(r[k] for k in FLAGS) for r in current.values()}
        grouped=defaultdict(list)
        for r in current.values():grouped[contract_id(r)].append(r)
        contracts={}
        for p in positions:
            source=source_for(p,current,grouped)
            if source:contracts[p['id']]=source
        bp_contracts={contract_id(p) for p in positions if p['src']=='bp'}
        used=set()
        for key,value in links.items():
            r=current.get(key)
            target=int(value)
            if not r or contract_id(r) in bp_contracts or target in used:
                raise ValueError('Недопустимое или повторное соответствие договора.')
            selected=next((p for p in positions if p['id']==target),None)
            if not selected or selected['src']!='bp' or not is_new_contract(selected['contract']) or selected['unp']!=r['unp'] or selected['ccy']!=r['ccy']:
                raise ValueError('Строка «Новый договор» не подходит по УНП или валюте.')
            peers=[p for p in positions if contract_id(p)==contract_id(selected) and p['src']=='bp']
            if any(p['id'] in used or p['id'] in contracts for p in peers):raise ValueError('Договор уже сопоставлен.')
            for peer in peers:
                used.add(peer['id'])
                lookup={**peer,'contract':r['contract'],'match_key':match_key(r['unp'],r['contract'],peer['ccy'],peer['side'])}
                contracts[peer['id']]=source_for(lookup,current,grouped)
            for cur in current.values():
                if contract_id(cur)==contract_id(r):
                    db.execute('UPDATE current_contracts SET mapped_id=? WHERE project_id=? AND match_key=?',(target,pid,cur['match_key']))
        changed=0
        for p in positions:
            if p['unp'] not in client_flags:continue
            values=dict(zip(FLAGS,client_flags[p['unp']]))
            r=contracts.get(p['id'])
            if r:
                values.update(restra=r['restra'],security=r['security'])
            modified=False
            for period in periods:
                if period<start:continue
                row=db.execute('SELECT * FROM position_periods WHERE project_id=? AND position_id=? AND period=?',
                               (pid,p['id'],period)).fetchone()
                if not row:continue
                updates={k:v for k,v in values.items() if row[k]!=v}
                base={'base_'+k:v for k,v in values.items() if k in FLAGS and row['base_'+k]!=v}
                if not updates and not base:continue
                fields={**base,**updates}
                if updates:
                    if row['override_reason']!=engine.RESTORE_REASON:
                        fields['override_reason']=''
                    modified=True
                db.execute('UPDATE position_periods SET '+','.join(f'{k}=?' for k in fields)+
                           ' WHERE project_id=? AND position_id=? AND period=?',(*fields.values(),pid,p['id'],period))
                for k,v in updates.items():
                    db.execute('INSERT INTO audit(project_id,at,action,position_id,period,field,old,new,reason) VALUES(?,?,?,?,?,?,?,?,?)',
                               (pid,engine.now(),'edit',p['id'],period,k,str(row[k]),str(v),f'Текущий портфель {meta["asof"]}, {actor}'))
            if modified:
                engine.calc_one(db,pid,p['id'],baseline,periods,False,from_period=start)
                bad=db.execute('SELECT period FROM position_periods WHERE project_id=? AND position_id=? AND period>=? AND reserve IS NULL',
                               (pid,p['id'],start)).fetchone()
                if bad:raise ValueError(f'Не рассчитан резерв по договору {p["contract"]} на {bad[0]}. Перенос отменён.')
                changed+=1
        at=engine.now()
        db.execute('UPDATE current_portfolios SET applied=? WHERE project_id=?',(at,pid))
        if changed:db.execute("UPDATE projects SET status='draft' WHERE id=?",(pid,))
        db.execute('INSERT INTO audit(project_id,at,action,reason) VALUES(?,?,?,?)',
                   (pid,at,'current_apply',f'{actor}, портфель {meta["asof"]}, позиций изменено: {changed}'))
        return {'applied':at,'changed':changed}
