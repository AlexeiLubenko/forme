"""Review and restore the starting risk inputs of individual forecast positions."""
import json
import re
from contextlib import closing
from pathlib import Path
from openpyxl import load_workbook

import engine


def recover_inputs(db,pid,baseline):
    missing=db.execute("""SELECT p.* FROM positions p LEFT JOIN input_risk i ON i.position_id=p.id
        WHERE p.project_id=? AND i.position_id IS NULL""",(pid,)).fetchall()
    if not missing:
        return
    by_row={}
    for position in missing:
        if position['src']=='bp':
            by_row[position['source_row']]=position
        else:
            fact=db.execute('SELECT gr,rate FROM fact_contracts WHERE project_id=? AND match_key=?',
                            (pid,position['match_key'])).fetchone()
            if fact:
                engine.remember_input_risk(db,position['id'],fact['gr'],fact['rate'])
    upload=db.execute("""SELECT path,uploaded,(SELECT MAX(at) FROM audit WHERE project_id=? AND action='rebuild') built
        FROM uploads WHERE project_id=? AND kind='bp'""",(pid,pid)).fetchone()
    if not by_row or not upload or not upload['built'] or upload['uploaded']>=upload['built']:
        return
    path=engine.ROOT/Path(upload['path'])
    if not path.is_file():
        path=engine.DATA/str(pid)/'bp.xlsx'
    if not path.is_file():
        return
    with closing(load_workbook(path,read_only=True,data_only=True)) as book:
        sheet,headrow,head=engine.find_sheet_header(book,['УНП','Номер договора','Валюта','ГР'])
        cols={engine.normalize_header(v):j for j,v in enumerate(head) if v}
        rate_col=next((i for i,v in enumerate(head) if re.fullmatch(
            r'%\s*рез\s*на\s*'+re.escape(engine.dd(baseline)),str(v or '').strip(),re.I)),None)
        for n,cells in enumerate(sheet.iter_rows(min_row=headrow+1),headrow+1):
            position=by_row.get(n)
            if not position:
                continue
            row=tuple(cell.value for cell in cells)
            key=engine.match_key(engine.normalize_unp(engine.get(row,cols,'УНП')),engine.get(row,cols,'Номер договора'),
                                 engine.get(row,cols,'Валюта'),engine.side_for_operation(row[0]))
            if key==position['match_key']:
                engine.remember_input_risk(db,position['id'],engine.get(row,cols,'ГР'),
                                           engine.input_rate_cell(cells,rate_col))


def review(pid,period,search,page):
    page=max(1,int(page))
    with engine.connect() as db:
        project=db.execute('SELECT fact_date,status FROM projects WHERE id=?',(pid,)).fetchone()
        if not project or not project['fact_date'] or project['status']=='building':
            raise ValueError('Завершите построение прогноза')
        recover_inputs(db,pid,project['fact_date'])
        args=(pid,period,*(['%'+search+'%']*3))
        source=""" FROM positions p JOIN position_periods r ON r.position_id=p.id AND r.project_id=p.project_id
            LEFT JOIN input_risk i ON i.position_id=p.id
            WHERE p.project_id=? AND r.period=? AND (p.client LIKE ? OR p.unp LIKE ? OR p.contract LIKE ?)"""
        count=db.execute('SELECT count(*)'+source,args).fetchone()[0]
        rows=db.execute("""SELECT p.id,p.client,p.unp,p.contract,p.ccy,p.side,p.src,p.source_row,
            i.original_gr,i.original_rate,i.gr AS input_gr,i.rate AS input_rate,i.token,
            r.gr,r.rate,r.override_reason"""+source+' ORDER BY p.client,p.contract,p.id LIMIT 50 OFFSET ?',
            (*args,(page-1)*50))
        return {'rows':[dict(r) for r in rows],'total':count,'page':page,'baseline':project['fact_date']}


def restore(pid,position_id,token,actor):
    with engine.connect() as db:
        db.execute('BEGIN IMMEDIATE')
        source=db.execute("""SELECT i.gr,i.rate,j.periods,j.fact_date,j.status FROM input_risk i
            JOIN positions p ON p.id=i.position_id JOIN projects j ON j.id=p.project_id
            WHERE j.id=? AND p.id=? AND i.token=?""",(pid,position_id,token)).fetchone()
        if not source or source['status']=='building':
            raise ValueError('Прогноз изменился. Обновите сверку.')
        if source['gr'] is None or source['rate'] is None:
            raise ValueError('Для восстановления нужны исходные ГР и ставка на дату начального факта.')
        rows=db.execute('SELECT period,gr,rate,override_reason FROM position_periods WHERE project_id=? AND position_id=?',
                        (pid,position_id)).fetchall()
        dates=json.loads(source['periods'])
        if not dates or {r['period'] for r in rows}!=set(dates):
            raise ValueError('Неполный горизонт расчёта по договору')
        new=[source['gr'],source['rate']]
        for row in rows:
            old=[row['gr'],row['rate']]
            if old!=new or row['override_reason']!=engine.RESTORE_REASON:
                db.execute("""INSERT INTO audit(project_id,at,action,position_id,period,field,old,new,reason)
                    VALUES(?,?,?,?,?,?,?,?,?)""",(pid,engine.now(),'restore_input_risk',position_id,row['period'],
                    'gr,rate',engine.js(old),engine.js(new),f'{actor} · {engine.RESTORE_REASON}'))
        db.execute('UPDATE position_periods SET gr=?,rate=?,override_reason=? WHERE project_id=? AND position_id=?',
                   (*new,engine.RESTORE_REASON,pid,position_id))
        engine.calc_one(db,pid,position_id,source['fact_date'],dates,enable_warnings=False)
        invalid=db.execute('SELECT period FROM position_periods WHERE project_id=? AND position_id=? AND reserve IS NULL LIMIT 1',
                           (pid,position_id)).fetchone()
        if invalid:
            raise ValueError(f'Не удалось пересчитать резерв на {engine.dd(invalid["period"])}. Восстановление отменено.')
        db.execute("UPDATE projects SET status='draft' WHERE id=?",(pid,))
        return {'count':len(dates)}
