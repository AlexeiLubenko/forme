"""Integration checks for imported client-wide DPD, written-off loans and Excel export."""
import tempfile
import unittest
from pathlib import Path
from openpyxl import Workbook,load_workbook
import engine
import dashboard_service as dash
import access_control as auth

HEADER=[x.value for x in next(load_workbook(Path(__file__).resolve().parents[1]/'examples'/'02_Выверенный_факт_пример.xlsx',read_only=True).active.rows)]
H={name:i for i,name in enumerate(HEADER)}

class ImportedFactors(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.db=engine.DB;self.data=engine.DATA
        engine.DB=Path(self.tmp.name)/'db.sqlite3';engine.DATA=Path(self.tmp.name)
        engine.initialize();dash.initialize();auth.initialize()
    def tearDown(self):
        engine.DB=self.db;engine.DATA=self.data
        self.tmp.cleanup()

    def source(self,name,records):
        wb=Workbook();ws=wb.active;ws.title='Данные';ws.append(HEADER)
        for contract,seg,grp,rate,dpd,kind,debt,reserve,unp in records:
            row=[None]*len(HEADER)
            def put(field,value):row[H[field]]=value
            put('УНП',unp);put('Клиент','Тестовый клиент');put('Сегмент',seg)
            put('Номер договора',contract);put('Тип операции','Кредит');put('Код валюты','933')
            put('ГР',grp);put('% рез',rate);put('Задолженность, тыс BYN',debt)
            put('Резерв факт',reserve);put('Курс',1);put('НИ',0);put('ПФН',0);put('НВВ',0)
            put('Рестра','');put('Обеспеченность','Обеспеченный')
            put('Max-Day OD',dpd);put('Max-Day %%',0)
            put('ПОК/СПОК',kind)
            ws.append(row)
        path=Path(self.tmp.name)/name;wb.save(path);wb.close();return path

    def test_client_wide_dpd_from_mmb_affects_medium(self):
        jan=self.source('jan.xlsx',[
            ('MED','Средний','1',.5,0,'',100,.5,'123'),
            ('MMB','ММБ','1',.5,0,'',50,.25,'123'),
        ])
        feb=self.source('feb.xlsx',[
            ('MED','Средний','4',30,0,'',100,30,'123'),
            ('MMB','ММБ','4',30,40,'',50,15,'123'),
        ])
        dash.import_portfolio(jan,'jan.xlsx','2027-01-01','admin')
        result=dash.import_portfolio(feb,'feb.xlsx','2027-02-01','admin')
        self.assertEqual(result['runs'][0]['errors'],0)
        self.assertEqual(result['runs'][0]['rows'],1)
        self.assertEqual(result['runs'][0]['totals_cents']['financial_state'],-2_950_000)
        dash.publish('admin')
        path=Path(self.tmp.name)/'export.xlsx'
        dash.export_factor_excel(2027,1,path)
        wb=load_workbook(path,read_only=True,data_only=True)
        self.assertEqual(wb.sheetnames,['Свод_клиенты','Договоры_помесячно'])
        rows=list(wb['Договоры_помесячно'].values)
        self.assertEqual(len(rows),2)
        self.assertEqual(rows[1][7],0)
        self.assertEqual(rows[1][8],40)
        self.assertAlmostEqual(rows[1][15],-0.0295,places=8)
        self.assertAlmostEqual(rows[1][17],-0.0295,places=8)
        wb.close()

    def test_pok_credit_and_uo_use_only_max_day_od(self):
        old=self.source('pok_old.xlsx',[
            ('POK1','Средний','ПОК',1.7,0,'ПОК',100,1.7,'123'),
            ('POK1','Средний','1',.5,0,'',50,.25,'123'),
        ])
        new=self.source('pok_new.xlsx',[
            ('POK1','Средний','ПОК',4.6,17,'ПОК',100,4.6,'123'),
            ('POK1','Средний','1',.5,17,'',50,.25,'123'),
        ])
        for path in (old,new):
            wb=load_workbook(path)
            ws=wb.active
            ws.cell(3,H['Тип операции']+1).value='УО'
            # The second overdue field is unrelated to this factor analysis.
            ws.cell(2,H['Max-Day %%']+1).value=200
            ws.cell(3,H['Max-Day %%']+1).value=200
            wb.save(path);wb.close()
        dash.import_portfolio(old,old.name,'2027-01-01','admin')
        result=dash.import_portfolio(new,new.name,'2027-02-01','admin')
        self.assertEqual(result['runs'][0]['errors'],0)
        self.assertEqual(result['runs'][0]['rows'],2)
        self.assertEqual(result['runs'][0]['totals_cents']['financial_state'],-290_000)
        with engine.connect() as db:
            self.assertEqual([tuple(r) for r in db.execute(
                'SELECT side,poc,dpd FROM dash_positions WHERE snapshot_id=? ORDER BY side',
                (result['snapshot_id'],))],[('баланс',1,17),('внебаланс',1,17)])
            breakdown=list(db.execute('SELECT subfactor,amount_cents FROM dash_factor_subrows'))
            self.assertEqual([tuple(r) for r in breakdown],[('poc_rate_dpd',-290_000)])

    def test_max_day_percent_column_is_optional(self):
        src=self.source('only_od.xlsx', [('A','Средний','1',.5,0,'',100,.5,'123')])
        wb=load_workbook(src)
        wb.active.delete_cols(H['Max-Day %%']+1)
        wb.active.cell(1,H['Max-Day OD']+1).value='Max Day OD'
        wb.save(src);wb.close()
        self.assertEqual(dash.import_portfolio(src,src.name,'2027-01-01','admin')['positions'],1)

    def test_pok_threshold_after_30_days_applies_to_credit_and_uo(self):
        before=self.source('pok_17.xlsx',[
            ('POK1','Средний','ПОК',4.6,17,'ПОК',100,4.6,'123'),
            ('POK1','Средний','1',.5,17,'',50,.25,'123')])
        after=self.source('pok_35.xlsx',[
            ('POK1','Средний','4',30,35,'ПОК',100,30,'123'),
            ('POK1','Средний','4',30,35,'',50,15,'123')])
        for source in (before,after):
            wb=load_workbook(source)
            wb.active.cell(3,H['Тип операции']+1).value='УО'
            wb.save(source);wb.close()
        dash.import_portfolio(before,before.name,'2027-01-01','admin')
        result=dash.import_portfolio(after,after.name,'2027-02-01','admin')
        self.assertEqual(result['runs'][0]['errors'],0)
        self.assertEqual(result['runs'][0]['totals_cents']['financial_state'],-4_015_000)
        with engine.connect() as db:
            self.assertEqual(db.execute("SELECT COUNT(*) FROM dash_factor_subrows WHERE subfactor='dpd_in'").fetchone()[0],2)

    def test_unrelated_contract_keeps_ordinary_overdue_rule(self):
        src=self.source('ordinary.xlsx',[
            ('POK1','Средний','ПОК',1.7,17,'ПОК',100,1.7,'123'),
            ('OTHER','Средний','1',.5,17,'',100,.5,'123'),
        ])
        with self.assertRaisesRegex(ValueError,'ниже минимальной'):
            dash.import_portfolio(src,src.name,'2027-01-01','admin')

    def test_pok_status_covers_different_currency_of_same_contract(self):
        src=self.source('pok_mixed_ccy.xlsx',[
            ('POK1','Средний','ПОК',1.7,17,'ПОК',100,1.7,'123'),
            ('POK1','Средний','1',.5,17,'',50,.25,'123'),
        ])
        wb=load_workbook(src)
        wb.active.cell(3,H['Тип операции']+1).value='УО'
        wb.active.cell(3,H['Код валюты']+1).value='840'
        wb.save(src);wb.close()
        result=dash.import_portfolio(src,src.name,'2027-01-01','admin')
        with engine.connect() as db:
            self.assertEqual([r['poc'] for r in db.execute(
                'SELECT poc FROM dash_positions WHERE snapshot_id=? ORDER BY side',(result['snapshot_id'],))],[1,1])

    def test_writtenoff_blank_ledger_reserve(self):
        src=self.source('writeoff.xlsx',[
            ('W','Средний','Списан',None,0,'',100,None,'123')
        ])
        result=dash.import_portfolio(src,'writeoff.xlsx','2027-01-01','admin')
        with engine.connect() as db:
            rec=db.execute('SELECT reserve_byn,rate,written_off FROM dash_positions WHERE snapshot_id=?',(result['snapshot_id'],)).fetchone()
        self.assertEqual(rec['reserve_byn'],100000)
        self.assertEqual(rec['rate'],100)
        self.assertEqual(rec['written_off'],1)

    def test_missing_reserve_regular_is_rejected(self):
        src=self.source('invalid.xlsx',[('Z','Средний','1',.5,0,'',100,None,'123')])
        with self.assertRaisesRegex(ValueError,'Не заполнен/некорректен резерв факт'):
            dash.import_portfolio(src,'invalid.xlsx','2027-01-01','admin')

    def test_factual_reserve_is_used_when_it_differs_from_reported_rate(self):
        old=self.source('reserve_jan.xlsx',[('A','Средний','1',.5,0,'',100,.6,'123')])
        new=self.source('reserve_feb.xlsx',[('A','Средний','1',.5,0,'',110,.72,'123')])
        dash.import_portfolio(old,'reserve_jan.xlsx','2027-01-01','admin')
        result=dash.import_portfolio(new,'reserve_feb.xlsx','2027-02-01','admin')
        self.assertEqual(result['runs'][0]['errors'],0)
        self.assertEqual(result['runs'][0]['totals_cents']['movement'],-5000)
        self.assertEqual(result['runs'][0]['totals_cents']['financial_state'],-7000)
        with engine.connect() as db:
            row=db.execute('SELECT reserve_byn FROM dash_positions WHERE snapshot_id=?',(result['snapshot_id'],)).fetchone()
            sub=db.execute("SELECT amount_cents FROM dash_factor_subrows WHERE subfactor='actual_reserve_difference'").fetchone()
        self.assertEqual(row['reserve_byn'],720)
        self.assertEqual(sub['amount_cents'],-7000)

    def test_equivalent_security_spellings_do_not_create_factor(self):
        for start,end in [('Не обеспеченый','Необеспеченный'),
                          ('Не достаточно обеспеченный','Недообеспеченый')]:
            with self.subTest(start=start):
                old=self.source('spell_jan.xlsx',[('A','Средний','2',5,0,'',100,5,'123')])
                new=self.source('spell_feb.xlsx',[('A','Средний','2',5,0,'',100,5,'123')])
                for path,security in ((old,start),(new,end)):
                    workbook=load_workbook(path)
                    workbook.active.cell(2,H['Обеспеченность']+1).value=security
                    workbook.save(path)
                    workbook.close()
                dash.import_portfolio(old,old.name,'2027-01-01','admin')
                result=dash.import_portfolio(new,new.name,'2027-02-01','admin')
                self.assertEqual(result['runs'][0]['errors'],0)
                self.assertEqual(result['runs'][0]['totals_cents']['security_effect'],0)

    def test_migration_keeps_old_snapshot(self):
        with engine.connect() as db:
            for col in ('dpd','spok','written_off'):
                self.assertIn(col,[r['name'] for r in db.execute('PRAGMA table_info(dash_positions)')])
        dash.initialize()
        with engine.connect() as db:
            self.assertEqual(len([r for r in db.execute('PRAGMA table_info(dash_positions)') if r['name']=='dpd']),1)

    def test_existing_unique_runs_migrate_without_changing_published_reference(self):
        with engine.connect() as db:
            db.execute('DROP TABLE dash_factor_runs')
            db.execute('''CREATE TABLE dash_factor_runs(
                id INTEGER PRIMARY KEY,start_id INTEGER NOT NULL,end_id INTEGER NOT NULL,
                month TEXT NOT NULL,created TEXT NOT NULL,rows INTEGER NOT NULL,
                errors INTEGER NOT NULL,amount_cents INTEGER NOT NULL DEFAULT 0,
                totals_json TEXT NOT NULL DEFAULT '{}',methodology_version INTEGER NOT NULL DEFAULT 2,
                UNIQUE(start_id,end_id))''')
            db.execute("INSERT INTO dash_factor_runs VALUES(9,1,2,'2027-01','now',1,0,-100,'{}',2)")
            db.execute("INSERT INTO dash_version_runs VALUES(7,'2027-01',9)")
        dash.initialize()
        with engine.connect() as db:
            self.assertEqual(db.execute('SELECT run_id FROM dash_version_runs WHERE version_id=7').fetchone()[0],9)
            db.execute("INSERT INTO dash_factor_runs VALUES(10,1,2,'2027-01','later',1,0,-200,'{}',2)")
            self.assertEqual(db.execute('SELECT COUNT(*) FROM dash_factor_runs WHERE start_id=1 AND end_id=2').fetchone()[0],2)

    def test_reimport_legacy_neighbor_in_chronological_order(self):
        # Before 1.4.0 the same date already exists without DPD/POK fields.
        with engine.connect() as db:
            db.execute("INSERT INTO dash_portfolios(asof,created,original_name,created_by,row_count,position_count) VALUES('2027-02-01','now','old.xlsx','admin',1,0)")
        jan=self.source('new_jan.xlsx',[('MED','Средний','1',.5,0,'',100,.5,'123')])
        feb=self.source('new_feb.xlsx',[('MED','Средний','1',.5,0,'',110,.55,'123')])
        r=dash.import_portfolio(jan,'new_jan.xlsx','2027-01-01','admin')
        self.assertEqual(r['runs'],[])
        self.assertEqual(len(dash.admin_state()['pending']),1)
        with self.assertRaisesRegex(ValueError,'повторно загрузите'):
            dash.publish('admin')
        r=dash.import_portfolio(feb,'new_feb.xlsx','2027-02-01','admin')
        self.assertEqual(r['runs'][0]['errors'],0)
        self.assertEqual(dash.admin_state()['pending'],[])
        dash.publish('admin')

    def test_previous_snapshot_recalculates_without_file_and_keeps_publication(self):
        jan=self.source('prior_rule_jan.xlsx',[('A','Средний','ПОК',1.7,0,'ПОК',100,1.7,'123')])
        feb=self.source('new_rule_feb.xlsx',[('A','Средний','ПОК',4.6,17,'ПОК',100,4.6,'123')])
        first=dash.import_portfolio(jan,jan.name,'2027-01-01','admin')
        with engine.connect() as db:
            db.execute('UPDATE dash_portfolios SET methodology_version=2 WHERE id=?',(first['snapshot_id'],))
        new=dash.import_portfolio(feb,feb.name,'2027-02-01','admin')
        self.assertEqual(len(new['runs']),1)
        self.assertEqual(new['runs'][0]['errors'],0)
        old_run=new['runs'][0]['id']
        published=dash.publish('admin')['version']
        result=dash.recalculate_saved('admin')
        self.assertEqual(result['legacy_months'],['2027-01'])
        self.assertNotEqual(result['runs'][0]['id'],old_run)
        with engine.connect() as db:
            historical=db.execute('SELECT run_id FROM dash_version_runs WHERE version_id=?',(published,)).fetchone()[0]
            self.assertEqual(historical,old_run)
            self.assertEqual(db.execute('SELECT COUNT(*) FROM dash_factor_runs WHERE start_id=? AND end_id=?',
                (first['snapshot_id'],new['snapshot_id'])).fetchone()[0],2)
        self.assertEqual(dash.recalculate_saved('admin')['legacy_months'],['2027-01'])

    def test_cross_side_draw_is_detected(self):
        # Two records, one off-balance shrink and one on-balance increase.
        before=[('x|d|BYN|внебаланс',{'side':'внебаланс','debt_byn':50000,'fx':1},None),
                ('x|d|BYN|баланс',None,{'side':'баланс','debt_byn':20000,'fx':1})]
        found=dash._transfer_by_side(before)
        self.assertEqual(found['баланс'],20000)
        self.assertEqual(dash._pairs_by_contract is not None,True)

if __name__=='__main__':unittest.main()
