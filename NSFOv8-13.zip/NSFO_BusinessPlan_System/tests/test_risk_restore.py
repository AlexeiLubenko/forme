from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch
import shutil
import unittest

from openpyxl import load_workbook
import engine
import risk_restore


class RiskRestoreTests(unittest.TestCase):
    def test_restore_initial_input_over_whole_horizon(self):
        with TemporaryDirectory(dir=engine.ROOT) as temp:
            root=Path(temp)
            with patch.object(engine,'DATA',root),patch.object(engine,'DB',root/'project.db'):
                engine.initialize()
                pid=engine.create_project('Сверка исходных значений')
                for kind,prefix in [('bp','01'),('fact','02'),('rates','03')]:
                    source=next((engine.ROOT/'examples').glob(prefix+'_*.xlsx'))
                    file=root/source.name
                    shutil.copy(source,file)
                    if kind=='bp':
                        book=load_workbook(file)
                        sheet=book.active
                        cols={c.value:c.column for c in sheet[1]}
                        sheet.cell(2,cols['ГР']).value=5
                        sheet.cell(2,cols['% рез на 01.10.2026']).value=47.5
                        sheet.cell(2,cols['% рез на 01.11.2026']).value=50
                        sheet.cell(3,cols['% рез на 01.10.2026']).value=None
                        book.save(file)
                        book.close()
                    engine.upload_path(pid,kind,str(file),source.name)
                built=engine.build(pid)
                rows=risk_restore.review(pid,'2026-11-01','D1',1)['rows']
                credit=next(r for r in rows if r['contract']=='D1' and r['side']=='баланс')
                uo=next(r for r in rows if r['contract']=='D1' and r['side']=='внебаланс')
                self.assertEqual((credit['input_gr'],credit['input_rate']),('5',47.5))
                self.assertNotEqual(credit['rate'],47.5)
                with self.assertRaises(ValueError):
                    risk_restore.restore(pid,uo['id'],uo['token'],'editor')
                with self.assertRaises(ValueError):
                    risk_restore.restore(pid,credit['id'],'stale','editor')
                risk_restore.restore(pid,credit['id'],credit['token'],'editor')
                engine.edit(pid,credit['id'],'2026-11-01','pfn',1,'')
                engine.recalculate_project(pid)
                with engine.connect() as db:
                    periods=db.execute('SELECT * FROM position_periods WHERE position_id=? ORDER BY period',
                                       (credit['id'],)).fetchall()
                    self.assertEqual([r['period'] for r in periods],built['dates'])
                    for r in periods:
                        self.assertEqual((r['gr'],r['rate'],r['reserve']),('5',47.5,round(r['od']*.475,2)))
                    self.assertFalse(db.execute('SELECT 1 FROM position_periods WHERE position_id=? AND rate=47.5',(uo['id'],)).fetchone())
                    self.assertEqual(db.execute("SELECT COUNT(*) FROM audit WHERE action='restore_input_risk' AND position_id=?",
                                                (credit['id'],)).fetchone()[0],len(periods))
                    db.execute('DELETE FROM input_risk')
                    db.execute("UPDATE uploads SET uploaded='2026-01-01' WHERE project_id=? AND kind='bp'",(pid,))
                legacy=risk_restore.review(pid,'2026-10-01','D1',1)['rows']
                self.assertEqual(next(r['input_rate'] for r in legacy if r['id']==credit['id']),47.5)
