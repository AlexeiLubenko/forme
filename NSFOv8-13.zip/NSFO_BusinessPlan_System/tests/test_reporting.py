"""Regression coverage for contract-level review and consistent client reports."""
import json
import shutil
import unittest
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch
from openpyxl import Workbook,load_workbook
import engine
import current_portfolio as cp
import exports


class ReportingTests(unittest.TestCase):
    def setUp(self):
        self.temp=TemporaryDirectory(dir=engine.ROOT)
        self.addCleanup(self.temp.cleanup)
        self.root=Path(self.temp.name)
        self.patch=patch.object(engine,'DB',self.root/'test.sqlite3');self.patch.start();self.addCleanup(self.patch.stop)
        shutil.copy(engine.ROOT/'examples/demo_nsfo.sqlite3',engine.DB)
        engine.initialize()
        with engine.connect() as db:
            db.execute("UPDATE positions SET segment26='Средний',segment27='Крупный'")
            db.execute('UPDATE position_periods SET expenses=0')

    def upload(self,rows):
        w=Workbook();ws=w.active;ws.append(cp.HEADERS)
        for row in rows:ws.append(row)
        path=self.root/'current.xlsx';w.save(path);w.close()
        cp.stage(1,path,'Текущий.xlsx','2026-10-24','editor')
        return cp.report(1)

    def test_segments_threshold_by_client_period_and_totals(self):
        with engine.connect() as db:
            db.execute("UPDATE position_periods SET expenses=-60000 WHERE position_id IN (1,2) AND period='2026-11-01'")
            db.execute("UPDATE positions SET segment26='Крупнейший' WHERE unp='1001'")
        r=engine.client_report(1,'2026-11-01')
        self.assertEqual([(x['unp'],x['segment'],x['expenses']) for x in r['important']],[('1001','Крупнейший',-120000)])
        self.assertEqual(sum(x['clients'] for x in r['standard_segments']),r['standard']['clients'])
        self.assertEqual(sum(x['expenses'] for x in r['important']+r['standard_segments']),-120000)
        self.assertEqual(engine.client_report(1,'2026-12-01')['important'],[])
        r=engine.client_report(1,'2027-01-01')
        self.assertEqual(next(x['clients'] for x in r['standard_segments'] if x['segment']=='Крупный'),6)

    def test_missing_and_conflicting_segments_are_explicit(self):
        with engine.connect() as db:
            db.execute("UPDATE positions SET segment26='Крупный' WHERE id=1")
            db.execute("UPDATE positions SET segment26=NULL WHERE unp='1003'")
        r=engine.client_report(1,'2026-11-01')
        groups={r['segment']:r for r in r['standard_segments']}
        self.assertEqual(groups['Конфликт сегментов']['clients'],1)
        self.assertEqual(groups['Не указан']['clients'],1)

    def test_subfactor_preserves_offsetting_clients_and_filters(self):
        with engine.connect() as db:
            db.execute("UPDATE position_periods SET factors='{}' WHERE period='2026-11-01'")
            for id,value in [(1,-120),(2,120),(3,-30)]:
                db.execute("UPDATE position_periods SET factors=? WHERE position_id=? AND period='2026-11-01'",(json.dumps({'ni_in':value}),id))
        r=engine.factor_clients(1,'2026-11-01','ni_in')
        x=next(x for x in r['rows'] if x['unp']=='1001')
        self.assertEqual((x['creation'],x['recovery'],x['amount']),(-120,120,0))
        self.assertEqual(x['contracts'],['D1'])
        self.assertEqual(r['totals']['amount'],engine.factor_summary(1,'2026-11-01')['subfactors']['ni_in'])
        filtered=engine.factor_clients(1,'2026-11-01','ni_in',search='D1',side='баланс')
        self.assertEqual(filtered['totals']['amount'],-120)
        self.assertEqual(engine.factor_clients(1,'2026-11-01','ni_in',limit=1,page=2)['count'],2)
        with self.assertRaises(ValueError):engine.factor_clients(1,'2026-11-01','unknown')

    def test_review_merges_sides_omits_unchanged_and_zero_next_balance(self):
        r=self.upload([['1001','D1','Кредит','USD',0,0,0,'','Обеспеченный'],['1001','D1','УО','USD',0,0,0,'','Обеспеченный']])
        self.assertFalse(any(x['contract']=='D1' for x in r['rows']))
        with engine.connect() as db:
            db.execute("UPDATE position_periods SET debt=0 WHERE position_id=3 AND period='2026-11-01'")
        self.assertFalse(any(x['contract']=='N1' for x in cp.report(1)['rows']))
        with engine.connect() as db:
            db.execute("UPDATE position_periods SET debt=100 WHERE position_id=3 AND period='2026-11-01'")
        self.assertIn('plan_only',next(x for x in cp.report(1)['rows'] if x['contract']=='N1')['tags'])
        r=self.upload([['1001','D1','Кредит','USD',1,0,0,'Рестр.ГР 4 % 30','Не обеспеченый'],['1001','D1','УО','USD',1,0,0,'Рестр.ГР 4 % 30','Не обеспеченый']])
        self.assertEqual(len([x for x in r['rows'] if x['contract']=='D1']),1)
        self.assertEqual(next(x for x in r['rows'] if x['contract']=='D1')['changes']['ni'],[0,1])

    def test_credit_only_transfers_all_attributes_to_uo_and_preserves_fact(self):
        with engine.connect() as db:
            initial=list(map(tuple,db.execute("SELECT * FROM position_periods WHERE period='2026-10-01' ORDER BY position_id")))
        r=self.upload([['1001','D1','Кредит','USD',1,1,1,'Рестр.ГР 4 % 30','Не обеспеченый']])
        cp.apply(1,r['meta']['token'],{},'editor')
        with engine.connect() as db:
            self.assertEqual(initial,list(map(tuple,db.execute("SELECT * FROM position_periods WHERE period='2026-10-01' ORDER BY position_id"))))
            vals=list(map(tuple,db.execute("SELECT DISTINCT ni,pfn,nvv,restra,security FROM position_periods WHERE position_id IN (1,2) AND period>'2026-10-01'")))
            self.assertEqual(vals,[(1,1,1,'Рестр.ГР 4 % 30','Необеспеченный')])

    def test_contract_mapping_updates_both_sides(self):
        with engine.connect() as db:
            db.execute("UPDATE positions SET contract='Новый договор',match_key=unp||'|НОВЫЙ ДОГОВОР|'||ccy||'|'||side WHERE id IN (1,2)")
        r=self.upload([['1001','Реальный','Кредит','USD',1,0,0,'Рестр.ГР 4 % 30','Необеспеченный']])
        row=next(x for x in r['rows'] if x['contract']=='Реальный')
        self.assertEqual(len(row['candidates']),1)
        cp.apply(1,r['meta']['token'],{row['key']:row['candidates'][0]['id']},'editor')
        with engine.connect() as db:
            self.assertEqual(db.execute("SELECT COUNT(DISTINCT position_id) FROM position_periods WHERE position_id IN (1,2) AND period>'2026-10-01' AND security='Необеспеченный' AND restra='Рестр.ГР 4 % 30'").fetchone()[0],2)

    def test_explicit_sides_keep_their_values(self):
        r=self.upload([['1001','D1','Кредит','USD',1,0,0,'','Необеспеченный'],['1001','D1','УО','USD',1,0,0,'','Обеспеченный']])
        cp.apply(1,r['meta']['token'],{},'editor')
        with engine.connect() as db:
            rows=dict(db.execute("SELECT position_id,security FROM position_periods WHERE position_id IN (1,2) AND period='2026-11-01'"))
            self.assertEqual(rows,{1:'Необеспеченный',2:'Обеспеченный'})

    def test_exports_include_all_segments_details_and_consistent_totals(self):
        with engine.connect() as db:
            db.execute("UPDATE position_periods SET expenses=-120000 WHERE position_id=1 AND period='2026-11-01'")
        wb=load_workbook(exports.build_excel(1),data_only=True)
        self.addCleanup(wb.close)
        self.assertEqual(wb.sheetnames[0],'Сводка')
        self.assertIn('Подфакторы по клиентам',wb.sheetnames)
        sheet=wb['Поклиентные расходы']
        self.assertIsNotNone(sheet.auto_filter.ref)
        self.assertEqual(sheet.freeze_panes,'C2')
        rows=list(sheet.values)[1:]
        self.assertEqual(next(r[6] for r in rows if r[0]=='01.11.2026' and r[2]=='ИТОГО'),-120000)
        self.assertTrue(any(r[3]=='Средний' and r[4]=='Стандартный портфель' for r in rows))
        self.assertEqual(next(c.number_format for row in sheet.iter_rows(min_row=2) for c in row if c.value==-120000),exports.NUM_FMT)
        project,sections,invalid=exports.report_sections(1)
        self.assertTrue(any('Подфакторы' in title for title,_,_ in sections))
        html=exports.build_printable_html(1)
        self.assertIn('Средний',html)
        pdf=exports.build_pdf(1)
        self.assertTrue(pdf.getvalue().startswith(b'%PDF'))
        self.assertGreater(len(pdf.getvalue()),20000)
