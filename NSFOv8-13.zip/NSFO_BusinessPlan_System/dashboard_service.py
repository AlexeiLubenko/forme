"""Read-only bank dashboard, staged Excel imports and independently versioned facts.

All monetary dashboard values are million BYN. Portfolio source OD / factual reserves
are thousand BYN; normalized fact positions use BYN. No Streamlit/Flask required.
"""
from __future__ import annotations
import datetime as dt
import json
import re
from collections import defaultdict
from decimal import Decimal, ROUND_HALF_UP, InvalidOperation
from pathlib import Path
from openpyxl import load_workbook
import engine
import fact_factor
from risk import (MethodologyError, flag, currency, rate_percent, canonical_security, normal_security,
                  gr_value, side_for_operation, match_key)

METRICS = {
    'bank_rnr': ('РнР Банк', 'money'),
    'bank_cor': ('COR Банк', 'percent'),
    'bank_upr': ('УПР Банк', 'percent'),
    'mmb_rnr': ('РнР ММБ', 'money'),
    'banks_other_rnr': ('РнР Банки и прочие', 'money'),
    'fl_rnr': ('РнР ФЛ', 'money'),
    'fl_writeoff': ('Поступления по списанным ФЛ', 'money'),
    'fl_cor': ('COR ФЛ', 'percent'),
    'fl_upr': ('УПР ФЛ', 'percent'),
    'ul_writeoff': ('Поступления по списанным ЮЛ', 'money'),
    'kb_cor': ('COR КБ', 'percent'),
    'kb_upr': ('УПР КБ', 'percent'),
}
MONEY={k for k,(_,typ) in METRICS.items() if typ=='money'}
FACTOR_KEYS=('movement','financial_state','security_effect','revaluation')
FACTOR_LABELS={'movement':'Движение КП','financial_state':'Финансовое состояние','security_effect':'Обеспечение','revaluation':'Переоценка'}
SEGMENTS={'крупнейший','крупный','средний'}
MONTHS=('Январь','Февраль','Март','Апрель','Май','Июнь','Июль','Август','Сентябрь','Октябрь','Ноябрь','Декабрь')


def initialize():
    with engine.connect() as db:
        db.executescript('''
        CREATE TABLE IF NOT EXISTS dash_versions(
            id INTEGER PRIMARY KEY, state TEXT NOT NULL CHECK(state IN ('draft','published','archived')),
            created TEXT NOT NULL, published TEXT, author TEXT NOT NULL, note TEXT DEFAULT '', source_name TEXT DEFAULT '');
        CREATE TABLE IF NOT EXISTS dash_metrics(
            version_id INTEGER NOT NULL,year INTEGER NOT NULL,metric TEXT NOT NULL,
            scenario TEXT NOT NULL CHECK(scenario IN ('plan','fact')),
            month INTEGER NOT NULL CHECK(month BETWEEN 1 AND 12),value REAL NOT NULL,
            PRIMARY KEY(version_id,year,metric,scenario,month));
        CREATE TABLE IF NOT EXISTS dash_portfolios(
            id INTEGER PRIMARY KEY, asof TEXT NOT NULL,created TEXT NOT NULL,original_name TEXT NOT NULL,
            created_by TEXT NOT NULL,row_count INTEGER NOT NULL,position_count INTEGER NOT NULL,
            status TEXT DEFAULT 'active');
        CREATE INDEX IF NOT EXISTS dash_portfolios_date ON dash_portfolios(asof,id);
        CREATE TABLE IF NOT EXISTS dash_positions(
            snapshot_id INTEGER NOT NULL,key TEXT NOT NULL,unp TEXT NOT NULL,client TEXT,
            contract TEXT,ccy TEXT,side TEXT,operation TEXT,segment TEXT,
            debt_byn REAL NOT NULL,reserve_byn REAL NOT NULL,fx REAL NOT NULL,rate REAL NOT NULL,
            gr TEXT,ni INTEGER,pfn INTEGER,nvv INTEGER,restra TEXT,security TEXT,micro INTEGER,poc INTEGER,
            poc_exited INTEGER NOT NULL DEFAULT 0,
            PRIMARY KEY(snapshot_id,key));
        CREATE INDEX IF NOT EXISTS dash_position_unp ON dash_positions(snapshot_id,unp);
        CREATE TABLE IF NOT EXISTS dash_pok_exits(
            unp TEXT PRIMARY KEY, exited_on TEXT NOT NULL, max_day_od INTEGER NOT NULL);
        CREATE TABLE IF NOT EXISTS dash_pok_exit_contracts(
            unp TEXT NOT NULL, contract_identity TEXT NOT NULL, exited_on TEXT NOT NULL,
            PRIMARY KEY(unp,contract_identity));
        CREATE TABLE IF NOT EXISTS dash_base_values(
            valid_from TEXT PRIMARY KEY, amount_byn REAL NOT NULL CHECK(amount_byn>0));
        CREATE TABLE IF NOT EXISTS dash_factor_runs(
            id INTEGER PRIMARY KEY,start_id INTEGER NOT NULL,end_id INTEGER NOT NULL,
            month TEXT NOT NULL,created TEXT NOT NULL,rows INTEGER NOT NULL,
            errors INTEGER NOT NULL,amount_cents INTEGER NOT NULL DEFAULT 0,
            totals_json TEXT NOT NULL DEFAULT '{}');
        CREATE TABLE IF NOT EXISTS dash_factor_rows(
            run_id INTEGER NOT NULL,key TEXT NOT NULL,unp TEXT,client TEXT,contract TEXT,
            segment TEXT, movement_cents INTEGER NOT NULL,financial_cents INTEGER NOT NULL,
            security_cents INTEGER NOT NULL,fx_cents INTEGER NOT NULL,expenses_cents INTEGER NOT NULL,
            explanation TEXT,PRIMARY KEY(run_id,key));
        CREATE TABLE IF NOT EXISTS dash_factor_errors(
            run_id INTEGER NOT NULL,key TEXT NOT NULL,description TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS dash_factor_subrows(
            run_id INTEGER NOT NULL,key TEXT NOT NULL,subfactor TEXT NOT NULL,
            amount_cents INTEGER NOT NULL,PRIMARY KEY(run_id,key,subfactor));
        CREATE INDEX IF NOT EXISTS dash_subrow_run ON dash_factor_subrows(run_id,subfactor);
        CREATE TABLE IF NOT EXISTS dash_version_runs(
            version_id INTEGER NOT NULL,month TEXT NOT NULL,run_id INTEGER NOT NULL,
            PRIMARY KEY(version_id,month));
        CREATE TABLE IF NOT EXISTS dash_factor_pending(
            version_id INTEGER NOT NULL,month TEXT NOT NULL,reason TEXT NOT NULL,
            PRIMARY KEY(version_id,month));
        CREATE TABLE IF NOT EXISTS dash_audit(
            id INTEGER PRIMARY KEY,at TEXT NOT NULL,actor TEXT NOT NULL,action TEXT NOT NULL,
            details TEXT NOT NULL DEFAULT '{}');
        ''')
        # Upgrade old SQLite databases in place.
        old_columns={r['name'] for r in db.execute('PRAGMA table_info(dash_positions)')}
        for col,sqltype in (('dpd','INTEGER NOT NULL DEFAULT 0'),('spok','INTEGER NOT NULL DEFAULT 0'),('written_off','INTEGER NOT NULL DEFAULT 0')):
            if col not in old_columns:
                db.execute(f'ALTER TABLE dash_positions ADD COLUMN {col} {sqltype}')
        if 'poc_exited' not in old_columns:
            db.execute('ALTER TABLE dash_positions ADD COLUMN poc_exited INTEGER NOT NULL DEFAULT 0')
        db.execute("INSERT OR IGNORE INTO dash_base_values(valid_from,amount_byn) VALUES('1900-01-01',45)")
        exit_columns={r['name'] for r in db.execute('PRAGMA table_info(dash_pok_exit_contracts)')}
        if 'exited_on' not in exit_columns:
            db.execute("ALTER TABLE dash_pok_exit_contracts ADD COLUMN exited_on TEXT NOT NULL DEFAULT '9999-12-31'")
            db.execute('''UPDATE dash_pok_exit_contracts SET exited_on=COALESCE(
                (SELECT exited_on FROM dash_pok_exits WHERE dash_pok_exits.unp=dash_pok_exit_contracts.unp),
                '9999-12-31')''')
        portfolio_cols={r['name'] for r in db.execute('PRAGMA table_info(dash_portfolios)')}
        if 'methodology_version' not in portfolio_cols:
            db.execute('ALTER TABLE dash_portfolios ADD COLUMN methodology_version INTEGER NOT NULL DEFAULT 1')
        factor_cols={r['name'] for r in db.execute('PRAGMA table_info(dash_factor_runs)')}
        if 'methodology_version' not in factor_cols:
            db.execute('ALTER TABLE dash_factor_runs ADD COLUMN methodology_version INTEGER NOT NULL DEFAULT 1')
        # Allow a new draft calculation for the same saved snapshots while
        # published runs continue to refer to their original, immutable rows.
        definition=db.execute("SELECT sql FROM sqlite_master WHERE type='table' AND name='dash_factor_runs'").fetchone()['sql']
        if 'unique(start_id,end_id)' in ''.join(definition.lower().split()):
            db.execute('ALTER TABLE dash_factor_runs RENAME TO dash_factor_runs_previous')
            db.execute('''CREATE TABLE dash_factor_runs(
                id INTEGER PRIMARY KEY,start_id INTEGER NOT NULL,end_id INTEGER NOT NULL,
                month TEXT NOT NULL,created TEXT NOT NULL,rows INTEGER NOT NULL,
                errors INTEGER NOT NULL,amount_cents INTEGER NOT NULL DEFAULT 0,
                totals_json TEXT NOT NULL DEFAULT '{}',methodology_version INTEGER NOT NULL DEFAULT 1)''')
            db.execute('''INSERT INTO dash_factor_runs(id,start_id,end_id,month,created,rows,errors,amount_cents,totals_json,methodology_version)
                SELECT id,start_id,end_id,month,created,rows,errors,amount_cents,totals_json,methodology_version
                FROM dash_factor_runs_previous''')
            db.execute('DROP TABLE dash_factor_runs_previous')
        db.execute('CREATE INDEX IF NOT EXISTS dash_factor_pair ON dash_factor_runs(start_id,end_id,id)')


def _audit(db,actor,action,details=None):
    db.execute('INSERT INTO dash_audit(at,actor,action,details) VALUES(?,?,?,?)',
               (engine.now(),actor,action,json.dumps(details or {},ensure_ascii=False)))


def _latest(db,state):
    return db.execute('SELECT * FROM dash_versions WHERE state=? ORDER BY id DESC LIMIT 1',(state,)).fetchone()


def _draft(db,actor):
    current=_latest(db,'draft')
    if current:return current['id']
    cur=db.execute('INSERT INTO dash_versions(state,created,author) VALUES(?,?,?)',('draft',engine.now(),actor))
    v=cur.lastrowid
    pub=_latest(db,'published')
    if pub:
        db.execute('INSERT INTO dash_metrics SELECT ?,year,metric,scenario,month,value FROM dash_metrics WHERE version_id=?',(v,pub['id']))
        db.execute('INSERT INTO dash_version_runs SELECT ?,month,run_id FROM dash_version_runs WHERE version_id=?',(v,pub['id']))
    return v


def _num(value, context):
    if isinstance(value,bool):raise ValueError(f'{context}: ожидается число')
    if value is None or (isinstance(value,str) and not value.strip()):return None
    s=str(value).replace('\xa0','').replace(' ','').replace(',','.').replace('−','-')
    try:n=Decimal(s)
    except InvalidOperation:raise ValueError(f'{context}: некорректное число {value!r}')
    if not n.is_finite():raise ValueError(f'{context}: бесконечное значение')
    return n


def _year(raw):
    try:y=int(raw)
    except (ValueError,TypeError):raise ValueError('Укажите год в ячейке B2 шаблона')
    if y<2020 or y>2100:raise ValueError('Год должен находиться в диапазоне 2020–2100')
    return y


def import_metrics(path,filename,actor):
    book=load_workbook(path,read_only=True,data_only=True)
    try:
        ws=book['Показатели'] if 'Показатели' in book else book.active
        year=_year(ws['B2'].value)
        headers=[engine.normalize_header(ws.cell(5,j).value) for j in range(1,15)]
        if headers[:2]!=['показатель','сценарий'] or [x.casefold() for x in MONTHS]!=headers[2:]:
            raise ValueError('Шапка должна содержать «Показатель», «Сценарий» и месяцы с января по декабрь в строке 5')
        names={engine.normalize_header(label):key for key,(label,_) in METRICS.items()}
        parsed={};rows_seen=set();errors=[]
        for rown,row in enumerate(ws.iter_rows(min_row=6,max_col=14,values_only=True),6):
            title=engine.normalize_header(row[0]);scenario=engine.normalize_header(row[1])
            if not title and not scenario and not any(x is not None for x in row[2:]):continue
            if not title or title not in names:
                errors.append(f'Строка {rown}: неизвестный показатель {row[0]!r}');continue
            if scenario not in ('бп','факт'):
                errors.append(f'Строка {rown}: сценарий должен быть БП или Факт');continue
            key=names[title];sc='plan' if scenario=='бп' else 'fact'
            if (key,sc) in rows_seen:
                errors.append(f'Строка {rown}: дублирование {row[0]} / {row[1]}');continue
            rows_seen.add((key,sc))
            for month,raw in enumerate(row[2:],1):
                if raw is None or (isinstance(raw,str) and not raw.strip()):continue
                try:val=_num(raw,f'Строка {rown}, {MONTHS[month-1]}')
                except ValueError as e:errors.append(str(e));continue
                if key not in MONEY and (val<0 or val>100):
                    errors.append(f'Строка {rown}: COR/УПР указывается числом от 0 до 100, например 2,5');continue
                parsed[(year,key,sc,month)]=float(val)
        if errors:raise ValueError('Ошибки Excel: '+'; '.join(errors[:15]))
        if not parsed:raise ValueError('В файле нет заполненных месячных значений')
    finally:book.close()
    with engine.connect() as db:
        version=_draft(db,actor)
        changes=[]
        for (y,metric,sc,month),val in parsed.items():
            old=db.execute('SELECT value FROM dash_metrics WHERE version_id=? AND year=? AND metric=? AND scenario=? AND month=?',
                           (version,y,metric,sc,month)).fetchone()
            if old is None or abs(old['value']-val)>1e-9:
                changes.append({'metric':METRICS[metric][0],'scenario':sc,'month':month,'old':old['value'] if old else None,'new':val})
            db.execute('INSERT INTO dash_metrics VALUES(?,?,?,?,?,?) ON CONFLICT(version_id,year,metric,scenario,month) DO UPDATE SET value=excluded.value',
                       (version,y,metric,sc,month,val))
        db.execute('UPDATE dash_versions SET source_name=? WHERE id=?',(filename,version))
        _audit(db,actor,'metrics_import',{'year':year,'count':len(parsed),'changed':len(changes),'filename':filename})
    return {'draft_id':version,'year':year,'values':len(parsed),'changed':len(changes),'preview':changes[:60]}


def _asof(date):
    try:d=dt.date.fromisoformat(date)
    except (ValueError,TypeError):raise ValueError('Дата портфеля должна быть в формате ГГГГ-ММ-ДД')
    if d.day!=1:raise ValueError('Фактический портфель должен быть на 1-е число месяца')
    return d.isoformat()


def _seg(s):
    s=engine.normalize_header(s)
    if s.startswith('крупнейш'):return 'Крупнейший'
    if s.startswith('крупн'):return 'Крупный'
    if s.startswith('средн'):return 'Средний'
    return s


def _money_cents(value):
    return int((Decimal(str(value))*100).quantize(Decimal('1'),rounding=ROUND_HALF_UP))


def _decround(value):
    return value.quantize(Decimal('.01'),rounding=ROUND_HALF_UP)


def _days(value, field):
    if value is None or str(value).strip()=='':return 0
    amount=_num(value,field)
    if amount is None or amount<0 or amount!=amount.to_integral_value():
        raise ValueError(f'{field}: дни просрочки должны быть целым неотрицательным числом')
    return int(amount)


def _position_pairs(db,start_id,end_id):
    """Merge two sorted SQLite cursors without materializing whole portfolios."""
    left=iter(db.execute('SELECT * FROM dash_positions WHERE snapshot_id=? ORDER BY key',(start_id,)))
    right=iter(db.execute('SELECT * FROM dash_positions WHERE snapshot_id=? ORDER BY key',(end_id,)))
    a=next(left,None);b=next(right,None)
    while a is not None or b is not None:
        if b is None or (a is not None and a['key']<b['key']):
            yield a['key'],dict(a),None
            a=next(left,None)
        elif a is None or b['key']<a['key']:
            yield b['key'],None,dict(b)
            b=next(right,None)
        else:
            yield a['key'],dict(a),dict(b)
            a=next(left,None);b=next(right,None)


def _pairs_by_contract(pairs):
    """Group adjacent balance/UO keys of the same client-contract-currency."""
    group=[];base=None
    for item in pairs:
        groupkey=item[0].rsplit('|',1)[0]
        if base is not None and base!=groupkey:
            yield group
            group=[]
        group.append(item);base=groupkey
    if group:yield group


def _contract_identity(key):
    """UNP and normalized contract number, shared by credit and UO currencies."""
    return key.rsplit('|',2)[0]


def _transfer_by_side(group):
    """Detect drawn principal in source currency, excluding FX revaluation."""
    def native(pos):
        return fact_factor.d(pos['debt_byn'])/fact_factor.d(pos['fx']) if pos else Decimal(0)
    old={};new={}
    for _,a,b in group:
        for source,dest in ((a,old),(b,new)):
            if source:dest[source['side']]=dest.get(source['side'],Decimal(0))+native(source)
    b_delta=new.get('баланс',Decimal(0))-old.get('баланс',Decimal(0))
    u_delta=new.get('внебаланс',Decimal(0))-old.get('внебаланс',Decimal(0))
    draws={}
    if b_delta>0 and u_delta<0:draws['баланс']=min(b_delta,-u_delta)
    if b_delta<0 and u_delta>0:draws['внебаланс']=min(-b_delta,u_delta)
    return draws


def _same_group(pos):
    return pos is not None and pos['segment'] in ('Крупнейший','Крупный','Средний')


def _calculate_factor_row(old,new,old_dpd=None,new_dpd=None,drawn_byn=0):
    """Fact-only decomposition with exact four-factor reconciliation in BYN kopecks."""
    if old_dpd is None:old_dpd=int(old.get('dpd',0)) if old else 0
    if new_dpd is None:new_dpd=int(new.get('dpd',0)) if new else 0
    return fact_factor.decompose(old,new,old_dpd,new_dpd,drawn_byn)


def _build_run(db,start_id,end_id):
    begin_row=db.execute('SELECT asof,methodology_version FROM dash_portfolios WHERE id=?',(start_id,)).fetchone()
    begin=begin_row['asof']
    end_row=db.execute('SELECT asof,methodology_version FROM dash_portfolios WHERE id=?',(end_id,)).fetchone()
    end=end_row['asof']
    if begin_row['methodology_version']<2 or end_row['methodology_version']<2:
        raise ValueError('В снимках прежнего формата нет сохранённой просрочки и ПОК/СПОК')
    if end!=_next_month(begin):raise ValueError('Для факторного анализа требуются два последовательных портфеля')
    methodology=min(begin_row['methodology_version'],end_row['methodology_version'],7)
    run=db.execute('INSERT INTO dash_factor_runs(start_id,end_id,month,created,rows,errors,totals_json,methodology_version) VALUES(?,?,?,?,0,0,\'{}\',?)',
                   (start_id,end_id,begin[:7],engine.now(),methodology)).lastrowid
    totals={k:0 for k in FACTOR_KEYS};total=0;count=0;errors=0
    # Normalize linked UO rows to the same POK status as their credit contract.
    pok_contracts=[{_contract_identity(r['key']) for r in db.execute(
        'SELECT key FROM dash_positions WHERE snapshot_id=? AND poc=1',(snapshot,))}
        for snapshot in (start_id,end_id)]
    for snapshot,index in ((start_id,0),(end_id,1)):
        for r in db.execute('SELECT key,spok,poc FROM dash_positions WHERE snapshot_id=?',(snapshot,)):
            if not r['poc'] and not r['spok'] and _contract_identity(r['key']) in pok_contracts[index]:
                db.execute('UPDATE dash_positions SET poc=1 WHERE snapshot_id=? AND key=?',(snapshot,r['key']))

    # Every current contract contributes its raw Day OD to the client's maximum.
    # An exit is attached to a contract identity, not permanently to the UNP:
    # a newly issued POK can enter POK if the client's current maximum is below 31.
    client_days={snapshot:{r['unp']:r['days'] for r in db.execute(
        'SELECT unp,MAX(dpd) days FROM dash_positions WHERE snapshot_id=? GROUP BY unp',(snapshot,))}
        for snapshot in (start_id,end_id)}
    client_debts={snapshot:{r['unp']:r['debt'] for r in db.execute(
        'SELECT unp,SUM(debt_byn) debt FROM dash_positions WHERE snapshot_id=? GROUP BY unp',(snapshot,))}
        for snapshot in (start_id,end_id)}
    for snapshot,date in ((start_id,begin),(end_id,end)):
        value=db.execute('SELECT amount_byn FROM dash_base_values WHERE valid_from<=? ORDER BY valid_from DESC LIMIT 1',(date,)).fetchone()['amount_byn']
        prior_pok={r['unp']+'|'+_contract_identity(r['key']) for r in db.execute(
            'SELECT unp,key FROM dash_positions WHERE snapshot_id=? AND poc=1',(start_id,))} if snapshot==end_id else set()
        for r in db.execute('SELECT unp,key,poc FROM dash_positions WHERE snapshot_id=?',(snapshot,)):
            breached=(client_days[snapshot].get(r['unp'],0)>=31 or
                      client_debts[snapshot].get(r['unp'],0)>=50000*value)
            if breached and (r['poc'] or r['unp']+'|'+_contract_identity(r['key']) in prior_pok):
                db.execute('''INSERT INTO dash_pok_exit_contracts(unp,contract_identity,exited_on)
                    VALUES(?,?,?) ON CONFLICT(unp,contract_identity) DO UPDATE SET
                    exited_on=MIN(exited_on,excluded.exited_on)''',
                    (r['unp'],_contract_identity(r['key']),date))
        for r in db.execute('SELECT * FROM dash_positions WHERE snapshot_id=?',(snapshot,)):
            exit_row=db.execute('SELECT exited_on FROM dash_pok_exit_contracts WHERE unp=? AND contract_identity=?',
                (r['unp'],_contract_identity(r['key']))).fetchone()
            if not exit_row or exit_row['exited_on']>date or r['written_off']:continue
            from dataclasses import replace
            c=replace(fact_factor.criteria(r),poc=False)
            base,_,_=fact_factor.classify(c)
            floor=fact_factor.delinquency_floor(c,client_days[snapshot].get(r['unp'],0))
            target=str(max(base if isinstance(base,int) else 0,floor))
            db.execute('UPDATE dash_positions SET poc=0,poc_exited=1,gr=? WHERE snapshot_id=? AND key=?',
                (target,snapshot,r['key']))

    old_days={r['unp']:r['days'] for r in db.execute(
        'SELECT unp,MAX(dpd) days FROM dash_positions WHERE snapshot_id=? AND poc=0 GROUP BY unp',(start_id,))}
    new_days={r['unp']:r['days'] for r in db.execute(
        'SELECT unp,MAX(dpd) days FROM dash_positions WHERE snapshot_id=? AND poc=0 GROUP BY unp',(end_id,))}
    old_pok_days={r['unp']:r['days'] for r in db.execute(
        'SELECT unp,MAX(dpd) days FROM dash_positions WHERE snapshot_id=? AND poc=1 GROUP BY unp',(start_id,))}
    new_pok_days={r['unp']:r['days'] for r in db.execute(
        'SELECT unp,MAX(dpd) days FROM dash_positions WHERE snapshot_id=? AND poc=1 GROUP BY unp',(end_id,))}
    # Match linked active/UO portions by client, contract, currency before
    # classifying new high-risk active drawdowns.
    for group in _pairs_by_contract(_position_pairs(db,start_id,end_id)):
        transfers=_transfer_by_side(group)
        for key,old,new in group:
            if not (_same_group(old) or _same_group(new)):continue
            try:
                p=new or old
                unp=p['unp']
                moved=transfers.get(p['side'],Decimal(0))*Decimal(str(new['fx'])) if new and p['side'] in transfers else Decimal(0)
                old_days_for_row=(old_pok_days if old and old['poc'] else old_days).get(unp,0)
                new_days_for_row=(new_pok_days if new and new['poc'] else new_days).get(unp,0)
                r=_calculate_factor_row(old,new,old_days_for_row,new_days_for_row,moved)
            except (ValueError,MethodologyError) as e:
                errors+=1
                if errors<=2000:db.execute('INSERT INTO dash_factor_errors VALUES(?,?,?)',(run,key,str(e)))
                continue
            if r is None:continue
            p=new or old;count+=1
            db.execute('INSERT INTO dash_factor_rows VALUES(?,?,?,?,?,?,?,?,?,?,?,?)',
                       (run,key,p['unp'],p['client'],p['contract'],p['segment'],r['movement'],r['financial_state'],
                        r['security_effect'],r['revaluation'],r['expenses'],r['explanation']))
            for subkey,amount in r['subfactors'].items():
                db.execute('INSERT INTO dash_factor_subrows VALUES(?,?,?,?)',(run,key,subkey,amount))
            total+=r['expenses']
            for k in FACTOR_KEYS:totals[k]+=r[k]
    db.execute('UPDATE dash_factor_runs SET rows=?,errors=?,amount_cents=?,totals_json=? WHERE id=?',
               (count,errors,total,json.dumps(totals),run))
    return run,{'rows':count,'errors':errors,'amount_cents':total,'totals_cents':totals,'month':begin[:7],
                'methodology_version':methodology}


def recalculate_saved(actor, progress=None):
    """Rebuild a draft using normalized saved snapshots; never touch published runs."""
    initialize()
    with engine.connect() as db:
        snapshots={r['asof']:dict(r) for r in db.execute(
            'SELECT id,asof,methodology_version FROM dash_portfolios ORDER BY asof,id')}
        if len(snapshots)<2:raise ValueError('Нужны сохранённые снимки хотя бы на две соседние даты')
        draft=_draft(db,actor)
        db.execute('DELETE FROM dash_version_runs WHERE version_id=?',(draft,))
        db.execute('DELETE FROM dash_factor_pending WHERE version_id=?',(draft,))
        # Rebuild the permanent POK exit history from the saved snapshots in
        # chronological order, so results do not depend on previous previews.
        db.execute('DELETE FROM dash_pok_exits')
        db.execute('DELETE FROM dash_pok_exit_contracts')
        # Restore source POK markers from previous draft calculations before
        # reconstructing contract exits from the earliest saved date.
        db.execute("""UPDATE dash_positions SET poc=1,poc_exited=0,
            gr=CASE WHEN side='внебаланс' THEN '1' ELSE 'ПОК' END
            WHERE poc_exited=1""")
        runs=[];legacy=[];legacy_micro=[];pending=[]
        for date,first in sorted(snapshots.items()):
            second=snapshots.get(_next_month(date))
            if second is None:continue
            month=date[:7]
            if progress:progress(f'Сохранённые портфели: {month} · {len(runs)+len(pending)+1}')
            if min(first['methodology_version'],second['methodology_version'])<2:
                reason='Снимок до версии 1.4 не содержит ни просрочки, ни ПОК/СПОК'
                db.execute('INSERT INTO dash_factor_pending VALUES(?,?,?)',(draft,month,reason))
                pending.append(month)
                continue
            runid,info=_build_run(db,first['id'],second['id'])
            db.execute('INSERT INTO dash_version_runs VALUES(?,?,?)',(draft,month,runid))
            runs.append({'id':runid,**info})
            if info['methodology_version']<3:legacy.append(month)
            elif info['methodology_version']<5:legacy_micro.append(month)
        if not runs and not pending:raise ValueError('Среди сохранённых портфелей нет соседних дат')
        _audit(db,actor,'recalculate_saved',{'draft':draft,'months':len(runs),'legacy_months':legacy,'legacy_micro_months':legacy_micro,'pending':pending})
        return {'draft_id':draft,'runs':runs,'legacy_months':legacy,'legacy_micro_months':legacy_micro,'pending':pending}


def _next_month(asof):
    y,m=map(int,asof[:7].split('-'))
    if m==12:y+=1;m=1
    else:m+=1
    return f'{y:04d}-{m:02d}-01'


def import_portfolio(path,filename,asof,actor):
    """Atomic streaming import for up to hundreds of thousands of XLSX records."""
    asof=_asof(asof)
    book=load_workbook(path,read_only=True,data_only=True)
    try:
        ws,headrow,header=engine.find_sheet_header(book,['УНП','Номер договора','Тип операции','Код валюты','Сегмент','Резерв факт','% рез'])
        h={engine.normalize_header(v):j for j,v in enumerate(header) if v is not None}
        # Source workbooks use both typographic spellings for this column.
        if 'max-day od' not in h and 'max day od' in h:
            h['max-day od']=h['max day od']
        required=['Задолженность, тыс BYN','Курс','ГР','НИ','ПФН','НВВ','Рестра','Обеспеченность','Day OD','ПОК/СПОК']
        for item in required:
            if engine.normalize_header(item) not in h:raise ValueError('Нет столбца фактического портфеля: '+item)
        count=0;medium=0;positions=0
        with engine.connect() as db:
            snap=db.execute('INSERT INTO dash_portfolios(asof,created,original_name,created_by,row_count,position_count,methodology_version) VALUES(?,?,?,?,0,0,7)',
                            (asof,engine.now(),filename,actor)).lastrowid
            for lineno,row in enumerate(ws.iter_rows(min_row=headrow+1,values_only=True),headrow+1):
                unp=engine.normalize_unp(engine.get(row,h,'УНП'))
                contract=str(engine.get(row,h,'Номер договора') or '').strip()
                if not unp or not contract:continue
                try:
                    ccy=currency(engine.get(row,h,'Код валюты'))
                    operation=str(engine.get(row,h,'Тип операции') or '').strip()
                    side=side_for_operation(operation)
                    key=match_key(unp,contract,ccy,side)
                    seg=_seg(engine.get(row,h,'Сегмент'))
                    if not seg:raise ValueError('Не заполнен сегмент')
                    debt=_num(engine.get(row,h,'Задолженность, тыс BYN'),'задолженность')
                    reserve=_num(engine.get(row,h,'Резерв факт'),'резерв факт')
                    fx=_num(engine.get(row,h,'Курс'),'курс')
                    if fx is None or fx<=0:raise ValueError('Курс должен быть положительным')
                    if debt is None or debt<0:raise ValueError('Недопустимая задолженность')
                    gr=str(engine.get(row,h,'ГР') or '').strip()
                    written_off=int(gr.strip().casefold()=='списан')
                    poc_spok=str(engine.get(row,h,'ПОК/СПОК') or '').strip().upper()
                    spok=int('СПОК' in poc_spok)
                    poc=int('ПОК' in poc_spok and not spok or gr_value(gr)=='ПОК')
                    dpd=_days(engine.get(row,h,'Day OD'),'Day OD')
                    debt_byn=debt*1000
                    if written_off:
                        # Source ledger reserves are empty for written-off loans; for
                        # *factor analysis only* reserve is taken as 100% of OD.
                        if reserve is not None and reserve<0:raise ValueError('Некорректен резерв факт')
                        reserve_byn=debt_byn if reserve is None or reserve==0 else reserve*1000
                        rate=100.0
                    else:
                        if reserve is None or reserve<0:raise ValueError('Не заполнен/некорректен резерв факт')
                        rate=rate_percent(engine.get(row,h,'% рез'))
                        if rate is None:raise ValueError('Не заполнен % резервирования')
                        reserve_byn=reserve*1000
                    credit_type=str(engine.get(row,h,'Вид кредита') or '').lstrip().casefold()
                    micro=int(credit_type.startswith('микро'))
                    raw_security=engine.get(row,h,'Обеспеченность')
                    unknown=(raw_security not in (None,'') and
                             normal_security(raw_security,True)=='micro_unknown')
                    previous_guarantee=False
                    if unknown and not micro and not credit_type.startswith('исполнительные обязательства'):
                        previous=db.execute('''SELECT operation FROM dash_positions WHERE snapshot_id=(
                            SELECT id FROM dash_portfolios WHERE asof<? ORDER BY asof DESC,id DESC LIMIT 1)
                            AND unp=? AND contract=? AND ccy=?''',(asof,unp,contract,ccy)).fetchall()
                        previous_guarantee=any('гарант' in str(x['operation']).casefold() or
                                               'аккредитив' in str(x['operation']).casefold() for x in previous)
                    if unknown and not (micro or credit_type.startswith('исполнительные обязательства') or previous_guarantee):
                        raise ValueError('«Обеспеченный (не указан)» допустим для микрокредита, исполнительных обязательств или договора, ранее бывшего гарантией/аккредитивом')
                    security=('Обеспеченный' if unknown and not micro else
                              canonical_security(raw_security,bool(micro)) if raw_security not in (None,'') or not (poc or written_off)
                              else '')
                    p={'key':key,'unp':unp,'contract':contract,'client':str(engine.get(row,h,'Клиент') or ''),
                       'ccy':ccy,'side':side,'operation':operation,'segment':seg,
                       'debt_byn':float(debt_byn),'reserve_byn':float(reserve_byn),'fx':float(fx),
                       'rate':rate,'gr':gr,'ni':flag(engine.get(row,h,'НИ')),
                       'pfn':flag(engine.get(row,h,'ПФН')),'nvv':flag(engine.get(row,h,'НВВ')),
                       'restra':str(engine.get(row,h,'Рестра') or ''),'security':security,
                       'micro':micro,
                       'poc':poc,'dpd':dpd,'spok':spok,'written_off':written_off}
                    prior=db.execute('SELECT * FROM dash_positions WHERE snapshot_id=? AND key=?',(snap,key)).fetchone()
                    if prior:
                        attrs=('unp','contract','ccy','side','operation','segment','rate','gr','ni','pfn','nvv','restra','security','micro','poc','fx','dpd','spok','written_off')
                        if any(prior[k]!=p[k] for k in attrs):
                            raise ValueError('Различные критерии или сегменты в строках одного договорного ключа: '+key)
                        db.execute('UPDATE dash_positions SET debt_byn=debt_byn+?,reserve_byn=reserve_byn+? WHERE snapshot_id=? AND key=?',
                                   (p['debt_byn'],p['reserve_byn'],snap,key))
                    else:
                        db.execute('''INSERT INTO dash_positions(
                           snapshot_id,key,unp,client,contract,ccy,side,operation,segment,
                           debt_byn,reserve_byn,fx,rate,gr,ni,pfn,nvv,restra,security,micro,poc,dpd,spok,written_off)
                           VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)''',
                           (snap,p['key'],p['unp'],p['client'],p['contract'],p['ccy'],p['side'],p['operation'],p['segment'],
                            p['debt_byn'],p['reserve_byn'],p['fx'],p['rate'],p['gr'],p['ni'],p['pfn'],p['nvv'],
                            p['restra'],p['security'],p['micro'],p['poc'],p['dpd'],p['spok'],p['written_off']))
                        positions+=1
                    count+=1
                    if seg in ('Крупнейший','Крупный','Средний'):medium+=1
                except (ValueError,MethodologyError) as e:
                    raise ValueError(f'Портфель не принят, строка {lineno}: {e}') from e
            if not count:raise ValueError('Не обнаружено договоров в файле')
            if not medium:raise ValueError('Нет ни одной позиции сегментов Крупнейший / Крупный / Средний: проверьте «Сегмент»')
            # A credit can carry the POK marker while its linked UO has numeric
            # GR 1. Determine the contract status before applying the ordinary
            # delinquency floor to any row of that contract.
            pok_contracts={_contract_identity(r['key']) for r in db.execute(
                'SELECT key FROM dash_positions WHERE snapshot_id=? AND poc=1',(snap,))}
            for r in db.execute('SELECT key,poc,spok FROM dash_positions WHERE snapshot_id=?',(snap,)):
                if not r['poc'] and not r['spok'] and _contract_identity(r['key']) in pok_contracts:
                    db.execute('UPDATE dash_positions SET poc=1 WHERE snapshot_id=? AND key=?',(snap,r['key']))
            # Validate micro risk by the client's ordinary-contract maximum,
            # including delinquency on another contract of the same client.
            ordinary_days={r['unp']:r['days'] for r in db.execute('''SELECT unp,MAX(dpd) days FROM dash_positions
                WHERE snapshot_id=? AND poc=0 GROUP BY unp''',(snap,))}
            for position in db.execute('SELECT * FROM dash_positions WHERE snapshot_id=? AND micro=1 AND poc=0 AND written_off=0',(snap,)):
                floor=fact_factor.delinquency_floor(fact_factor.criteria(position),ordinary_days.get(position['unp'],0))
                gr_numeric=gr_value(position['gr'])
                if floor and isinstance(gr_numeric,int) and gr_numeric<floor:
                    raise ValueError(f'Портфель не принят, микрокредит {position["contract"]}: {ordinary_days[position["unp"]]} дней Day OD требует не ниже {floor} ГР; указана {gr_numeric} ГР')
            db.execute('UPDATE dash_portfolios SET row_count=?,position_count=? WHERE id=?',(count,positions,snap))
            draft=_draft(db,actor)
            runs=[]
            for begin in (date_before(asof),asof):
                end=_next_month(begin)
                old=db.execute('SELECT id FROM dash_portfolios WHERE asof=? ORDER BY id DESC LIMIT 1',(begin,)).fetchone()
                nxt=db.execute('SELECT id FROM dash_portfolios WHERE asof=? ORDER BY id DESC LIMIT 1',(end,)).fetchone()
                if not old or not nxt:continue
                old_version=db.execute('SELECT methodology_version FROM dash_portfolios WHERE id=?',(old['id'],)).fetchone()['methodology_version']
                next_version=db.execute('SELECT methodology_version FROM dash_portfolios WHERE id=?',(nxt['id'],)).fetchone()['methodology_version']
                if old_version<2 or next_version<2:
                    # Keep a newly imported snapshot and request its legacy
                    # neighbour, rather than rolling back and making chronological
                    # re-import impossible. Never reuse a legacy computed run.
                    db.execute('DELETE FROM dash_version_runs WHERE version_id=? AND month=?',(draft,begin[:7]))
                    db.execute('INSERT INTO dash_factor_pending VALUES(?,?,?) ON CONFLICT(version_id,month) DO UPDATE SET reason=excluded.reason',
                               (draft,begin[:7],'В снимке прежнего формата нет сохранённых данных о просрочке и ПОК/СПОК'))
                    continue
                db.execute('DELETE FROM dash_factor_pending WHERE version_id=? AND month=?',(draft,begin[:7]))
                exists=db.execute('SELECT id FROM dash_factor_runs WHERE start_id=? AND end_id=? AND methodology_version>=7 ORDER BY id DESC LIMIT 1',(old['id'],nxt['id'])).fetchone()
                if exists:
                    runid=exists['id'];rr=db.execute('SELECT * FROM dash_factor_runs WHERE id=?',(runid,)).fetchone()
                    info={'rows':rr['rows'],'errors':rr['errors'],'amount_cents':rr['amount_cents'],'month':begin[:7]}
                else:runid,info=_build_run(db,old['id'],nxt['id'])
                db.execute('INSERT INTO dash_version_runs VALUES(?,?,?) ON CONFLICT(version_id,month) DO UPDATE SET run_id=excluded.run_id',
                           (draft,begin[:7],runid))
                runs.append({'id':runid,**info})
            _audit(db,actor,'portfolio_import',{'asof':asof,'name':filename,'snapshot_id':snap,'runs':runs})
        return {'snapshot_id':snap,'asof':asof,'rows':count,'positions':positions,'medium_rows':medium,'draft_id':draft,'runs':runs}
    finally:book.close()


def date_before(asof):
    y,m=map(int,asof[:7].split('-'))
    if m==1:y-=1;m=12
    else:m-=1
    return f'{y:04d}-{m:02d}-01'


def publish(actor,note=''):
    with engine.connect() as db:
        draft=_latest(db,'draft')
        if not draft:raise ValueError('Нет черновика для публикации')
        runs=list(db.execute('SELECT r.month,r.errors,r.methodology_version FROM dash_version_runs vr JOIN dash_factor_runs r ON r.id=vr.run_id WHERE vr.version_id=?',(draft['id'],)))
        blocked=[r['month'] for r in runs if r['errors']]
        pending=[r['month'] for r in db.execute('SELECT month FROM dash_factor_pending WHERE version_id=? ORDER BY month',(draft['id'],))]
        if pending:raise ValueError('Для публикации по новой методике повторно загрузите фактические портфели соседних месяцев: '+', '.join(pending))
        if blocked:raise ValueError('Факторный анализ не сходится по месяцам: '+', '.join(blocked)+'. Исправьте ошибки до публикации.')
        values=db.execute('SELECT COUNT(*) n FROM dash_metrics WHERE version_id=?',(draft['id'],)).fetchone()['n']
        if not values and not runs:raise ValueError('Черновик не содержит данных')
        db.execute("UPDATE dash_versions SET state='archived' WHERE state='published'")
        db.execute("UPDATE dash_versions SET state='published',published=?,note=? WHERE id=?",
                   (engine.now(),str(note)[:300],draft['id']))
        _audit(db,actor,'publish',{'version':draft['id'],'values':values,'runs':len(runs)})
        return {'version':draft['id'],'values':values,'factor_periods':len(runs),'published_at':engine.now()}


def restore(version_id,actor):
    with engine.connect() as db:
        item=db.execute("SELECT id FROM dash_versions WHERE id=? AND state IN ('published','archived')",(version_id,)).fetchone()
        if not item:raise ValueError('Версия для восстановления не найдена')
        old=_latest(db,'draft')
        if old:
            db.execute('DELETE FROM dash_metrics WHERE version_id=?',(old['id'],))
            db.execute('DELETE FROM dash_version_runs WHERE version_id=?',(old['id'],))
            db.execute('DELETE FROM dash_factor_pending WHERE version_id=?',(old['id'],))
            db.execute('DELETE FROM dash_versions WHERE id=?',(old['id'],))
        new=db.execute('INSERT INTO dash_versions(state,created,author,note) VALUES(?,?,?,?)',
                       ('draft',engine.now(),actor,f'Восстановление версии {version_id}')).lastrowid
        db.execute('INSERT INTO dash_metrics SELECT ?,year,metric,scenario,month,value FROM dash_metrics WHERE version_id=?',(new,version_id))
        db.execute('INSERT INTO dash_version_runs SELECT ?,month,run_id FROM dash_version_runs WHERE version_id=?',(new,version_id))
        _audit(db,actor,'restore_staged',{'source':version_id,'draft':new})
        return {'draft_id':new,'restored_from':version_id}


def _metric_data(db,v,year):
    result={}
    for r in db.execute('SELECT metric,scenario,month,value FROM dash_metrics WHERE version_id=? AND year=?',(v,year)):
        result.setdefault(r['metric'],{}).setdefault(r['scenario'],{})[r['month']]=r['value']
    for r in db.execute('SELECT vr.month,r.totals_json,r.amount_cents FROM dash_version_runs vr JOIN dash_factor_runs r ON r.id=vr.run_id WHERE vr.version_id=? AND substr(vr.month,1,4)=?',(v,str(year))):
        month=int(r['month'][5:7]);result.setdefault('medium_rnr',{}).setdefault('fact',{})[month]=r['amount_cents']/100_000_000
        for key,cents in json.loads(r['totals_json']).items():
            result.setdefault('factor_'+key,{}).setdefault('fact',{})[month]=cents/100_000_000
    return result


def dashboard_data(year,month,admin=False):
    year=_year(year)
    try:month=int(month)
    except (TypeError,ValueError):raise ValueError('Некорректный месяц')
    if not 1<=month<=12:raise ValueError('Месяц должен быть от 1 до 12')
    with engine.connect() as db:
        v=_latest(db,'draft') if admin else _latest(db,'published')
        if not v:return {'version':None,'year':year,'month':month,'metrics':{},'factor_names':FACTOR_LABELS,'is_draft':admin,'status':'empty'}
        src=_metric_data(db,v['id'],year)
        out={}
        for key,series in src.items():
            out[key]={}
            for sc,months in series.items():
                current=[months.get(m) for m in range(1,month+1)]
                if key in MONEY or key=='medium_rnr' or key.startswith('factor_'):
                    out[key][sc]={'series':current,'value':round(sum(current),6) if all(z is not None for z in current) else None,
                                   'monthly':True}
                else:out[key][sc]={'series':current,'value':current[-1] if current else None,'monthly':False}
        return {'version':v['id'],'created':v['created'],'published':v['published'],'year':year,'month':month,
                'is_draft':admin,'status':v['state'],'metrics':out,'factor_names':FACTOR_LABELS}


def admin_state():
    with engine.connect() as db:
        versions=[dict(r) for r in db.execute('SELECT id,state,created,published,author,note,source_name FROM dash_versions ORDER BY id DESC LIMIT 40')]
        ports=[dict(r) for r in db.execute('SELECT id,asof,created,original_name,row_count,position_count FROM dash_portfolios ORDER BY asof DESC,id DESC LIMIT 50')]
        draft=_latest(db,'draft');pub=_latest(db,'published')
        runs=[]
        if draft:
            runs=[dict(r) for r in db.execute('SELECT vr.month,r.id,r.rows,r.errors,r.amount_cents,r.methodology_version FROM dash_version_runs vr JOIN dash_factor_runs r ON vr.run_id=r.id WHERE vr.version_id=? ORDER BY vr.month',(draft['id'],))]
        pending=[dict(x) for x in db.execute('SELECT month,reason FROM dash_factor_pending WHERE version_id=? ORDER BY month',(draft['id'],))] if draft else []
        base_values=[dict(r) for r in db.execute('SELECT valid_from,amount_byn FROM dash_base_values ORDER BY valid_from')]
        return {'versions':versions,'portfolios':ports,'runs':runs,'pending':pending,'base_values':base_values,'draft_id':draft['id'] if draft else None,'published_id':pub['id'] if pub else None}


def set_base_value(valid_from,amount,actor):
    initialize()
    try:valid_from=dt.date.fromisoformat(valid_from).isoformat()
    except (ValueError,TypeError):raise ValueError('Дата действия должна быть в формате ГГГГ-ММ-ДД')
    value=_num(amount,'базовая величина')
    if value is None or value<=0:raise ValueError('Базовая величина должна быть положительной')
    with engine.connect() as db:
        db.execute('INSERT INTO dash_base_values(valid_from,amount_byn) VALUES(?,?) ON CONFLICT(valid_from) DO UPDATE SET amount_byn=excluded.amount_byn',(valid_from,value))
        _audit(db,actor,'set_base_value',{'date':valid_from,'amount_byn':value})
    return {'valid_from':valid_from,'amount_byn':value,'recalculation_required':True}


def factor_detail(year,month,search='',page=1,limit=50):
    """Contract-level YTD factor detail for the published snapshot, not just month-end."""
    year=_year(year);month=int(month);page=max(1,int(page));limit=max(1,min(int(limit),100))
    if not 1<=month<=12:raise ValueError('Некорректный месяц')
    ym=f'{year:04d}-{month:02d}'
    with engine.connect() as db:
        published=_latest(db,'published')
        if not published:return {'total':0,'rows':[],'page':page,'limit':limit}
        runs=list(db.execute('SELECT month,run_id FROM dash_version_runs WHERE version_id=? AND month BETWEEN ? AND ? ORDER BY month',
                 (published['id'],f'{year:04d}-01',ym)))
        if len(runs)!=month or any(row['month']!=f'{year:04d}-{i:02d}' for i,row in enumerate(runs,1)):
            return {'total':0,'rows':[],'page':page,'limit':limit,'error':'Накопленный факторный анализ не полон за выбранный период'}
        ids=[row['run_id'] for row in runs]
        placeholders=','.join('?' for _ in ids)
        pattern='%'+search.strip()+'%'
        where=f'WHERE run_id IN ({placeholders}) AND (unp LIKE ? OR client LIKE ? OR contract LIKE ?)'
        args=(*ids,pattern,pattern,pattern)
        count=db.execute('SELECT COUNT(*) n FROM (SELECT key FROM dash_factor_rows '+where+' GROUP BY key)',args).fetchone()['n']
        sql=('SELECT key,MAX(unp) unp,MAX(client) client,MAX(contract) contract,MAX(segment) segment,'
             'SUM(movement_cents) movement_cents,SUM(financial_cents) financial_cents,'
             'SUM(security_cents) security_cents,SUM(fx_cents) fx_cents,'
             'SUM(expenses_cents) expenses_cents FROM dash_factor_rows '+where+
             ' GROUP BY key ORDER BY ABS(SUM(expenses_cents)) DESC LIMIT ? OFFSET ?')
        rows=[dict(r) for r in db.execute(sql,(*args,limit,(page-1)*limit))]
        for row in rows:
            for k in ('movement_cents','financial_cents','security_cents','fx_cents','expenses_cents'):
                row[k.removesuffix('_cents')]=row.pop(k)/100_000_000
        return {'total':count,'rows':rows,'page':page,'limit':limit}


def factor_errors(run_id,limit=100):
    with engine.connect() as db:
        r=db.execute('SELECT month,errors,rows FROM dash_factor_runs WHERE id=?',(run_id,)).fetchone()
        if not r:raise ValueError('Расчёт не найден')
        return {'month':r['month'],'errors':r['errors'],'rows':r['rows'],
                'items':[dict(x) for x in db.execute('SELECT key,description FROM dash_factor_errors WHERE run_id=? LIMIT ?', (run_id,max(1,min(int(limit),200))))]}


def export_factor_excel(year,month,output_path,admin=False):
    """Export YTD client summaries and per-month contract subfactors to an XLSX.

    All output monetary values are million BYN; 8 decimal places preserve
    one kopeck (0.01 BYN) without floating-point reporting loss.
    """
    from openpyxl import Workbook
    from openpyxl.cell import WriteOnlyCell
    from openpyxl.styles import PatternFill, Font, Alignment
    year=_year(year);month=int(month)
    if month<1 or month>12:raise ValueError('Некорректный месяц')
    with engine.connect() as db:
        version=_latest(db,'draft' if admin else 'published')
        if not version:raise ValueError('Нет доступной версии факторного анализа')
        runs=list(db.execute('''SELECT r.id,r.month,r.start_id,r.end_id,r.errors,r.methodology_version
            FROM dash_version_runs vr JOIN dash_factor_runs r ON vr.run_id=r.id
            WHERE vr.version_id=? AND r.month BETWEEN ? AND ? ORDER BY r.month''',
            (version['id'],f'{year:04d}-01',f'{year:04d}-{month:02d}')))
        if len(runs)!=month or any(r['month']!=f'{year:04d}-{i:02d}' for i,r in enumerate(runs,1)):
            raise ValueError('Нет непрерывного фактического факторного анализа с января по выбранный месяц')
        if any(r['errors'] for r in runs):raise ValueError('Нельзя выгружать несошедшийся факторный анализ')
        if any(r['methodology_version']<2 for r in runs):
            raise ValueError('Для детализации подфакторов необходимо повторно загрузить исходные портфели по новой методике')
        ids=[r['id'] for r in runs];marks=','.join('?' for _ in ids)
        keys=list(fact_factor.SUB_LABELS)
        wb=Workbook(write_only=True)
        sw=wb.create_sheet('Свод_клиенты')
        dw=wb.create_sheet('Договоры_помесячно')
        def header(ws,titles):
            styled=[]
            for title in titles:
                c=WriteOnlyCell(ws,value=title)
                c.font=Font(bold=True,color='FFFFFF')
                c.fill=PatternFill('solid',fgColor='19355A')
                c.alignment=Alignment(wrap_text=True)
                styled.append(c)
            ws.append(styled)
        def money(c):return round(int(c)/100_000_000,8) if c is not None else None
        head=['УНП','Клиент','РнР','Движение КП','Фин. состояние','Обеспечение','Переоценка']+[fact_factor.SUB_LABELS[k] for k in keys]
        header(sw,head)
        totals={}
        for r in db.execute(f'''SELECT unp,MAX(client) client,
            SUM(expenses_cents) expenses,SUM(movement_cents) movement,
            SUM(financial_cents) financial,SUM(security_cents) security,SUM(fx_cents) fx
            FROM dash_factor_rows WHERE run_id IN ({marks}) GROUP BY unp''',ids):
            totals[r['unp']]={'name':r['client'],'factors':(r['expenses'],r['movement'],r['financial'],r['security'],r['fx']), 'subs':{}}
        for r in db.execute(f'''SELECT f.unp,s.subfactor,SUM(s.amount_cents) amount
            FROM dash_factor_subrows s JOIN dash_factor_rows f ON f.run_id=s.run_id AND f.key=s.key
            WHERE s.run_id IN ({marks}) GROUP BY f.unp,s.subfactor''',ids):
            totals[r['unp']]['subs'][r['subfactor']]=r['amount']
        for unp,t in sorted(totals.items()):
            sw.append([unp,t['name'],*[money(x) for x in t['factors']],*[money(t['subs'].get(k,0)) for k in keys]])
        del totals

        detail_head=['Месяц','УНП','Клиент','Договор','Сегмент',
          'ГР было','ГР стало','Максимум Day OD группы договора был','Максимум Day OD группы договора стал',
          'ОД было, млн BYN','ОД стало, млн BYN',
          'Резерв был, млн BYN','Резерв стал, млн BYN','Ставка была, %','Ставка стала, %',
          'РнР, млн BYN','Движение КП','Фин. состояние','Обеспечение','Переоценка',
          'Объяснение']+[fact_factor.SUB_LABELS[k] for k in keys]
        header(dw,detail_head)
        for r in runs:
            def days_by_group(snapshot_id):
                result={'ordinary':{},'poc':{}}
                for x in db.execute('''SELECT unp,MAX(dpd) days,
                    CASE WHEN poc=1 THEN 'poc' ELSE 'ordinary' END grp
                    FROM dash_positions WHERE snapshot_id=? GROUP BY unp,grp''',(snapshot_id,)):
                    result[x['grp']][x['unp']]=x['days']
                return result
            old_dpd=days_by_group(r['start_id'])
            new_dpd=days_by_group(r['end_id'])
            subset=iter(db.execute('SELECT key,subfactor,amount_cents FROM dash_factor_subrows WHERE run_id=? ORDER BY key,subfactor',(r['id'],)))
            nxt=next(subset,None)
            sql='''SELECT f.*,a.gr gr_old,b.gr gr_new,a.poc poc_old,b.poc poc_new,
                a.poc_exited exited_old,b.poc_exited exited_new,
                a.debt_byn debt_old,b.debt_byn debt_new,
                a.reserve_byn reserve_old,b.reserve_byn reserve_new,a.rate rate_old,b.rate rate_new
                FROM dash_factor_rows f
                LEFT JOIN dash_positions a ON a.snapshot_id=? AND a.key=f.key
                LEFT JOIN dash_positions b ON b.snapshot_id=? AND b.key=f.key
                WHERE f.run_id=? ORDER BY f.key'''
            for rec in db.execute(sql,(r['start_id'],r['end_id'],r['id'])):
                old_group='poc' if rec['poc_old'] else 'ordinary'
                new_group='poc' if rec['poc_new'] else 'ordinary'
                sf={}
                while nxt and nxt['key']==rec['key']:
                    sf[nxt['subfactor']]=nxt['amount_cents'];nxt=next(subset,None)
                dw.append([r['month'],rec['unp'],rec['client'],rec['contract'],rec['segment'],
                    rec['gr_old'],rec['gr_new'],old_dpd[old_group].get(rec['unp'],0),new_dpd[new_group].get(rec['unp'],0),
                    round((rec['debt_old'] or 0)/1_000_000,8),round((rec['debt_new'] or 0)/1_000_000,8),
                    round((rec['reserve_old'] or 0)/1_000_000,8),round((rec['reserve_new'] or 0)/1_000_000,8),
                    rec['rate_old'],rec['rate_new'],money(rec['expenses_cents']),money(rec['movement_cents']),
                    money(rec['financial_cents']),money(rec['security_cents']),money(rec['fx_cents']),rec['explanation'],
                    *[money(sf.get(k,0)) for k in keys]])
        wb.save(output_path)
        wb.close()
        return str(output_path)
