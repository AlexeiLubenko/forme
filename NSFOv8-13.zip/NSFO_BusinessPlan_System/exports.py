"""Streaming wide NSFO forecast workbook export (runtime openpyxl)."""
import json, re
from datetime import datetime
from io import BytesIO
from openpyxl import Workbook
from openpyxl.cell import WriteOnlyCell, Cell
from openpyxl.styles import Font,PatternFill,Alignment,Border,Side
from openpyxl.utils import get_column_letter
from engine import connect, dd, _prior_period, client_report, factor_clients, factor_summary
from risk import FACTOR_NAMES

BASE_HEADERS=['Ключ','Индивидуал / ДРПА','Рабочая строка','Комментарий','Ключ сверки','Баланс/внебаланс',
'Сегмент 2026','Сегмент 2027','Наименование клиента','Тип операции','УНП','Номер договора',
'Номер договора верхнего уровня','Валюта','РД','Продукт','Микрокредит','КМ','CRM_ID',
'Отрасль','Зона проблемности','Дата начала договора','Дата окончания договора',
'Предельная дата выборки','СПОК']
PERIOD_BASE_FIELDS=['Задолженность','OD','НИ','ПФН','НВВ','Рестра','Обеспеченность','ГР','%рез']
FACTOR_KEYS=list(FACTOR_NAMES.keys())
FIELDS=PERIOD_BASE_FIELDS+list(FACTOR_NAMES.values())+[
    'Движение кредитного портфеля','Изменение финансового состояния',
    'Изменение обеспечения','Переоценка'
]
BGC='#16243B';CYAN='#E6F1FF';NUM_FMT='#,##0.00;[Red](#,##0.00);–'

def header_cells(ws,headers):
    ws.sheet_view.showGridLines=False
    ws.freeze_panes=ws.freeze_panes or 'C2'
    ws.print_title_rows='1:1'
    ws.sheet_properties.pageSetUpPr.fitToPage=True
    ws.page_setup.orientation='landscape'
    ws.page_setup.paperSize='8'
    ws.page_setup.fitToWidth=1
    ws.page_setup.fitToHeight=0
    ws.row_dimensions[1].height=48
    for j,h in enumerate(headers,1):
        ws.column_dimensions[get_column_letter(j)].width=38 if any(x in h for x in ('Клиент','Комментарий','Подфактор','Описание')) else 20
    original_append=ws.append
    ws._report_count=0
    def append(values):
        ws._report_count+=1
        values=list(values)
        cells=[v if isinstance(v,Cell) else amount_cell(ws,v) for v in values]
        if 'ИТОГО' in values:
            for cell in cells:
                cell.font=Font(name='Aptos',size=10,bold=True,color='15263F')
                cell.fill=PatternFill('solid',fgColor='DDE9F7')
        original_append(cells)
    ws.append=append
    row=[]
    for h in headers:
        c=WriteOnlyCell(ws,value=h)
        c.font=Font(name='Aptos',size=10,bold=True,color='FFFFFF')
        c.fill=PatternFill('solid',fgColor='15263F')
        c.alignment=Alignment(wrap_text=True,vertical='center')
        row.append(c)
    ws.append(row)

def amount_cell(ws,v,editable=False):
    c=WriteOnlyCell(ws,value=v)
    if isinstance(v,str):c.data_type='s'
    c.alignment=Alignment(vertical='top',wrap_text=True)
    c.font=Font(name='Aptos',size=10,color='0000FF' if editable else '101828')
    if isinstance(v,(int,float)):c.number_format=NUM_FMT
    if editable:c.fill=PatternFill('solid',fgColor='EDF5FF')
    return c

def build_excel(pid,output_path=None):
    with connect() as db:
        project=db.execute('SELECT * FROM projects WHERE id=?',(pid,)).fetchone()
        if not project:raise ValueError('Нет проекта')
        periods=json.loads(project['periods'])
        if not periods:raise ValueError('Нет рассчитанного прогноза')
        wb=Workbook(write_only=True)
        s=wb.create_sheet('Прогноз НСФО')
        s.sheet_view.showGridLines=False
        base=BASE_HEADERS
        headers=base+[f'{name}_{dd(period)}' for period in periods for name in FIELDS]
        headers += [f'Резерв_{dd(period)}' for period in periods]
        headers += [f'Расходы_{dd(period)}' for period in periods[1:]]
        headers += ['ПОК','Ставка ПОК'] + [f'Курс_{dd(d)}' for d in periods]
        s.freeze_panes='K2'
        for j in range(1,len(headers)+1):
            s.column_dimensions[get_column_letter(j)].width=(19 if j<=len(base) else 15)
        header_cells(s,headers)
        for p in db.execute('SELECT * FROM positions WHERE project_id=? ORDER BY unp,contract,id',(pid,)):
            rows={r['period']:r for r in db.execute('SELECT * FROM position_periods WHERE position_id=? AND project_id=? ORDER BY period',(p['id'],pid))}
            black='ДРПА' if 'черн' in (p['zone'] or '').lower() else ''
            important=any(abs(r['expenses'] or 0)>=100000 for r in rows.values())
            label='/'.join(x for x in ('Индивидуал' if important else '',black) if x)
            vals=[str(p['id']),label,'Добавлен из факта' if p['src']!='bp' else '',p['comment'],p['match_key'],p['side'],p['segment26'],p['segment27'],p['client'],p['operation'],p['unp'],p['contract'],p['parent_contract'],p['ccy'],p['rd'],p['product'],'Да' if p['micro'] else 'Нет',p['km'],p['crm'],p['sector'],p['zone'],p['start_date'],p['end_date'],p['limit_date'],p['spok']]
            for dt in periods:
                r=rows.get(dt)
                if not r: vals += [None]*len(FIELDS);continue
                f=json.loads(r['factors'] or '{}')
                vals += [r['debt'],r['od'],r['ni'],r['pfn'],r['nvv'],r['restra'],r['security'],r['gr'],r['rate'],
                    *[f.get(key,0.) for key in FACTOR_KEYS],
                    r['movement'],r['financial_state'],r['security_effect'],r['revaluation']]
            vals += [rows[t]['reserve'] if t in rows else None for t in periods]
            vals += [rows[t]['expenses'] if t in rows else None for t in periods[1:]]
            vals += [p['poc'],p['poc_rate']] + [rows[d]['fx'] if d in rows else None for d in periods]
            s.append([amount_cell(s,value,editable=(j in (3,) or (j>=len(base) and (j-len(base))%len(FIELDS) in (0,2,3,4,5,6)))) for j,value in enumerate(vals)])
        # The threshold is evaluated independently for each reporting period, as on screen.
        per=wb.create_sheet('Поклиентные расходы')
        header_cells(per,['Период','УНП','Клиент','Сегмент','Категория','Клиентов','Расходы, BYN','Резерв, BYN','Движение КП','Финансовое состояние','Обеспечение','Переоценка','Комментарий'])
        for d in periods[1:]:
            report=client_report(pid,d,limit=10**9)
            for r in report['important']+report['standard_segments']:
                category=('ДРПА' if 'черн' in (r['zone'] or '').lower() else 'Индивидуал') if r['unp'] else 'Стандартный портфель'
                per.append([dd(d),r['unp'],r['client'],r['segment'],category,r.get('clients',1),r['expenses'],r['reserve'],r['movement'],r['financial_state'],r['security_effect'],r['revaluation'],r['comment'] or r.get('auto_comment','')])
            total={k:sum(r[k] or 0 for r in report['important'])+(report['standard'][k] or 0) for k in ('expenses','reserve','movement','financial_state','security_effect','revaluation')}
            per.append([dd(d),'','ИТОГО','','',report['count']+report['standard']['clients'],*[total[k] for k in ('expenses','reserve','movement','financial_state','security_effect','revaluation')],''])
        detail=wb.create_sheet('Подфакторы по клиентам')
        header_cells(detail,['Период','Подфактор','УНП','Клиент','Сегмент','Договоры','Создание, BYN','Восстановление, BYN','Итого, BYN'])
        for d in periods[1:]:
            for r in factor_clients(pid,d,None,limit=10**9)['rows']:
                detail.append([dd(d),FACTOR_NAMES.get(r['factor'],r['factor']),r['unp'],r['client'],r['segment'],', '.join(r['contracts']),r['creation'],r['recovery'],r['amount']])
        summary=wb.create_sheet('Сводка',0)
        header_cells(summary,['Период','OD, BYN','Резерв, BYN','Расходы, BYN','Движение КП','Финансовое состояние','Обеспечение','Переоценка','Нерассчитанных позиций'])
        for d in periods:
            totals=factor_summary(pid,d)['totals']
            invalid=db.execute('SELECT COUNT(*) FROM position_periods WHERE project_id=? AND period=? AND reserve IS NULL',(pid,d)).fetchone()[0]
            summary.append([dd(d),*[totals[k] for k in ('od','reserve','expenses','movement','financial_state','security_effect','revaluation')],invalid])
        notes=wb.create_sheet('О файле')
        header_cells(notes,['Раздел','Описание'])
        for row in [('Проект',project['name']),('Факт',dd(project['fact_date'])),('Сформирован',datetime.now().isoformat(timespec='seconds')),('Единицы','BYN; ставка резервирования указана в процентных пунктах'),('Знак расходов','Отрицательное значение — создание резерва; положительное — восстановление'),('Сегменты','Сегмент 2026 для дат до конца 2026; Сегмент 2027 для дат с 2027. Пустые и конфликтующие значения показаны отдельно.'),('Поклиентный отчёт','Порог |расходы| ≥ 100 000 BYN применяется отдельно на каждую дату. Остальные клиенты сгруппированы по сегментам.'),('Подфакторы по клиентам','Включены все клиенты с ненулевым влиянием по договорам, в том числе с нулевым итогом из-за взаимного погашения.'),('Расчёт','Нерассчитанные позиции не включаются в денежные итоги; их количество указано в сводке.')]:notes.append(row)
        import current_portfolio
        review=current_portfolio.report(pid)
        if review.get('meta'):
            cp=wb.create_sheet('Сверка портфелей')
            header_cells(cp,['УНП','Клиент','Номер договора','Результат','Изменённый признак','Было','Стало'])
            labels={'missing':'Нет во входном БП','plan_only':'Нет в текущем портфеле; остаток БП на следующий период','changed':'Изменились признаки','new':'Появился','gone':'Выбыл'}
            for page in range(1,(review['count']+99)//100+1):
                batch=review if page==1 else current_portfolio.report(pid,page=page)
                for r in batch['rows']:
                    changes='; '.join({'ni':'НИ','pfn':'ПФН','nvv':'НВВ','restra':'Реструктуризация','security':'Обеспеченность'}[k] for k in r['changes'])
                    cp.append([r['unp'],r['client'],r['contract'],'; '.join(labels[k] for k in r['tags']),changes,'; '.join(str(v[0]) for v in r['changes'].values()),'; '.join(str(v[1]) for v in r['changes'].values())])
        # Four-factor bridge and detailed subfactors.
        factor_headers=['Период','Движение кредитного портфеля','Изменение финансового состояния',
                        'Изменение обеспечения','Переоценка','Расходы','Сверка']+list(FACTOR_NAMES.values())
        fws=wb.create_sheet('Факторный анализ');header_cells(fws,factor_headers)
        for d in periods[1:]:
            summ=db.execute('''SELECT SUM(movement) movement,SUM(financial_state) financial_state,
                SUM(security_effect) security_effect,SUM(revaluation) revaluation,
                SUM(expenses) expenses,SUM(rounding) rounding
                FROM position_periods WHERE project_id=? AND period=?''',(pid,d)).fetchone()
            factors={k:0. for k in FACTOR_NAMES}
            for r in db.execute('SELECT factors FROM position_periods WHERE project_id=? AND period=?',(pid,d)):
                for k,v in json.loads(r['factors'] or '{}').items():factors[k]+=v
            check=round((summ['expenses'] or 0.)-(summ['movement'] or 0.)-
                        (summ['financial_state'] or 0.)-(summ['security_effect'] or 0.)-
                        (summ['revaluation'] or 0.),2)
            fws.append([dd(d),round(summ['movement'] or 0.,2),round(summ['financial_state'] or 0.,2),
                        round(summ['security_effect'] or 0.,2),round(summ['revaluation'] or 0.,2),
                        round(summ['expenses'] or 0.,2),check]+[round(factors[k],2) for k in FACTOR_NAMES])
        for sheetname,sql,cols in [
            ('Сверка задолженности',"SELECT client,contract,details,message FROM warnings WHERE project_id=? AND kind='debt'",['Клиент','Договор','Задолженность БП, BYN','Факт, BYN','Отклонение, BYN','Курс']),
            ('Сверка резервов',"SELECT client,contract,details,message FROM warnings WHERE project_id=? AND kind='reserve'",['Клиент','Договор','Рассчитанный резерв, BYN','Резерв факт, BYN','Отклонение, BYN']),
        ]:
            w=wb.create_sheet(sheetname);header_cells(w,cols)
            for r in db.execute(sql,(pid,)):
                x=json.loads(r['details'] or '{}')
                if sheetname=='Сверка задолженности':w.append([r['client'],r['contract'],x.get('bp_byn'),x.get('fact_byn'),x.get('diff_byn'),x.get('fx')])
                else:w.append([r['client'],r['contract'],x.get('calc_byn'),x.get('fact_byn'),x.get('diff_byn')])
        w=wb.create_sheet('Реестр договоров');header_cells(w,['УНП','Клиент','Договор','Валюта','Баланс','Зона','Сумма факта, BYN','Статус','Добавлено'])
        for r in db.execute('SELECT * FROM missing WHERE project_id=? ORDER BY status,client',(pid,)):
            w.append([r['unp'],r['client'],r['contract'],r['ccy'],r['side'],r['zone'],r['amount_byn'],r['status'],r['added']])
        w=wb.create_sheet('Контроль данных');header_cells(w,['Тип','Серьёзность','Клиент','Договор','Описание'])
        for r in db.execute('SELECT kind,severity,client,contract,message FROM warnings WHERE project_id=? AND kind NOT IN ("debt","reserve")',(pid,)):
            w.append([r['kind'],r['severity'],r['client'],r['contract'],r['message']])
        w=wb.create_sheet('История изменений');header_cells(w,['Время','Действие','Позиция','Период','Поле','Было','Стало','Причина'])
        for r in db.execute('SELECT at,action,position_id,period,field,old,new,reason FROM audit WHERE project_id=? ORDER BY id',(pid,)):
            w.append([r['at'],r['action'],r['position_id'],r['period'],r['field'],r['old'],r['new'],r['reason']])
        w=wb.create_sheet('Плановые изменения');header_cells(w,[
            'Версия файла','Файл-источник','Статус набора','УНП','Клиент','Признак',
            'Событие','Дата в файле','Плановая дата (+1 месяц)','Дата применения в БП',
            'Статус события','Решение','Конфликт / комментарий'
        ])
        for r in db.execute('''SELECT b.version,b.original_name,b.status batch_status,
                e.unp,e.feature,e.action,e.source_date,e.requested_date,e.applied_period,
                e.status,e.resolution,e.conflict_message,
                COALESCE((SELECT MAX(p.client) FROM positions p WHERE p.project_id=e.project_id AND p.unp=e.unp),'') client
            FROM plan_events e JOIN plan_event_batches b ON b.id=e.batch_id
            WHERE e.project_id=? ORDER BY b.version,e.applied_period,e.unp,e.feature''',(pid,)):
            feature={'ni':'НИ','pfn':'ПФН','nvv':'НВВ'}.get(r['feature'],r['feature'])
            action={'recognition':'Возникновение','removal':'Снятие'}.get(r['action'],r['action'])
            w.append([r['version'],r['original_name'],r['batch_status'],r['unp'],r['client'],feature,action,
                      dd(r['source_date']),dd(r['requested_date']),dd(r['applied_period']) if r['applied_period'] else '',
                      r['status'],r['resolution'],r['conflict_message']])
        for sheet in wb.worksheets:
            if getattr(sheet,'_report_count',0):
                sheet.auto_filter.ref=f'A1:{get_column_letter(len(sheet.column_dimensions))}{sheet._report_count}'
        if output_path is not None:
            wb.save(str(output_path))
            return output_path
        b=BytesIO();wb.save(b);b.seek(0);return b


def report_sections(pid):
    """Shared complete report for downloadable PDF and browser printing."""
    with connect() as db:
        project=db.execute('SELECT * FROM projects WHERE id=?',(pid,)).fetchone()
        if not project:raise ValueError('Нет бизнес-плана')
        project=dict(project);periods=json.loads(project['periods'])
        invalid=db.execute('SELECT COUNT(*) FROM position_periods WHERE project_id=? AND reserve IS NULL',(pid,)).fetchone()[0]
    sections=[]
    totals=[]
    for d in periods:
        t=factor_summary(pid,d)['totals']
        totals.append([dd(d),*[t[k] for k in ('od','reserve','expenses','movement','financial_state','security_effect','revaluation')]])
    sections.append(('Резервы и факторы · BYN',['Период','OD','Резерв','Расходы','Движение КП','Фин. состояние','Обеспечение','Переоценка'],totals))
    for d in periods[1:]:
        clients=client_report(pid,d,limit=10**9)
        rows=[]
        for r in clients['important']+clients['standard_segments']:
            rows.append([r['client'],r['unp'] or str(r.get('clients',0))+' клиентов',r['segment'],r['expenses'],r['movement'],r['financial_state'],r['security_effect'],r['revaluation']])
        rows.append(['ИТОГО','','',*[sum(r[k] or 0 for r in clients['important'])+clients['standard'][k] for k in ('expenses','movement','financial_state','security_effect','revaluation')]])
        sections.append(('Клиенты и сегменты · '+dd(d),['Клиент','УНП / число','Сегмент','Расходы','Движение КП','Фин. состояние','Обеспечение','Переоценка'],rows))
        detail=factor_clients(pid,d,None,limit=10**9)['rows']
        rows=[[FACTOR_NAMES.get(r['factor'],r['factor']),r['client'],r['unp'],r['segment'],', '.join(r['contracts']),r['creation'],r['recovery'],r['amount']] for r in detail]
        sections.append(('Подфакторы по клиентам · '+dd(d),['Подфактор','Клиент','УНП','Сегмент','Договоры','Создание','Восстановление','Итого'],rows))
    return project,sections,invalid


def report_value(value):
    return f'{value:,.2f}'.replace(',',' ') if isinstance(value,(int,float)) else str(value or '—')


def build_pdf(pid):
    try:
        from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, LongTable, TableStyle, PageBreak
        from reportlab.lib.pagesizes import A4, landscape
        from reportlab.lib.styles import ParagraphStyle
        from reportlab.lib import colors
        from reportlab.pdfbase import pdfmetrics
        from reportlab.pdfbase.ttfonts import TTFont
    except ImportError:raise ValueError('Для экспорта PDF установите reportlab или используйте печать из браузера.')
    from html import escape
    from pathlib import Path
    paths=[Path(__file__).parent/'static/fonts/DejaVuSans.ttf',Path('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'),Path('C:/Windows/Fonts/arial.ttf')]
    font_path=next((p for p in paths if p.exists()),None)
    if not font_path:raise ValueError('Для PDF нужен кириллический шрифт. Используйте печать из браузера.')
    pdfmetrics.registerFont(TTFont('NSFOReport',str(font_path)))
    project,sections,invalid=report_sections(pid)
    b=BytesIO();doc=SimpleDocTemplate(b,pagesize=landscape(A4),leftMargin=26,rightMargin=26,topMargin=32,bottomMargin=32,title='Прогноз резервов НСФО',author='АС НСФО')
    normal=ParagraphStyle('body',fontName='NSFOReport',fontSize=8,leading=11)
    title=ParagraphStyle('title',parent=normal,fontSize=16,leading=22,textColor=colors.HexColor('#16243B'))
    heading=ParagraphStyle('heading',parent=normal,fontSize=12,leading=17,spaceAfter=10)
    cell=ParagraphStyle('cell',parent=normal,fontSize=7,leading=10,splitLongWords=True)
    head=ParagraphStyle('head',parent=cell,textColor=colors.white)
    number=ParagraphStyle('number',parent=cell,alignment=2)
    story=[Paragraph('Прогноз резервов НСФО',title),Paragraph(escape(project['name']),heading),Paragraph('Факт на '+dd(project['fact_date'])+' · Сформирован '+datetime.now().strftime('%d.%m.%Y %H:%M'),normal),Spacer(1,10),Paragraph('Все суммы в BYN. Отрицательное значение — создание резерва, положительное — восстановление. Индивидуальные клиенты: |расходы| ≥ 100 000 BYN за период; остальные сгруппированы по сегментам.',normal),Paragraph(f'Нерассчитанных позиций по всем датам: {invalid}. Такие суммы не включены в итоги.',normal),Spacer(1,14)]
    for i,(name,headers,rows) in enumerate(sections):
        if i:story.append(PageBreak())
        story.append(Paragraph(escape(name),heading))
        if not rows:story.append(Paragraph('Нет ненулевых влияний.',normal));continue
        data=[[Paragraph(escape(h),head) for h in headers]]+[[Paragraph(escape(report_value(v)),number if isinstance(v,(int,float)) else cell) for v in row] for row in rows]
        weights=([1.5,1,1,1,1,1,1,1] if 'Клиенты' in name else [1.6,1.5,.85,1.1,1.5,1,1,1] if 'Подфакторы' in name else [1]*8)
        table=LongTable(data,colWidths=[doc.width*w/sum(weights) for w in weights],repeatRows=1,hAlign='LEFT',splitInRow=1)
        table.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#16243B')),('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,colors.HexColor('#F1F5FA')]),('VALIGN',(0,0),(-1,-1),'TOP'),('BOTTOMPADDING',(0,0),(-1,-1),6),('TOPPADDING',(0,0),(-1,-1),6),('LINEBELOW',(0,0),(-1,0),.5,colors.HexColor('#CED7E5'))]))
        story.append(table)
    def footer(canvas,document):
        canvas.setFont('NSFOReport',7);canvas.setFillColor(colors.HexColor('#526178'))
        canvas.drawString(26,17,'АС НСФО · Прогноз резервов · BYN')
        canvas.drawRightString(landscape(A4)[0]-26,17,'Страница '+str(document.page))
    doc.build(story,onFirstPage=footer,onLaterPages=footer)
    b.seek(0);return b

def PathCheck(p):
    import os
    return os.path.exists(p)

def build_printable_html(pid):
    from html import escape
    p,sections,invalid=report_sections(pid)
    blocks=[]
    for name,headers,rows in sections:
        head=''.join('<th>'+escape(h)+'</th>' for h in headers)
        body=''.join('<tr>'+''.join('<td>'+escape(report_value(v))+'</td>' for v in row)+'</tr>' for row in rows)
        blocks.append('<section><h2>'+escape(name)+'</h2><table><thead><tr>'+head+'</tr></thead><tbody>'+body+'</tbody></table></section>')
    return '<!doctype html><html lang="ru"><meta charset="utf-8"><title>Прогноз НСФО</title><style>body{font-family:Arial,sans-serif;color:#213147;margin:24px}table{border-collapse:collapse;width:100%;font-size:10px;table-layout:fixed}td,th{padding:7px;border-bottom:1px solid #dee5ee;overflow-wrap:anywhere;vertical-align:top}th{background:#1c3150;color:white}tr:nth-child(even){background:#f1f5fa}h2{font-size:16px}section{margin-top:25px}@page{size:A4 landscape;margin:12mm}@media print{button{display:none}thead{display:table-header-group}tr{break-inside:avoid}section+section{break-before:page}}</style><button onclick="window.print()">Сохранить в PDF / печать</button><h1>Прогноз резервов НСФО</h1><p>'+escape(p['name'])+' · Факт на '+dd(p['fact_date'])+'</p><p>Суммы в BYN. Отрицательное значение — создание резерва; положительное — восстановление. Порог индивидуального раскрытия: |расходы| ≥ 100 000 BYN за период.</p><p>Нерассчитанных позиций по всем датам: '+str(invalid)+'. Их суммы не включены в итоги.</p>'+''.join(blocks)+'</html>'
