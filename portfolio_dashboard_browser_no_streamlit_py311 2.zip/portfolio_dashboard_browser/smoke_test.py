"""Offline smoke test for the live browser app; no optional test packages."""
from __future__ import annotations
import ast
import json
import tempfile
import threading
from http.server import ThreadingHTTPServer
from pathlib import Path
from urllib.request import urlopen, Request
from web_server import AppState, Handler

BASE = Path(__file__).resolve().parent

def main():
    for name in ('web_server.py','web_store.py','portfolio_core.py','portfolio_schema.py',
                 'portfolio_store.py','reserve_operational_analysis.py','material_changes.py'):
        ast.parse((BASE/name).read_text('utf-8'),feature_version=(3,11))
    with tempfile.TemporaryDirectory() as tmp:
        a = AppState(Path(tmp))
        ids=[]
        for day in ('2026-09-30','2026-10-29'):
            f=BASE/f'demo_{day}.csv'
            ids.append(a.store.save(f.read_bytes(),f.name,'CSV',1,'Демо '+day,report_date=day))
        before,after=ids
        result,mat=a.comparison(before,after)
        assert abs(result.balance_error)<1e-6
        assert abs(mat.balance_error)<1e-6
        assert (mat.material['Δ резерва'].abs()>=100).all()
        sid=before
        assert a.store.current_revision(sid)==0
        a.store.commit(sid,0,changes={'0':{'Резерв факт':123.45}},note='тест правок')
        assert a.store.current_revision(sid)==1
        a.store.restore_revision(sid,1,0)
        assert a.store.current_revision(sid)==2
        with ThreadingHTTPServer(('127.0.0.1',0),Handler) as server:
            server.app=a
            url='http://127.0.0.1:'+str(server.server_port)
            runner=threading.Thread(target=server.serve_forever,daemon=True)
            runner.start()
            try:
                with urlopen(url+'/',timeout=5) as response:
                    html=response.read().decode('utf8')
                    assert response.status==200 and 'Портфель' in html
                with urlopen(url+'/api/health',timeout=5) as response:
                    assert json.load(response)['ok']
                with urlopen(url+'/api/meta',timeout=5) as response:
                    assert len(json.load(response)['snapshots'])==2
                with urlopen(url+f'/api/compare?before={before}&after={after}',timeout=10) as response:
                    assert abs(json.load(response)['balance_error'])<1e-6
                with urlopen(url+f'/api/portfolio?id={before}',timeout=10) as response:
                    assert json.load(response)['revision']==2
                with urlopen(url+'/static/app.js',timeout=5) as response:
                    assert 'showUpload' in response.read().decode('utf8')
            finally:
                server.shutdown();runner.join(timeout=5)
        print('SMOKE TEST PASSED: HTTP, upload storage, edit, revision restore, reserve analysis')
        print('Reserve delta, thousand BYN:',round(result.delta,2))

if __name__=='__main__':
    main()
