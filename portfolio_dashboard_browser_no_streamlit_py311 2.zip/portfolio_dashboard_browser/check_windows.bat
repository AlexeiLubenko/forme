@echo off
setlocal
chcp 65001 >nul
pushd "%~dp0" || (echo Cannot open project folder & pause & exit /b 1)
python check_environment.py
pause
popd
