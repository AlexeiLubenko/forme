"""Real interactive browser application. Python standard-library HTTP server.

Requirements: Python 3.11, pandas 2.0.3, numpy 1.24.3, openpyxl 3.0.10.
No Streamlit/Flask/pip/internet, no external JS CDNs or HTML report exports.
Runs ONLY on 127.0.0.1; a local TCP port must be permitted by IT policy.
"""
from __future__ import annotations

import argparse
from collections import OrderedDict
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from io import BytesIO
import json
import math
import os
from pathlib import Path
import secrets
import sys
import traceback
from urllib.parse import parse_qs, urlsplit
import webbrowser
import csv

import numpy as np
import pandas as pd

from web_store import WebStore, RevisionConflict
from portfolio_core import group_summary, quality_summary, sheet_names
from portfolio_schema import EXPECTED_COLUMNS, NUMERIC_COLUMNS, DATE_COLUMNS
from reserve_operational_analysis import compare_operational
from material_changes import build_material_client_report

BASE = Path(__file__).resolve().parent
DEFAULT_STORAGE = BASE / 'portfolio_storage'
HOST = '127.0.0.1'
DEFAULT_PORT = 8501
MAX_UPLOAD = 200 * 1024 * 1024
MAX_JSON = 8 * 1024 * 1024
PRIMARY_COLS = ['УНП','Клиент','Номер договора','Сегмент','ГР','Задолженность, тыс BYN',
                'Резерв факт','Просроченная задолженность, тыс. BYN','Day OD',
                'НИ','ПФН','НВВ','Рестра','Обеспеченность']


def as_json_value(value):
    if value is None:
        return None
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (np.floating, float)):
        return float(value) if math.isfinite(float(value)) else None
    if isinstance(value, (np.bool_, bool)):
        return bool(value)
    if isinstance(value, (pd.Timestamp, datetime)):
        return value.strftime('%Y-%m-%d') if pd.notna(value) else None
    if value is pd.NA or value is pd.NaT:
        return None
    if isinstance(value, (str, int)):
        return value
    try:
        if pd.isna(value):
            return None
    except (TypeError, ValueError):
        pass
    return str(value)


def frame_records(frame):
    if frame.empty:
        return []
    rows = frame.to_dict('records')
    return [{str(k): as_json_value(v) for k,v in row.items()} for row in rows]


def query_arg(q, key, default=''):
    return q.get(key, [default])[0]


def number(q, key, default=1, lower=1, upper=10000000):
    try:
        value = int(query_arg(q, key, str(default)))
    except (TypeError, ValueError):
        raise ValueError(f'Неверное значение параметра {key}')
    if not lower <= value <= upper:
        raise ValueError(f'Значение {key} вне допустимого диапазона')
    return value


def page_of(frame, q, default_size=50, max_size=200):
    page = number(q, 'page', 1, 1)
    size = number(q, 'size', default_size, 1, max_size)
    total = len(frame)
    offset = (page - 1) * size
    return {'total': total, 'page': page, 'size': size, 'pages': max(1, math.ceil(total / size)),
            'rows': frame_records(frame.iloc[offset: offset + size])}


def filter_rows(frame, q, *, include_index=False):
    df = frame.copy(deep=False)
    if include_index:
        df = df.reset_index().rename(columns={'index':'_rowid'})
    query = str(query_arg(q, 'search', '')).strip()
    if query:
        cols = [c for c in ('УНП','Клиент','Номер договора') if c in df]
        mask = pd.Series(False, index=df.index)
        for col in cols:
            mask = mask | df[col].astype('string').str.contains(query, case=False, regex=False, na=False)
        df = df.loc[mask]
    fcol = str(query_arg(q, 'filter_col', ''))
    fval = str(query_arg(q, 'filter_val', ''))
    if fcol in df and fval:
        df = df.loc[df[fcol].astype('string').fillna('—').eq(fval)]
    order = str(query_arg(q, 'sort', ''))
    if order in df:
        ascending = query_arg(q, 'direction', 'asc') == 'asc'
        df = df.sort_values(order, ascending=ascending, kind='stable', na_position='last')
    return df


class AppState:
    def __init__(self, root=DEFAULT_STORAGE):
        self.store = WebStore(root)
        self.token = secrets.token_urlsafe(32)
        self.cache = OrderedDict()
        self.compare_cache = OrderedDict()

    def snapshot(self, sid, revision=None):
        sid = int(sid)
        rev = self.store.current_revision(sid) if revision is None else int(revision)
        key = (sid, rev)
        if key not in self.cache:
            self.cache[key] = self.store.load(sid, rev)
            if len(self.cache) > 2:
                self.cache.popitem(last=False)
        return self.cache[key]

    def drop_cache(self):
        self.cache.clear()
        self.compare_cache.clear()

    def comparison(self, before, after):
        before, after = int(before), int(after)
        x = self.store.get_version(before)
        y = self.store.get_version(after)
        if before == after:
            raise ValueError('Выбери разные отчётные даты')
        if x['report_date'] and y['report_date'] and x['report_date'] >= y['report_date']:
            raise ValueError('Начальная дата должна быть раньше конечной')
        key = (before, self.store.current_revision(before), after, self.store.current_revision(after))
        if key not in self.compare_cache:
            result = compare_operational(self.snapshot(before), self.snapshot(after))
            material = build_material_client_report(result, 100.0)
            self.compare_cache[key] = (result, material)
            if len(self.compare_cache) > 2:
                self.compare_cache.popitem(last=False)
        return self.compare_cache[key]


class Handler(BaseHTTPRequestHandler):
    server_version = 'PortfolioWeb/1.0'
    protocol_version = 'HTTP/1.1'

    @property
    def app(self):
        return self.server.app

    def log_message(self, fmt, *args):
        if not self.path.startswith('/api/health'):
            print('[HTTP]', self.address_string(), fmt % args, flush=True)

    def _base_headers(self):
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Frame-Options', 'DENY')
        self.send_header('Referrer-Policy', 'no-referrer')
        self.send_header('Content-Security-Policy',
                         "default-src 'self'; script-src 'self'; connect-src 'self'; "
                         "style-src 'self' 'unsafe-inline'; img-src 'self' data:; "
                         "object-src 'none'; frame-ancestors 'none'")

    def send_bytes(self, content, ctype='application/octet-stream', status=200, filename=None):
        self.send_response(status)
        self.send_header('Content-Type', ctype)
        self.send_header('Content-Length', str(len(content)))
        self._base_headers()
        if filename:
            self.send_header('Content-Disposition', "attachment; filename*=UTF-8''" +
                             __import__('urllib.parse', fromlist=['quote']).quote(filename))
        self.end_headers()
        self.wfile.write(content)

    def reply(self, obj, status=200):
        content = json.dumps(obj, ensure_ascii=False, allow_nan=False, default=as_json_value).encode('utf-8')
        self.send_bytes(content, 'application/json; charset=utf-8', status)

    def fail(self, error, status=None):
        if status is None:
            status = 409 if isinstance(error, RevisionConflict) else 400 if isinstance(error, (ValueError, KeyError)) else 500
        if status == 500:
            traceback.print_exc()
        self.reply({'error': str(error) if status != 500 else 'Ошибка сервера; смотри окно Python'}, status)

    def do_GET(self):
        try:
            p = urlsplit(self.path)
            q = parse_qs(p.query, keep_blank_values=True)
            if p.path in ('/', '/index.html'):
                html = (BASE / 'static/index.html').read_text('utf-8')
                html = html.replace('__APP_TOKEN__', self.app.token)
                return self.send_bytes(html.encode('utf-8'), 'text/html; charset=utf-8')
            assets = {'/static/app.js':('app.js','text/javascript; charset=utf-8'),
                      '/static/style.css':('style.css','text/css; charset=utf-8')}
            if p.path in assets:
                fn, typ = assets[p.path]
                return self.send_bytes((BASE / 'static' / fn).read_bytes(), typ)
            if p.path == '/favicon.ico':
                return self.send_bytes(b'', status=204)
            if p.path.startswith('/api/'):
                return self.get_api(p.path, q)
            self.reply({'error':'Страница не найдена', 'path':p.path}, 404)
        except Exception as exc:
            self.fail(exc)

    def do_POST(self):
        try:
            p = urlsplit(self.path)
            q = parse_qs(p.query, keep_blank_values=True)
            if self.headers.get('X-Portfolio-Token') != self.app.token:
                return self.fail(ValueError('Недействительная сессия. Обнови страницу.'), 403)
            try:
                size = int(self.headers.get('Content-Length', '0'))
            except ValueError:
                return self.fail(ValueError('Неизвестная длина запроса'))
            if size <= 0 or size > (MAX_UPLOAD if p.path in ('/api/upload','/api/sheets') else MAX_JSON):
                return self.fail(ValueError('Неверный размер запроса'))
            content = self.rfile.read(size)
            if p.path == '/api/upload':
                filename = str(query_arg(q,'filename','portfolio.xlsx'))
                sheet = str(query_arg(q,'sheet',''))
                header_row = number(q, 'header_row', 1, 1, 100)
                extension = Path(filename).suffix.lower()
                if extension not in ('.xlsx','.xlsm','.csv'):
                    raise ValueError('Допускаются только файлы XLSX, XLSM или CSV')
                selected = sheet or sheet_names(content, filename)[0]
                sid = self.app.store.save(content, filename, selected, header_row,
                                          str(query_arg(q,'title','Портфель '+query_arg(q,'date'))),
                                          str(query_arg(q,'note','')),
                                          report_date=str(query_arg(q,'date','')))
                self.app.drop_cache()
                return self.reply({'id':sid, 'message':'Портфель сохранён'})
            if p.path == '/api/sheets':
                return self.reply({'sheets': sheet_names(content, str(query_arg(q,'filename','file.xlsx')))})
            payload = json.loads(content.decode('utf-8'))
            if p.path == '/api/save':
                ans = self.app.store.commit(payload['id'], payload['revision'], payload.get('changes'),
                                            payload.get('deletions'), payload.get('additions'), payload.get('note',''))
                self.app.drop_cache()
                return self.reply(ans)
            if p.path == '/api/date':
                self.app.store.set_report_date(int(payload['id']), str(payload['date']))
                self.app.drop_cache()
                return self.reply({'ok':True})
            if p.path == '/api/restore':
                # Revert editing to prior revision by creating a NEW revision; history preserved.
                sid = int(payload['id'])
                target = int(payload['target_revision'])
                current = self.app.store.current_revision(sid)
                if target < 0 or target >= current:
                    raise ValueError('Выбери более раннюю редакцию')
                older = self.app.store.load(sid, target)
                latest = self.app.store.load(sid)
                # Reverting is an explicit new revision; use full replacement helper.
                ans = self.app.store.restore_revision(sid, current, target, older)
                self.app.drop_cache()
                return self.reply(ans)
            return self.reply({'error':'Действие не найдено'}, 404)
        except Exception as exc:
            self.fail(exc)

    def get_api(self, path, q):
        if path == '/api/health':
            return self.reply({'ok':True,'server':'portfolio-web-stdlib','python':sys.version.split()[0]})
        if path == '/api/meta':
            snaps = self.app.store.list_with_current()
            return self.reply({'snapshots':snaps, 'active_id':self.app.store.active_id(),
                               'columns':list(EXPECTED_COLUMNS), 'numeric':list(NUMERIC_COLUMNS),
                               'date_columns':list(DATE_COLUMNS), 'primary':PRIMARY_COLS,
                               'threshold':100.0})
        if path == '/api/portfolio':
            sid = number(q, 'id')
            df = self.app.snapshot(sid)
            view = filter_rows(df,q,include_index=True)
            result = page_of(view,q)
            result.update({'id':sid, 'revision':self.app.store.current_revision(sid),
                           'total_rows':len(df),
                           'reserve':float(view['Резерв факт'].sum()),
                           'debt':float(view['Задолженность, тыс BYN'].sum()),
                           'unique_unp':int(view['УНП'].nunique())})
            return self.reply(result)
        if path == '/api/overview':
            sid = number(q, 'id')
            df = self.app.snapshot(sid)
            seg = group_summary(df, 'Сегмент', 'Резерв факт', limit=12)
            risk = group_summary(df, 'Зона проблемности', 'Резерв факт', limit=12)
            return self.reply({'rows':len(df),'clients':int(df['УНП'].nunique()),
                'contracts':int(df[['УНП','Номер договора']].drop_duplicates().shape[0]),
                'reserve':float(df['Резерв факт'].sum()),
                'debt':float(df['Задолженность, тыс BYN'].sum()),
                'overdue':float(df['Просроченная задолженность, тыс. BYN'].sum()),
                'segments':frame_records(seg),'risk':frame_records(risk)})
        if path == '/api/revisions':
            sid = number(q, 'id')
            return self.reply({'id':sid, 'current':self.app.store.current_revision(sid),
                               'history':self.app.store.revision_history(sid)})
        if path == '/api/slices':
            sid = number(q, 'id')
            df = self.app.snapshot(sid)
            dimension = str(query_arg(q,'dimension','Сегмент'))
            metric = str(query_arg(q,'metric','Резерв факт'))
            agg = str(query_arg(q,'agg','Сумма'))
            if dimension not in EXPECTED_COLUMNS or metric not in NUMERIC_COLUMNS:
                raise ValueError('Неизвестное поле среза')
            if agg not in ('Сумма','Среднее','Медиана','Количество','Минимум','Максимум'):
                raise ValueError('Неизвестная агрегация')
            table = group_summary(df, dimension, metric, agg, 50)
            return self.reply({'rows':frame_records(table),'dimension':dimension,'metric':metric,'agg':agg})
        if path == '/api/quality':
            sid = number(q, 'id')
            result = quality_summary(self.app.snapshot(sid))
            return self.reply({'rows':frame_records(result)})
        if path == '/api/compare':
            before, after = number(q,'before'),number(q,'after')
            result,mat = self.app.comparison(before,after)
            return self.reply({'before':before,'after':after,
                'initial_reserve':result.total_before,'final_reserve':result.total_after,
                'delta':result.delta,'debt_before':result.debt_before,'debt_after':result.debt_after,
                'balance_error':result.balance_error,'material_count':len(mat.material),
                'material_delta':mat.material_delta,'other_count':mat.other_clients_count,
                'other_delta':mat.other_clients_delta,'unmatched_delta':mat.unmatched_delta,
                'material_balance_error':mat.balance_error,
                'factors':frame_records(result.factors), 'segments':frame_records(result.segments)})
        if path == '/api/compare/clients':
            before, after = number(q,'before'),number(q,'after')
            result,mat = self.app.comparison(before,after)
            subset = mat.material
            query = str(query_arg(q,'search','')).strip().lower()
            if query:
                a = subset['УНП'].astype('string').str.contains(query,case=False,regex=False,na=False)
                b = subset['Клиент'].astype('string').str.contains(query,case=False,regex=False,na=False)
                subset = subset.loc[a | b]
            direction = str(query_arg(q,'movement','all'))
            if direction == 'up':
                subset = subset.loc[subset['Δ резерва'] > 0]
            elif direction == 'down':
                subset = subset.loc[subset['Δ резерва'] < 0]
            cols = ['УНП','Клиент','Сегмент','Резерв — было','Резерв — стало',
                    'Δ резерва','Основные факторы','Комментарий', 'Договоров — было','Договоров — стало']
            return self.reply(page_of(subset[[c for c in cols if c in subset]],q,50,200))
        if path == '/api/compare/client':
            before,after = number(q,'before'),number(q,'after')
            unp = str(query_arg(q,'unp',''))
            if not unp:
                raise ValueError('Не указан УНП')
            result,mat = self.app.comparison(before,after)
            contracts = result.contracts.loc[result.contracts['УНП'].astype('string').eq(unp)]
            return self.reply({'unp':unp,'contracts':frame_records(contracts.head(300)),
                'total':len(contracts),'columns':list(contracts.columns)})
        if path == '/api/export':
            return self.download(q)
        return self.reply({'error':'Метод API не найден'},404)

    def download(self, q):
        kind = str(query_arg(q,'kind','portfolio'))
        fmt = str(query_arg(q,'format','csv'))
        if kind == 'portfolio':
            sid = number(q,'id')
            frame = self.app.snapshot(sid)
            name = f'portfolio_{sid}_rev{self.app.store.current_revision(sid)}'
        elif kind == 'original':
            sid = number(q,'id')
            meta = self.app.store.get_version(sid)
            data = self.app.store.raw_bytes(sid)
            return self.send_bytes(data,filename=meta['filename'])
        else:
            before, after = number(q,'before'),number(q,'after')
            result,mat = self.app.comparison(before,after)
            options = {'material':mat.material,'all_clients':result.clients,
                       'contracts':result.contracts,'factors':result.factors,
                       'segments':result.segments}
            if kind not in options:
                raise ValueError('Неверный тип выгрузки')
            frame = options[kind]
            name = f'{kind}_{before}_{after}'
        if fmt == 'xlsx':
            output = BytesIO()
            with pd.ExcelWriter(output, engine='openpyxl') as writer:
                # Prevent formula injection when opened by Excel.
                safe = frame.copy()
                for col in safe.select_dtypes(include=['object','string']).columns:
                    safe[col] = safe[col].map(lambda v: "'" + v if isinstance(v,str) and v.lstrip().startswith(('=','+','-','@')) else v)
                safe.to_excel(writer, sheet_name='Данные', index=False)
            return self.send_bytes(output.getvalue(),
                'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                filename=name+'.xlsx')
        if fmt != 'csv':
            raise ValueError('Допустимы CSV и XLSX')
        safe = frame.copy()
        for col in safe.select_dtypes(include=['object','string']).columns:
            safe[col] = safe[col].map(lambda v: "'" + v if isinstance(v,str) and v.lstrip().startswith(('=','+','-','@')) else v)
        content = safe.to_csv(index=False,sep=';',encoding='utf-8',date_format='%Y-%m-%d').encode('utf-8-sig')
        return self.send_bytes(content, 'text/csv; charset=utf-8',filename=name+'.csv')


def run(port=DEFAULT_PORT, root=DEFAULT_STORAGE, open_browser=True):
    app = AppState(root)
    try:
        # Binds loopback only, never 0.0.0.0. No attempt to evade Windows policy.
        httpd = ThreadingHTTPServer((HOST, int(port)), Handler)
    except OSError as exc:
        print('\nНЕ УДАЛОСЬ ЗАПУСТИТЬ ЛОКАЛЬНЫЙ ВЕБ-СЕРВЕР', file=sys.stderr)
        print(f'Ошибка: {exc}', file=sys.stderr)
        if getattr(exc,'winerror',None) == 10013:
            print('WinError 10013: Windows или банковская политика запрещает привязку к сокету.',file=sys.stderr)
            print('Попросите ИТ разрешить локальный TCP-сервер для python.exe на 127.0.0.1.',file=sys.stderr)
            print('Не отключайте защиту самостоятельно.',file=sys.stderr)
        raise SystemExit(2)
    httpd.app = app
    url = f'http://127.0.0.1:{httpd.server_port}/'
    print('\nПОРТФЕЛЬ И РЕЗЕРВЫ — ВЕБ-ПРИЛОЖЕНИЕ', flush=True)
    print('Адрес:',url,flush=True)
    print('Хранилище:',app.store.root,flush=True)
    print('Дополнительные пакеты не требуются. Остановить: Ctrl+C',flush=True)
    if open_browser:
        try:
            webbrowser.open(url)
        except Exception:
            pass
    try:
        httpd.serve_forever(poll_interval=0.25)
    except KeyboardInterrupt:
        print('\nСервер остановлен.')
    finally:
        httpd.server_close()


def main():
    parser = argparse.ArgumentParser(description='Веб-приложение портфеля без Streamlit')
    parser.add_argument('--port', type=int, default=DEFAULT_PORT)
    parser.add_argument('--storage', default=str(DEFAULT_STORAGE))
    parser.add_argument('--no-browser', action='store_true')
    args = parser.parse_args()
    run(args.port, Path(args.storage), not args.no_browser)


if __name__ == '__main__':
    main()
