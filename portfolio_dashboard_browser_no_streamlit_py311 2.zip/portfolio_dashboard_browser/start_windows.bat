@echo off
setlocal
chcp 65001 >nul
pushd "%~dp0" || (
  echo ERROR: Cannot access project folder.
  pause
  exit /b 1
)
echo ============================================================
echo Portfolio and Reserves - browser app, Python 3.11
echo No Streamlit, no pip, no internet packages
 echo ============================================================
python --version
if errorlevel 1 (
  echo.
  echo Python is not available. Open Anaconda Prompt, activate the
  echo environment with Python 3.11.5, then run start_windows.bat again.
  pause
  popd
  exit /b 1
)
echo.
python check_environment.py
if errorlevel 1 (
  echo.
  echo Required libraries are not available in this Python environment.
  echo No installation will be attempted.
  pause
  popd
  exit /b 1
)
echo.
echo Starting the browser application...
echo If browser doesn't open automatically, use the URL below.
echo.
python web_server.py --port 8501
set EXIT_CODE=%ERRORLEVEL%
if not "%EXIT_CODE%"=="0" (
  echo.
  echo Launch failed, error code %EXIT_CODE%.
  echo On WinError 10013 contact bank IT about local TCP listening.
  pause
)
popd
exit /b %EXIT_CODE%
