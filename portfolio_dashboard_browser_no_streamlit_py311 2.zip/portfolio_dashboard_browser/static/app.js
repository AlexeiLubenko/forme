'use strict';
const token = document.querySelector('meta[name="portfolio-token"]').content;
const page = document.getElementById('page');
const modalRoot = document.getElementById('modalRoot');
const nav = document.getElementById('nav');
const fmt = (v,d=1) => v == null || !Number.isFinite(Number(v)) ? '—' : new Intl.NumberFormat('ru-RU',{maximumFractionDigits:d,minimumFractionDigits:d}).format(Number(v));
const esc = v => String(v == null ? '' : v).replace(/[&<>"']/g, ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
const opts = (arr, selected, labelFn=(v)=>v) => arr.map(v=>`<option value="${esc(v)}" ${String(v)===String(selected)?'selected':''}>${esc(labelFn(v))}</option>`).join('');
const el = id => document.getElementById(id);
const delay = ms => new Promise(r=>setTimeout(r,ms));
const qs = v => new URLSearchParams(v).toString();
const state = {view:'home', meta:null,selected:null,before:null,after:null, editMode:false,allCols:false,
  table:{page:1,size:50,search:'',filter_col:'',filter_val:'',sort:'',direction:'asc'},
  clients:{page:1,size:50,search:'',movement:'all'}, draft:{changes:{},deletions:new Set(),additions:[]},
  slice:{dimension:'Сегмент',metric:'Резерв факт',agg:'Сумма'}};
function toast(message, error=false){const d=document.createElement('div');d.className='toast-msg'+(error?' toast-error':'');d.textContent=message;el('toast').appendChild(d);setTimeout(()=>d.remove(),5500)}
async function api(path, options){
 const r=await fetch(path,{cache:'no-store',...options});let content;
 try{content=await r.json()}catch(e){throw Error('Сервер вернул не JSON (HTTP '+r.status+'). Проверь адрес и окно Python.')}
 if(!r.ok)throw Error(content.error || `HTTP ${r.status}`);
 return content;
}
async function post(path,obj){return api(path,{method:'POST',headers:{'Content-Type':'application/json','X-Portfolio-Token':token},body:JSON.stringify(obj)})}
async function sendFile(path,file){return api(path,{method:'POST',headers:{'X-Portfolio-Token':token},body:file})}
function link(path,args){return `${path}?${qs(args)}`}
function resetDraft(){state.draft={changes:{},deletions:new Set(),additions:[]}}
function draftCount(){return Object.keys(state.draft.changes).length+state.draft.deletions.size+state.draft.additions.length}
async function reloadMeta(){state.meta=await api('/api/meta');const list=state.meta.snapshots; if(!list.length){state.selected=null;state.before=null;state.after=null;return}
 if(!list.some(s=>s.id===state.selected))state.selected=state.meta.active_id || list[0].id;
 let dated=list.filter(s=>s.report_date).sort((a,b)=>a.report_date.localeCompare(b.report_date));
 if(!list.some(s=>s.id===state.before))state.before=(dated[0]||list[list.length-1]).id;
 if(!list.some(s=>s.id===state.after))state.after=(dated[dated.length-1]||list[0]).id;
 if(state.before===state.after && list.length>1){state.before=list[list.length-1].id;state.after=list[0].id}
}
function snapshotName(s){return `${s.report_date||'Дата не задана'} · ${s.title} (№${s.id})`}
function dateOptions(selected){return opts(state.meta.snapshots.map(s=>s.id),selected,id=>snapshotName(state.meta.snapshots.find(s=>s.id===id)))}
function head(title,desc,extra=''){return `<div class="page-header"><div><p class="eyebrow">ПОРТФЕЛЬ И РЕЗЕРВЫ</p><h1 class="page-title">${title}</h1><p class="subtitle">${desc}</p></div>${extra}</div>`}
function card(label,value,hint='',color='blue'){return `<div class="card accent-${color}"><div class="stat-label">${label}</div><div class="stat-value">${value}</div>${hint?`<div class="stat-hint">${hint}</div>`:''}</div>`}
function noData(label='Сначала загрузи портфель',text='Добавь Excel или CSV на вкладке «Портфели по датам».'){return `<div class="empty"><div class="empty-icon">▤</div><h2>${label}</h2><p class="muted">${text}</p><button class="btn btn-primary" id="emptyUpload">+ Загрузить Excel</button></div>`}
function attachEmpty(){el('emptyUpload')?.addEventListener('click',showUpload)}
function notifyError(e){console.error(e);toast(e.message || String(e),true)}
function barChart(data,key='Группа',value='Значение',signed=false){let max=Math.max(1,...data.map(r=>Math.abs(Number(r[value])||0)));
 return `<div class="bar-chart">${data.length?data.map(r=>{let v=Number(r[value])||0;return `<div class="bar-row"><span title="${esc(r[key])}" class="bar-label">${esc(r[key])}</span><div class="bar-track"><div class="bar-fill ${signed&&v<0?'down':''}" style="width:${Math.max(0,Math.abs(v)/max*100).toFixed(2)}%"></div></div><span class="bar-val ${signed?(v>0?'positive':v<0?'negative':''):''}">${signed&&v>0?'+':''}${fmt(v,1)}</span></div>`}).join(''):'<p class="muted">Данных пока нет</p>'}</div>`}
function makeTable(rows,columns,options={}){
 if(!rows.length)return '<div class="notice">По выбранным условиям записей не найдено.</div>';
 return `<div class="table-scroll"><table><thead><tr>${columns.map(c=>`<th ${options.sortable?`data-sort="${esc(c)}" title="Нажми для сортировки"`:''}>${esc(c)}${options.sortable&&state.table.sort===c?(state.table.direction==='asc'?' ▲':' ▼'):''}</th>`).join('')}${options.edit?'<th>Действие</th>':''}</tr></thead><tbody>${rows.map(r=>`<tr class="${options.edit&&state.draft.deletions.has(r._rowid)?'deleted-row':options.edit&&state.draft.changes[r._rowid]?'changed-row':''}">${columns.map(c=>{let v=options.edit&&state.draft.changes[r._rowid]&&Object.prototype.hasOwnProperty.call(state.draft.changes[r._rowid],c)?state.draft.changes[r._rowid][c]:r[c];let num=typeof v==='number';let delta=options.deltaCol===c&&num;let css=options.longCols?.includes(c)?'wide-cell':num?'num':'';let sign=delta?(v>0?'positive':v<0?'negative':''):'';return `<td class="${css} ${sign}" title="${esc(v)}">${num?(delta&&v>0?'+':'')+fmt(v,2):esc(v==null?'—':v)}</td>`}).join('')}${options.edit?`<td><button class="btn btn-small btn-subtle edit-row" data-row="${r._rowid}">Изменить</button></td>`:''}</tr>`).join('')}</tbody></table></div>`}
function pager(data,selector,callback){return `<div class="table-actions"><span class="muted text-sm">Показано ${data.total===0?'0':(data.page-1)*data.size+1}–${Math.min(data.page*data.size,data.total)} из ${data.total}</span><span class="row"><button class="btn btn-small" id="${selector}Prev" ${data.page<=1?'disabled':''}>← Назад</button><span class="muted text-sm">Страница ${data.page} / ${data.pages}</span><button class="btn btn-small" id="${selector}Next" ${data.page>=data.pages?'disabled':''}>Далее →</button></span></div>`}
function wirePager(name,data,callback){el(name+'Prev')?.addEventListener('click',()=>callback(data.page-1));el(name+'Next')?.addEventListener('click',()=>callback(data.page+1))}
function chooseSnapshot(){return `<div class="control" style="max-width:450px"><label>Отчётная дата / портфель</label><select id="activeSnapshot" class="input">${dateOptions(state.selected)}</select></div>`}
function bindSnapshot(){el('activeSnapshot')?.addEventListener('change',async e=>{if(draftCount()&&!confirm('Есть несохранённые правки. Сменить портфель и потерять черновик?')){e.target.value=state.selected;return}resetDraft();state.selected=Number(e.target.value);state.table.page=1;await render()})}
function viewGo(view){if(draftCount()&&view!=='portfolio'&&!confirm('Несохранённые изменения останутся в браузере до смены портфеля. Продолжить?'))return;
 state.view=view;for(const b of nav.querySelectorAll('button'))b.classList.toggle('selected',b.dataset.view===view);
 el('breadcrumbs').textContent='Рабочее пространство / '+({home:'Главная',snapshots:'Портфели по датам',portfolio:'Таблица и редактор',reserves:'Расходы на резервы',slices:'Срезы и аналитика',quality:'Качество данных'}[view]||'');
 render().catch(notifyError)}
async function render(){page.innerHTML='<div class="loading">Загрузка данных…</div>';try{
 if(state.view==='home')return renderHome();if(state.view==='snapshots')return renderSnapshots();
 if(state.view==='portfolio')return renderPortfolio();if(state.view==='reserves')return renderReserves();
 if(state.view==='slices')return renderSlices();if(state.view==='quality')return renderQuality();
 }catch(e){page.innerHTML=`<div class="errorbox">${esc(e.message)}</div>`;notifyError(e)}}
async function renderHome(){const list=state.meta.snapshots;
 if(!list.length){page.innerHTML=head('Главная','Управление кредитным портфелем и резервами')+noData();attachEmpty();return}
 let snap=list.find(s=>s.id===state.selected)||list[0];const overview=await api(link('/api/overview',{id:snap.id}));
 page.innerHTML=head('Обзор портфеля','Текущее состояние, отчётные даты и быстрые действия')+
 `<div class="hero card"><p class="eyebrow">АКТИВНЫЙ ПОРТФЕЛЬ</p><h1>${esc(snap.report_date||'Без даты')}</h1><div class="subtitle">${esc(snap.title)} · ${fmt(overview.rows,0)} строк · редакция ${snap.revision}</div><div class="hero-actions"><button class="btn" id="homeOpen">Открыть таблицу</button><button class="btn" id="homeCompare">Сравнить резервы</button></div></div>`+
 `<div class="grid grid-4 mt">${card('Задолженность',fmt(overview.debt,1),'тыс. BYN')}${card('Резерв факт',fmt(overview.reserve,1),'тыс. BYN','red')}${card('Просрочка',fmt(overview.overdue,1),'тыс. BYN','slate')}${card('Клиентов по УНП',fmt(overview.clients,0),`${overview.contracts} договоров`,'green')}</div>`+
 `<div class="grid grid-2 mt"><div class="card"><div class="card-title"><h3>Структура резервов по сегментам</h3><span class="tag">тыс. BYN</span></div>${barChart(overview.segments)}</div><div class="card"><div class="card-title"><h3>Зоны проблемности</h3><span class="tag">тыс. BYN</span></div>${barChart(overview.risk)}</div></div>`+
 `<h2 class="section-title mt">Три основных действия</h2><div class="steps"><div class="step"><div class="step-index">1</div><h3>Загрузи дату</h3><p>Фиксированные 55 столбцов, исходный файл хранится отдельно.</p><button class="btn btn-small" id="homeUpload">Загрузить</button></div><div class="step"><div class="step-index">2</div><h3>Проверь данные</h3><p>Редактирование строк, фильтры, сортировка и история редакций.</p><button class="btn btn-small" id="homeEdit">Редактор</button></div><div class="step"><div class="step-index">3</div><h3>Сравни резервы</h3><p>Факторы, договоры, УНП и комментарии по существенным изменениям.</p><button class="btn btn-small" id="homeReserve">Сравнить</button></div></div>`;
 el('homeOpen').onclick=()=>viewGo('portfolio');el('homeCompare').onclick=()=>viewGo('reserves');el('homeUpload').onclick=showUpload;el('homeEdit').onclick=()=>viewGo('portfolio');el('homeReserve').onclick=()=>viewGo('reserves');}
async function renderSnapshots(){const snaps=state.meta.snapshots;
 page.innerHTML=head('Портфели по датам','Каждая дата — отдельный снимок. Редактирование создаёт новую редакцию без потери оригинала.',`<button class="btn btn-primary" id="newUpload">+ Загрузить портфель</button>`)+
 (snaps.length?`<div class="card"><div class="card-title"><h3>Сохранённые портфели</h3><span class="pill">${snaps.length} дат(ы)</span></div><div class="table-scroll"><table><thead><tr><th>Дата</th><th>Название</th><th>Строк</th><th>Резерв, тыс. BYN</th><th>Редакция</th><th>Действия</th></tr></thead><tbody>${snaps.map(s=>`<tr><td><b>${esc(s.report_date||'Не назначена')}</b></td><td>${esc(s.title)}</td><td class="num">${fmt(s.rows_count,0)}</td><td class="num">${fmt(s.reserve_total)}</td><td><span class="pill">№ ${s.revision}</span></td><td><div class="row"><button class="btn btn-small snap-open" data-id="${s.id}">Открыть</button><button class="btn btn-small snap-revisions" data-id="${s.id}">История</button>${!s.report_date?`<button class="btn btn-small snap-date" data-id="${s.id}">Назначить дату</button>`:''}</div></td></tr>`).join('')}</tbody></table></div></div>`:noData())+
 `<div class="notice mt">Исходные Excel-файлы и все редакции хранятся в <b>portfolio_storage</b>. Не удаляй эту папку при обновлении приложения. На каждую отчётную дату сохраняется один портфель.</div>`;
 el('newUpload')?.addEventListener('click',showUpload);attachEmpty();
 for(let b of page.querySelectorAll('.snap-open'))b.onclick=async()=>{if(draftCount()&&!confirm('Потерять несохранённые правки?'))return;resetDraft();state.selected=Number(b.dataset.id);viewGo('portfolio')};
 for(let b of page.querySelectorAll('.snap-revisions'))b.onclick=()=>showRevisions(Number(b.dataset.id));
 for(let b of page.querySelectorAll('.snap-date'))b.onclick=()=>showDate(Number(b.dataset.id));}
function modal(title,body,actions=''){modalRoot.innerHTML=`<div class="modal-cover"><div class="modal"><div class="modal-head"><h2>${esc(title)}</h2><button class="btn btn-small" id="closeModal">✕</button></div><div class="modal-body">${body}</div><div class="modal-foot">${actions||'<button class="btn" id="cancelModal">Закрыть</button>'}</div></div></div>`;
 el('closeModal').onclick=closeModal;el('cancelModal')?.addEventListener('click',closeModal);
 modalRoot.querySelector('.modal-cover').addEventListener('click',e=>{if(e.target.classList.contains('modal-cover'))closeModal()})}
function closeModal(){modalRoot.innerHTML=''}
function field(label,id,type='text',value='',extra=''){return `<div class="control"><label for="${id}">${label}</label><input id="${id}" class="input" type="${type}" value="${esc(value)}" ${extra}/></div>`}
function showUpload(){modal('Загрузить портфель',`<div class="form-grid">${field('Отчётная дата','upDate','date',new Date().toISOString().slice(0,10),'required')}${field('Название','upTitle','text','Кредитный портфель')}${field('Excel (.xlsx, .xlsm) или CSV','upFile','file','','accept=".xlsx,.xlsm,.csv"')}
 <div class="control"><label>Лист Excel</label><select id="upSheet" class="input"><option value="">Первый лист</option></select></div>${field('Номер строки заголовка','upHeader','number',1,'min="1" max="100"')}<div class="control"><label>Комментарий (необязательно)</label><input id="upNote" class="input" placeholder="Например: конец месяца"/></div></div><div class="notice mt">Проверяется точное совпадение всех 55 столбцов. Форматы .xls и .numbers напрямую не поддерживаются. Ничего не передаётся во внешние сервисы.</div>`,`<button class="btn" id="cancelModal">Отмена</button><button class="btn btn-primary" id="submitUpload">Загрузить и сохранить</button>`);
 el('cancelModal').onclick=closeModal;
 el('upFile').onchange=async()=>{let file=el('upFile').files[0];if(!file)return;el('upSheet').innerHTML='<option>Получаю листы…</option>';try{let r=await sendFile(link('/api/sheets',{filename:file.name}),file);el('upSheet').innerHTML=opts(r.sheets,r.sheets[0]);}catch(e){el('upSheet').innerHTML='<option value="">Первый лист</option>';notifyError(e)}};
 el('submitUpload').onclick=async()=>{const file=el('upFile').files[0];if(!file){toast('Выбери Excel или CSV',true);return}if(!el('upDate').value){toast('Укажи отчётную дату',true);return}let b=el('submitUpload');b.disabled=true;b.textContent='Загружаю…';try{const res=await sendFile(link('/api/upload',{filename:file.name,date:el('upDate').value,title:el('upTitle').value||`Портфель ${el('upDate').value}`,note:el('upNote').value,header_row:el('upHeader').value,sheet:el('upSheet').value}),file);closeModal();resetDraft();await reloadMeta();state.selected=res.id;toast('Портфель загружен и сохранён');viewGo('portfolio')}catch(e){notifyError(e);b.disabled=false;b.textContent='Загрузить и сохранить'}}}
async function showDate(sid){modal('Назначить отчётную дату',field('Дата портфеля','assignDate','date',''),`<button class="btn" id="cancelModal">Отмена</button><button class="btn btn-primary" id="saveDate">Сохранить</button>`);el('cancelModal').onclick=closeModal;el('saveDate').onclick=async()=>{try{await post('/api/date',{id:sid,date:el('assignDate').value});closeModal();await reloadMeta();await render()}catch(e){notifyError(e)}}}
async function showRevisions(sid){try{const data=await api(link('/api/revisions',{id:sid}));const history=[...data.history].reverse();modal('История изменений',`<div class="notice">Исходный снимок неизменяем. Возврат к ранней редакции создаёт следующую редакцию, ничего не удаляя.</div><div class="mt">${history.map(h=>`<div class="revision-item"><div><b>Редакция ${h.revision}</b> ${h.revision===data.current?'<span class="pill pill-green">Текущая</span>':''}<div class="muted text-sm">${esc(h.created_at)} · ${esc(h.note)} · ${fmt(h.rows_count,0)} строк</div></div>${h.revision<data.current?`<button class="btn btn-small rev-restore" data-rev="${h.revision}">Восстановить</button>`:''}</div>`).join('')}</div>`);
 for(let b of modalRoot.querySelectorAll('.rev-restore'))b.onclick=async()=>{if(!confirm('Восстановить редакцию '+b.dataset.rev+' как новую текущую?'))return;try{await post('/api/restore',{id:sid,target_revision:Number(b.dataset.rev)});closeModal();resetDraft();await reloadMeta();await render();toast('Редакция восстановлена')}catch(e){notifyError(e)}}}catch(e){notifyError(e)}}
async function renderPortfolio(){if(!state.selected){page.innerHTML=head('Таблица портфеля','')+noData();attachEmpty();return}
 const t=state.table;
 const req=Object.assign({id:state.selected},t);
 const data=await api(link('/api/portfolio',req));
 let cols=state.allCols?state.meta.columns:state.meta.primary;
 page.innerHTML=head('Таблица и редактор','Просмотр, фильтрация, сортировка и исправление портфеля непосредственно в браузере',`<div class="row"><button class="btn" id="btnHistory">История редакций</button><button class="btn btn-primary" id="btnSave" ${draftCount()?'':'disabled'}>Сохранить изменения (${draftCount()})</button></div>`)+
 `<div class="card"><div class="filters">${chooseSnapshot()}<div class="control" style="max-width:300px"><label>Поиск по УНП, клиенту и договору</label><input class="input" id="tblSearch" placeholder="Введите название или номер" value="${esc(t.search)}"/></div><div class="control" style="max-width:230px"><label>Фильтр по столбцу</label><select id="filterCol">${opts(['','Сегмент','Зона проблемности','ГР','НИ','ПФН','НВВ','Код валюты'],t.filter_col,v=>v||'Все столбцы')}</select></div><div class="control" style="max-width:170px"><label>Значение фильтра</label><input class="input" id="filterVal" value="${esc(t.filter_val)}" placeholder="Точное значение"/></div><button class="btn" id="filterApply">Применить</button></div>
 <div class="row wrap space"><div class="row wrap"><span class="pill">Строк: ${fmt(data.total,0)}</span><span class="pill">УНП: ${fmt(data.unique_unp,0)}</span><span class="pill">Резерв: ${fmt(data.reserve)} тыс. BYN</span><span class="pill">Редакция ${data.revision}</span></div><div class="row wrap"><label class="row muted text-sm"><input type="checkbox" id="allCols" ${state.allCols?'checked':''}/> Все 55 столбцов</label><label class="row muted text-sm"><input type="checkbox" id="editToggle" ${state.editMode?'checked':''}/> Режим редактирования</label><button class="btn btn-small" id="downloadPort">↓ XLSX</button><button class="btn btn-small" id="addRow">+ Строка</button></div></div><div class="notice ${draftCount()?'warn':''} mt" id="draftHint">${draftCount()?`В черновике ${draftCount()} изменений. Они ещё НЕ сохранены. Сохранение создаст новую редакцию.`:'Изменения оригинала не затрагивают. Отредактируй строку и нажми «Сохранить изменения».'}</div><div class="mt" id="tableHere"></div></div>`;
 bindSnapshot();
 el('tblSearch').onkeydown=e=>{if(e.key==='Enter')el('filterApply').click()};
 el('filterApply').onclick=()=>{t.search=el('tblSearch').value.trim();t.filter_col=el('filterCol').value;t.filter_val=el('filterVal').value.trim();t.page=1;renderPortfolio().catch(notifyError)};
 el('allCols').onchange=e=>{state.allCols=e.target.checked;renderPortfolio().catch(notifyError)};
 el('editToggle').onchange=e=>{state.editMode=e.target.checked;renderPortfolio().catch(notifyError)};
 el('btnSave').onclick=saveDraft;el('btnHistory').onclick=()=>showRevisions(state.selected);
 el('addRow').onclick=()=>showRowEditor(null);
 el('downloadPort').onclick=()=>window.location.assign(link('/api/export',{kind:'portfolio',id:state.selected,format:'xlsx'}));
 const draw=()=>{el('tableHere').innerHTML=makeTable(data.rows,cols,{edit:state.editMode,sortable:true})+pager(data,'tbl');
 for(let b of el('tableHere').querySelectorAll('.edit-row'))b.onclick=()=>showRowEditor(data.rows.find(r=>r._rowid===Number(b.dataset.row)));
 for(let h of el('tableHere').querySelectorAll('th[data-sort]'))h.onclick=()=>{let col=h.dataset.sort;t.direction=t.sort===col&&t.direction==='asc'?'desc':'asc';t.sort=col;t.page=1;renderPortfolio().catch(notifyError)};
 wirePager('tbl',data,n=>{t.page=n;renderPortfolio().catch(notifyError)})};draw();}
function showRowEditor(row){const isNew=!row;const rid=isNew?null:row._rowid;
 const present=row?{...row,...(state.draft.changes[rid]||{})}:Object.fromEntries(state.meta.columns.map(c=>[c,'']));
 modal(isNew?'Добавить строку':'Редактировать строку '+(rid+1),`<p class="muted text-sm">Поля с числовыми значениями вводи в тыс. BYN. НИ, ПФН и НВВ: 1 / 0 / пусто. Изменения сначала попадают в черновик.</p><div class="field-grid">${state.meta.columns.map((c,i)=>`<div class="control"><label for="cell${i}">${esc(c)}</label><input class="input" data-col="${esc(c)}" id="cell${i}" value="${esc(present[c])}"/></div>`).join('')}</div>`,`<button class="btn" id="cancelModal">Отмена</button>${!isNew?'<button class="btn btn-danger" id="deleteRow">Удалить строку</button>':''}<button class="btn btn-primary" id="keepRow">В черновик</button>`);
 el('cancelModal').onclick=closeModal;
 el('keepRow').onclick=()=>{const out={};for(let input of modalRoot.querySelectorAll('[data-col]')){let old=present[input.dataset.col];if(isNew){if(input.value.trim())out[input.dataset.col]=input.value.trim()}else if(String(input.value).trim()!==String(old==null?'':old).trim()){out[input.dataset.col]=input.value.trim()}}
 if(isNew){if(!out['УНП']||!out['Номер договора'])return toast('Для новой строки укажи УНП и номер договора',true);state.draft.additions.push(out)}
 else {state.draft.changes[rid]={...(state.draft.changes[rid]||{}),...out};if(!Object.keys(state.draft.changes[rid]).length)delete state.draft.changes[rid]}
 closeModal();toast('Изменения добавлены в черновик');renderPortfolio().catch(notifyError)};
 el('deleteRow')?.addEventListener('click',()=>{if(!confirm('Пометить строку для удаления при сохранении?'))return;state.draft.deletions.add(rid);delete state.draft.changes[rid];closeModal();renderPortfolio().catch(notifyError)})}
async function saveDraft(){if(!draftCount())return toast('Черновик пуст');let note=prompt('Комментарий к новой редакции (необязательно):','Исправление данных портфеля');if(note===null)return;
 try{const snap=state.meta.snapshots.find(s=>s.id===state.selected);const r=await post('/api/save',{id:state.selected,revision:snap.revision,changes:state.draft.changes,deletions:[...state.draft.deletions],additions:state.draft.additions,note});resetDraft();await reloadMeta();toast('Сохранена редакция №'+r.revision);await renderPortfolio()}catch(e){notifyError(e)}}
async function renderReserves(){if(state.meta.snapshots.length<2){page.innerHTML=head('Расходы на резервы','Сравнение двух дат на уровне договоров и УНП')+noData('Нужно минимум две даты','Загрузи портфель на начало и на конец периода.');attachEmpty();return}
 page.innerHTML=head('Расходы на резервы','Поклиентное изменение резерва с комментариями и факторным мостом')+`<div class="card"><div class="filters"><div class="control"><label>Дата на начало</label><select id="beforeDate" class="input">${dateOptions(state.before)}</select></div><div class="control"><label>Дата на конец</label><select id="afterDate" class="input">${dateOptions(state.after)}</select></div><button class="btn btn-primary" id="calcReserve">Рассчитать</button></div><div class="notice">В список существенных попадают УНП с <b>Δ резерва ≤ −100</b> или <b>≥ +100</b> тыс. BYN, включая границы. Остальные клиенты суммируются отдельно.</div></div><div id="reserveContents" class="mt"></div>`;
 el('calcReserve').onclick=()=>{state.before=Number(el('beforeDate').value);state.after=Number(el('afterDate').value);state.clients.page=1;runComparison().catch(notifyError)};
 await runComparison();}
async function runComparison(){if(state.view!=='reserves')return;
 let holder=el('reserveContents');if(!holder)return;holder.innerHTML='<div class="loading">Сопоставление договоров, расчёт резервов и комментариев…</div>';
 try{let before=state.before,after=state.after;if(before===after){holder.innerHTML='<div class="notice warn">Выбери две разные даты.</div>';return}
 let d=await api(link('/api/compare',{before,after}));
 const check=Math.abs(d.balance_error)+Math.abs(d.material_balance_error);
 holder.innerHTML=`<div class="grid grid-4">${card('Резерв на начало',fmt(d.initial_reserve,2),'тыс. BYN')}${card('Резерв на конец',fmt(d.final_reserve,2),'тыс. BYN','slate')}${card('Изменение',`${d.delta>0?'+':''}${fmt(d.delta,2)}`,'тыс. BYN',d.delta>=0?'red':'green')}${card('Существенные УНП',fmt(d.material_count,0),'|Δ| ≥ 100 тыс. BYN','blue')}</div>`+
 `<div class="grid grid-3 mt">${card('Сумма существенных',`${d.material_delta>0?'+':''}${fmt(d.material_delta,2)}`,'тыс. BYN','red')}${card('Остальные клиенты',fmt(d.other_count,0),`Совокупное Δ: ${fmt(d.other_delta,2)} тыс. BYN`,'slate')}${card('Без сопоставления',fmt(d.unmatched_delta,2),'УНП или номер договора отсутствует','slate')}</div>`+
 `<div class="notice ${check>0.01?'warn':''} mt">Сверка: существенные ${fmt(d.material_delta,2)} + остальные ${fmt(d.other_delta,2)} + несопоставленные ${fmt(d.unmatched_delta,2)} = ${fmt(d.delta,2)} тыс. BYN. Разница: ${fmt(check,6)}.</div>`+
 `<div class="card mt"><div class="card-title"><h3>Существенные клиенты с комментариями</h3><div class="row"><button class="btn btn-small" id="exportMaterial">↓ Excel</button><button class="btn btn-small" id="exportContracts">↓ Договоры CSV</button></div></div><div class="filters"><div class="control"><label>Поиск по УНП или клиенту</label><input class="input" id="clientSearch" value="${esc(state.clients.search)}" placeholder="Введите УНП / название"/></div><div class="control" style="max-width:210px"><label>Направление изменения</label><select id="clientMove"><option value="all">Все</option><option value="up" ${state.clients.movement==='up'?'selected':''}>Рост резервов</option><option value="down" ${state.clients.movement==='down'?'selected':''}>Снижение резервов</option></select></div><button class="btn" id="clientApply">Применить</button></div><div id="clientsTable"></div></div>`+
 `<div class="grid grid-2 mt"><div class="card"><div class="card-title"><h3>Факторный мост</h3><button class="btn btn-small" id="exportFactors">↓ CSV</button></div>${barChart(d.factors,'Фактор','Изменение',true)}<p class="help">Вклад факторов без повторного счёта. Совместные изменения учитываются отдельной категорией.</p></div><div class="card"><div class="card-title"><h3>Изменение резервов по сегментам</h3></div>${barChart(d.segments,'Сегмент','Δ резерва',true)}</div></div>`+
 `<div class="card mt"><h3>Как интерпретировать расходы</h3><p class="muted">«Расход на резервы» здесь означает изменение остатка «Резерв факт» между двумя датами, а не бухгалтерские проводки. Анализ выполняется по договорам (УНП + номер договора), затем агрегируется по клиенту. Учитываются новые/выбывшие договоры, погашения, НИ, ПФН, НВВ, реструктуризация, обеспеченность, просрочка и другие изменения. Комментарии описывают наблюдаемые события; они не доказывают бухгалтерскую причинность.</p><div class="row wrap"><button class="btn btn-small" id="exportClients">Скачать всех клиентов</button><button class="btn btn-small" id="exportOriginal">Выбрать другую пару дат</button></div></div>`;
 el('exportMaterial').onclick=()=>window.location.assign(link('/api/export',{kind:'material',before,after,format:'xlsx'}));
 el('exportContracts').onclick=()=>window.location.assign(link('/api/export',{kind:'contracts',before,after,format:'csv'}));
 el('exportFactors').onclick=()=>window.location.assign(link('/api/export',{kind:'factors',before,after,format:'csv'}));
 el('exportClients').onclick=()=>window.location.assign(link('/api/export',{kind:'all_clients',before,after,format:'xlsx'}));
 el('exportOriginal').onclick=()=>{el('beforeDate').focus();window.scrollTo({top:0,behavior:'smooth'})};
 el('clientSearch').onkeydown=e=>{if(e.key==='Enter')el('clientApply').click()};
 el('clientApply').onclick=()=>{state.clients.search=el('clientSearch').value.trim();state.clients.movement=el('clientMove').value;state.clients.page=1;loadMaterial().catch(notifyError)};
 await loadMaterial();
 }catch(e){holder.innerHTML=`<div class="errorbox">${esc(e.message)}</div>`;notifyError(e)}}
async function loadMaterial(){const q={before:state.before,after:state.after,...state.clients};const data=await api(link('/api/compare/clients',q));const columns=['УНП','Клиент','Резерв — было','Резерв — стало','Δ резерва','Основные факторы','Комментарий'];
 el('clientsTable').innerHTML=makeTable(data.rows,columns,{deltaCol:'Δ резерва',longCols:['Основные факторы','Комментарий']})+pager(data,'clients')+
 (data.rows.length?'<p class="help">Нажми на строку клиента для поконтрактной детализации.</p>':'');
 for(let tr of el('clientsTable').querySelectorAll('tbody tr'))tr.style.cursor='pointer';
 el('clientsTable').querySelectorAll('tbody tr').forEach((tr,i)=>{tr.addEventListener('click',()=>showClient(data.rows[i]['УНП']))});
 wirePager('clients',data,n=>{state.clients.page=n;loadMaterial().catch(notifyError)})}
async function showClient(unp){try{const data=await api(link('/api/compare/client',{before:state.before,after:state.after,unp}));const important=['УНП','Номер договора','Статус','Δ резерва','Задолженность — было','Задолженность — стало','Резерв — было','Резерв — стало','Сигналы','НИ (было)','НИ (стало)','ПФН (было)','ПФН (стало)','НВВ (было)','НВВ (стало)','Рестра (стало)','Обеспеченность (было)','Обеспеченность (стало)','Просрочка — было','Просрочка — стало'];
 modal('Договоры клиента '+unp,`<p class="muted">Всего договоров: ${data.total}. Показаны первые 300 по абсолютному изменению резерва.</p>${makeTable(data.contracts,important.filter(c=>data.columns.includes(c)),{deltaCol:'Δ резерва'})}`)}catch(e){notifyError(e)}}
async function renderSlices(){if(!state.selected){page.innerHTML=noData();attachEmpty();return}
 page.innerHTML=head('Срезы и аналитика','Построй распределение сумм и количества по любому столбцу портфеля')+`<div class="card"><div class="filters">${chooseSnapshot()}<div class="control"><label>Группировать по</label><select id="sliceDim">${opts(state.meta.columns,state.slice.dimension)}</select></div><div class="control"><label>Показатель</label><select id="sliceMetric">${opts(state.meta.numeric,state.slice.metric)}</select></div><div class="control"><label>Агрегация</label><select id="sliceAgg">${opts(['Сумма','Среднее','Медиана','Количество','Минимум','Максимум'],state.slice.agg)}</select></div><button class="btn btn-primary" id="sliceGo">Показать</button></div><div id="sliceResult"></div></div>`;
 bindSnapshot();el('sliceGo').onclick=()=>{state.slice={dimension:el('sliceDim').value,metric:el('sliceMetric').value,agg:el('sliceAgg').value};loadSlice().catch(notifyError)};
 await loadSlice()}
async function loadSlice(){const data=await api(link('/api/slices',{id:state.selected,...state.slice}));el('sliceResult').innerHTML=`<div class="grid grid-2 mt"><div><h3 class="section-title">Распределение</h3>${barChart(data.rows)}</div><div><h3 class="section-title">Сводная таблица</h3>${makeTable(data.rows,['Группа','Значение'])}</div></div>`}
async function renderQuality(){if(!state.selected){page.innerHTML=noData();attachEmpty();return}
 let info=await api(link('/api/quality',{id:state.selected}));let columns=info.rows.length?Object.keys(info.rows[0]):[];
 page.innerHTML=head('Качество данных','Проверка заполненности полей, пропусков и структуры портфеля')+`<div class="card"><div class="filters">${chooseSnapshot()}</div><div class="notice">Импорт выполняется только при точном совпадении 55 наименований столбцов. Пропуски УНП и номера договора при сравнении учитываются отдельно, чтобы не создавать ложных совпадений.</div><h3 class="mt">Статистика полей</h3>${makeTable(info.rows,columns)}</div>`;bindSnapshot()}
nav.addEventListener('click',e=>{let b=e.target.closest('button[data-view]');if(b)viewGo(b.dataset.view)});
el('quickUpload').addEventListener('click',showUpload);
(async()=>{try{await reloadMeta();viewGo('home')}catch(e){page.innerHTML=`<div class="errorbox">Ошибка подключения: ${esc(e.message)}. Проверь, что открыт адрес, показанный сервером.</div>`;notifyError(e)}})();
