"""Editable dated portfolios with immutable, auditable edit revisions.

Original PortfolioStore snapshots are NEVER overwritten; each browser save adds
an independent CSV revision linked to a reporting date and records an audit row.
"""
from __future__ import annotations
from datetime import datetime, timezone
from hashlib import sha256
from io import BytesIO
from pathlib import Path
import os
import tempfile

import pandas as pd

from portfolio_core import load_fixed_portfolio, to_numeric_flexible
from portfolio_schema import EXPECTED_COLUMNS, NUMERIC_COLUMNS, DATE_COLUMNS
from portfolio_store import PortfolioStore


class RevisionConflict(Exception):
    pass


class WebStore(PortfolioStore):
    def __init__(self, root):
        super().__init__(root)
        with self._connect() as conn:
            conn.executescript('''
                CREATE TABLE IF NOT EXISTS web_revisions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    snapshot_id INTEGER NOT NULL REFERENCES versions(id),
                    revision INTEGER NOT NULL,
                    created_at TEXT NOT NULL,
                    note TEXT NOT NULL DEFAULT '',
                    blob_name TEXT NOT NULL,
                    content_sha256 TEXT NOT NULL,
                    rows_count INTEGER NOT NULL,
                    debt_total REAL NOT NULL,
                    reserve_total REAL NOT NULL,
                    UNIQUE(snapshot_id, revision)
                );
            ''')

    def revision_info(self, snapshot_id):
        self.get_version(snapshot_id)
        with self._connect() as conn:
            row = conn.execute('''SELECT * FROM web_revisions
                WHERE snapshot_id=? ORDER BY revision DESC LIMIT 1''', (int(snapshot_id),)).fetchone()
        return dict(row) if row else None

    def current_revision(self, snapshot_id):
        info = self.revision_info(snapshot_id)
        return int(info['revision']) if info else 0

    def revision_history(self, snapshot_id):
        meta = self.get_version(snapshot_id)
        rows = [dict(revision=0, created_at=meta['created_at'],
                     note='Исходный загруженный файл', rows_count=meta['rows_count'],
                     reserve_total=meta['reserve_total'], debt_total=meta['debt_total'])]
        with self._connect() as conn:
            rows.extend(dict(row) for row in conn.execute('''SELECT revision, created_at, note,
                rows_count, reserve_total, debt_total FROM web_revisions
                WHERE snapshot_id=? ORDER BY revision''', (int(snapshot_id),)))
        return rows

    def load(self, version_id, revision=None):
        """Default to latest edited data; revision=0 restores original view."""
        sid = int(version_id)
        info = self.revision_info(sid)
        if revision is not None and int(revision) == 0:
            return super().load(sid)
        if revision is not None and (info is None or int(revision) != info['revision']):
            with self._connect() as conn:
                row = conn.execute('SELECT * FROM web_revisions WHERE snapshot_id=? AND revision=?',
                                   (sid, int(revision))).fetchone()
            if row is None:
                raise KeyError('Редакция не найдена')
            info = dict(row)
        if info is None:
            return super().load(sid)
        raw = (self.blobs / info['blob_name']).read_bytes()
        if sha256(raw).hexdigest() != info['content_sha256']:
            raise IOError('Нарушена целостность сохранённой редакции')
        return load_fixed_portfolio(raw, 'revision.csv', 'CSV', 1)

    def list_with_current(self):
        result = []
        for snap in self.list_versions():
            info = self.revision_info(snap['id'])
            snap['revision'] = info['revision'] if info else 0
            if info:
                snap['rows_count'] = info['rows_count']
                snap['debt_total'] = info['debt_total']
                snap['reserve_total'] = info['reserve_total']
            result.append(snap)
        return result

    @staticmethod
    def _validate_cell(col, val):
        if val is None:
            return pd.NA
        if isinstance(val, (dict, list)):
            raise ValueError(f'Недопустимый тип значения поля «{col}»')
        value = str(val).strip()
        if len(value) > 10000:
            raise ValueError('Слишком длинное значение ячейки')
        if not value:
            return pd.NA
        if col in NUMERIC_COLUMNS:
            num = to_numeric_flexible(pd.Series([value])).iloc[0]
            if pd.isna(num) or not pd.notna(num) or not float('-inf') < float(num) < float('inf'):
                raise ValueError(f'Числовое поле «{col}»: неверное значение «{value}»')
            return float(num)
        if col in ('НИ', 'ПФН', 'НВВ') and value not in ('0', '1'):
            raise ValueError(f'Поле «{col}» допускает только 0, 1 или пусто')
        if col in DATE_COLUMNS:
            parsed = pd.to_datetime(value, dayfirst=True, errors='coerce')
            if pd.isna(parsed):
                raise ValueError(f'Неверная дата в поле «{col}»: {value}')
            return parsed
        return value

    def commit(self, snapshot_id, expected_revision, changes=None, deletions=None,
               additions=None, note=''):
        sid = int(snapshot_id)
        expected_revision = int(expected_revision)
        changes = changes or {}
        deletions = deletions or []
        additions = additions or []
        if not changes and not deletions and not additions:
            raise ValueError('Нет изменений для сохранения')
        if len(changes) + len(deletions) + len(additions) > 20000:
            raise ValueError('Слишком много изменений за одно сохранение')
        if len(str(note)) > 1000:
            raise ValueError('Слишком длинный комментарий')
        if self.current_revision(sid) != expected_revision:
            raise RevisionConflict('Портфель изменился в другой вкладке. Обнови данные перед сохранением.')
        frame = self.load(sid)
        original_count = len(frame)
        # Row ids are ORIGINAL zero-based positional indexes of this revision.
        changed_index = set()
        for raw_idx, updates in changes.items():
            idx = int(raw_idx)
            if idx < 0 or idx >= original_count:
                raise ValueError('Неверный номер строки')
            if not isinstance(updates, dict):
                raise ValueError('Неправильный формат правок')
            for field, value in updates.items():
                if field not in EXPECTED_COLUMNS:
                    raise ValueError(f'Неизвестный столбец: {field}')
                frame.at[idx, field] = self._validate_cell(field, value)
            changed_index.add(idx)
        deleted_ids = set(int(v) for v in deletions)
        if any(v < 0 or v >= original_count for v in deleted_ids):
            raise ValueError('Неверный номер удаляемой строки')
        if any(v in deleted_ids for v in changed_index):
            raise ValueError('Нельзя одновременно удалить и редактировать одну строку')
        frame = frame.drop(index=list(deleted_ids)).reset_index(drop=True)
        added = []
        for row in additions:
            if not isinstance(row, dict) or any(k not in EXPECTED_COLUMNS for k in row):
                raise ValueError('Неправильная структура новой строки')
            normalized = {field: self._validate_cell(field, row.get(field)) for field in EXPECTED_COLUMNS}
            if pd.isna(normalized['УНП']) or pd.isna(normalized['Номер договора']):
                raise ValueError('Для новой строки обязательны УНП и номер договора')
            added.append(normalized)
        if added:
            frame = pd.concat([frame, pd.DataFrame(added, columns=EXPECTED_COLUMNS)], ignore_index=True)
        if frame.empty:
            raise ValueError('Нельзя сохранить пустой портфель')
        # CSV revision format is efficient for >100k records; all 55 headers retained.
        content = frame.loc[:, list(EXPECTED_COLUMNS)].to_csv(
            index=False, sep=';', encoding='utf-8', date_format='%Y-%m-%d',
            na_rep='', lineterminator='\n').encode('utf-8-sig')
        checked = load_fixed_portfolio(content, 'revision.csv', 'CSV', 1)
        if len(checked) != len(frame):
            raise ValueError('Проверка сохранённого файла не прошла')
        digest = sha256(content).hexdigest()
        filename = digest + '.csv'
        destination = self.blobs / filename
        if not destination.exists():
            fd, temp = tempfile.mkstemp(prefix='revision_', suffix='.tmp', dir=self.blobs)
            try:
                with os.fdopen(fd, 'wb') as f:
                    f.write(content)
                    f.flush()
                    os.fsync(f.fileno())
                os.replace(temp, destination)
            finally:
                if os.path.exists(temp):
                    os.unlink(temp)
        reserve = float(checked['Резерв факт'].sum())
        debt = float(checked['Задолженность, тыс BYN'].sum())
        with self._connect() as conn:
            conn.execute('BEGIN IMMEDIATE')
            latest = conn.execute('SELECT COALESCE(MAX(revision), 0) FROM web_revisions WHERE snapshot_id=?',
                                  (sid,)).fetchone()[0]
            if int(latest) != expected_revision:
                raise RevisionConflict('Конфликт редакций. Другой пользователь сохранил изменения.')
            revision = expected_revision + 1
            conn.execute('''INSERT INTO web_revisions(snapshot_id, revision, created_at, note,
                blob_name, content_sha256, rows_count, debt_total, reserve_total)
                VALUES(?,?,?,?,?,?,?,?,?)''',
                (sid, revision, datetime.now(timezone.utc).isoformat(timespec='seconds'),
                 str(note).strip(), filename, digest, len(checked), debt, reserve))
            conn.execute('''INSERT INTO audit(created_at, action, from_version, to_version, details)
                VALUES(?, 'browser_edit', ?, ?, ?)''',
                (datetime.now(timezone.utc).isoformat(timespec='seconds'), sid, sid,
                 f'Редакция {revision}: +{len(added)} / -{len(deleted_ids)} / изменено {len(changed_index)}; {note}'))
        return {'revision': revision, 'rows_count': len(checked), 'reserve_total': reserve,
                'debt_total': debt, 'changes': len(changed_index),
                'additions': len(added), 'deletions': len(deleted_ids)}

    def restore_revision(self, snapshot_id, expected_revision, target_revision, restored_frame=None):
        """Create a new latest revision equal to a historical revision; no history deletion."""
        sid, expected, target = int(snapshot_id), int(expected_revision), int(target_revision)
        if target < 0 or target >= expected:
            raise ValueError('Некорректная редакция для восстановления')
        self.get_version(sid)
        if target == 0:
            source = self.get_version(sid)
            blob, digest = source['blob_name'], source['content_sha256']
            rows, debt, reserve = source['rows_count'], source['debt_total'], source['reserve_total']
            # original may have old empty totals; calculate if so
            if debt is None or reserve is None:
                frame = super().load(sid)
                rows, debt, reserve = len(frame), float(frame['Задолженность, тыс BYN'].sum()), float(frame['Резерв факт'].sum())
        else:
            with self._connect() as conn:
                row = conn.execute('SELECT * FROM web_revisions WHERE snapshot_id=? AND revision=?',
                                   (sid, target)).fetchone()
            if row is None:
                raise ValueError('Историческая редакция не найдена')
            blob, digest = row['blob_name'], row['content_sha256']
            rows, debt, reserve = row['rows_count'], row['debt_total'], row['reserve_total']
        actual = (self.blobs / blob).read_bytes()
        if sha256(actual).hexdigest() != digest:
            raise IOError('Нарушена целостность исторической редакции')
        with self._connect() as conn:
            conn.execute('BEGIN IMMEDIATE')
            current = conn.execute('SELECT COALESCE(MAX(revision),0) FROM web_revisions WHERE snapshot_id=?',
                                   (sid,)).fetchone()[0]
            if int(current) != expected:
                raise RevisionConflict('Редакция изменилась. Обнови страницу.')
            rev = expected + 1
            conn.execute('''INSERT INTO web_revisions(snapshot_id,revision,created_at,note,
                blob_name,content_sha256,rows_count,debt_total,reserve_total) VALUES(?,?,?,?,?,?,?,?,?)''',
                (sid, rev, datetime.now(timezone.utc).isoformat(timespec='seconds'),
                 f'Восстановлена редакция {target}',blob,digest,rows,debt,reserve))
            conn.execute('''INSERT INTO audit(created_at,action,from_version,to_version,details)
                VALUES(?,'browser_restore',?,?,?)''',
                (datetime.now(timezone.utc).isoformat(timespec='seconds'),sid,sid,
                 f'Восстановлена редакция {target} как редакция {rev}'))
        return {'revision':rev,'rows_count':rows,'debt_total':debt,'reserve_total':reserve}
