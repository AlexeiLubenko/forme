"""Verify available packages and ability to bind local TCP port. No pip or installation."""
import importlib
import socket
import sys

REQUIRED = {'pandas': '2.0.3', 'numpy': '1.24.3', 'openpyxl': '3.0.10'}
OPTIONAL = {'plotly': '5.9.0'}

def main():
    print('Python executable:', sys.executable)
    print('Python version:', sys.version.split()[0])
    ok = sys.version_info[:2] == (3, 11)
    if not ok:
        print('WARNING: project was designed for Python 3.11.5.')
    print('\nDependency checks:')
    for name, reference in {**REQUIRED, **OPTIONAL}.items():
        try:
            module = importlib.import_module(name)
            version = getattr(module, '__version__', '?')
            print('  OK  {} {} (reference version: {})'.format(name, version, reference))
        except Exception as exc:
            print('  {}  {}: {}'.format('WARN' if name in OPTIONAL else 'ERROR', name, exc))
            if name in REQUIRED:
                ok = False
    print('  Streamlit: NOT REQUIRED')
    print('\nLocal-only TCP test:')
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.bind(('127.0.0.1', 0))
            print('  OK  Can bind 127.0.0.1 to an ephemeral port')
    except OSError as exc:
        print('  BLOCKED  {}'.format(exc))
        print('  To use this BROWSER application, bank IT must permit a loopback TCP listener.')
        print('  Do not disable corporate security yourself.')
        ok = False
    print('\n' + ('READY TO START' if ok else 'ENVIRONMENT REQUIRES ATTENTION'))
    return 0 if ok else 1

if __name__ == '__main__':
    sys.exit(main())
