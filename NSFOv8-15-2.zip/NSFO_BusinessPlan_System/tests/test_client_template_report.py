import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from openpyxl import load_workbook
import engine
from client_template_report import build_report

class ClientReport(unittest.TestCase):
    def test_categories_threshold_comments_and_inputs(self):
        with tempfile.TemporaryDirectory() as d, patch.object(engine,'DB',Path(d)/'db'):
            engine.initialize()
            pid=engine.create_project('Тест')
            dates=['2026-11-01','2026-12-01','2027-01-01']
            with engine.connect() as db:
                db.execute('update projects set periods=? where id=?',(json.dumps(dates),pid))
                for u,amount,zone,gr,rate in [('1',50000,'',1,0.5),('2',-100001,'',2,5),('3',100000,'',1,.5),('4',1300,'черная',2,20),('5',500,'',2,20)]:
                    pos=db.execute('insert into positions(project_id,unp,client,contract,operation,segment26,segment27,zone) values(?,?,?,?,?,?,?,?)',(pid,u,'Имя '+u,'Д'+u,'Кредит','КШБ','КШБ',zone)).lastrowid
                    for i,date in enumerate(dates):
                        db.execute('insert into position_periods(project_id,position_id,period,gr,rate,reserve,expenses,factors) values(?,?,?,?,?,?,?,?)',(pid,pos,date,str(gr),rate,1000000-amount*i,amount if i else 0,json.dumps({'debt_change':amount if i else 0})))
            book=load_workbook(next((engine.ROOT/'examples').glob('09*')))
            w=book.active
            for k,v in {'C5':'1','D5':'Имя 1','X5':.25,'AC5':.2,'Z277':.12,'Z283':.04,'Z291':.123,'Z292':.456}.items():w[k]=v
            inp=Path(d)/'in.xlsx';out=Path(d)/'out.xlsx'
            book.save(inp);build_report(pid,inp,out)
            w=load_workbook(out,data_only=True)
            s=w.active
            self.assertEqual(s['C6'].value,'2')
            self.assertIsNone(s['C7'].value)
            for cell,value in {'Z263':-.050001,'Z264':.1,'Z265':.0005,'Z266':.0013,'Z285':.211799,'AD5':.35,'AP5':.15,'Z291':.123,'Z292':.456}.items():
                self.assertAlmostEqual(s[cell].value,value,msg=cell)
            details=list(w['Комментарии РнР'].values)
            self.assertEqual(len(details),5)
            self.assertIn('ГР 1 → 1',details[1][-1])
            self.assertIn('задолженности',details[1][-1])

            self.assertAlmostEqual(details[1][-3],.30)
            # A second export updates the same detail sheet and preserves the client list.
            repeated=Path(d)/'repeat.xlsx'
            build_report(pid,out,repeated)
            again=load_workbook(repeated,data_only=True)
            self.assertEqual(again.sheetnames,w.sheetnames)
            self.assertAlmostEqual(again.active['AD5'].value,.35)
            self.assertEqual(list(again['Комментарии РнР'].values),details)
            again.close();w.close()

    def test_template_segments_override_source_for_every_period(self):
        with tempfile.TemporaryDirectory() as directory, patch.object(engine, 'DB', Path(directory)/'db'):
            engine.initialize()
            pid = engine.create_project('Сегменты из шаблона')
            dates = ['2026-11-01', '2026-12-01', '2027-01-01', '2027-04-01']
            records = [
                ('1', 200000, 'КБ', 'СБ'),
                ('1', 10000, 'СБ', 'КБ'),
                ('2', 300000, 'КШБ', 'ММБ'),
                ('3', 400000, 'ММБ', 'КШБ'),
                ('4', 500000, 'КШБ', 'КБ'),
                ('5', 600000, 'КБ', 'КБ'),
            ]
            with engine.connect() as db:
                db.execute('UPDATE projects SET periods=? WHERE id=?', (json.dumps(dates), pid))
                for index, (unp, amount, segment26, segment27) in enumerate(records):
                    position = db.execute('''INSERT INTO positions
                        (project_id,unp,client,contract,operation,segment26,segment27,zone)
                        VALUES (?,?,?,?,?,?,?,?)''',
                        (pid, unp, 'Клиент '+unp, 'Д'+str(index), 'Кредит', segment26, segment27, '')).lastrowid
                    for period in dates:
                        db.execute('''INSERT INTO position_periods
                            (project_id,position_id,period,gr,rate,reserve,expenses,factors)
                            VALUES (?,?,?,?,?,?,?,?)''',
                            (pid, position, period, '1', .5, 1000000, amount, '{}'))
            source = Path(directory)/'source.xlsx'
            output = Path(directory)/'report.xlsx'
            book = load_workbook(next((engine.ROOT/'examples').glob('09*')))
            sheet = book.active
            for row, unp in [(5, '1'), (81, '2'), (165, '3'), (230, '4')]:
                sheet.cell(row, 3, unp)
                sheet.cell(row, 4, 'Клиент '+unp)
            for col in (26, 28, 32):
                sheet.cell(230, col, .123)
                sheet.cell(277, col, .123)
                sheet.cell(283, col, .02)
            book.save(source)
            book.close()
            result = build_report(pid, source, output)
            self.assertEqual(result['added_clients'], 1)
            for iteration in range(2):
                report = load_workbook(output, data_only=True)
                sheet = report.active
                self.assertEqual([sheet.cell(r, 3).value for r in (5, 81, 165, 230)], ['1', '2', '3', '4'])
                self.assertEqual(sheet['C82'].value, '5')
                for col in (26, 28, 32):
                    for row, expected in [(262, .21), (267, .9), (272, .4), (230, .123), (277, .123), (285, 1.653)]:
                        self.assertAlmostEqual(sheet.cell(row, col).value, expected, msg=f'{row}, {col}')
                report.close()
                if iteration == 0:
                    source = output
                    output = Path(directory)/'repeated.xlsx'
                    build_report(pid, source, output)
